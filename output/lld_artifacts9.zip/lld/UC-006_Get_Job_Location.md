# UC-006 — Search Jobs By Location · 🔵 GET /job/location

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/location`
> **Actor:**   API Client
> **Entry:**   `JobController.getJobsByLocation()`

Searches for jobs by location. Throws EntityNotFoundException if no jobs are found in the specified location.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-006 |
| **Name** | Search Jobs By Location |
| **Trigger Type** | HTTP |
| **Trigger Detail** | GET /job/location |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.JobController` |
| **Entry Method** | `getJobsByLocation` |
| **Return Type** | List |

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

## 3. Input Contract

**HTTP Method:** GET

**Path:** `/job/location`

**Parameters:**

| Name | Type | Source | Annotations | Required |
|---|---|---|---|---|
| location | String | @RequestParam | @RequestParam("location") | Yes |

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobsByLocation()`

Extract location from request parameter and delegate to service layer

### Step 2 — [service] `JobServiceImpl.getJobsByLocation()` 🌍

Query repository for jobs in location and validate results

**External Call:** System.out.println (Debug logging of search results)

### Step 3 — [repository] `JobRepo.findByLocation()` 🗄️

**DB Operation:** SELECT

Search for jobs by location

⚠️ **Guard:** If no jobs exist in the specified location → throw `EntityNotFoundException`

## 5. Business Rules

- If no jobs exist in the specified location, throw an exception.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/location?location=...
    JobController->>JobServiceImpl: getJobsByLocation(location)
    JobServiceImpl->>JobRepo: findByLocation(location)
    alt No jobs found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Jobs found
        JobRepo-->>JobServiceImpl: List<Job>
        JobServiceImpl-->>JobController: List<Job>
        JobController-->>Actor: 200 OK
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: SELECT (JobRepo.findByLocation) |
| **Events Published** | none |
| **External Calls** | System.out.println (console_output) |
| **Exception Types** | EntityNotFoundException |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Jobs found in location | List of Job entities |
| 404 Not Found | No jobs found in location | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** List
