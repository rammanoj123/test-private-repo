# UC-003 — List Jobs · 🔵 GET /job

> **Trigger:** 🌐 HTTP — 🔵 GET `/job`
> **Actor:**   API Client
> **Entry:**   `JobController.getAllJobs()`

Retrieves all job postings from the database.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-003 |
| **Name** | List Jobs |
| **Trigger Type** | HTTP |
| **Trigger Detail** | GET /job |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.JobController` |
| **Entry Method** | `getAllJobs` |
| **Return Type** | List |

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

## 3. Input Contract

**HTTP Method:** GET

**Path:** `/job`

**Parameters:** None

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getAllJobs()`

Delegate to service layer to retrieve all jobs

### Step 2 — [service] `JobServiceImpl.getAllJobs()`

Call repository to retrieve all jobs

### Step 3 — [repository] `JobRepo.findAll()` 🗄️

**DB Operation:** SELECT

Retrieve all jobs from the database

## 5. Business Rules

(none)

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job
    JobController->>JobServiceImpl: getAllJobs()
    JobServiceImpl->>JobRepo: findAll()
    JobRepo-->>JobServiceImpl: List<Job>
    JobServiceImpl-->>JobController: List<Job>
    JobController-->>Actor: 200 OK
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: SELECT (JobRepo.findAll) |
| **Events Published** | none |
| **External Calls** | none |
| **Exception Types** | none |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Jobs retrieved successfully | List of Job entities |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** List
