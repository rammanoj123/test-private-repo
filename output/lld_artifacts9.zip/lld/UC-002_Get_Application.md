# UC-002 — List Applications · 🔵 GET /application

> **Trigger:** 🌐 HTTP — 🔵 GET `/application`
> **Actor:**   API Client
> **Entry:**   `ApplicationController.getAllApplications()`

Retrieves all job applications from the database.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-002 |
| **Name** | List Applications |
| **Trigger Type** | HTTP |
| **Trigger Detail** | GET /application |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.ApplicationController` |
| **Entry Method** | `getAllApplications` |
| **Return Type** | List |

## 2. Call Chain

`ApplicationController` → `ApplicationServiceImpl` → `ApplicationRepo`

## 3. Input Contract

**HTTP Method:** GET

**Path:** `/application`

**Parameters:** None

## 4. Implementation Steps

### Step 1 — [controller] `ApplicationController.getAllApplications()`

Delegate to service layer to retrieve all applications

### Step 2 — [service] `ApplicationServiceImpl.getAllApplications()`

Call repository to retrieve all applications

### Step 3 — [repository] `ApplicationRepo.findAll()` 🗄️

**DB Operation:** SELECT

Retrieve all applications from the database

## 5. Business Rules

(none)

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant ApplicationController
    participant ApplicationServiceImpl
    participant ApplicationRepo

    Actor->>ApplicationController: GET /application
    ApplicationController->>ApplicationServiceImpl: getAllApplications()
    ApplicationServiceImpl->>ApplicationRepo: findAll()
    ApplicationRepo-->>ApplicationServiceImpl: List<Application>
    ApplicationServiceImpl-->>ApplicationController: List<Application>
    ApplicationController-->>Actor: 200 OK
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: SELECT (ApplicationRepo.findAll) |
| **Events Published** | none |
| **External Calls** | none |
| **Exception Types** | none |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Applications retrieved successfully | List of Application entities |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** List
