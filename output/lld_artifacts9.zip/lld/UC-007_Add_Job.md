# UC-007 — Create Job · 🟢 POST /job

> **Trigger:** 🌐 HTTP — 🟢 POST `/job`
> **Actor:**   API Client
> **Entry:**   `JobController.addJob()`

Creates a new job posting and persists it to the database.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-007 |
| **Name** | Create Job |
| **Trigger Type** | HTTP |
| **Trigger Detail** | POST /job |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.JobController` |
| **Entry Method** | `addJob` |
| **Return Type** | Job |

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

## 3. Input Contract

**HTTP Method:** POST

**Path:** `/job`

**Parameters:**

| Name | Type | Source | Annotations | Required |
|---|---|---|---|---|
| job | Job | @RequestBody | @RequestBody | Yes |

## 4. Implementation Steps

### Step 1 — [controller] `JobController.addJob()`

Receive job from HTTP request body and delegate to service layer

### Step 2 — [service] `JobServiceImpl.addJob()`

Persist the job to the database

### Step 3 — [repository] `JobRepo.save()` 🗄️

**DB Operation:** INSERT

Persist the new job to the database

## 5. Business Rules

(none)

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: POST /job
    JobController->>JobServiceImpl: addJob(job)
    JobServiceImpl->>JobRepo: save(job)
    JobRepo-->>JobServiceImpl: Job
    JobServiceImpl-->>JobController: Job
    JobController-->>Actor: 200 OK
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: INSERT (JobRepo.save) |
| **Events Published** | none |
| **External Calls** | none |
| **Exception Types** | none |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Job created successfully | Job entity |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** Job

**Response Fields:**

| Field | Type | Annotations |
|---|---|---|
| id | Long | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| title | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| company | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| location | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| description | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| salaryRange | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| requiredSkills | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| applications | List | @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true), @JsonManagedReference |
| other | Job | @Override |
