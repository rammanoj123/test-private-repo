# UC-004 — Get Job By Id · 🔵 GET /job/{id}

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/{id}`
> **Actor:**   API Client
> **Entry:**   `JobController.getJobById()`

Retrieves a specific job by its ID. Throws EntityNotFoundException if the job does not exist.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-004 |
| **Name** | Get Job By Id |
| **Trigger Type** | HTTP |
| **Trigger Detail** | GET /job/{id} |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.JobController` |
| **Entry Method** | `getJobById` |
| **Return Type** | Job |

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

## 3. Input Contract

**HTTP Method:** GET

**Path:** `/job/{id}`

**Parameters:**

| Name | Type | Source | Annotations | Required |
|---|---|---|---|---|
| id | Long | @PathVariable | @PathVariable("id") | Yes |

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobById()`

Extract job ID from path variable and delegate to service layer

### Step 2 — [service] `JobServiceImpl.getJobById()`

Query repository for job by ID and validate existence

### Step 3 — [repository] `JobRepo.findById()` 🗄️

**DB Operation:** SELECT

Retrieve job by ID from database

⚠️ **Guard:** If no job exists with the given ID → throw `EntityNotFoundException`

## 5. Business Rules

- If no job exists with the given ID, throw an exception.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/{id}
    JobController->>JobServiceImpl: getJobById(id)
    JobServiceImpl->>JobRepo: findById(id)
    alt Job not found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Job found
        JobRepo-->>JobServiceImpl: Job
        JobServiceImpl-->>JobController: Job
        JobController-->>Actor: 200 OK
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: SELECT (JobRepo.findById) |
| **Events Published** | none |
| **External Calls** | none |
| **Exception Types** | EntityNotFoundException |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Job retrieved successfully | Job entity |
| 404 Not Found | Job not found | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** Job

**Response Fields:**

| Field | Type | Annotations |
|---|---|---|
| id | Long | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| title | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| company | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| location | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| description | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| salaryRange | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| requiredSkills | String | @Id, @GeneratedValue(strategy=GenerationType.IDENTITY) |
| applications | List | @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true), @JsonManagedReference |
| other | Job | @Override |
