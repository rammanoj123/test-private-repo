# UC-005 — Search Jobs By Title · 🔵 GET /job/search

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/search`
> **Actor:**   API Client
> **Entry:**   `JobController.getJobsBySearch()`

Searches for jobs by title matching the search term. Throws EntityNotFoundException if no matching jobs are found.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-005 |
| **Name** | Search Jobs By Title |
| **Trigger Type** | HTTP |
| **Trigger Detail** | GET /job/search |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.JobController` |
| **Entry Method** | `getJobsBySearch` |
| **Return Type** | List |

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

## 3. Input Contract

**HTTP Method:** GET

**Path:** `/job/search`

**Parameters:**

| Name | Type | Source | Annotations | Required |
|---|---|---|---|---|
| search | String | @RequestParam | @RequestParam("search") | Yes |

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobsBySearch()`

Extract search term from request parameter and delegate to service layer

### Step 2 — [service] `JobServiceImpl.getJobsBySearch()` 🌍

Query repository for jobs matching title and validate results

**External Call:** System.out.println (Debug logging of search results)

### Step 3 — [repository] `JobRepo.findByTitle()` 🗄️

**DB Operation:** SELECT

Search for jobs by title matching the search term

⚠️ **Guard:** If no jobs match the search term → throw `EntityNotFoundException`

## 5. Business Rules

- If no jobs match the search term, throw an exception.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/search?search=...
    JobController->>JobServiceImpl: getJobsBySearch(search)
    JobServiceImpl->>JobRepo: findByTitle(search)
    alt No jobs found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Jobs found
        JobRepo-->>JobServiceImpl: List<Job>
        JobServiceImpl-->>JobController: List<Job>
        JobController-->>Actor: 200 OK
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 1 operation: SELECT (JobRepo.findByTitle) |
| **Events Published** | none |
| **External Calls** | System.out.println (console_output) |
| **Exception Types** | EntityNotFoundException |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Jobs found matching search | List of Job entities |
| 404 Not Found | No jobs found matching search | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** List
