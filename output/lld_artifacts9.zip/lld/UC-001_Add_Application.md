# UC-001 — Create Application · 🟢 POST /application

> **Trigger:** 🌐 HTTP — 🟢 POST `/application`
> **Actor:**   API Client
> **Entry:**   `ApplicationController.addApplication()`

Creates a new job application after validating that the job exists and no duplicate application exists for the same person and job.

## 1. Use Case Overview

| Property | Value |
|---|---|
| **UC ID** | UC-001 |
| **Name** | Create Application |
| **Trigger Type** | HTTP |
| **Trigger Detail** | POST /application |
| **Actor** | API Client |
| **Entry Class** | `com.jobboard.controller.ApplicationController` |
| **Entry Method** | `addApplication` |
| **Return Type** | Application |

## 2. Call Chain

`ApplicationController` → `ApplicationServiceImpl` → `JobRepo` / `ApplicationRepo`

## 3. Input Contract

**HTTP Method:** POST

**Path:** `/application`

**Parameters:**

| Name | Type | Source | Annotations | Required |
|---|---|---|---|---|
| application | Application | @RequestBody | @RequestBody | Yes |

## 4. Implementation Steps

### Step 1 — [controller] `ApplicationController.addApplication()`

Receive application from HTTP request body and delegate to service layer

### Step 2 — [service] `ApplicationServiceImpl.addApplication()`

Validate job exists and check for duplicate application

### Step 3 — [repository] `JobRepo.findById()` 🗄️

**DB Operation:** SELECT

Query database to verify that the job exists

⚠️ **Guard:** If job does not exist → throw `EntityNotFoundException`

### Step 4 — [repository] `ApplicationRepo.findByfullNameAndEmailAndJobId()` 🗄️

**DB Operation:** SELECT

Check for duplicate application by same person for same job

⚠️ **Guard:** If application with same fullName, email, and jobId already exists → throw `ApplicationAlreadyExistsException`

### Step 5 — [repository] `ApplicationRepo.save()` 🗄️

**DB Operation:** INSERT

Persist the new application to the database

## 5. Business Rules

- If an application with the same fullName, email, and jobId already exists, reject the submission.
- If the job ID referenced by the application does not exist, reject the application.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor as API Client
    participant ApplicationController
    participant ApplicationServiceImpl
    participant JobRepo
    participant ApplicationRepo

    Actor->>ApplicationController: POST /application
    ApplicationController->>ApplicationServiceImpl: addApplication(application)
    ApplicationServiceImpl->>JobRepo: findById(jobId)
    alt Job not found
        JobRepo-->>ApplicationServiceImpl: throw EntityNotFoundException
        ApplicationServiceImpl-->>ApplicationController: exception
        ApplicationController-->>Actor: 404 Not Found
    else Job exists
        JobRepo-->>ApplicationServiceImpl: Job
        ApplicationServiceImpl->>ApplicationRepo: findByfullNameAndEmailAndJobId(...)
        alt Duplicate found
            ApplicationRepo-->>ApplicationServiceImpl: throw ApplicationAlreadyExistsException
            ApplicationServiceImpl-->>ApplicationController: exception
            ApplicationController-->>Actor: 409 Conflict
        else No duplicate
            ApplicationRepo-->>ApplicationServiceImpl: null
            ApplicationServiceImpl->>ApplicationRepo: save(application)
            ApplicationRepo-->>ApplicationServiceImpl: Application
            ApplicationServiceImpl-->>ApplicationController: Application
            ApplicationController-->>Actor: 200 OK
        end
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| **Transaction** | none |
| **Cache** | none |
| **Security** | none (public endpoint) |
| **DB Operations** | 3 operations: SELECT (JobRepo.findById), SELECT (ApplicationRepo.findByfullNameAndEmailAndJobId), INSERT (ApplicationRepo.save) |
| **Events Published** | none |
| **External Calls** | none |
| **Exception Types** | EntityNotFoundException, ApplicationAlreadyExistsException |

## 8. Output Contract

**Success Response:**

| HTTP Status | Condition | Body |
|---|---|---|
| 200 OK | Application created successfully | Application entity |
| 404 Not Found | Job not found | Error details |
| 409 Conflict | Application already exists | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

**Response Type:** Application

**Response Fields:**

| Field | Type | Annotations |
|---|---|---|
| id | Long | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY) |
| fullName | String | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY) |
| email | String | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY) |
| job | Job | @ManyToOne, @JoinColumn(name="job_id",nullable=false), @JsonBackReference |
