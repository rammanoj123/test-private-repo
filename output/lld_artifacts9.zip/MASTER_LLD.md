# LLD: Job-Board-Litee

> **8 Technical Use Cases** — enriched from source

---

## Table of Contents

### 🌐 HTTP Endpoints

- [UC-001 — Create Application](lld/UC-001_Add_Application.md)  
  `POST /application` · API Client · 6 steps · 2 rules

- [UC-002 — List Applications](lld/UC-002_Get_Application.md)  
  `GET /application` · API Client · 4 steps · 0 rules

- [UC-003 — List Jobs](lld/UC-003_Get_Job.md)  
  `GET /job` · API Client · 4 steps · 0 rules

- [UC-004 — Get Job By Id](lld/UC-004_Get_Job.md)  
  `GET /job/{id}` · API Client · 4 steps · 1 rule

- [UC-005 — Search Jobs By Title](lld/UC-005_Get_Job.md)  
  `GET /job/search` · API Client · 4 steps · 1 rule

- [UC-006 — Search Jobs By Location](lld/UC-006_Get_Job_Location.md)  
  `GET /job/location` · API Client · 4 steps · 1 rule

- [UC-007 — Create Job](lld/UC-007_Add_Job.md)  
  `POST /job` · API Client · 4 steps · 0 rules

### 🚀 Application Start

- [UC-008 — Start Job Board Litee Application](lld/UC-008_Start_Job_Board_Litee.md)  
  `main(String[] args) in JobBoardLiteeApplication` · JVM / OS Process · 2 steps · 0 rules

---

## Summary Statistics

| Metric | Value |
|---|---|
| Total Use Cases | 8 |
| With Implementation Steps | 8 |
| With Business Rules | 5 |
| With Transactions | 0 |
| With Auth | 0 |
| With DB Operations | 7 |
| Total Implementation Steps | 32 |
| Total Business Rules | 5 |
| Total DB Operations | 8 |

---

## Use Case Reference Cards

> Each card is a quick-reference summary. Click the **📄 Full LLD** link to open the complete design document.

### UC-001 — Create Application  ·  POST /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.addApplication()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-001_Add_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/application` |
| Call chain | `ApplicationController` → `ApplicationServiceImpl` → `JobRepo` → `ApplicationRepo` |
| Steps | 6 |
| Rules | 2 |
| DB Operations | 3 (2 SELECT, 1 INSERT) |

**Business Rules:**

1. If an application with the same fullName, email, and jobId already exists, reject the submission.
2. If the job ID referenced by the application does not exist, reject the application.

**Implementation steps:**

1. `[controller]` **ApplicationController**.addApplication() — Receive application from HTTP request body and delegate to service layer
2. `[service]` **ApplicationServiceImpl**.addApplication() — Validate job exists and check for duplicate application
3. `[repository]` **JobRepo**.findById() — Query database to verify that the job exists (⚠️ Guard: EntityNotFoundException)
4. `[repository]` **ApplicationRepo**.findByfullNameAndEmailAndJobId() — Check for duplicate application by same person for same job (⚠️ Guard: ApplicationAlreadyExistsException)
5. `[repository]` **ApplicationRepo**.save() — Persist the new application to the database

> 📄 [Open full LLD for UC-001](lld/UC-001_Add_Application.md)

---

### UC-002 — List Applications  ·  GET /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.getAllApplications()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-002_Get_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/application` |
| Call chain | `ApplicationController` → `ApplicationServiceImpl` → `ApplicationRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (SELECT) |

**Implementation steps:**

1. `[controller]` **ApplicationController**.getAllApplications() — Delegate to service layer to retrieve all applications
2. `[service]` **ApplicationServiceImpl**.getAllApplications() — Call repository to retrieve all applications
3. `[repository]` **ApplicationRepo**.findAll() — Retrieve all applications from the database

> 📄 [Open full LLD for UC-002](lld/UC-002_Get_Application.md)

---

### UC-003 — List Jobs  ·  GET /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getAllJobs()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-003_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (SELECT) |

**Implementation steps:**

1. `[controller]` **JobController**.getAllJobs() — Delegate to service layer to retrieve all jobs
2. `[service]` **JobServiceImpl**.getAllJobs() — Call repository to retrieve all jobs
3. `[repository]` **JobRepo**.findAll() — Retrieve all jobs from the database

> 📄 [Open full LLD for UC-003](lld/UC-003_Get_Job.md)

---

### UC-004 — Get Job By Id  ·  GET /job/{id}

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobById()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-004_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/{id}` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 1 |
| DB Operations | 1 (SELECT) |

**Business Rules:**

1. If no job exists with the given ID, throw an exception.

**Implementation steps:**

1. `[controller]` **JobController**.getJobById() — Extract job ID from path variable and delegate to service layer
2. `[service]` **JobServiceImpl**.getJobById() — Query repository for job by ID and validate existence
3. `[repository]` **JobRepo**.findById() — Retrieve job by ID from database (⚠️ Guard: EntityNotFoundException)

> 📄 [Open full LLD for UC-004](lld/UC-004_Get_Job.md)

---

### UC-005 — Search Jobs By Title  ·  GET /job/search

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsBySearch()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-005_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/search` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 1 |
| DB Operations | 1 (SELECT) |

**Business Rules:**

1. If no jobs match the search term, throw an exception.

**Implementation steps:**

1. `[controller]` **JobController**.getJobsBySearch() — Extract search term from request parameter and delegate to service layer
2. `[service]` **JobServiceImpl**.getJobsBySearch() — Query repository for jobs matching title and validate results
3. `[repository]` **JobRepo**.findByTitle() — Search for jobs by title matching the search term (⚠️ Guard: EntityNotFoundException)

> 📄 [Open full LLD for UC-005](lld/UC-005_Get_Job.md)

---

### UC-006 — Search Jobs By Location  ·  GET /job/location

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsByLocation()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-006_Get_Job_Location.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/location` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 1 |
| DB Operations | 1 (SELECT) |

**Business Rules:**

1. If no jobs exist in the specified location, throw an exception.

**Implementation steps:**

1. `[controller]` **JobController**.getJobsByLocation() — Extract location from request parameter and delegate to service layer
2. `[service]` **JobServiceImpl**.getJobsByLocation() — Query repository for jobs in location and validate results
3. `[repository]` **JobRepo**.findByLocation() — Search for jobs by location (⚠️ Guard: EntityNotFoundException)

> 📄 [Open full LLD for UC-006](lld/UC-006_Get_Job_Location.md)

---

### UC-007 — Create Job  ·  POST /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.addJob()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-007_Add_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/job` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (INSERT) |

**Implementation steps:**

1. `[controller]` **JobController**.addJob() — Receive job from HTTP request body and delegate to service layer
2. `[service]` **JobServiceImpl**.addJob() — Persist the job to the database
3. `[repository]` **JobRepo**.save() — Persist the new job to the database

> 📄 [Open full LLD for UC-007](lld/UC-007_Add_Job.md)

---

### UC-008 — Start Job Board Litee Application  ·  main(String[] args) in JobBoardLiteeApplication

> 🚀 **Application Start** &nbsp;|&nbsp; **Actor:** JVM / OS Process &nbsp;|&nbsp; **Entry:** `JobBoardLiteeApplication.main()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-008_Start_Job_Board_Litee.md)

| Property | Value |
|---|---|
| Trigger | 🚀 **Application Start** — `main(String[] args) in JobBoardLiteeApplication` |
| Call chain | `JobBoardLiteeApplication` → `SpringApplication` |
| Steps | 2 |
| Rules | 0 |
| DB Operations | 0 |

**Implementation steps:**

1. `[config]` **JobBoardLiteeApplication**.main() — Bootstrap the Spring Boot application

> 📄 [Open full LLD for UC-008](lld/UC-008_Start_Job_Board_Litee.md)

---
