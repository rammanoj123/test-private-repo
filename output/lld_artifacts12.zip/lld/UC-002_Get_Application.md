# UC-002 — List Applications · GET /application

> **Trigger:** 🌐 HTTP — 🔵 GET `/application`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.ApplicationController.getAllApplications()`

Retrieves all job applications from the database.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-002 |
| **Name** | List Applications |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `ApplicationController.getAllApplications()` |
| **Return Type** | `List<Application>` |

---

## 2. Call Chain

`ApplicationController` → `ApplicationServiceImpl` → `ApplicationRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `GET`  
**Path:** `/application`

### Parameters

None

---

## 4. Implementation Steps

### Step 1 — [controller] `ApplicationController.getAllApplications()`

Delegate to service to retrieve all applications

### Step 2 — [service] `ApplicationServiceImpl.getAllApplications()`

Query repository for all applications

### Step 3 — [repository] `ApplicationRepo.findAll()`

🗄️ **DB Operation:** SELECT

Retrieve all applications from database

---

## 5. Business Rules

None

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant ApplicationController
    participant ApplicationServiceImpl
    participant ApplicationRepo

    Actor->>ApplicationController: GET /application
    ApplicationController->>ApplicationServiceImpl: getAllApplications()
    ApplicationServiceImpl->>ApplicationRepo: findAll()
    ApplicationRepo-->>ApplicationServiceImpl: List<Application>
    ApplicationServiceImpl-->>ApplicationController: List<Application>
    ApplicationController-->>Actor: 200 OK
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | None |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Applications retrieved successfully | `List<Application>` |
| 500 Internal Server Error | Unexpected error | Error details |

---
