# UC-001 — Create Application · POST /application

> **Trigger:** 🌐 HTTP — 🟢 POST `/application`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.ApplicationController.addApplication()`

Creates a new job application after validating that the job exists and no duplicate application exists for the same fullName, email, and jobId combination.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-001 |
| **Name** | Create Application |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `ApplicationController.addApplication()` |
| **Return Type** | `Application` |

---

## 2. Call Chain

`ApplicationController` → `ApplicationServiceImpl` → `JobRepo` → `ApplicationRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `POST`  
**Path:** `/application`

### Parameters

| Parameter | Type | Source | Required | Description |
|-----------|------|--------|----------|-------------|
| `application` | `Application` | `@RequestBody` | Yes | Application data to create |

---

## 4. Implementation Steps

### Step 1 — [controller] `ApplicationController.addApplication()`

Receive Application from request body and delegate to service

### Step 2 — [service] `ApplicationServiceImpl.addApplication()`

Validate job exists and check for duplicate application

### Step 3 — [repository] `JobRepo.findById()`

⚠️ **Guard:** Throws `EntityNotFoundException` if job not found

🗄️ **DB Operation:** SELECT

Query database to verify job exists

### Step 4 — [repository] `ApplicationRepo.findByfullNameAndEmailAndJobId()`

⚠️ **Guard:** Throws `ApplicationAlreadyExistsException` if duplicate found

🗄️ **DB Operation:** SELECT

Check for duplicate application by fullName, email, and jobId

### Step 5 — [repository] `ApplicationRepo.save()`

🗄️ **DB Operation:** INSERT

Persist new application to database

---

## 5. Business Rules

- If job does not exist, then throw EntityNotFoundException
- If application already exists for same fullName, email, and jobId, then throw ApplicationAlreadyExistsException
- If job exists and no duplicate application, then save and return application

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant ApplicationController
    participant ApplicationServiceImpl
    participant JobRepo
    participant ApplicationRepo

    Actor->>ApplicationController: POST /application
    ApplicationController->>ApplicationServiceImpl: addApplication(application)
    ApplicationServiceImpl->>JobRepo: findById(jobId)
    alt Job not found
        JobRepo-->>ApplicationServiceImpl: throw EntityNotFoundException
        ApplicationServiceImpl-->>ApplicationController: exception
        ApplicationController-->>Actor: 404 Not Found
    else Job found
        JobRepo-->>ApplicationServiceImpl: Job
        ApplicationServiceImpl->>ApplicationRepo: findByfullNameAndEmailAndJobId(...)
        alt Duplicate exists
            ApplicationRepo-->>ApplicationServiceImpl: throw ApplicationAlreadyExistsException
            ApplicationServiceImpl-->>ApplicationController: exception
            ApplicationController-->>Actor: 409 Conflict
        else No duplicate
            ApplicationRepo-->>ApplicationServiceImpl: null
            ApplicationServiceImpl->>ApplicationRepo: save(application)
            ApplicationRepo-->>ApplicationServiceImpl: Application
            ApplicationServiceImpl-->>ApplicationController: Application
            ApplicationController-->>Actor: 200 OK
        end
    end
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | `EntityNotFoundException`, `ApplicationAlreadyExistsException` |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Application created successfully | `Application` entity |
| 404 Not Found | Job not found | Error details |
| 409 Conflict | Application already exists | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

### Response Fields (`Application`)

| Field | Type | Description |
|-------|------|-------------|
| `id` | `Long` | Application ID |
| `fullName` | `String` | Applicant full name |
| `email` | `String` | Applicant email |
| `job` | `Job` | Associated job |

---
