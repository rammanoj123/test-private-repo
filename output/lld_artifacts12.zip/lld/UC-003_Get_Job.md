# UC-003 — List Jobs · GET /job

> **Trigger:** 🌐 HTTP — 🔵 GET `/job`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.JobController.getAllJobs()`

Retrieves all job postings from the database.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-003 |
| **Name** | List Jobs |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `JobController.getAllJobs()` |
| **Return Type** | `List<Job>` |

---

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `GET`  
**Path:** `/job`

### Parameters

None

---

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getAllJobs()`

Delegate to service to retrieve all jobs

### Step 2 — [service] `JobServiceImpl.getAllJobs()`

Query repository for all jobs

### Step 3 — [repository] `JobRepo.findAll()`

🗄️ **DB Operation:** SELECT

Retrieve all jobs from database

---

## 5. Business Rules

None

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job
    JobController->>JobServiceImpl: getAllJobs()
    JobServiceImpl->>JobRepo: findAll()
    JobRepo-->>JobServiceImpl: List<Job>
    JobServiceImpl-->>JobController: List<Job>
    JobController-->>Actor: 200 OK
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | None |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Jobs retrieved successfully | `List<Job>` |
| 500 Internal Server Error | Unexpected error | Error details |

---
