# UC-004 — Get Job By ID · GET /job/{id}

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/{id}`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.JobController.getJobById()`

Retrieves a specific job posting by its ID. Throws EntityNotFoundException if the job does not exist.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-004 |
| **Name** | Get Job By ID |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `JobController.getJobById()` |
| **Return Type** | `Job` |

---

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `GET`  
**Path:** `/job/{id}`

### Parameters

| Parameter | Type | Source | Required | Description |
|-----------|------|--------|----------|-------------|
| `id` | `Long` | `@PathVariable` | Yes | Job ID to retrieve |

---

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobById()`

Extract job ID from path variable and delegate to service

### Step 2 — [service] `JobServiceImpl.getJobById()`

Query repository for job by ID

### Step 3 — [repository] `JobRepo.findById()`

⚠️ **Guard:** Throws `EntityNotFoundException` if job not found

🗄️ **DB Operation:** SELECT

Retrieve job by ID from database

---

## 5. Business Rules

- If job with given ID exists, then return the job
- If job with given ID does not exist, then throw EntityNotFoundException

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/{id}
    JobController->>JobServiceImpl: getJobById(id)
    JobServiceImpl->>JobRepo: findById(id)
    alt Job not found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Job found
        JobRepo-->>JobServiceImpl: Job
        JobServiceImpl-->>JobController: Job
        JobController-->>Actor: 200 OK
    end
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | `EntityNotFoundException` |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Job retrieved successfully | `Job` entity |
| 404 Not Found | Job not found | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

---
