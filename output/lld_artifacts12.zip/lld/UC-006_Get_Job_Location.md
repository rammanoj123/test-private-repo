# UC-006 — Get Jobs By Location · GET /job/location

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/location`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.JobController.getJobsByLocation()`

Retrieves all job postings for a specific location. Throws EntityNotFoundException if no jobs exist in the specified location.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-006 |
| **Name** | Get Jobs By Location |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `JobController.getJobsByLocation()` |
| **Return Type** | `List<Job>` |

---

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `GET`  
**Path:** `/job/location`

### Parameters

| Parameter | Type | Source | Required | Description |
|-----------|------|--------|----------|-------------|
| `location` | `String` | `@RequestParam` | Yes | Location to search for jobs |

---

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobsByLocation()`

Extract location from request parameter and delegate to service

### Step 2 — [service] `JobServiceImpl.getJobsByLocation()`

🌍 **External Call:** System.out.println (Console output for debugging)

Query repository for jobs by location and log results

### Step 3 — [repository] `JobRepo.findByLocation()`

⚠️ **Guard:** Throws `EntityNotFoundException` if no jobs found

🗄️ **DB Operation:** SELECT

Find all jobs in specified location

---

## 5. Business Rules

- If jobs exist in the location, then return the list
- If no jobs exist in the location, then throw EntityNotFoundException

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/location?location=...
    JobController->>JobServiceImpl: getJobsByLocation(location)
    JobServiceImpl->>JobRepo: findByLocation(location)
    alt No jobs found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Jobs found
        JobRepo-->>JobServiceImpl: List<Job>
        JobServiceImpl-->>JobController: List<Job>
        JobController-->>Actor: 200 OK
    end
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | `EntityNotFoundException` |
| **External Calls** | System.out.println |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Jobs retrieved successfully | `List<Job>` |
| 404 Not Found | No jobs found in location | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

---
