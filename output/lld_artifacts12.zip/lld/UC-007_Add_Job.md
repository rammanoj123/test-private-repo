# UC-007 — Create Job · POST /job

> **Trigger:** 🌐 HTTP — 🟢 POST `/job`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.JobController.addJob()`

Creates a new job posting and persists it to the database.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-007 |
| **Name** | Create Job |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `JobController.addJob()` |
| **Return Type** | `Job` |

---

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `POST`  
**Path:** `/job`

### Parameters

| Parameter | Type | Source | Required | Description |
|-----------|------|--------|----------|-------------|
| `job` | `Job` | `@RequestBody` | Yes | Job data to create |

---

## 4. Implementation Steps

### Step 1 — [controller] `JobController.addJob()`

Receive Job from request body and delegate to service

### Step 2 — [service] `JobServiceImpl.addJob()`

Persist job to database

### Step 3 — [repository] `JobRepo.save()`

🗄️ **DB Operation:** INSERT

Persist new job to database

---

## 5. Business Rules

None

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: POST /job
    JobController->>JobServiceImpl: addJob(job)
    JobServiceImpl->>JobRepo: save(job)
    JobRepo-->>JobServiceImpl: Job
    JobServiceImpl-->>JobController: Job
    JobController-->>Actor: 200 OK
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | None |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Job created successfully | `Job` entity |
| 500 Internal Server Error | Unexpected error | Error details |

---
