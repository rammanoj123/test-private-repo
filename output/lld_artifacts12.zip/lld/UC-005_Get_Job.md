# UC-005 — Search Jobs By Title · GET /job/search

> **Trigger:** 🌐 HTTP — 🔵 GET `/job/search`
> **Actor:** API Client
> **Entry:** `com.jobboard.controller.JobController.getJobsBySearch()`

Searches for job postings by title. Throws EntityNotFoundException if no jobs match the search term.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| **Use Case ID** | UC-005 |
| **Name** | Search Jobs By Title |
| **Trigger Type** | HTTP |
| **Actor** | API Client |
| **Entry Point** | `JobController.getJobsBySearch()` |
| **Return Type** | `List<Job>` |

---

## 2. Call Chain

`JobController` → `JobServiceImpl` → `JobRepo`

---

## 3. Input Contract

### HTTP Request

**Method:** `GET`  
**Path:** `/job/search`

### Parameters

| Parameter | Type | Source | Required | Description |
|-----------|------|--------|----------|-------------|
| `search` | `String` | `@RequestParam` | Yes | Job title search term |

---

## 4. Implementation Steps

### Step 1 — [controller] `JobController.getJobsBySearch()`

Extract search term from request parameter and delegate to service

### Step 2 — [service] `JobServiceImpl.getJobsBySearch()`

🌍 **External Call:** System.out.println (Console output for debugging)

Query repository for jobs by title and log results

### Step 3 — [repository] `JobRepo.findByTitle()`

⚠️ **Guard:** Throws `EntityNotFoundException` if no jobs found

🗄️ **DB Operation:** SELECT

Find all jobs with matching title

---

## 5. Business Rules

- If jobs with matching title exist, then return the list
- If no jobs with matching title exist, then throw EntityNotFoundException

---

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant Actor
    participant JobController
    participant JobServiceImpl
    participant JobRepo

    Actor->>JobController: GET /job/search?search=title
    JobController->>JobServiceImpl: getJobsBySearch(search)
    JobServiceImpl->>JobRepo: findByTitle(search)
    alt No jobs found
        JobRepo-->>JobServiceImpl: throw EntityNotFoundException
        JobServiceImpl-->>JobController: exception
        JobController-->>Actor: 404 Not Found
    else Jobs found
        JobRepo-->>JobServiceImpl: List<Job>
        JobServiceImpl-->>JobController: List<Job>
        JobController-->>Actor: 200 OK
    end
```

---

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---------|--------|
| **Transaction** | None |
| **Cache** | None |
| **Security** | Public endpoint |
| **Exceptions** | `EntityNotFoundException` |
| **External Calls** | System.out.println |

---

## 8. Output Contract

### HTTP Response

| Status Code | Condition | Response Body |
|-------------|-----------|---------------|
| 200 OK | Jobs retrieved successfully | `List<Job>` |
| 404 Not Found | No jobs found with title | Error details |
| 500 Internal Server Error | Unexpected error | Error details |

---
