# LLD: Job-Board-Litee

> **8 Technical Use Cases** — generated from source code

---

## Summary Statistics

| Metric | Count |
|--------|-------|
| **Total Use Cases** | 8 |
| **HTTP Endpoints** | 7 |
| **Application Start** | 1 |
| **Total Implementation Steps** | 33 |
| **Total Business Rules** | 9 |
| **Total Database Operations** | 10 |
| **Use Cases with Transactions** | 0 |
| **Use Cases with Cache** | 0 |
| **Use Cases with Auth** | 0 |

---

## Table of Contents

### 🌐 HTTP Endpoints (7)

- [UC-001 — Create Application](lld/UC-001_Add_Application.md)  
  `POST /application` · API Client · 6 steps · 3 rules · 3 DB ops
- [UC-002 — List Applications](lld/UC-002_Get_Application.md)  
  `GET /application` · API Client · 4 steps · 0 rules · 1 DB ops
- [UC-003 — List Jobs](lld/UC-003_Get_Job.md)  
  `GET /job` · API Client · 4 steps · 0 rules · 1 DB ops
- [UC-004 — Get Job By ID](lld/UC-004_Get_Job.md)  
  `GET /job/{id}` · API Client · 4 steps · 2 rules · 1 DB ops
- [UC-005 — Search Jobs By Title](lld/UC-005_Get_Job.md)  
  `GET /job/search` · API Client · 4 steps · 2 rules · 1 DB ops
- [UC-006 — Get Jobs By Location](lld/UC-006_Get_Job_Location.md)  
  `GET /job/location` · API Client · 4 steps · 2 rules · 1 DB ops
- [UC-007 — Create Job](lld/UC-007_Add_Job.md)  
  `POST /job` · API Client · 4 steps · 0 rules · 1 DB ops

### 🚀 Application Start (1)

- [UC-008 — Run Job Board Litee Application](lld/UC-008_Start_Job_Board_Litee.md)  
  `main(String[] args) in JobBoardLiteeApplication` · JVM / OS Process · 3 steps · 0 rules · 0 DB ops

---

## Use Case Reference Cards

> Each card is a quick-reference summary. Click the **📄 Full LLD** link to open the complete design document.

### UC-001 — Create Application  ·  POST /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.addApplication()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-001_Add_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/application` |
| Call chain | `ApplicationController` → `ApplicationServiceImpl` → `JobRepo` → `ApplicationRepo` |
| Steps | 6 |
| Rules | 3 |
| DB Operations | 3 (2 SELECT, 1 INSERT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **ApplicationController**.addApplication() — Receive Application from request body and delegate to service
2. `[service]` **ApplicationServiceImpl**.addApplication() — Validate job exists and check for duplicate application
3. `[repository]` **JobRepo**.findById() — Query database to verify job exists
4. `[repository]` **ApplicationRepo**.findByfullNameAndEmailAndJobId() — Check for duplicate application by fullName, email, and jobId
5. `[repository]` **ApplicationRepo**.save() — Persist new application to database

**Business rules:**

- If job does not exist, then throw EntityNotFoundException
- If application already exists for same fullName, email, and jobId, then throw ApplicationAlreadyExistsException
- If job exists and no duplicate application, then save and return application

> 📄 [Open full LLD for UC-001](lld/UC-001_Add_Application.md)

---

### UC-002 — List Applications  ·  GET /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.getAllApplications()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-002_Get_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/application` |
| Call chain | `ApplicationController` → `ApplicationServiceImpl` → `ApplicationRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (1 SELECT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **ApplicationController**.getAllApplications() — Delegate to service to retrieve all applications
2. `[service]` **ApplicationServiceImpl**.getAllApplications() — Query repository for all applications
3. `[repository]` **ApplicationRepo**.findAll() — Retrieve all applications from database

> 📄 [Open full LLD for UC-002](lld/UC-002_Get_Application.md)

---

### UC-003 — List Jobs  ·  GET /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getAllJobs()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-003_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (1 SELECT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **JobController**.getAllJobs() — Delegate to service to retrieve all jobs
2. `[service]` **JobServiceImpl**.getAllJobs() — Query repository for all jobs
3. `[repository]` **JobRepo**.findAll() — Retrieve all jobs from database

> 📄 [Open full LLD for UC-003](lld/UC-003_Get_Job.md)

---

### UC-004 — Get Job By ID  ·  GET /job/{id}

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobById()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-004_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/{id}` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 2 |
| DB Operations | 1 (1 SELECT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **JobController**.getJobById() — Extract job ID from path variable and delegate to service
2. `[service]` **JobServiceImpl**.getJobById() — Query repository for job by ID
3. `[repository]` **JobRepo**.findById() — Retrieve job by ID from database

**Business rules:**

- If job with given ID exists, then return the job
- If job with given ID does not exist, then throw EntityNotFoundException

> 📄 [Open full LLD for UC-004](lld/UC-004_Get_Job.md)

---

### UC-005 — Search Jobs By Title  ·  GET /job/search

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsBySearch()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-005_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/search` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 2 |
| DB Operations | 1 (1 SELECT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **JobController**.getJobsBySearch() — Extract search term from request parameter and delegate to service
2. `[service]` **JobServiceImpl**.getJobsBySearch() — Query repository for jobs by title and log results
3. `[repository]` **JobRepo**.findByTitle() — Find all jobs with matching title

**Business rules:**

- If jobs with matching title exist, then return the list
- If no jobs with matching title exist, then throw EntityNotFoundException

> 📄 [Open full LLD for UC-005](lld/UC-005_Get_Job.md)

---

### UC-006 — Get Jobs By Location  ·  GET /job/location

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsByLocation()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-006_Get_Job_Location.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/location` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 2 |
| DB Operations | 1 (1 SELECT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **JobController**.getJobsByLocation() — Extract location from request parameter and delegate to service
2. `[service]` **JobServiceImpl**.getJobsByLocation() — Query repository for jobs by location and log results
3. `[repository]` **JobRepo**.findByLocation() — Find all jobs in specified location

**Business rules:**

- If jobs exist in the location, then return the list
- If no jobs exist in the location, then throw EntityNotFoundException

> 📄 [Open full LLD for UC-006](lld/UC-006_Get_Job_Location.md)

---

### UC-007 — Create Job  ·  POST /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.addJob()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-007_Add_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/job` |
| Call chain | `JobController` → `JobServiceImpl` → `JobRepo` |
| Steps | 4 |
| Rules | 0 |
| DB Operations | 1 (1 INSERT) |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[controller]` **JobController**.addJob() — Receive Job from request body and delegate to service
2. `[service]` **JobServiceImpl**.addJob() — Persist job to database
3. `[repository]` **JobRepo**.save() — Persist new job to database

> 📄 [Open full LLD for UC-007](lld/UC-007_Add_Job.md)

---

### UC-008 — Run Job Board Litee Application  ·  main(String[] args) in JobBoardLiteeApplication

> 🚀 **Application Start** &nbsp;|&nbsp; **Actor:** JVM / OS Process &nbsp;|&nbsp; **Entry:** `JobBoardLiteeApplication.main()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-008_Start_Job_Board_Litee.md)

| Property | Value |
|---|---|
| Trigger | 🚀 **Application Start** — `main(String[] args) in JobBoardLiteeApplication` |
| Call chain | `JobBoardLiteeApplication` → `SpringApplication` |
| Steps | 3 |
| Rules | 0 |
| DB Operations | 0 |
| Transaction | ❌ |
| Cache | ❌ |
| Auth | ❌ |

**Implementation steps:**

1. `[application]` **JobBoardLiteeApplication**.main() — Bootstrap Spring Boot application context
2. `[framework]` **SpringApplication**.run() — Start Spring Boot application server

> 📄 [Open full LLD for UC-008](lld/UC-008_Start_Job_Board_Litee.md)

---
