# UC-001 — Add Application  ·  POST /application

> **Trigger:** 🌐 **HTTP** — 🟢 POST `/application`  
> **Actor:** API Client  
> **Entry:** `ApplicationController.addApplication()`  

HTTP endpoint POST /application. Entry: ApplicationController.addApplication(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-001` |
| Name | **Add Application** |
| Trigger | 🌐 **HTTP** — 🟢 POST `/application` |
| Actor | API Client |
| Entry Point | `ApplicationController.addApplication()` |
| Return Type | `Application` |

## 2. Call Chain

`ApplicationController` → `ApplicationService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `application` | `Application` | `@RequestBody` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.


#### ⚙️ Service Layer

**Step 1** — Invoke service: create / persist — add Application

| Attribute | Value |
|---|---|
| Component | `service` |
| Call | `service.addApplication(application)` |

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber

    participant API_Client as API Client
    participant ApplicationController as ApplicationController
    participant service as service

    API_Client->>ApplicationController: POST /application
    ApplicationController->>service: Invoke service: create / persist — add Application
    service-->>ApplicationController: return
    ApplicationController->>API_Client: 200 OK — success
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | none |
| Events Published | none |
| External Calls | none |
| Exception Types | none detected |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `Application` |

**Response fields** (`Application`):

| Field | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `fullName` | `String` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `email` | `String` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `job` | `Job` | `@ManyToOne` `@JoinColumn(name="job_id",nullable=false)` `@JsonBackReference` |

**HTTP status codes:**

- 200 OK — success
- 500 Internal Server Error — unexpected error

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `ApplicationController` | Controller | Handle `POST /application`. Parse request, call service, return response. |
| ⚙️ `service` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |

### Domain Model Fields

**Application** (`entity`) — package `com.jobboard.dvo`

| Field | Type | Annotations | Required? |
|---|---|---|---|
| `id` 🔑 | `Long` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `fullName` 🔑 | `String` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `email` 🔑 | `String` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `job` | `Job` | @ManyToOne @JoinColumn(name="job_id",nullable=false) @JsonBackReference |  *(required)* |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="applicationController" class="<your.package>.ApplicationController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

<bean id="service" class="<your.package>.service">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-001 — "Add Application"
Trigger : POST /application
Actor   : API Client

Call chain (implement ALL classes):
  ApplicationController → ApplicationService

Entry: ApplicationController.addApplication()

Input:
  Parameters : @RequestBody Application application
  Fields:
  (no request body)

Implementation steps (IN ORDER — implement each one):
   1. [service     ] Invoke service: create / persist — add Application

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: Application
HTTP status: 200 OK — success, 500 Internal Server Error — unexpected error

Side effects: none

Domain types:
  Application (entity):
    id: Long  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    fullName: String  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    email: String  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    job: Job  @ManyToOne @JoinColumn(name="job_id",nullable=false) @JsonBackReference


Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Include all imports. Write production-quality code.
```

---

