package com.jobboard.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.jobboard.dvo.Job;
import com.jobboard.exceptions.EntityNotFoundException;
import com.jobboard.service.JobService;

//@ExtendWith(MockitoExtension.class)

@WebMvcTest(value = JobController.class)
public class JobControllerTest {

	@MockBean
	private JobService jobService;

	@InjectMocks
	private JobController jobController;

	@Test
	public void getAllJobs_shouldReturnListOfJobs_whenJobsExist() {

		List<Job> jobs = Arrays.asList(new Job(), new Job());
		when(jobService.getAllJobs()).thenReturn(jobs);

		List<Job> result = jobController.getAllJobs();

		assertEquals(2, result.size());
		verify(jobService, times(1)).getAllJobs();
	}

	@Test
    public void getAllJobs_shouldReturnEmptyList_whenNoJobsExist() {
        when(jobService.getAllJobs()).thenReturn(Collections.emptyList());

        List<Job> result = jobController.getAllJobs();

        assertTrue(result.isEmpty());
        verify(jobService, times(1)).getAllJobs();
    }

	@Test
	public void getJobById_shouldReturnJob_whenIdIsValid() {
		Job job = new Job();
		when(jobService.getJobById(1L)).thenReturn(job);

		Job result = jobController.getJobById(1L);

		assertNotNull(result);
		verify(jobService, times(1)).getJobById(1L);
	}

	@Test
    public void getJobById_shouldThrowException_whenIdIsInvalid() {
        when(jobService.getJobById(99L)).thenThrow(new EntityNotFoundException("job id with 99 is not found"));

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobController.getJobById(99L));
        assertEquals("job id with 99 is not found", ex.getMessage());
        verify(jobService, times(1)).getJobById(99L);
    }

	@Test
	public void getJobsBySearch_shouldReturnJobs_whenSearchMatches() {
		List<Job> jobs = Arrays.asList(new Job());
		when(jobService.getJobsBySearch("dev")).thenReturn(jobs);

		List<Job> result = jobController.getJobsBySearch("dev");

		assertEquals(1, result.size());
		verify(jobService, times(1)).getJobsBySearch("dev");
	}

	@Test
    public void getJobsBySearch_shouldThrowException_whenNoMatch() {
        when(jobService.getJobsBySearch("zzz")).thenThrow(new EntityNotFoundException("Job with title zzz is not found"));

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobController.getJobsBySearch("zzz"));
        assertEquals("Job with title zzz is not found", ex.getMessage());
        verify(jobService, times(1)).getJobsBySearch("zzz");
    }

	@Test
	public void getJobsByLocation_shouldReturnJobs_whenLocationMatches() {
		List<Job> jobs = Arrays.asList(new Job());
		when(jobService.getJobsByLocation("NY")).thenReturn(jobs);

		List<Job> result = jobController.getJobsByLocation("NY");

		assertEquals(1, result.size());
		verify(jobService, times(1)).getJobsByLocation("NY");
	}

	@Test
    public void getJobsByLocation_shouldThrowException_whenNoMatch() {
        when(jobService.getJobsByLocation("Moon")).thenThrow(new EntityNotFoundException("Job in location Moon is not found"));

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobController.getJobsByLocation("Moon"));
        assertEquals("Job in location Moon is not found", ex.getMessage());
        verify(jobService, times(1)).getJobsByLocation("Moon");
    }

	@Test
	public void addJob_shouldReturnSavedJob_whenJobIsValid() {
		Job job = new Job();
		when(jobService.addJob(job)).thenReturn(job);

		Job result = jobController.addJob(job);

		assertNotNull(result);
		verify(jobService, times(1)).addJob(job);
	}
}
