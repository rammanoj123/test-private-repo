# UC-003: List Jobs

## Trigger
🔵 **HTTP GET** `GET /job`

## Actor
API Client

## Entry Point
`JobController.getAllJobs()`

## One-Sentence Description
Retrieves a list of all jobs.

## Use Case Overview
| Field              | Value                        |
|--------------------|------------------------------|
| Use Case ID        | UC-003                       |
| Name               | List Jobs                    |
| Trigger Type       | http                         |
| Trigger Detail     | GET /job                     |
| Actor              | API Client                   |
| Entry Class        | JobController                |
| Entry Method       | getAllJobs                   |
| Response Type      | List<Job>                    |
| HTTP Status Codes  | 200 OK                       |

## Call Chain
1. JobController.getAllJobs
2. JobService.getAllJobs

## Input Contract
_No input parameters._

## Implementation Steps
1. Receive GET /job request.
2. Controller delegates to `JobServiceImpl.getAllJobs()`.
3. Service calls `repo.findAll()` to retrieve all jobs from the database.
4. Return list of Job objects as response.

### DB Operations
- `repo.findAll`: Fetches all Job records from the database.

### Exception Paths
_No exception types specified._

### Events Published
_None._

### External Calls
_None._

## Business Rules
_No business rules specified._

## Sequence Diagram
```
participant API_Client
participant JobController
participant JobServiceImpl
participant JobRepository

API_Client->>JobController: GET /job
JobController->>JobServiceImpl: getAllJobs()
JobServiceImpl->>JobRepository: findAll()
JobRepository-->>JobServiceImpl: List<Job>
JobServiceImpl-->>JobController: List<Job>
JobController-->>API_Client: 200 OK, List<Job>
```

## Cross-Cutting Concerns
- No authentication or authorization required for this endpoint.
- No transactional scope.

## Output Contract
| Status Code | Response Body                 |
|-------------|-------------------------------|
| 200 OK      | List<Job>                     |

### Response Fields
_No specific response fields detailed. Returns full Job objects._
