# UC-005: Search Jobs

## Trigger
🔵 **HTTP GET** `/job/search`

## Actor
API Client

## Entry Point
`JobController.getJobsBySearch`

## One-Sentence Description
Retrieves a list of jobs matching the search criteria.

## Use Case Overview
| Field                | Value                                  |
|----------------------|----------------------------------------|
| Use Case ID          | UC-005                                 |
| Name                 | Search Jobs                            |
| Trigger Type         | http                                   |
| Trigger Detail       | GET /job/search                        |
| Actor                | API Client                             |
| Entry Class          | JobController                          |
| Entry Method         | getJobsBySearch                        |
| Response Type        | List<Job>                              |
| HTTP Status Codes    | 200 OK, 404 Not Found                  |

## Call Chain
- JobController.getJobsBySearch
- JobService.getJobsBySearch

## Input Contract
- `search` (query parameter): String value used to filter jobs by title.

## Implementation Steps
1. Receive GET `/job/search` request with `search` parameter.
2. Controller delegates to `JobServiceImpl.getJobsBySearch(search)`.
3. Service calls `repo.findByTitle(search)` to retrieve jobs.
4. If jobs are found (not null), return the list.
5. If jobs are null, throw `EntityNotFoundException`.

### Exception Paths
- If no jobs are found, an `EntityNotFoundException` is thrown, resulting in a `404 Not Found` response.

### DB Operations
- `repo.findByTitle(search)`: Queries the database for jobs matching the given title.

## Business Rules
_None specified._

## Sequence Diagram
```mermaid
sequenceDiagram
    participant APIClient as API Client
    participant JobController as JobController
    participant JobService as JobServiceImpl
    participant JobRepo as JobRepo

    APIClient->>JobController: GET /job/search?search=criteria
    JobController->>JobService: getJobsBySearch(search)
    JobService->>JobRepo: findByTitle(search)
    JobRepo-->>JobService: List<Job> or null
    alt Jobs found
        JobService-->>JobController: List<Job>
        JobController-->>APIClient: 200 OK, List<Job>
    else No jobs found
        JobService-->>JobController: EntityNotFoundException
        JobController-->>APIClient: 404 Not Found
    end
```

## Cross-Cutting Concerns
- Exception handling: `EntityNotFoundException` is mapped to HTTP 404.
- No authentication or authorization rules specified.
- No transaction management required.

## Output Contract
### Status Codes
- **200 OK**: List of jobs matching the search criteria returned.
- **404 Not Found**: No jobs found for the given search criteria.

### Response Fields
- **List<Job>**: Each Job object contains fields as defined in the Job model.
