# UC-002: List Applications

## Trigger

🔵 **HTTP GET** `/application`

**Actor:** API Client

## Entry Point

- **Class:** `ApplicationController`
- **Method:** `getAllApplications`

## Description

Retrieves a list of all applications.

## Use Case Overview

| Item                | Detail                              |
|---------------------|-------------------------------------|
| Use Case ID         | UC-002                              |
| Name                | List Applications                    |
| Actor               | API Client                          |
| Trigger             | HTTP GET /application               |
| Entry Point         | ApplicationController.getAllApplications |
| Response Type       | List<Application>                   |
| Transactional       | No                                  |

## Call Chain

1. `ApplicationController.getAllApplications`
2. `ApplicationService.getAllApplications`

## Input Contract

_No input parameters._

## Implementation Steps

1. Receive `GET /application` request.
2. Controller delegates to `ApplicationServiceImpl.getAllApplications()`.
3. Service calls `repo.findAll()` to retrieve all applications from the database.
4. Return list of `Application` objects.

### Database Operations
- `repo.findAll` — Fetches all Application entities from the database.

### Events Published
- None

### External Calls
- None

## Business Rules

_No business rules defined._

## Sequence Diagram

```mermaid
sequenceDiagram
    participant Client as API Client
    participant Controller as ApplicationController
    participant Service as ApplicationService
    participant Repo as ApplicationRepository

    Client->>Controller: GET /application
    Controller->>Service: getAllApplications()
    Service->>Repo: findAll()
    Repo-->>Service: List<Application>
    Service-->>Controller: List<Application>
    Controller-->>Client: 200 OK, List<Application>
```

## Cross-Cutting Concerns

- Authentication: _None specified._
- Authorization: _None specified._
- Auditing: _None specified._
- Logging: Standard request/response logging may apply.

## Output Contract

| HTTP Status | Description                | Response Body         |
|-------------|----------------------------|-----------------------|
| 200 OK      | Success. Returns all applications. | List<Application> |

### Response Fields

_The response is a JSON array of `Application` objects._

> See `Application` type definition for object structure.
