# UC-004: Get Job Details

## Trigger
🔵 **HTTP GET** `/job/{id}`

## Actor
API Client

## Entry Point
`JobController.getJobById`

## One-Sentence Description
Retrieves the details of a specific job by its ID.

## Use Case Overview
| Field              | Value                                   |
|--------------------|-----------------------------------------|
| Use Case ID        | UC-004                                  |
| Name               | Get Job Details                         |
| Trigger Type       | HTTP                                    |
| Trigger Detail     | GET /job/{id}                           |
| Actor              | API Client                              |
| Entry Class        | JobController                           |
| Entry Method       | getJobById                              |
| Input Params       | id (path variable)                      |
| Request Type       |                                         |
| Return Type        | Job                                     |
| Response Type      | Job                                     |
| Transactional      | No                                      |
| Related Types      | Job                                     |

## Call Chain
- JobController.getJobById
- JobService.getJobById

## Input Contract
- Path Variable: `id` (Long)

## Implementation Steps
1. Receive GET `/job/{id}` request.
2. Controller delegates to `JobServiceImpl.getJobById(id)`.
3. Service calls `repo.findById(id)` to retrieve the job.
4. If job is found, return the Job object.
5. If job is not found, throw `EntityNotFoundException`.

### DB Operations
- `repo.findById`

### Exception Paths
- If job is not found: `EntityNotFoundException` is thrown and results in a 404 Not Found response.

## Business Rules
_No business rules defined for this use case._

## Sequence Diagram
```mermaid
sequenceDiagram
    participant APIClient as API Client
    participant JobController as JobController
    participant JobService as JobServiceImpl
    participant JobRepo as JobRepo

    APIClient->>JobController: GET /job/{id}
    JobController->>JobService: getJobById(id)
    JobService->>JobRepo: findById(id)
    JobRepo-->>JobService: Job (or null)
    alt Job found
        JobService-->>JobController: Job
        JobController-->>APIClient: 200 OK + Job
    else Job not found
        JobService-->>JobController: EntityNotFoundException
        JobController-->>APIClient: 404 Not Found
    end
```

## Cross-Cutting Concerns
- Exception handling: `EntityNotFoundException` mapped to 404 Not Found.
- No authentication or authorization rules specified.

## Output Contract
### Status Codes
- 200 OK: Job found and returned.
- 404 Not Found: Job not found.

### Response Fields
| Field           | Type   | Nullable | Description                  |
|-----------------|--------|----------|------------------------------|
| id              | Long   | Yes      | Job identifier               |
| title           | String | Yes      | Job title                    |
| company         | String | Yes      | Company name                 |
| location        | String | Yes      | Job location                 |
| description     | String | Yes      | Job description              |
| salaryRange     | String | Yes      | Salary range                 |
| requiredSkills  | String | Yes      | Required skills              |
| applications    | List   | Yes      | List of applications         |
| other           | Job    | Yes      | Other job (if applicable)    |
