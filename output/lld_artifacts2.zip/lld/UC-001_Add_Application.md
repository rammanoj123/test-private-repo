# UC-001: Add Application

## Trigger
🟢 **HTTP POST** `/application`

## Actor
API Client

## Entry Point
`ApplicationController.addApplication()`

## One-Sentence Description
Create a new Application for a Job via HTTP POST, ensuring the Job exists and the applicant has not already applied to the same Job.

## Use Case Overview
| Field                | Value                                  |
|----------------------|----------------------------------------|
| Use Case ID          | UC-001                                 |
| Name                 | Add Application                        |
| Trigger Type         | HTTP                                   |
| Trigger Detail       | POST /application                      |
| Actor                | API Client                             |
| Entry Class          | ApplicationController                   |
| Entry Method         | addApplication                         |
| Request Type         | Application (JSON body)                |
| Response Type        | Application                             |
| Related Types        | Application, Job                       |
| Transactional        | No                                     |

## Call Chain
- ApplicationController
- ApplicationService

## Input Contract
**POST /application**

Request Body: `Application` (JSON)

| Field     | Type   | Nullable | Annotations                                                |
|-----------|--------|----------|-----------------------------------------------------------|
| id        | Long   | Yes      | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY)  |
| fullName  | String | Yes      | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY)  |
| email     | String | Yes      | @Id, @GeneratedValue(strategy = GenerationType.IDENTITY)  |
| job       | Job    | No       | @ManyToOne, @JoinColumn(name="job_id",nullable=false), @JsonBackReference |

## Implementation Steps
1. Receive POST `/application` request with Application payload.
2. Controller delegates to `ApplicationServiceImpl.addApplication(Application)`.
3. Service checks if Job exists via `jobRepo.findById(application.getJob().getId())`.
   - If Job does not exist, throw `EntityNotFoundException` (returns 404).
4. If Job exists, check for existing Application via `repo.findByfullNameAndEmailAndJobId(...)`.
   - If Application exists, throw `ApplicationAlreadyExistsException` (returns 409).
5. If not, save Application via `repo.save(application)`.
6. Return saved Application (returns 201 Created).

### DB Operations
- `jobRepo.findById`
- `repo.findByfullNameAndEmailAndJobId`
- `repo.save`

### Exception Paths
- **EntityNotFoundException**: Job does not exist (404 Not Found)
- **ApplicationAlreadyExistsException**: Application already exists for same applicant and job (409 Conflict)

## Business Rules
- Application can only be added if the referenced Job exists.
- An applicant cannot apply to the same job more than once (checked by fullName, email, jobId).

## Sequence Diagram
```mermaid
sequenceDiagram
    participant Client
    participant ApplicationController
    participant ApplicationServiceImpl
    participant JobRepo
    participant ApplicationRepo

    Client->>ApplicationController: POST /application (Application JSON)
    ApplicationController->>ApplicationServiceImpl: addApplication(Application)
    ApplicationServiceImpl->>JobRepo: findById(jobId)
    JobRepo-->>ApplicationServiceImpl: Job or null
    ApplicationServiceImpl->>ApplicationRepo: findByfullNameAndEmailAndJobId(...)
    ApplicationRepo-->>ApplicationServiceImpl: Application or null
    alt Job not found
        ApplicationServiceImpl-->>ApplicationController: throw EntityNotFoundException
        ApplicationController-->>Client: 404 Not Found
    else Application exists
        ApplicationServiceImpl-->>ApplicationController: throw ApplicationAlreadyExistsException
        ApplicationController-->>Client: 409 Conflict
    else Success
        ApplicationServiceImpl->>ApplicationRepo: save(application)
        ApplicationRepo-->>ApplicationServiceImpl: saved Application
        ApplicationServiceImpl-->>ApplicationController: saved Application
        ApplicationController-->>Client: 201 Created (saved Application)
    end
```

## Cross-Cutting Concerns
- No authentication required (public endpoint).
- Standard error handling via `GlobalExceptionHandler`.

## Output Contract
**Status Codes:**
- 201 Created: Application successfully created.
- 404 Not Found: Referenced Job does not exist.
- 409 Conflict: Application already exists for this applicant and job.

**Response Body (201 Created):**
```json
{
  "id": Long,
  "fullName": String,
  "email": String,
  "job": {
    // Job fields
  }
}
```
