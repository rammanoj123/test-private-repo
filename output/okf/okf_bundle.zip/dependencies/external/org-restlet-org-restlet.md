---
type: Dependency
title: org.restlet:org.restlet
description: Third-party library org.restlet:org.restlet at 1.1.6 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.restlet/org.restlet
tags: [dependency, external]
status: draft
artifact_id: org.restlet
group_id: org.restlet
scope: compile
version: 1.1.6
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.restlet:org.restlet:1.1.6`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.restlet:org.restlet` is used from 57 classes (229 import site(s)), in the controller, unknown, config layer(s). Of everything it ships, this service reaches 3 package(s).

What is used:
- `org.restlet.Context`
- `org.restlet.data`
- `org.restlet.data.CharacterSet`
- `org.restlet.data.Form`
- `org.restlet.data.Language`
- `org.restlet.data.MediaType`
- `org.restlet.data.Method`
- `org.restlet.data.Parameter`
- `org.restlet.data.Reference`
- `org.restlet.data.Request`
- `org.restlet.data.Response`
- `org.restlet.data.Status`
- …and 6 more type(s)

Used by: [AbstractResource](/components/controllers/AbstractResource.md), [CustomHttpStatus](/components/misc/CustomHttpStatus.md), `EPrintCenterResourceTest`, [Utility](/components/misc/Utility.md), [InvalidUUIDException](/components/exceptions/InvalidUUIDException.md), [BlackListHandler](/components/controllers/BlackListHandler.md), [BlackListsHandler](/components/controllers/BlackListsHandler.md), [WhitelistHandler](/components/controllers/WhitelistHandler.md), [OwnerAccessProcessor](/components/misc/OwnerAccessProcessor.md), `OwnerAccessProcessorTest`, [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md), [AvailabilityResource](/components/controllers/AvailabilityResource.md) (+45 more).
