---
type: Dependency
title: org.powermock:powermock-module-testng
description: Third-party library org.powermock:powermock-module-testng at ${powermock.version} on the test classpath.
resource: https://central.sonatype.com/artifact/org.powermock/powermock-module-testng
tags: [dependency, external]
status: draft
artifact_id: powermock-module-testng
group_id: org.powermock
scope: test
version: ${powermock.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.powermock:powermock-module-testng:${powermock.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is a test-scope dependency, so it is used by the test sources; those are outside this bundle, which covers production code.
