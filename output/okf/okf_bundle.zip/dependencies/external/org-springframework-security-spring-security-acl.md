---
type: Dependency
title: org.springframework.security:spring-security-acl
description: Third-party library org.springframework.security:spring-security-acl at ${springframework.security.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-acl
tags: [dependency, external]
status: draft
artifact_id: spring-security-acl
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.springframework.security:spring-security-acl:${springframework.security.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.springframework.security:spring-security-acl` is used from 5 classes (12 import site(s)), in the service, exception, security layer(s). Of everything it ships, this service reaches 4 package(s).

What is used:
- `org.springframework.security.core.Authentication`
- `org.springframework.security.core.AuthenticationException`
- `org.springframework.security.core.GrantedAuthority`
- `org.springframework.security.core.SpringSecurityMessageSource`
- `org.springframework.security.core.authority.SimpleGrantedAuthority`
- `org.springframework.security.core.context.SecurityContextHolder`
- `org.springframework.security.core.userdetails.User`
- `org.springframework.security.core.userdetails.UserDetails`
- `org.springframework.security.core.userdetails.UserDetailsService`
- `org.springframework.security.core.userdetails.UsernameNotFoundException`

Used by: `ExceptionTranslationFilterTest`, [EPrintUserDetailsService](/components/services/EPrintUserDetailsService.md), [ExceptionTranslationFilter](/components/exceptions/ExceptionTranslationFilter.md), [ProtectedResourceAccessTokenService](/components/services/ProtectedResourceAccessTokenService.md), [ProtectedResourceProcessingFilter_DraftHammer](/components/security/ProtectedResourceProcessingFilter_DraftHammer.md).
