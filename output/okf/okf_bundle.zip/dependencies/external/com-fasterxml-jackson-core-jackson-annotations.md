---
type: Dependency
title: com.fasterxml.jackson.core:jackson-annotations
description: Third-party library com.fasterxml.jackson.core:jackson-annotations at 2.15.2 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.fasterxml.jackson.core/jackson-annotations
tags: [dependency, external]
status: draft
artifact_id: jackson-annotations
group_id: com.fasterxml.jackson.core
scope: compile
version: 2.15.2
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.fasterxml.jackson.core:jackson-annotations:2.15.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`com.fasterxml.jackson.core:jackson-annotations` is used from 12 classes (12 import site(s)), in the controller, unknown, service layer(s). Of everything it ships, this service reaches 1 package(s).

What is used:
- `com.fasterxml.jackson.core.JsonParseException`
- `com.fasterxml.jackson.core.JsonProcessingException`

Used by: `EPrintCenterResourceTest`, [OwnershipStatusService](/components/services/OwnershipStatusService.md), [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md), `DeviceOwnershipResourceTest`, [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md), [OptInScheduleResource](/components/controllers/OptInScheduleResource.md), [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md), `OwnershipStatusResourceTest`, [PrinterResource](/components/controllers/PrinterResource.md), `PrinterResourceTest`, [SolutionOptInResource](/components/controllers/SolutionOptInResource.md), [StratusClientImpl](/components/misc/StratusClientImpl.md).
