---
type: Dependency
title: net.sf.ehcache:ehcache
description: Third-party library net.sf.ehcache:ehcache at 1.3.0 on the compile classpath.
resource: https://central.sonatype.com/artifact/net.sf.ehcache/ehcache
tags: [dependency, external]
status: draft
artifact_id: ehcache
group_id: net.sf.ehcache
scope: compile
version: 1.3.0
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `net.sf.ehcache:ehcache:1.3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
