---
type: Dependency
title: org.slf4j:slf4j-api
description: Third-party library org.slf4j:slf4j-api at ${slf4j.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.slf4j/slf4j-api
tags: [dependency, external]
status: draft
artifact_id: slf4j-api
group_id: org.slf4j
scope: compile
version: ${slf4j.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.slf4j:slf4j-api:${slf4j.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.slf4j:slf4j-api` is used from 8 classes (17 import site(s)), in the unknown, controller, config layer(s). Of everything it ships, this service reaches 1 package(s).

What is used:
- `org.slf4j.Logger`
- `org.slf4j.LoggerFactory`
- `org.slf4j.MDC`

Used by: [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md), [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md), [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md), [PrinterResource](/components/controllers/PrinterResource.md), [CoreOAuthSignatureMethodFactory_DraftHammer](/components/config/CoreOAuthSignatureMethodFactory_DraftHammer.md), [CalypsoClientImpl](/components/misc/CalypsoClientImpl.md), [StratusClientImpl](/components/misc/StratusClientImpl.md), [StratusHttpClient](/components/misc/StratusHttpClient.md).
