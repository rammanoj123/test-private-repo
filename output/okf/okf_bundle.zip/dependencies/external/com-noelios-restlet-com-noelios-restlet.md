---
type: Dependency
title: com.noelios.restlet:com.noelios.restlet
description: Third-party library com.noelios.restlet:com.noelios.restlet at 1.1.6 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.noelios.restlet/com.noelios.restlet
tags: [dependency, external]
status: draft
artifact_id: com.noelios.restlet
group_id: com.noelios.restlet
scope: compile
version: 1.1.6
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.noelios.restlet:com.noelios.restlet:1.1.6`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`com.noelios.restlet:com.noelios.restlet` is used from 3 classes (6 import site(s)), in the controller layer(s). Of everything it ships, this service reaches 2 package(s).

What is used:
- `com.noelios.restlet.ext.servlet.ServletCall`
- `com.noelios.restlet.http.HttpRequest`

Used by: [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md), [OwnerShipResource](/components/controllers/OwnerShipResource.md), [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).
