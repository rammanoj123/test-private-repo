---
type: Dependency
title: org.springframework.security:spring-security-config
description: Third-party library org.springframework.security:spring-security-config at ${springframework.security.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-config
tags: [dependency, external]
status: draft
artifact_id: spring-security-config
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.springframework.security:spring-security-config:${springframework.security.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
