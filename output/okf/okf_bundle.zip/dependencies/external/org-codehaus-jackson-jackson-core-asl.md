---
type: Dependency
title: org.codehaus.jackson:jackson-core-asl
description: Third-party library org.codehaus.jackson:jackson-core-asl at 1.9.2 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.codehaus.jackson/jackson-core-asl
tags: [dependency, external]
status: draft
artifact_id: jackson-core-asl
group_id: org.codehaus.jackson
scope: compile
version: 1.9.2
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.codehaus.jackson:jackson-core-asl:1.9.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.codehaus.jackson:jackson-core-asl` is used from one class (2 import site(s)), in the unknown layer(s). Of everything it ships, this service reaches 2 package(s).

What is used:
- `org.codehaus.jackson.JsonNode`
- `org.codehaus.jackson.map.ObjectMapper`

Used by: [CalypsoClientImpl](/components/misc/CalypsoClientImpl.md).
