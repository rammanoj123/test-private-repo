---
type: Dependency
title: org.springframework.security.oauth:spring-security-oauth
description: Third-party library org.springframework.security.oauth:spring-security-oauth at ${spring-security-oauth.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework.security.oauth/spring-security-oauth
tags: [dependency, external]
status: draft
artifact_id: spring-security-oauth
group_id: org.springframework.security.oauth
scope: compile
version: ${spring-security-oauth.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.springframework.security.oauth:spring-security-oauth:${spring-security-oauth.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.springframework.security.oauth:spring-security-oauth` is used from 4 classes (14 import site(s)), in the service, security, config layer(s). Of everything it ships, this service reaches 4 package(s).

What is used:
- `org.springframework.security.oauth.common.OAuthConsumerParameter`
- `org.springframework.security.oauth.common.signature`
- `org.springframework.security.oauth.provider.ConsumerAuthentication`
- `org.springframework.security.oauth.provider.ConsumerDetails`
- `org.springframework.security.oauth.provider.ConsumerDetailsService`
- `org.springframework.security.oauth.provider.InvalidOAuthParametersException`
- `org.springframework.security.oauth.provider.filter.ProtectedResourceProcessingFilter`
- `org.springframework.security.oauth.provider.token.ExpiredOAuthTokenException`
- `org.springframework.security.oauth.provider.token.InvalidOAuthTokenException`
- `org.springframework.security.oauth.provider.token.OAuthAccessProviderToken`
- `org.springframework.security.oauth.provider.token.OAuthProviderToken`
- `org.springframework.security.oauth.provider.token.OAuthProviderTokenServices`

Used by: [ConsumerDetailServiceProvider](/components/services/ConsumerDetailServiceProvider.md), [CoreOAuthSignatureMethodFactory_DraftHammer](/components/config/CoreOAuthSignatureMethodFactory_DraftHammer.md), [ProtectedResourceAccessTokenService](/components/services/ProtectedResourceAccessTokenService.md), [ProtectedResourceProcessingFilter_DraftHammer](/components/security/ProtectedResourceProcessingFilter_DraftHammer.md).
