---
type: Dependency
title: com.sun.jersey:jersey-client
description: Third-party library com.sun.jersey:jersey-client at 1.10 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.sun.jersey/jersey-client
tags: [dependency, external]
status: draft
artifact_id: jersey-client
group_id: com.sun.jersey
scope: compile
version: "1.10"
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.sun.jersey:jersey-client:1.10`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
