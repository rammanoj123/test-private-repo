---
type: Dependency
title: org.springframework:spring-aop
description: Third-party library org.springframework:spring-aop at ${spring.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework/spring-aop
tags: [dependency, external]
status: draft
artifact_id: spring-aop
group_id: org.springframework
scope: compile
version: ${spring.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.springframework:spring-aop:${spring.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.springframework:spring-aop` is used from 14 classes (18 import site(s)), in the service, security, exception layer(s). Of everything it ships, this service reaches 9 package(s).

What is used:
- `org.springframework.beans.factory.annotation.Autowired`
- `org.springframework.beans.factory.annotation.Configurable`
- `org.springframework.context.ApplicationContext`
- `org.springframework.context.support.ClassPathXmlApplicationContext`
- `org.springframework.context.support.MessageSourceAccessor`
- `org.springframework.dao.DataAccessException`
- `org.springframework.mock.web.MockFilterChain`
- `org.springframework.mock.web.MockHttpServletRequest`
- `org.springframework.mock.web.MockHttpServletResponse`
- `org.springframework.stereotype.Component`
- `org.springframework.transaction.PlatformTransactionManager`
- `org.springframework.transaction.annotation.Transactional`
- …and 1 more type(s)

Used by: [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md), `ExceptionTranslationFilterTest`, [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md), [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md), [WpConfigurationServiceProvider](/components/services/WpConfigurationServiceProvider.md), [EmailAddressResource](/components/controllers/EmailAddressResource.md), `WhiteListEntryResourceTest`, [BasicAuthenticationFilter](/components/security/BasicAuthenticationFilter.md), `BasicAuthenticationFilterTest`, [EPrintUserDetailsService](/components/services/EPrintUserDetailsService.md), [ExceptionTranslationFilter](/components/exceptions/ExceptionTranslationFilter.md), [ProtectedResourceAccessTokenService](/components/services/ProtectedResourceAccessTokenService.md) (+2 more).
