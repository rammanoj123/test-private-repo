---
type: Dependency
title: mysql:mysql-connector-java
description: Third-party library mysql:mysql-connector-java at 8.0.11 on the compile classpath.
resource: https://central.sonatype.com/artifact/mysql/mysql-connector-java
tags: [dependency, external]
status: draft
artifact_id: mysql-connector-java
group_id: mysql
scope: compile
version: 8.0.11
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `mysql:mysql-connector-java:8.0.11`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
