---
type: Dependency
title: org.aspectj:aspectjrt
description: Third-party library org.aspectj:aspectjrt at 1.9.20.1 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.aspectj/aspectjrt
tags: [dependency, external]
status: draft
artifact_id: aspectjrt
group_id: org.aspectj
scope: compile
version: 1.9.20.1
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.aspectj:aspectjrt:1.9.20.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
