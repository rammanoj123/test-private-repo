---
type: Dependency
title: org.mockito:mockito-core
description: Third-party library org.mockito:mockito-core at 5.8.0 on the test classpath.
resource: https://central.sonatype.com/artifact/org.mockito/mockito-core
tags: [dependency, external]
status: draft
artifact_id: mockito-core
group_id: org.mockito
scope: test
version: 5.8.0
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.mockito:mockito-core:5.8.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.mockito:mockito-core` is used from 24 classes (84 import site(s)), in the unknown, config, exception layer(s). Of everything it ships, this service reaches 7 package(s).

What is used:
- `org.mockito`
- `org.mockito.ArgumentCaptor`
- `org.mockito.ArgumentMatcher`
- `org.mockito.InjectMocks`
- `org.mockito.Matchers.argThat`
- `org.mockito.Mock`
- `org.mockito.Mockito`
- `org.mockito.Mockito.doReturn`
- `org.mockito.Mockito.doThrow`
- `org.mockito.Mockito.mock`
- `org.mockito.Mockito.never`
- `org.mockito.Mockito.times`
- …and 6 more type(s)

Used by: `EPrintCenterResourceTest`, `ExceptionTranslationFilterTest`, `OwnerAccessProcessorTest`, `CDCASubscriptionResourceTest`, `CloudConfigurationResourceTest`, `ConsumableSubscriptionConfigResourceTest`, `DeviceOwnershipResourceTest`, `EmailAddressResourceTest`, `OptInConfigResourceTest`, `OptinInkLevelResourceTest`, `OptinScheduleResourceTest`, `OptinSuppliesInfoResourceTest` (+12 more).
