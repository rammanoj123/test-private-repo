---
type: Dependency
title: org.testng:testng
description: Third-party library org.testng:testng at ${testng.version} on the test classpath.
resource: https://central.sonatype.com/artifact/org.testng/testng
tags: [dependency, external]
status: draft
artifact_id: testng
group_id: org.testng
scope: test
version: ${testng.version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.testng:testng:${testng.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.testng:testng` is used from 27 classes (79 import site(s)), in the unknown, config, exception layer(s). Of everything it ships, this service reaches 3 package(s).

What is used:
- `org.testng.Assert`
- `org.testng.Assert.assertEquals`
- `org.testng.Assert.fail`
- `org.testng.annotations.BeforeClass`
- `org.testng.annotations.BeforeMethod`
- `org.testng.annotations.BeforeTest`
- `org.testng.annotations.DataProvider`
- `org.testng.annotations.Test`

Used by: `EPrintCenterResourceTest`, `ExceptionTranslationFilterTest`, `EprintCenterHealthControllerTest`, `OwnerAccessProcessorTest`, `CDCASubscriptionResourceTest`, `CloudConfigurationResourceTest`, `ConsumableSubscriptionConfigResourceTest`, `DeviceOwnershipResourceTest`, `EmailAddressResourceTest`, `OptInConfigResourceTest`, `OptinInkLevelResourceTest`, `OptinScheduleResourceTest` (+15 more).
