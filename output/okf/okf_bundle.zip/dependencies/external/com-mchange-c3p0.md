---
type: Dependency
title: com.mchange:c3p0
description: Third-party library com.mchange:c3p0 at 0.9.5.5 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.mchange/c3p0
tags: [dependency, external]
status: draft
artifact_id: c3p0
group_id: com.mchange
scope: compile
version: 0.9.5.5
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.mchange:c3p0:0.9.5.5`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`com.mchange:c3p0` is used from 3 classes (3 import site(s)), in the controller, config layer(s). Of everything it ships, this service reaches 2 package(s).

What is used:
- `com.mchange.util.AssertException`
- `com.mchange.v2.c3p0.ComboPooledDataSource`

Used by: [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md), `EprintCenterHealthControllerTest`, `CloudConfigurationResourceTest`.
