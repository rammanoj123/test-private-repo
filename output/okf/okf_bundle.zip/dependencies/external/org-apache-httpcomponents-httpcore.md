---
type: Dependency
title: org.apache.httpcomponents:httpcore
description: Third-party library org.apache.httpcomponents:httpcore at 4.4.13 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.apache.httpcomponents/httpcore
tags: [dependency, external]
status: draft
artifact_id: httpcore
group_id: org.apache.httpcomponents
scope: compile
version: 4.4.13
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.apache.httpcomponents:httpcore:4.4.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
