---
type: Dependency
title: org.apache.commons:commons-configuration2
description: Third-party library org.apache.commons:commons-configuration2 at 2.9.0 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.apache.commons/commons-configuration2
tags: [dependency, external]
status: draft
artifact_id: commons-configuration2
group_id: org.apache.commons
scope: compile
version: 2.9.0
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.apache.commons:commons-configuration2:2.9.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

`org.apache.commons:commons-configuration2` is used from 19 classes (32 import site(s)), in the unknown, controller, security layer(s). Of everything it ships, this service reaches 7 package(s).

What is used:
- `org.apache.commons.codec.binary.Base64`
- `org.apache.commons.configuration.ConfigurationException`
- `org.apache.commons.configuration.XMLConfiguration`
- `org.apache.commons.httpclient.Header`
- `org.apache.commons.httpclient.HttpClient`
- `org.apache.commons.httpclient.HttpException`
- `org.apache.commons.httpclient.methods.DeleteMethod`
- `org.apache.commons.httpclient.methods.GetMethod`
- `org.apache.commons.httpclient.methods.PostMethod`
- `org.apache.commons.httpclient.methods.PutMethod`
- `org.apache.commons.httpclient.methods.RequestEntity`
- `org.apache.commons.httpclient.methods.StringRequestEntity`
- …and 5 more type(s)

Used by: `HttpsTest`, [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md), [OutEmailHelper](/components/misc/OutEmailHelper.md), [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md), [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md), `CDCASubscriptionResourceTest`, [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md), [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md), `OptinInkLevelResourceTest`, `OptinSuppliesInfoResourceTest`, [OwnerShipsResource](/components/controllers/OwnerShipsResource.md), [PrinterResource](/components/controllers/PrinterResource.md) (+7 more).
