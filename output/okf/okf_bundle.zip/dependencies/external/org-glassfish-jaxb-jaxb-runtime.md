---
type: Dependency
title: org.glassfish.jaxb:jaxb-runtime
description: Third-party library org.glassfish.jaxb:jaxb-runtime at 4.0.4 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.glassfish.jaxb/jaxb-runtime
tags: [dependency, external]
status: draft
artifact_id: jaxb-runtime
group_id: org.glassfish.jaxb
scope: compile
version: 4.0.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `org.glassfish.jaxb:jaxb-runtime:4.0.4`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
