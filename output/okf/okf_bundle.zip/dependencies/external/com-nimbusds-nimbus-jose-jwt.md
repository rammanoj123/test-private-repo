---
type: Dependency
title: com.nimbusds:nimbus-jose-jwt
description: Third-party library com.nimbusds:nimbus-jose-jwt at 9.25.1 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.nimbusds/nimbus-jose-jwt
tags: [dependency, external]
status: draft
artifact_id: nimbus-jose-jwt
group_id: com.nimbusds
scope: compile
version: 9.25.1
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.nimbusds:nimbus-jose-jwt:9.25.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Not imported anywhere in this service's main source. Declared as a dependency. It is reached at runtime, or through configuration, or is no longer needed — the source does not name it.
