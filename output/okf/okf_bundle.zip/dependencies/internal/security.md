---
type: Internal Library
title: security
description: Internal library security.
tags: [dependency, internal, library]
status: draft
artifact_id: security
depends_on_bundle: hp/security
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:security:25.1.4`.

# Used by

4 class(es) in this service import `security` (4 import site(s)):

- [ConsumerDetailServiceProvider](/components/services/ConsumerDetailServiceProvider.md) — `com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider`
- [EPrintUserDetailsService](/components/services/EPrintUserDetailsService.md) — `com.hp.cloudprint.api.eprintcenter.security.EPrintUserDetailsService`
- [ProtectedResourceAccessTokenService](/components/services/ProtectedResourceAccessTokenService.md) — `com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService`
- [ShardPersistenceFilter](/components/security/ShardPersistenceFilter.md) — `com.hp.cloudprint.api.eprintcenter.security.ShardPersistenceFilter`

Packages reached: `com.hp.cloudprint.security`.
Used from: service (3), security (1).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/security`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
