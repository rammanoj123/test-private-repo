---
type: Internal Library
title: util
description: Internal library util.
tags: [dependency, internal, library]
status: draft
artifact_id: util
depends_on_bundle: hp/util
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:util:25.1.4`.

# Used by

59 class(es) in this service import `util` (206 import site(s)):

- `HttpsTest` — `HttpsTest`
- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md) — `com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`
- `EPrintCenterResourceTest` — `com.hp.cloudprint.api.eprintcenter.EPrintCenterResourceTest`
- `JaxbUnmarshallTest` — `com.hp.cloudprint.api.eprintcenter.JaxbUnmarshallTest`
- [InvalidUUIDException](/components/exceptions/InvalidUUIDException.md) — `com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`
- [BlackListsHandler](/components/controllers/BlackListsHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`
- [WhitelistHandler](/components/controllers/WhitelistHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`
- [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`
- [OutEmailHelper](/components/misc/OutEmailHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`
- [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper`
- [SortingAndPaginationHelper](/components/misc/SortingAndPaginationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`
- [OwnershipStatusServiceImpl](/components/services/OwnershipStatusServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`
- [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`
- [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md) — `com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`
- [OwnerAccessProcessor](/components/misc/OwnerAccessProcessor.md) — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`
- [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`
- [AvailabilityResource](/components/controllers/AvailabilityResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`
- [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`
- `CDCASubscriptionResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResourceTest`
- [CancelPrintResource](/components/controllers/CancelPrintResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`
- [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- `ConsumableSubscriptionConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResourceTest`
- [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`
- [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`
- [EmailAddressResource](/components/controllers/EmailAddressResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- `OptInConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResourceTest`
- [OptInScheduleResource](/components/controllers/OptInScheduleResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`
- [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`
- `OptinInkLevelResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResourceTest`
- [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`
- `OptinSuppliesInfoResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResourceTest`
- [OwnerShipResource](/components/controllers/OwnerShipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`
- [OwnerShipsResource](/components/controllers/OwnerShipsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`
- `OwnerShipsResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResourceTest`
- [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`
- [PrintJobsResource](/components/controllers/PrintJobsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`
- `PrintJobsResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResourceTest`
- [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`
- …and 19 more

Packages reached: `com.hp.cloudprint.util`, `com.hp.cloudprint.util.config`, `com.hp.cloudprint.util.logging`, `com.hp.cloudprint.util.url`.
Used from: controller (148), unknown (30), security (14), service (9), config (3).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/util`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
