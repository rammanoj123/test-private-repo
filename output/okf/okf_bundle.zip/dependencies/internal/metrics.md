---
type: Internal Library
title: metrics
description: Internal library metrics.
tags: [dependency, internal, library]
status: draft
artifact_id: metrics
depends_on_bundle: hp/metrics
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:metrics:25.1.4`.

# Used by

27 class(es) in this service import `metrics` (27 import site(s)):

- [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`
- [AvailabilityResource](/components/controllers/AvailabilityResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`
- [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`
- [CancelPrintResource](/components/controllers/CancelPrintResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`
- [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`
- [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`
- [EmailAddressResource](/components/controllers/EmailAddressResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- [OptInScheduleResource](/components/controllers/OptInScheduleResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`
- [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`
- [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`
- [OwnerShipResource](/components/controllers/OwnerShipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`
- [OwnerShipsResource](/components/controllers/OwnerShipsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`
- [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`
- [PrintJobsResource](/components/controllers/PrintJobsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`
- [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`
- [PrinterOwnerResource](/components/controllers/PrinterOwnerResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`
- [PrinterResource](/components/controllers/PrinterResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterResource`
- [PrinterStatusResource](/components/controllers/PrinterStatusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`
- [PrinterSupportedProcessingElementsResource](/components/controllers/PrinterSupportedProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource`
- [SolutionOptInResource](/components/controllers/SolutionOptInResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource`
- [SuggestionsResource](/components/controllers/SuggestionsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource`
- [VersionResource](/components/controllers/VersionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.VersionResource`
- [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource`
- [WhiteListResource](/components/controllers/WhiteListResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.WhiteListResource`

Packages reached: `com.hp.cloudprint.metrics`.
Used from: controller (27).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/metrics`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
