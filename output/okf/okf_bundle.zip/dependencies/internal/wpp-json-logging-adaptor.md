---
type: Internal Library
title: wpp-json-logging-adaptor
description: Internal library wpp-json-logging-adaptor.
tags: [dependency, internal, library]
status: draft
artifact_id: wpp-json-logging-adaptor
depends_on_bundle: hp/wpp-json-logging-adaptor
group_id: com.hp.wpp
scope: compile
version: 1.0.13
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.wpp:wpp-json-logging-adaptor:1.0.13`.

# Used by

29 class(es) in this service import `wpp-json-logging-adaptor` (31 import site(s)):

- [LoggingInitializer](/components/misc/LoggingInitializer.md) — `com.hp.cloudprint.LoggingInitializer`
- [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md) — `com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`
- [OwnerAccessProcessor](/components/misc/OwnerAccessProcessor.md) — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`
- [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`
- [AvailabilityResource](/components/controllers/AvailabilityResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`
- [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`
- [CancelPrintResource](/components/controllers/CancelPrintResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`
- [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`
- [EmailAddressResource](/components/controllers/EmailAddressResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- [OptInScheduleResource](/components/controllers/OptInScheduleResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`
- [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`
- [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`
- [OwnerShipResource](/components/controllers/OwnerShipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`
- [OwnerShipsResource](/components/controllers/OwnerShipsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`
- [PrintJobsResource](/components/controllers/PrintJobsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`
- [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`
- [PrinterResource](/components/controllers/PrinterResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterResource`
- [PrinterStatusResource](/components/controllers/PrinterStatusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`
- [PrinterSupportedProcessingElementsResource](/components/controllers/PrinterSupportedProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource`
- [SolutionOptInResource](/components/controllers/SolutionOptInResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource`
- [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource`
- [WhiteListResource](/components/controllers/WhiteListResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.WhiteListResource`
- [LoggingConfig](/components/config/LoggingConfig.md) — `com.hp.cloudprint.config.LoggingConfig`
- [CalypsoClientImpl](/components/misc/CalypsoClientImpl.md) — `com.hp.cloudprint.http.clients.CalypsoClientImpl`
- [StratusClientImpl](/components/misc/StratusClientImpl.md) — `com.hp.cloudprint.http.clients.StratusClientImpl`
- [StratusHttpClient](/components/misc/StratusHttpClient.md) — `com.hp.cloudprint.http.clients.StratusHttpClient`

Packages reached: `com.hp.wpp.common.jsonlogging.control`, `com.hp.wpp.common.jsonlogging.servicelog`.
Used from: controller (23), unknown (6), config (2).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wpp-json-logging-adaptor`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
