---
type: Internal Library
title: entities
description: Internal library entities.
tags: [dependency, internal, library]
status: draft
artifact_id: entities
depends_on_bundle: hp/entities
group_id: com.hp.cloudprint
scope: compile
version: 25.3.5
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:entities:25.3.5`.

# Used by

51 class(es) in this service import `entities` (154 import site(s)):

- [EntityConverter](/domain/EntityConverter.md) — `com.hp.cloudprint.api.eprintcenter.EntityConverter`
- [BlackListsHandler](/components/controllers/BlackListsHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`
- [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`
- [SortingAndPaginationHelper](/components/misc/SortingAndPaginationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`
- [OwnershipUserService](/components/services/OwnershipUserService.md) — `com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`
- [OwnershipStatusServiceImpl](/components/services/OwnershipStatusServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`
- [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`
- [OwnerAccessProcessor](/components/misc/OwnerAccessProcessor.md) — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`
- `OwnerAccessProcessorTest` — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessorTest`
- [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`
- [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`
- `CDCASubscriptionResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResourceTest`
- [CancelPrintResource](/components/controllers/CancelPrintResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`
- [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`
- `CloudConfigurationResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResourceTest`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- `ConsumableSubscriptionConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResourceTest`
- [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`
- `DeviceOwnershipResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResourceTest`
- [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`
- [EmailAddressResource](/components/controllers/EmailAddressResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`
- `EmailAddressResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResourceTest`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- `OptInConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResourceTest`
- [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`
- `OptinInkLevelResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResourceTest`
- [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`
- `OptinSuppliesInfoResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResourceTest`
- [OwnerShipResource](/components/controllers/OwnerShipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`
- [OwnerShipsResource](/components/controllers/OwnerShipsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`
- `OwnerShipsResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResourceTest`
- `OwnershipStatusResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResourceTest`
- [PrintJobsResource](/components/controllers/PrintJobsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`
- `PrintJobsResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResourceTest`
- [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`
- [PrinterOwnerResource](/components/controllers/PrinterOwnerResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`
- `PrinterOwnerResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResourceTest`
- [PrinterResource](/components/controllers/PrinterResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterResource`
- `PrinterResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.PrinterResourceTest`
- [PrinterStatusResource](/components/controllers/PrinterStatusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`
- …and 11 more

Packages reached: `com.hp.cloudprint.entities`, `com.hp.cloudprint.entities.common`, `com.hp.cloudprint.entities.common.Enums`, `com.hp.cloudprint.entities.common.utils`, `com.hp.cloudprint.entities.dao`, `com.hp.cloudprint.entities.dao.SearchJobCriteria`, `com.hp.cloudprint.entities.dm`, `com.hp.cloudprint.entities.exception`.
Used from: controller (76), unknown (63), config (6), service (5), entity (3).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/entities`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
