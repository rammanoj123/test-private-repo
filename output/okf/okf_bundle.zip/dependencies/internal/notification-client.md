---
type: Internal Library
title: notification-client
description: Internal library notification-client.
tags: [dependency, internal, library]
status: draft
artifact_id: notification-client
depends_on_bundle: hp/notification-client
group_id: com.hp.cloudprint
scope: compile
version: 25.2.3
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:notification-client:25.2.3`.

# Used by

1 class(es) in this service import `notification-client` (1 import site(s)):

- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`

Packages reached: `com.hp.cloudprint.notification.client`.
Used from: controller (1).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/notification-client`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
