---
type: Internal Library
title: wp-common-web
description: Internal library wp-common-web.
tags: [dependency, internal, library]
status: draft
artifact_id: wp-common-web
depends_on_bundle: hp/wp-common-web
group_id: com.hp.iws.wpp
scope: compile
version: ${wp-common-version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.iws.wpp:wp-common-web:${wp-common-version}`.

# Used by

No compile-time usage found in this bundle: no class in this service imports it — it may be used only at runtime, through reflection or configuration, or be an inherited transitive dependency; note its package set was inferred from the coordinate because the jar was not in the local repository, so an unconventional package layout would not have matched.

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wp-common-web`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
