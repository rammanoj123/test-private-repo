---
type: Internal Library
title: printerlist-schema
description: Internal library printerlist-schema.
tags: [dependency, internal, library]
status: draft
artifact_id: printerlist-schema
depends_on_bundle: hp/printerlist-schema
group_id: com.hp.ipg.iws.wp
scope: compile
version: ${ukas-wp-version}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.ipg.iws.wp:printerlist-schema:${ukas-wp-version}`.

# Used by

11 class(es) in this service import `printerlist-schema` (12 import site(s)):

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md) — `com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`
- [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md) — `com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`
- [WpConfigurationServiceProvider](/components/services/WpConfigurationServiceProvider.md) — `com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- `ConsumableSubscriptionConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResourceTest`
- `EmailAddressResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResourceTest`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- `OptInConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResourceTest`
- [BasicAuthenticationFilter](/components/security/BasicAuthenticationFilter.md) — `com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilter`
- `BasicAuthenticationFilterTest` — `com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilterTest`
- `CalypsoClientImplTest` — `com.hp.cloudprint.http.clients.CalypsoClientImplTest`

Packages reached: `com.hp.ipg.iws.wp.common.config`.
Used from: controller (4), config (3), security (2), unknown (2), service (1).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/printerlist-schema`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
