---
type: Internal Library
title: eprintcenter-schema
description: Internal library eprintcenter-schema.
tags: [dependency, internal, library]
status: draft
artifact_id: eprintcenter-schema
depends_on_bundle: hp/eprintcenter-schema
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:eprintcenter-schema:25.1.4`.

# Used by

No compile-time usage found in this bundle: no class in this service imports it — it may be used only at runtime, through reflection or configuration, or be an inherited transitive dependency; note its package set was inferred from the coordinate because the jar was not in the local repository, so an unconventional package layout would not have matched.

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/eprintcenter-schema`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
