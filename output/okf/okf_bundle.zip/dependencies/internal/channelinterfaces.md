---
type: Internal Library
title: channelinterfaces
description: Internal library channelinterfaces.
tags: [dependency, internal, library]
status: draft
artifact_id: channelinterfaces
depends_on_bundle: hp/channelinterfaces
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

Maven coordinate: `com.hp.cloudprint:channelinterfaces:25.1.4`.

# Used by

82 class(es) in this service import `channelinterfaces` (713 import site(s)):

- `HttpsTest` — `HttpsTest`
- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md) — `com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`
- `EPrintCenterResourceTest` — `com.hp.cloudprint.api.eprintcenter.EPrintCenterResourceTest`
- [EntityConverter](/domain/EntityConverter.md) — `com.hp.cloudprint.api.eprintcenter.EntityConverter`
- `ExceptionTranslationFilterTest` — `com.hp.cloudprint.api.eprintcenter.ExceptionTranslationFilterTest`
- `JaxbUnmarshallTest` — `com.hp.cloudprint.api.eprintcenter.JaxbUnmarshallTest`
- [Utility](/components/misc/Utility.md) — `com.hp.cloudprint.api.eprintcenter.Utility`
- [InvalidUUIDException](/components/exceptions/InvalidUUIDException.md) — `com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`
- [BlackListHandler](/components/controllers/BlackListHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`
- [BlackListsHandler](/components/controllers/BlackListsHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`
- [WhitelistHandler](/components/controllers/WhitelistHandler.md) — `com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`
- [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`
- [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper`
- [SortingAndPaginationHelper](/components/misc/SortingAndPaginationHelper.md) — `com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`
- [OwnershipStatusService](/components/services/OwnershipStatusService.md) — `com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipStatusService`
- [OwnershipUserService](/components/services/OwnershipUserService.md) — `com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`
- [OwnershipStatusServiceImpl](/components/services/OwnershipStatusServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`
- [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md) — `com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`
- [EprintCenterHealthController](/components/controllers/EprintCenterHealthController.md) — `com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`
- `EprintCenterHealthControllerTest` — `com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthControllerTest`
- [OwnerAccessProcessor](/components/misc/OwnerAccessProcessor.md) — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`
- `OwnerAccessProcessorTest` — `com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessorTest`
- [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`
- [AvailabilityResource](/components/controllers/AvailabilityResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`
- [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`
- `CDCASubscriptionResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResourceTest`
- [CancelPrintResource](/components/controllers/CancelPrintResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`
- [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`
- `CloudConfigurationResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResourceTest`
- [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`
- `ConsumableSubscriptionConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResourceTest`
- [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`
- `DeviceOwnershipResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResourceTest`
- [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`
- [EmailAddressResource](/components/controllers/EmailAddressResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`
- `EmailAddressResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResourceTest`
- [OptInConfigResource](/components/controllers/OptInConfigResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`
- `OptInConfigResourceTest` — `com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResourceTest`
- [OptInScheduleResource](/components/controllers/OptInScheduleResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`
- [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md) — `com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`
- …and 42 more

Packages reached: `com.hp.cloudprint.api.annotations`, `com.hp.cloudprint.api.base`, `com.hp.cloudprint.api.entities`, `com.hp.cloudprint.api.eprintcenter`, `com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`, `com.hp.cloudprint.api.eprintcenter.Utility`, `com.hp.cloudprint.api.eprintcenter.dm`, `com.hp.cloudprint.api.eprintcenter.dm.helper` (+43 more).
Used from: controller (416), unknown (214), service (35), config (24), entity (10).

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/channelinterfaces`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
