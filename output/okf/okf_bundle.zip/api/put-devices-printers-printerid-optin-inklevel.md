---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/optin/inklevel/
description: Serves PUT /devices/printers/{PrinterID}/optin/inklevel/ through OptinInkLevelResource.handlePut.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, put]
status: draft
handler: OptinInkLevelResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | OptinInkLevelResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).
