---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/inklevel/
description: Serves GET /devices/printers/{PrinterID}/optin/inklevel/ through OptinInkLevelResource.handleGet.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, get]
status: draft
handler: OptinInkLevelResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | OptinInkLevelResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).
