---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/cDCA
description: Serves GET /devices/printers/{PrinterID}/optin/cDCA through CDCASubscriptionResource.handleGet.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, get]
status: draft
handler: CDCASubscriptionResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | CDCASubscriptionResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).

# Errors

- If printer is already opted in via v2 API, return 201 without updating
- If printer is opted in for different optin type, return 409 Conflict
