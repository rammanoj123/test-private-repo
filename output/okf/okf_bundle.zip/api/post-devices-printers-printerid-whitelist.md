---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/whitelist/
description: Serves POST /devices/printers/{PrinterID}/whitelist/ through WhiteListResource.handlePost.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, post]
status: draft
handler: WhiteListResource
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | WhiteListResource.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhiteListResource](/components/controllers/WhiteListResource.md).
