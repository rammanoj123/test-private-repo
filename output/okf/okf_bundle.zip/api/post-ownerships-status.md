---
type: API Endpoint
title: POST /ownerships/status
description: Serves POST /ownerships/status through OwnershipStatusResource.acceptRepresentation.
resource: /ownerships/status
tags: [api, endpoint, post]
status: draft
handler: OwnershipStatusResource
handler_method: acceptRepresentation
http_method: POST
http_path: /ownerships/status
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships/status` |
| Handler | OwnershipStatusResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).
