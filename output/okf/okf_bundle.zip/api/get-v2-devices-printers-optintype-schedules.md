---
type: API Endpoint
title: GET /v2/devices/printers/{optinType}/schedules
description: Serves GET /v2/devices/printers/{optinType}/schedules through OptInScheduleResource.handleGet.
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, get]
status: draft
handler: OptInScheduleResource
handler_method: handleGet
http_method: GET
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | OptInScheduleResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptInScheduleResource](/components/controllers/OptInScheduleResource.md).
