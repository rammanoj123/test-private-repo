---
type: API Endpoint
title: GET /ownerships/{OwnershipID}/
description: Serves GET /ownerships/{OwnershipID}/ through OwnerShipResource.represent.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, get]
status: draft
handler: OwnerShipResource
handler_method: represent
http_method: GET
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | OwnerShipResource.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnerShipResource](/components/controllers/OwnerShipResource.md).
