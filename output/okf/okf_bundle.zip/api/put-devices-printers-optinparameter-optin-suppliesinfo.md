---
type: API Endpoint
title: PUT /devices/printers/{optinParameter}/optin/suppliesinfo/
description: Serves PUT /devices/printers/{optinParameter}/optin/suppliesinfo/ through OptinSuppliesInfoResource.handlePut.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, put]
status: draft
handler: OptinSuppliesInfoResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | OptinSuppliesInfoResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).
