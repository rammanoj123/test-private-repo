---
type: API Endpoint
title: POST /devices/printers/ownerships
description: Serves POST /devices/printers/ownerships through DeviceOwnershipResource.acceptRepresentation.
resource: /devices/printers/ownerships
tags: [api, endpoint, post]
status: draft
handler: DeviceOwnershipResource
handler_method: acceptRepresentation
http_method: POST
http_path: /devices/printers/ownerships
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/ownerships` |
| Handler | DeviceOwnershipResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).
