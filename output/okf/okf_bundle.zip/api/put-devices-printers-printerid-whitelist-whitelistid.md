---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
description: Serves PUT /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ through WhiteListEntryResource.handlePut.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, put]
status: draft
handler: WhiteListEntryResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | WhiteListEntryResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md).
