---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/emailaddress/
description: Serves PUT /devices/printers/{PrinterID}/emailaddress/ through EmailAddressResource.handlePut.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, put]
status: draft
handler: EmailAddressResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | EmailAddressResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [EmailAddressResource](/components/controllers/EmailAddressResource.md).
