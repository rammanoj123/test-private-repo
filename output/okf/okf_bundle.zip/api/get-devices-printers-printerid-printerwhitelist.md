---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/printerwhitelist/
description: Serves GET /devices/printers/{PrinterID}/printerwhitelist/ through WhitelistHandler.handleGet.
resource: /devices/printers/{PrinterID}/printerwhitelist/
tags: [api, endpoint, get]
status: draft
handler: WhitelistHandler
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/printerwhitelist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printerwhitelist/` |
| Handler | WhitelistHandler.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhitelistHandler](/components/controllers/WhitelistHandler.md).
