---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/consumablesubscription/
description: Serves PUT /devices/printers/{PrinterID}/consumablesubscription/ through ConsumableSubscriptionConfigResource.handlePut.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, put]
status: draft
handler: ConsumableSubscriptionConfigResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | ConsumableSubscriptionConfigResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md).
