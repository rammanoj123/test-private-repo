---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/defaultprocessingelements/
description: Serves PUT /devices/printers/{PrinterID}/defaultprocessingelements/ through PrinterDefaultsProcessingElementsResource.handlePut.
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, put]
status: draft
handler: PrinterDefaultsProcessingElementsResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | PrinterDefaultsProcessingElementsResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md).
