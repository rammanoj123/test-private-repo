---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/blacklist/
description: Serves POST /devices/printers/{PrinterID}/blacklist/ through BlackListsHandler.handlePost.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, post]
status: draft
handler: BlackListsHandler
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | BlackListsHandler.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [BlackListsHandler](/components/controllers/BlackListsHandler.md).
