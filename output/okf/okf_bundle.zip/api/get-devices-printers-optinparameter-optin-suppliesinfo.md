---
type: API Endpoint
title: GET /devices/printers/{optinParameter}/optin/suppliesinfo/
description: Serves GET /devices/printers/{optinParameter}/optin/suppliesinfo/ through OptinSuppliesInfoResource.handleGet.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, get]
status: draft
handler: OptinSuppliesInfoResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | OptinSuppliesInfoResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).
