---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/whitelist/
description: Serves GET /devices/printers/{PrinterID}/whitelist/ through WhiteListResource.handleGet.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, get]
status: draft
handler: WhiteListResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | WhiteListResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhiteListResource](/components/controllers/WhiteListResource.md).
