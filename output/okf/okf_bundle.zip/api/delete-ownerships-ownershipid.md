---
type: API Endpoint
title: DELETE /ownerships/{OwnershipID}/
description: Serves DELETE /ownerships/{OwnershipID}/ through OwnerShipResource.removeRepresentations.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, delete]
status: draft
handler: OwnerShipResource
handler_method: removeRepresentations
http_method: DELETE
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | OwnerShipResource.removeRepresentations |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnerShipResource](/components/controllers/OwnerShipResource.md).
