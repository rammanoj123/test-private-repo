---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/emailaddress/availability/
description: Serves POST /devices/printers/{PrinterID}/emailaddress/availability/ through AvailabilityResource.handlePost.
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, post]
status: draft
handler: AvailabilityResource
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | AvailabilityResource.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [AvailabilityResource](/components/controllers/AvailabilityResource.md).
