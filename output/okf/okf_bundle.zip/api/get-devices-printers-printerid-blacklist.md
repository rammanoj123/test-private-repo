---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/blacklist/
description: Serves GET /devices/printers/{PrinterID}/blacklist/ through BlackListsHandler.handleGet.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, get]
status: draft
handler: BlackListsHandler
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | BlackListsHandler.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [BlackListsHandler](/components/controllers/BlackListsHandler.md).
