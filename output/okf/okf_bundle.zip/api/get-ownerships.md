---
type: API Endpoint
title: GET /ownerships
description: Serves GET /ownerships through OwnerShipsResource.handleGet.
resource: /ownerships
tags: [api, endpoint, get]
status: draft
handler: OwnerShipsResource
handler_method: handleGet
http_method: GET
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships` |
| Handler | OwnerShipsResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).
