---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/cloudconfiguration/
description: Serves PUT /devices/printers/{PrinterID}/cloudconfiguration/ through CloudConfigurationResource.handlePut.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, put]
status: draft
handler: CloudConfigurationResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | CloudConfigurationResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md).
