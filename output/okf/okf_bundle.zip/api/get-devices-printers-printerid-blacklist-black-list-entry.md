---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
description: Serves GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} through BlackListHandler.handleGet.
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, get]
status: draft
handler: BlackListHandler
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | BlackListHandler.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [BlackListHandler](/components/controllers/BlackListHandler.md).
