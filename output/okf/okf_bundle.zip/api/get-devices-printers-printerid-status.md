---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/status/
description: Serves GET /devices/printers/{PrinterID}/status/ through PrinterStatusResource.handleGet.
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, get]
status: draft
handler: PrinterStatusResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/status/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | PrinterStatusResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).
