---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/consumablesubscription/
description: Serves GET /devices/printers/{PrinterID}/consumablesubscription/ through ConsumableSubscriptionConfigResource.handleGet.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, get]
status: draft
handler: ConsumableSubscriptionConfigResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | ConsumableSubscriptionConfigResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md).
