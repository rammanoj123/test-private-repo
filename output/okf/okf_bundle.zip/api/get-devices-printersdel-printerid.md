---
type: API Endpoint
title: GET /devices/printersDel/{PrinterID}/
description: Serves GET /devices/printersDel/{PrinterID}/ through PrinterResource.handleGet.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, get]
status: draft
handler: PrinterResource
handler_method: handleGet
http_method: GET
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | PrinterResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterResource](/components/controllers/PrinterResource.md).
