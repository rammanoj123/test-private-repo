---
type: API Endpoint
title: PUT /jobs/printjobs/{JobID}/cancel/
description: Serves PUT /jobs/printjobs/{JobID}/cancel/ through CancelPrintResource.handlePut.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, put]
status: draft
handler: CancelPrintResource
handler_method: handlePut
http_method: PUT
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | CancelPrintResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CancelPrintResource](/components/controllers/CancelPrintResource.md).
