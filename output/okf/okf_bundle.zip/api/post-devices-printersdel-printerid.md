---
type: API Endpoint
title: POST /devices/printersDel/{PrinterID}/
description: Serves POST /devices/printersDel/{PrinterID}/ through PrinterResource.acceptRepresentation.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, post]
status: draft
handler: PrinterResource
handler_method: acceptRepresentation
http_method: POST
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | PrinterResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterResource](/components/controllers/PrinterResource.md).
