---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/optin/cDCA
description: Serves DELETE /devices/printers/{PrinterID}/optin/cDCA through CDCASubscriptionResource.handleDelete.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, delete]
status: draft
handler: CDCASubscriptionResource
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | CDCASubscriptionResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).

# Errors

- If printer is already opted in via v2 API, return 201 without updating
- If printer is opted in for different optin type, return 409 Conflict
