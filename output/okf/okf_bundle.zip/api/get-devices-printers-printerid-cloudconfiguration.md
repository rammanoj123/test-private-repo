---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/cloudconfiguration/
description: Serves GET /devices/printers/{PrinterID}/cloudconfiguration/ through CloudConfigurationResource.handleGet.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, get]
status: draft
handler: CloudConfigurationResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | CloudConfigurationResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md).
