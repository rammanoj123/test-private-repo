---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
description: Serves DELETE /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ through WhiteListEntryResource.handleDelete.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, delete]
status: draft
handler: WhiteListEntryResource
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | WhiteListEntryResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md).
