---
type: API Endpoint
title: DELETE /v2/devices/printers/{PrinterID}/optin/{optinType}
description: Serves DELETE /v2/devices/printers/{PrinterID}/optin/{optinType} through SolutionOptInResource.handleDelete.
resource: /v2/devices/printers/{PrinterID}/optin/{optinType}
tags: [api, endpoint, delete]
status: draft
handler: SolutionOptInResource
handler_method: handleDelete
http_method: DELETE
http_path: /v2/devices/printers/{PrinterID}/optin/{optinType}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/v2/devices/printers/{PrinterID}/optin/{optinType}` |
| Handler | SolutionOptInResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).
