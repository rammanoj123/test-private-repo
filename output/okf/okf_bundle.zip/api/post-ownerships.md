---
type: API Endpoint
title: POST /ownerships
description: Serves POST /ownerships through OwnerShipsResource.acceptRepresentation.
resource: /ownerships
tags: [api, endpoint, post]
status: draft
handler: OwnerShipsResource
handler_method: acceptRepresentation
http_method: POST
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships` |
| Handler | OwnerShipsResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).
