---
type: API Endpoint
title: GET /v2/devices/printers/{PrinterID}/optin/{optinType}
description: Serves GET /v2/devices/printers/{PrinterID}/optin/{optinType} through SolutionOptInResource.handleGet.
resource: /v2/devices/printers/{PrinterID}/optin/{optinType}
tags: [api, endpoint, get]
status: draft
handler: SolutionOptInResource
handler_method: handleGet
http_method: GET
http_path: /v2/devices/printers/{PrinterID}/optin/{optinType}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v2/devices/printers/{PrinterID}/optin/{optinType}` |
| Handler | SolutionOptInResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).
