---
type: API Endpoint
title: PUT /v2/devices/printers/{PrinterID}/optin/{optinType}
description: Serves PUT /v2/devices/printers/{PrinterID}/optin/{optinType} through SolutionOptInResource.handlePut.
resource: /v2/devices/printers/{PrinterID}/optin/{optinType}
tags: [api, endpoint, put]
status: draft
handler: SolutionOptInResource
handler_method: handlePut
http_method: PUT
http_path: /v2/devices/printers/{PrinterID}/optin/{optinType}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/v2/devices/printers/{PrinterID}/optin/{optinType}` |
| Handler | SolutionOptInResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).
