---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/emailaddress/
description: Serves POST /devices/printers/{PrinterID}/emailaddress/ through EmailAddressResource.handlePost.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, post]
status: draft
handler: EmailAddressResource
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | EmailAddressResource.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [EmailAddressResource](/components/controllers/EmailAddressResource.md).
