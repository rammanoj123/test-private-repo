---
type: API Endpoint
title: PUT /devices/printers
description: Serves PUT /devices/printers through PrinterResource.storeRepresentation.
resource: /devices/printers
tags: [api, endpoint, put]
status: draft
handler: PrinterResource
handler_method: storeRepresentation
http_method: PUT
http_path: /devices/printers
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers` |
| Handler | PrinterResource.storeRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterResource](/components/controllers/PrinterResource.md).
