---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/supportedprocessingelements/
description: Serves GET /devices/printers/{PrinterID}/supportedprocessingelements/ through PrinterSupportedProcessingElementsResource.handleGet.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, get]
status: draft
handler: PrinterSupportedProcessingElementsResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | PrinterSupportedProcessingElementsResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterSupportedProcessingElementsResource](/components/controllers/PrinterSupportedProcessingElementsResource.md).
