---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/
description: Serves DELETE /devices/printers/{PrinterID}/ through PrinterResource.handleDelete.
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, delete]
status: draft
handler: PrinterResource
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | PrinterResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterResource](/components/controllers/PrinterResource.md).
