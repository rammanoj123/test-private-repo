---
type: API Endpoint
title: PUT /ownerships
description: Serves PUT /ownerships through OwnerShipsResource.storeRepresentation.
resource: /ownerships
tags: [api, endpoint, put]
status: draft
handler: OwnerShipsResource
handler_method: storeRepresentation
http_method: PUT
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/ownerships` |
| Handler | OwnerShipsResource.storeRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).
