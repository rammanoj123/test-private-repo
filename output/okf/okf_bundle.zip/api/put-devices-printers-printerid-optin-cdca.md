---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/optin/cDCA
description: Serves PUT /devices/printers/{PrinterID}/optin/cDCA through CDCASubscriptionResource.handlePut.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, put]
status: draft
handler: CDCASubscriptionResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | CDCASubscriptionResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).
