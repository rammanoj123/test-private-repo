---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/emailaddress/suggestions/
description: Serves POST /devices/printers/{PrinterID}/emailaddress/suggestions/ through SuggestionsResource.handlePost.
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, post]
status: draft
handler: SuggestionsResource
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SuggestionsResource.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [SuggestionsResource](/components/controllers/SuggestionsResource.md).
