---
type: API Endpoint
title: GET /version/
description: Serves GET /version/ through VersionResource.handleGet.
resource: /version/
tags: [api, endpoint, get]
status: draft
handler: VersionResource
handler_method: handleGet
http_method: GET
http_path: /version/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/version/` |
| Handler | VersionResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [VersionResource](/components/controllers/VersionResource.md).
