---
type: API Endpoint
title: DELETE /devices/printers/{optinParameter}/optin/suppliesinfo/
description: Serves DELETE /devices/printers/{optinParameter}/optin/suppliesinfo/ through OptinSuppliesInfoResource.handleDelete.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, delete]
status: draft
handler: OptinSuppliesInfoResource
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | OptinSuppliesInfoResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).
