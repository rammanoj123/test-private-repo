---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/
description: Serves PUT /devices/printers/{PrinterID}/ through PrinterResource.storeRepresentation.
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, put]
status: draft
handler: PrinterResource
handler_method: storeRepresentation
http_method: PUT
http_path: /devices/printers/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | PrinterResource.storeRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrinterResource](/components/controllers/PrinterResource.md).
