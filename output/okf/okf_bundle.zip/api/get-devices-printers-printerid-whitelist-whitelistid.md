---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
description: Serves GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ through WhiteListEntryResource.handleGet.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, get]
status: draft
handler: WhiteListEntryResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | WhiteListEntryResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md).
