---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/optin/
description: Serves PUT /devices/printers/{PrinterID}/optin/ through OptInConfigResource.handlePut.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, put]
status: draft
handler: OptInConfigResource
handler_method: handlePut
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | OptInConfigResource.handlePut |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptInConfigResource](/components/controllers/OptInConfigResource.md).
