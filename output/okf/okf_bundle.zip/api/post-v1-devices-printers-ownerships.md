---
type: API Endpoint
title: POST /v1/devices/printers/ownerships
description: Serves POST /v1/devices/printers/ownerships through DeviceOwnershipStratusResource.acceptRepresentation.
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, post]
status: draft
handler: DeviceOwnershipStratusResource
handler_method: acceptRepresentation
http_method: POST
http_path: /v1/devices/printers/ownerships
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/v1/devices/printers/ownerships` |
| Handler | DeviceOwnershipStratusResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).
