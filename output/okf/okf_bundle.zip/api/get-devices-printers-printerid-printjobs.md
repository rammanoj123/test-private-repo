---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/printjobs/
description: Serves GET /devices/printers/{PrinterID}/printjobs/ through PrintJobsResource.handleGet.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, get]
status: draft
handler: PrintJobsResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | PrintJobsResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [PrintJobsResource](/components/controllers/PrintJobsResource.md).
