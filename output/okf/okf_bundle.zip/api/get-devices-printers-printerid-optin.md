---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/
description: Serves GET /devices/printers/{PrinterID}/optin/ through OptInConfigResource.handleGet.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, get]
status: draft
handler: OptInConfigResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | OptInConfigResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptInConfigResource](/components/controllers/OptInConfigResource.md).
