---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
description: Serves DELETE /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} through BlackListHandler.handleDelete.
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, delete]
status: draft
handler: BlackListHandler
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | BlackListHandler.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [BlackListHandler](/components/controllers/BlackListHandler.md).
