---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/emailaddress/
description: Serves GET /devices/printers/{PrinterID}/emailaddress/ through EmailAddressResource.handleGet.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, get]
status: draft
handler: EmailAddressResource
handler_method: handleGet
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | EmailAddressResource.handleGet |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [EmailAddressResource](/components/controllers/EmailAddressResource.md).
