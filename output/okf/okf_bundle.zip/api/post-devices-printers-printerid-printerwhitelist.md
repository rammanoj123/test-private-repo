---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/printerwhitelist/
description: Serves POST /devices/printers/{PrinterID}/printerwhitelist/ through WhitelistHandler.handlePost.
resource: /devices/printers/{PrinterID}/printerwhitelist/
tags: [api, endpoint, post]
status: draft
handler: WhitelistHandler
handler_method: handlePost
http_method: POST
http_path: /devices/printers/{PrinterID}/printerwhitelist/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/printerwhitelist/` |
| Handler | WhitelistHandler.handlePost |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [WhitelistHandler](/components/controllers/WhitelistHandler.md).
