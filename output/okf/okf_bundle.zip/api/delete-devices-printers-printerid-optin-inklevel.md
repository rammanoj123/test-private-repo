---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/optin/inklevel/
description: Serves DELETE /devices/printers/{PrinterID}/optin/inklevel/ through OptinInkLevelResource.handleDelete.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, delete]
status: draft
handler: OptinInkLevelResource
handler_method: handleDelete
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | OptinInkLevelResource.handleDelete |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).
