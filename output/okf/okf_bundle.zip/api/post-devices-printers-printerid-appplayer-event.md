---
type: API Endpoint
title: POST /devices/printers/{PrinterID}/appplayer/event/
description: Serves POST /devices/printers/{PrinterID}/appplayer/event/ through AppPlayerEventResource.acceptRepresentation.
resource: /devices/printers/{PrinterID}/appplayer/event/
tags: [api, endpoint, post]
status: draft
handler: AppPlayerEventResource
handler_method: acceptRepresentation
http_method: POST
http_path: /devices/printers/{PrinterID}/appplayer/event/
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/{PrinterID}/appplayer/event/` |
| Handler | AppPlayerEventResource.acceptRepresentation |
| Returns |  |
| Auth | none detected |

# Parameters

_None._

Handled by [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md).
