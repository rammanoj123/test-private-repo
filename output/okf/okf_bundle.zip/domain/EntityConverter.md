---
type: Domain Entity
title: EntityConverter
description: Utility class for converting between domain entities and API schema types.
tags: [domain, entity]
status: draft
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EntityConverter.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.EntityConverter`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| createOwnerFromOwnershipEntity | Owner | Ownership printerOwnerEntity |  |
| createBlacklist | com.hp.cloudprint.api.eprintcenter.schemas.BlackList | List<BlackList> blackListEntries |  |
| createBlacklist | List | com.hp.cloudprint.api.eprintcenter.schemas.BlackList blackListEntries |  |
| createBlackListEntry | BlackList | BlackListEntryType blackListEntry |  |
| createBlackListEntry | JAXBElement | BlackList blackList |  |
| createBlackListEntryType | BlackListEntryType | BlackList blackList |  |
| createAdditionalEmailAddresses | AdditionalEmailAddress | List<OwnerAdditionalEmailAddress> additionalEmailAddresses |  |
| createAdditionalEmailAddress | JAXBElement | OwnerAdditionalEmailAddress additionalEmailAddress |  |
| createAdditionalEmailAddressEntryType | AdditionalEmailAddressEntryType | OwnerAdditionalEmailAddress additionalEmailAddress |  |
| createWhiteList | WhiteList | List<com.hp.cloudprint.entities.WhiteList> whitelist |  |
| createWhiteListEntry | WhiteListEntryType | com.hp.cloudprint.entities.WhiteList whiteList |  |
| createWhiteList | List | WhiteList whiteList |  |
| createWhiteListEntry | com.hp.cloudprint.entities.WhiteList | WhiteListEntryType whiteList |  |
| buildPapiErrorMessage | Error | String message, int httpStatusCode |  |

# Participates in

- [UC-022 — Get Printers](/usecases/uc-022-get-printers.md)
- [UC-028 — Get](/usecases/uc-028-get.md)
- [UC-029 — Get](/usecases/uc-029-get.md)
- [UC-030 — Get](/usecases/uc-030-get.md)
