---
type: Playbook
title: Bug fix flow
description: Traversal + generation steps for a bug-fix ticket.
tags: [playbook, codegen, bug]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

# When the ticket reports a defect

1. Map the symptom to a use case or endpoint; walk its `Steps` to the component/method most likely responsible.
2. Inspect that component's `Depends on` and `Cross-cutting` sections for the smallest correct change.
3. Keep the change minimal and local; do not alter unrelated contracts.
4. Add or strengthen a test that reproduces the defect.
5. Attest via [build & test](/architecture/build-and-test.md).

# Traversal

For a defect ticket, walk this bundle in this order. Every step names a concept that exists here, so the walk never leaves the bundle.

1. **Locate the entry point.** Start from the API index ([api/index.md](/api/index.md)) — 64 endpoint concept(s) — or a use case (33 of them) when the ticket describes a flow rather than a call.
2. **Read its `Contract`.** The endpoint concept states its verbs, its path parameters and the handler class that serves it.
3. **Open the handler component.** For example [VersionResource](/components/controllers/VersionResource.md). Its `Business context` says what the class is for; its `Schema` lists the collaborators it holds.
4. **Follow the collaborators.** Each injected field is another component concept in this bundle; the digest records which methods call which, so the call path is already written down.
5. **Check the libraries.** 93 dependency concept(s) record which classes import them and what for, so a change that touches one is visible before you make it.
6. **Check configuration.** [layering](/architecture/layering.md), [cache](/config/cache.md), [context](/config/context.md), [security](/config/security.md) hold the keys this service reads.
7. **Attest.** Run [build & test](/architecture/build-and-test.md) and do not present a change whose attestation fails.

# Worked example

Taking `GET /version/` as the ticket's subject:

- The endpoint concept is [api/get-version](/api/get-version.md).
- It is served by `VersionResource`, documented at [components/controllers/VersionResource](/components/controllers/VersionResource.md).
- Finish by running [build & test](/architecture/build-and-test.md).
