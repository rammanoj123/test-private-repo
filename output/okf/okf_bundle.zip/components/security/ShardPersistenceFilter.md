---
type: Component
title: ShardPersistenceFilter
description: Security `ShardPersistenceFilter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ShardPersistenceFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ShardPersistenceFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| urlProcessorUtility | URLProcessorUtility | @Resource |
| printerManager | PrinterManager |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain |  |
| getShardCode | String | HttpServletRequest request, HttpServletResponse response, String requestURL |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| getActivePrinter | Printer | String printerID |  |
| buildRequestUrl | String | String servletPath, String requestURI, String contextPath, String pathInfo, String queryString |  |
| setUrlProcessorUtility | void | URLProcessorUtility urlProcessorUtility |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| init | void | FilterConfig filterConfig |  |
| destroy | void |  |  |

# Depends on

* `URLProcessorUtility`
