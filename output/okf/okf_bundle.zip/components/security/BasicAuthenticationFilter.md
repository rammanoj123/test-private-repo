---
type: Component
title: BasicAuthenticationFilter
description: Security `BasicAuthenticationFilter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\BasicAuthenticationFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| authorizationHeader | String |  |
| headerValueType | String |  |
| securityDirectory | SecurityDirectory |  |
| wpConfigurationService | WpConfigurationService |  |
| clientID | String |  |
| clientSecret | String |  |
| decodedTokens | String[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| BasicAuthenticationFilter |  |  |  |
| doFilter | void | ServletRequest req, ServletResponse res, FilterChain chain |  |
| getCharacterEncoding | String | HttpServletRequest request |  |
| isBasicValidationAllowed | boolean |  |  |
| validateToken | boolean | Token token |  |
| getToken | Token | String decodedBasicToken |  |
| isWellFormedToken | boolean | Token token |  |
| getClientAuthDetails | ClientAuthDetails | Token token |  |
| setUnAuthResponse | void | HttpServletResponse response |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getClientID | String |  |  |
| setClientID | void | String clientID |  |
| getClientSecret | String |  |  |
| setClientSecret | void | String clientSecret |  |
