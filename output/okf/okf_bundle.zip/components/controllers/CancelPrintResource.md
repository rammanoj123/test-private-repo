---
type: Component
title: CancelPrintResource
description: REST resource for canceling print jobs.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CancelPrintResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printService | PrintService | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| doWork | void | String jobId |  |

# Depends on

* `PrintService`

# Business context

This resource cancels print jobs. It is invoked when a user or system requests cancellation of a pending or in-progress print job. The cancellation request is forwarded to the print service, which coordinates with the printer. If cancellation fails or is not supported for completed jobs, users see incorrect job states or cannot stop unwanted print jobs.

# Algorithm

**handlePut**

1. Generate log UID and set in MDC
2. Extract jobId from request attributes
3. Set shard from jobId
4. Call doWork with jobId (retryable)
5. Return 404 Not Found if NotFoundException occurs
6. Return 400 Bad Request if SuccessOkPartiallyCanceledException occurs (job already completed/canceled)
7. Return 202 Accepted with Location header pointing to job status URI
8. Clear MDC

**doWork**

1. Call printService.cancelJob with jobId

# Business rules

- Job cancellation is retried up to 3 times on transient failures

# Participates in

- [UC-002 — Update Job Printjobs](/usecases/uc-002-update-job-printjobs.md)
