---
type: Component
title: WhitelistHandler
description: Message handler for retrieving and creating whitelist entries for a printer.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\WhitelistHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |

# Business context

This handler processes GET and POST requests for a printer's whitelist collection. It enables users to view all authorized email addresses and add new entries to grant specific users permission to send print jobs or manage the printer. Whitelist failures prevent legitimate users from accessing the printer or allow unauthorized access.

# Algorithm

**handleGet**

1. Extract userId from request parameters via Utility.extractUIDFromPUC
2. Initialize logging MDC with userId
3. Extract printerID from request parameters
4. Get active printer via printerManager.getActivePrinterByPrinterID(printerID)
5. Get whitelist via printerManager.getWhiteListByInternalPrinterID(internalPrinterID)
6. Convert entities to schema type via EntityConverter
7. Set response entity
8. Clear MDC

**handlePost**

1. Initialize logging MDC
2. Extract printerID and WhiteList from request
3. Call printerManager.addEntryToWhiteList with printerID and converted entities
4. Convert result to schema type
5. Set response entity and 201 Created status
6. Clear MDC

# Depends on

- [Utility](/components/misc/Utility.md)
- [EntityConverter](/domain/EntityConverter.md)

# Participates in

- [UC-029 — Get](/usecases/uc-029-get.md)
