---
type: Component
title: EprintCenterHealthController
description: Health check controller for ePrint Center service dependencies.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\EprintCenterHealthController.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| LOG | EPrintLogger |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| GEN2_CALYPSO_HEALTH_CHECK | String |  |
| ULS_HEALTH_CHECK | String |  |
| EPC_PLATFORM | String |  |
| DISABLE_PAM_LOOKUP_FOR_USER_IDENTITIES | String |  |
| ULS_ABOUT_URL | String |  |
| ULS_PROXY_ENABLED | String |  |
| ULS_PROXY_HOST | String |  |
| ULS_PROXY_PORT | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| cpgDBHealthCheck | void |  |  |
| getEprintDirDS | ComboPooledDataSource |  |  |
| getDetails | String | ComboPooledDataSource comboPooledDataSource |  |
| getHostName | String | String url |  |
| shardDBHealthCheck | void |  |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| tigaseDBHealthCheck | void |  |  |
| getTigaseDBDataSource | DataSource | String shardCode |  |
| getTigaseDbGroupType | GroupType |  |  |
| getThresholdForTigaseDbHealth | int |  |  |
| channelHealthCheck | void |  |  |
| plsHealthCheck | void |  |  |
| idmHealthCheck | void |  |  |
| authzHealthCheck | void |  |  |
| pamHealthCheck | void |  |  |
| ulsHealthCheck | void |  |  |
| pumaHealthCheck | void |  |  |
| pdsHealthCheck | void |  |  |
| outBoundEmailHealthCheck | void |  |  |
| eprintUserDirectoryHealthCheck | void |  |  |
| gen2CalypsoHealthCheck | void |  |  |
| constructAboutContextPathFromServiceContext | String | String serviceContextPath |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |

# Business context

This controller orchestrates health checks for all internal and external dependencies of the ePrint Center service. It is invoked by the health check framework at startup and periodically during runtime. It validates connectivity to databases (cpgDB, shard DBs, Tigase, user directory), external services (PLS, ULS, Authz, PDS, Calypso, Channel), and configures thresholds for shard availability. Health check failures trigger alerts and can prevent the service from receiving traffic. Incorrect health checks cause false positives (service marked healthy when dependencies are down) or false negatives (service marked unhealthy when it is operational).

# Algorithm

**initialize**

1. Call cpgDBHealthCheck
2. Call shardDBHealthCheck
3. Call tigaseDBHealthCheck
4. Call channelHealthCheck
5. Call plsHealthCheck
6. Call idmHealthCheck
7. Call authzHealthCheck
8. Call pdsHealthCheck
9. Call eprintUserDirectoryHealthCheck
10. Call gen2CalypsoHealthCheck

**cpgDBHealthCheck**

1. Get eprintDirDS ComboPooledDataSource
2. Extract JDBC URL and hostname
3. Call addDatabaseCheck with cpgDB details

**getHostName**

1. Extract hostname from JDBC URL by parsing URI after 'jdbc:' prefix
2. Return hostname or null if URL is invalid

**shardDBHealthCheck**

1. Get ShardDataSourceProvider instance
2. Get shard datasource map
3. For each shard code, get ComboPooledDataSource
4. Extract hostname and call addDatabaseCheck for each shard
5. Get threshold for shard health from config
6. Set strategy for SHARD_DB group type with threshold

**tigaseDBHealthCheck**

1. Get ShardDataSourceProvider instance
2. Get shard datasource map
3. For each shard code, get Tigase DB datasource
4. Extract hostname and call addDatabaseCheck for each Tigase DB
5. Get threshold for Tigase DB health from config
6. Set strategy for TIGASE_DB group type with threshold

**channelHealthCheck**

1. Get ShardDataSourceProvider instance
2. Get shard datasource map
3. For each shard code, get XmppServerGroup
4. Extract channel endpoint IP
5. Call addEprintDependentServiceCheck with channel IP, optionally using proxy

**plsHealthCheck**

1. Get PLS service URL from config
2. Construct about URL from service context
3. Call addEprintDependentServiceCheck with PLS URL, optionally using proxy

**idmHealthCheck**

1. Call ulsHealthCheck

**authzHealthCheck**

1. Get Authz service URL from config
2. Call addEprintDependentServiceCheck with Authz URL, optionally using proxy

**pamHealthCheck**

1. Get PAM service URL from config
2. Construct about URL from service context
3. Call addEprintDependentServiceCheck with PAM URL, optionally using proxy

**ulsHealthCheck**

1. Get ULS service URL from config
2. Call addEprintDependentServiceCheck with ULS URL, optionally using proxy

**pumaHealthCheck**

1. Get PUMA service URL from config
2. Construct about URL from service context
3. Call addEprintDependentServiceCheck with PUMA URL, optionally using proxy

**pdsHealthCheck**

1. Get PDS about URL from config
2. If empty, construct from endpoint and root URI
3. Call addEprintDependentServiceCheck with PDS URL, optionally using proxy

**outBoundEmailHealthCheck**

1. Get outBoundEmail service URL from config
2. Construct about URL from service context
3. Call addEprintDependentServiceCheck with outBoundEmail URL, optionally using proxy

**eprintUserDirectoryHealthCheck**

1. Get EprintUserDirectory application context
2. Get eprintUserDirDS ComboPooledDataSource
3. Extract JDBC URL and hostname
4. Call addDatabaseCheck with eprint_user_directory details

**gen2CalypsoHealthCheck**

1. Get Gen2 Calypso URL from config
2. Call addEprintDependentServiceCheck with Calypso URL, optionally using proxy

**constructAboutContextPathFromServiceContext**

1. Find first '/' after position 1 in serviceContextPath
2. Return substring from start to that position
3. Return null if serviceContextPath is empty or invalid

# Business rules

- Minimum shard up count threshold is configurable
- Minimum Tigase DB up count threshold is configurable
- Proxy usage is controlled by configuration flag
- PDS about URL is pre-configured for prod, constructed for non-prod

# Depends on

- [WpConfigurationServiceProvider](/components/services/WpConfigurationServiceProvider.md)
