---
type: Component
title: EprintCenterHealthController
description: Controller `EprintCenterHealthController`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\EprintCenterHealthController.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| LOG | EPrintLogger |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| GEN2_CALYPSO_HEALTH_CHECK | String |  |
| ULS_HEALTH_CHECK | String |  |
| EPC_PLATFORM | String |  |
| DISABLE_PAM_LOOKUP_FOR_USER_IDENTITIES | String |  |
| ULS_ABOUT_URL | String |  |
| ULS_PROXY_ENABLED | String |  |
| ULS_PROXY_HOST | String |  |
| ULS_PROXY_PORT | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| cpgDBHealthCheck | void |  |  |
| getEprintDirDS | ComboPooledDataSource |  |  |
| getDetails | String | ComboPooledDataSource comboPooledDataSource |  |
| getHostName | String | String url |  |
| shardDBHealthCheck | void |  |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| tigaseDBHealthCheck | void |  |  |
| getTigaseDBDataSource | DataSource | String shardCode |  |
| getTigaseDbGroupType | GroupType |  |  |
| getThresholdForTigaseDbHealth | int |  |  |
| channelHealthCheck | void |  |  |
| plsHealthCheck | void |  |  |
| idmHealthCheck | void |  |  |
| authzHealthCheck | void |  |  |
| pamHealthCheck | void |  |  |
| ulsHealthCheck | void |  |  |
| pumaHealthCheck | void |  |  |
| pdsHealthCheck | void |  |  |
| outBoundEmailHealthCheck | void |  |  |
| eprintUserDirectoryHealthCheck | void |  |  |
| gen2CalypsoHealthCheck | void |  |  |
| constructAboutContextPathFromServiceContext | String | String serviceContextPath |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |
