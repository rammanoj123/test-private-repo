---
type: Component
title: AbstractResource
description: Base class for Restlet resources that determines allowed HTTP methods via configuration.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\AbstractResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.AbstractResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |

# Business context

This class provides a common foundation for all REST API resources in the ePrint Center service. It enables declarative control over which HTTP verbs each endpoint accepts, ensuring that method-level security and routing constraints are enforced consistently. Resources that fail to properly configure allowed methods expose unintended operations or return incorrect 405 responses.

# Algorithm

**allowGet**

1. Check if methods list contains 'GET'

**allowPost**

1. Check if methods list contains 'POST'

**allowDelete**

1. Check if methods list contains 'DELETE'

**allowPut**

1. Check if methods list contains 'PUT'

**allowOptions**

1. Check if methods list contains 'OPTIONS'

**allowHead**

1. Check if methods list contains 'HEAD'

# Business rules

- Methods list must be set before the resource handles any request
