---
type: Component
title: CloudConfigurationResource
description: REST resource for managing printer cloud configuration settings.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CloudConfigurationResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| securityDirectory | SecurityDirectory | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handlePut | void |  |  |
| handleGet | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| extractUIDFromPUC | String |  |  |
| createWhitelist | List | List<OwnerAdditionalEmailAddress> ownerAdditionalEmailAddresses |  |
| updateUserEmailInWhitelistOrBlacklistOfPrinter | void | Printer printer |  |
| getUserIdFromHeader | String |  |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `SecurityDirectory`
* `UserEmailAddressHelper`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Business context

This resource manages printer cloud configuration settings, including email, mobile app, SIPS, Google services, and protection mode. It is invoked when users view or update their printer's cloud connectivity settings. Protection mode controls whether the printer accepts print jobs only from whitelisted senders. Incorrect configuration management causes printers to reject legitimate jobs or accept unauthorized ones.

# Algorithm

**handlePut**

1. Generate log UID and set in MDC
2. Extract printerID from request attributes
3. Unmarshal PrinterCloudConfiguration from request entity, with optional XSD validation
4. Return 400 Bad Request if unmarshalling fails
5. Get active printer via printerManager.getActivePrinterByPrinterID
6. Return 404 Not Found if printer not found
7. Get old printer cloud configuration via printerCloudConfigurationManager.getPrinterCloudConfig
8. Update printer cloud configuration via printerCloudConfigurationManager.updatePrinterCloudConfiguration
9. If protection mode was enabled (old=false, new=true), get owner's additional email addresses and add to whitelist
10. Get updated printer cloud configuration
11. If protection mode is enabled, call updateUserEmailInWhitelistOrBlacklistOfPrinter
12. Generate JAXB response object via jaxbObjectCreationHelper.generatePrinterCloudConfigurationJAXBObject
13. Marshal response to XML
14. Return 200 OK with XML entity
15. Clear MDC

**handleGet**

1. Generate log UID and set in MDC
2. Extract printerID from request attributes
3. Get active printer via printerManager.getActivePrinterByPrinterID
4. Return 404 Not Found if printer not found
5. Get printer cloud configuration via printerCloudConfigurationManager.getPrinterCloudConfig
6. Return 400 Bad Request if configuration not found
7. Build PrinterCloudConfiguration schema object from entity
8. Marshal response to XML
9. Return 200 OK with XML entity and Cache-Control: no-store header
10. Clear MDC

**extractUIDFromPUC**

1. Get TokenDO from request attributes
2. Extract uid from TokenDO
3. Return uid or null

**createWhitelist**

1. Create empty whitelist
2. For each additional email address, create WhiteList entry with ALLOW privilege and PRINT feature
3. Return whitelist

**updateUserEmailInWhitelistOrBlacklistOfPrinter**

1. Get userId from request header via getUserIdFromHeader
2. Return if userId is null
3. Get all user identities via userEmailAddressHelper.getAllPrimaryAndAdditionalUserIdentitiesBasedOnUserId
4. Return if userIdentities is null
5. Call printerManager.addWhitelistAndRemoveBlackListBasedOnPrinter with all email IDs and printer
6. Log and ignore any exceptions

**getUserIdFromHeader**

1. Call Utility.extractUIDFromPUC with request attributes
2. Return userId

# Business rules

- When protection mode is enabled, owner's email addresses are automatically whitelisted
- User's email addresses are added to whitelist and removed from blacklist when protection mode is enabled

# Participates in

- [UC-003 — Get Printer Cloudconfiguration](/usecases/uc-003-get-printer-cloudconfiguration.md)
