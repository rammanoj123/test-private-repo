---
type: Component
title: CloudConfigurationResource
description: Controller `CloudConfigurationResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CloudConfigurationResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| securityDirectory | SecurityDirectory | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handlePut | void |  |  |
| handleGet | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| extractUIDFromPUC | String |  |  |
| createWhitelist | List | List<OwnerAdditionalEmailAddress> ownerAdditionalEmailAddresses |  |
| updateUserEmailInWhitelistOrBlacklistOfPrinter | void | Printer printer |  |
| getUserIdFromHeader | String |  |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `SecurityDirectory`
* `UserEmailAddressHelper`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
