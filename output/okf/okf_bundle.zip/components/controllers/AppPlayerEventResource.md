---
type: Component
title: AppPlayerEventResource
description: REST resource for handling app player events from printers.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AppPlayerEventResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| acceptRepresentation | void | Representation entity |  |

# Depends on

* `PrinterManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Business context

This resource handles app player events from printers, specifically app list update notifications. When a printer's installed app list changes, it sends an event to this endpoint, which triggers deletion of the cached screen data. This ensures that the next time a user views the printer's app list, they see the current state. If screen cache deletion fails, users see stale app lists, causing confusion and support calls.

# Algorithm

**acceptRepresentation**

1. Log received representation if finer logging enabled
2. Unmarshal AppPlayerEvent from request entity, with optional XSD validation
3. Return 400 Bad Request if unmarshalling fails
4. Extract printerID from request attributes
5. Get active printer via printerManager.getActivePrinterByPrinterID
6. Return 404 Not Found if printer not found
7. If appPlayerEvent.isAppListUpdate() is true, call printerManager.deleteScreenCache
8. Return 200 OK if DeviceDisconnectedException occurs
9. Return 500 Internal Server Error if other exception occurs

# Business rules

- Screen cache is only deleted if appListUpdate flag is true

# Participates in

- [UC-021 — Create Appplayer](/usecases/uc-021-create-appplayer.md)
