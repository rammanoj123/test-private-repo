---
type: Component
title: WhiteListEntryResource
description: Controller `WhiteListEntryResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\WhiteListEntryResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| handleGet | void |  |  |
| handleDelete | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |

# Depends on

* `IPrinterManager`
* `UserEmailAddressHelper`
