---
type: Component
title: BlackListsHandler
description: Message handler for retrieving and creating blacklist entries for a printer.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListsHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |

# Business context

This handler processes GET and POST requests for a printer's blacklist collection. It enables users to view all blocked email addresses and add new entries to prevent unwanted senders from submitting print jobs. The POST operation retrieves the printer owner's email address to support notification or audit requirements. Blacklist failures allow spam print jobs or prevent legitimate blocking.

# Algorithm

**handleGet**

1. Initialize logging MDC
2. Extract printerID from request parameters
3. Call printerManager.getBlackListEntries(printerID)
4. Convert entities to schema type via EntityConverter
5. Set response entity
6. Clear MDC

**handlePost**

1. Initialize logging MDC
2. Extract printerID and BlackList from request
3. Retrieve printer owner via printerManager.getPrinterOwner(printerID)
4. If owner exists, get primary email address via userEmailAddressHelper
5. If email retrieval fails, return 500 error
6. Call printerManager.addEntryToBlackList with printerID, primaryEmailAddress, and converted entities
7. Convert result to schema type
8. Set response entity and 201 Created status
9. Clear MDC

# Business rules

- Owner's primary email address is required for blacklist creation

# Depends on

- [EntityConverter](/domain/EntityConverter.md)

# Participates in

- [UC-028 — Get](/usecases/uc-028-get.md)
