---
type: Component
title: CDCASubscriptionResource
description: REST resource for managing CDCA opt-in subscriptions for printers.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CDCASubscriptionResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| CDCASubscriptionResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| getErrorXML | String | ErrorCode errorCode |  |
| putPrinterCloudConfiguration | void | Printer printer |  |
| isPrinterOptedinWithSchedule | boolean | PrinterCloudConfiguration printerCloudConfiguration, String printerId |  |
| deletePrinterCloudConfiguration | void | Printer printer |  |
| getPrinterCloudConfiguration | void | Printer printer |  |
| putPrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`

# Business context

This resource manages CDCA (Connected Device Configuration and Analytics) opt-in subscriptions for printers. It enables users to opt in or out of CDCA data collection, and retrieves the current opt-in status. CDCA opt-in controls whether the printer sends configuration and usage data to HP for analytics and support. Incorrect opt-in management causes data collection failures or privacy violations.

# Algorithm

**handlePut**

1. Generate log UID and set in MDC
2. Call handleMethod with RequestType.PUT
3. Clear MDC

**handleDelete**

1. Generate log UID and set in MDC
2. Call handleMethod with RequestType.DELETE
3. Clear MDC

**handleGet**

1. Generate log UID and set in MDC
2. Call handleMethod with RequestType.GET
3. Clear MDC

**handleMethod**

1. Get printerID via getPrinterID
2. Return if printerID is null
3. Get printer via getPrinter
4. Return if printer is null
5. If requestType is PUT, call putPrinterCloudConfiguration
6. If requestType is DELETE, call deletePrinterCloudConfiguration
7. If requestType is GET, call getPrinterCloudConfiguration
8. Set success response status based on requestType

**setSuccessResponseStatus**

1. If requestType is PUT, set status to 201 Created
2. If requestType is DELETE, set status to 204 No Content
3. If requestType is GET, set status to 204 No Content

**getPrinterID**

1. Extract printerID from request attributes
2. Return 400 Bad Request if printerID is null
3. Return printerID

**getPrinter**

1. Call printerManager.getActivePrinterByPrinterID
2. Return 404 Not Found if printer is null or DeviceNotFoundExcpeption occurs
3. Return 500 Internal Server Error if other exception occurs
4. Return printer

**getErrorXML**

1. Create Error instance with errorCode
2. Set errorDescription from errorCode
3. Marshal Error to XML
4. Return XML string

**putPrinterCloudConfiguration**

1. Get printer cloud configuration via printerCloudConfigurationManager.getPrinterCloudConfig
2. If configuration is null, return 500 Internal Server Error
3. Check if printer is already opted in with schedule via isPrinterOptedinWithSchedule
4. If not opted in, call putPrinterCloudConfigurationCDCAOptin and updatePrinterCloudConfiguration

**isPrinterOptedinWithSchedule**

1. Check if optinType is not blank
2. If optinType is not CDCA, return 409 Conflict
3. Return true if optinType is set, false otherwise

**deletePrinterCloudConfiguration**

1. Get printer cloud configuration via printerCloudConfigurationManager.getPrinterCloudConfig
2. If configuration is null, return 500 Internal Server Error
3. Call deletePrinterCloudConfigurationCDCAOptin and updatePrinterCloudConfiguration

**getPrinterCloudConfiguration**

1. Get printer cloud configuration via printerCloudConfigurationManager.getPrinterCloudConfig
2. If configuration is null, return 500 Internal Server Error
3. If CDCAOptin is false, return 404 Not Found

**putPrinterCloudConfigurationCDCAOptin**

1. Set CDCAOptin to true
2. Set IsOptinConfigSynced to 0
3. Set LastOptinUpdateTime to current timestamp

**deletePrinterCloudConfigurationCDCAOptin**

1. Set CDCAOptin to false
2. Set IsOptinConfigSynced to 0
3. Set LastOptinUpdateTime to current timestamp

# Business rules

- If printer is already opted in via v2 API, return 201 without updating
- If printer is opted in for different optin type, return 409 Conflict
- V2 API opt-in takes precedence over v1 API opt-in

# Participates in

- [UC-026 — Get Optin](/usecases/uc-026-get-optin.md)
