---
type: Component
title: SolutionOptInResource
description: Controller `SolutionOptInResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SolutionOptInResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| DEFAULT_SCHEDULE | String |  |
| IS_CDCA_SCHEDULE_MIGRATION_ENABLED | String |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| optinClientSchedulesMap | OptinClientSchedulesMap |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinClientSchedulesMap | OptinClientSchedulesMap |  |  |
| setOptinClientSchedulesMap | void | OptinClientSchedulesMap optinClientSchedulesMap |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| SolutionOptInResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| validateOptInTypeAndSchedule | void | String optInType, String schedule |  |
| setSuccessResponseStatus | void | RequestType requestType, OptinSchedules schedules |  |
| getSchedule | String |  |  |
| getOptInType | String |  |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| putPrinterCloudConfiguration | void | Printer printer, String optinType, String schedule |  |
| deletePrinterCloudConfiguration | void | Printer printer, String optinType |  |
| getPrinterCloudConfiguration | OptinSchedules | Printer printer, String optinType |  |
| isUpdateRequired | boolean | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| putPrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| deletePrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String printerId |  |
| getErrorResponse | Representation | String errorCode, String errorDescription, Status status |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
