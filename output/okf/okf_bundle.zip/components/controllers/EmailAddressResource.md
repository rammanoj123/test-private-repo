---
type: Component
title: EmailAddressResource
description: Controller `EmailAddressResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\EmailAddressResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| emailAddressManager | EmailAddressManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| deleteEmailAddressFromCalypso | void | String printerEmailAddress |  |
| handlePost | void |  |  |
| handleGet | void |  |  |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEmailAddressManager | EmailAddressManager |  |  |
| setEmailAddressManager | void | EmailAddressManager emailAddressManager |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |

# Depends on

* `IPrinterManager`
* `EmailAddressManager`
* [CalypsoClient](/components/services/CalypsoClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Participates in

- [UC-004 — Get Printer Emailaddress](/usecases/uc-004-get-printer-emailaddress.md)
