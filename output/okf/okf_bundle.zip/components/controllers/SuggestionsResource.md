---
type: Component
title: SuggestionsResource
description: Controller `SuggestionsResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SuggestionsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| MIN_SUGGESTIONS | int |  |
| emailAddressManager | EmailAddressManager | @Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SuggestionsResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
