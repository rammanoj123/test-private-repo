---
type: Component
title: AvailabilityResource
description: REST resource for checking email address alias availability for printers.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`

# Business context

This resource checks whether a desired email address alias is available for a printer. It is invoked when a user attempts to set a friendly email address for their printer. The check prevents duplicate aliases and validates the alias format. If availability checks fail or return incorrect results, users cannot set email addresses or experience conflicts with existing aliases.

# Algorithm

**handlePost**

1. Extract printerId from request attributes
2. Return 400 Bad Request if printerId is null
3. Unmarshal PrinterEmailAddress from request entity with XSD validation
4. Return 400 Bad Request if unmarshalling fails
5. Extract desiredEmailAddressAlias from PrinterEmailAddress
6. Call emailAddressManager.isAliasAvailable with alias and printerId
7. Return 400 Bad Request if alias fails basic acceptance testing
8. Return 200 OK if alias is available
9. Return 409 Conflict if alias is not available

# Business rules

- Email alias must pass basic acceptance testing
- Alias availability is checked against existing aliases

# Participates in

- [UC-006 — Create Emailaddress](/usecases/uc-006-create-emailaddress.md)
