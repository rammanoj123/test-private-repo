---
type: Component
title: BlackListHandler
description: Message handler for retrieving and deleting individual blacklist entries.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | IPrinterManager |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleDelete | void | CPGMessage message |  |
| handleGet | void | CPGMessage message |  |

# Business context

This handler processes GET and DELETE requests for individual blacklist entries on a printer. It enables users to view or remove specific email addresses that are blocked from sending print jobs to their printer. Incorrect blacklist management allows spam or unwanted print jobs, or prevents legitimate senders from reaching the printer.

# Algorithm

**handleDelete**

1. Extract printerID and blackListID from request parameters
2. Call printerManager.removeBlackListEntry(printerID, blackListID)
3. Set response status to 204 No Content

**handleGet**

1. Extract printerID and blackListID from request parameters
2. Call printerManager.getBlackListEntry(printerID, blackListID)
3. Convert entity to schema type via EntityConverter
4. Set response entity

# Depends on

- [EntityConverter](/domain/EntityConverter.md)

# Participates in

- [UC-030 — Get](/usecases/uc-030-get.md)
