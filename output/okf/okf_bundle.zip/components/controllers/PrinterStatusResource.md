---
type: Component
title: PrinterStatusResource
description: Controller `PrinterStatusResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterStatusResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| NON_BLOCKING | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| verifyPrinterOwner | boolean | String printerID, String userId |  |
| sendData | void | PrinterStatus printStatus |  |

# Depends on

* `IPrinterManager`
* `PrintService`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
