---
type: Component
title: PrinterSupportedProcessingElementsResource
description: Controller `PrinterSupportedProcessingElementsResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterSupportedProcessingElementsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ERROR_MESSAGE_INTERNAL_ERROR | String |  |
| ERROR_MESSAGE_INVALID_PRINTER | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| handleGet | void |  |  |

# Depends on

* `IPrinterManager`
* `DeviceCapabilitiesManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
