---
type: Component
title: OutEmailHelper
description: Helper class for sending outbound email notifications via the EOS (Email Outreach Service) client.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\OutEmailHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| EMAIL_LIST_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| EMAIL_LIST_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| logger | EPrintLogger |  |
| FROM_EMAIL_ID | String |  |
| eosClient | EOSClient |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEosClient | EOSClient |  |  |
| setEosClient | void | EOSClient eosClient |  |
| sendAdditionalEmailAddressValidationMail | void | String userId, String emailId, String url, String firstName |  |

# Business context

This helper sends email verification messages to users who add additional email addresses to their account. It is invoked when a user registers a new email address for receiving print jobs, and the email contains a verification link. If email sending fails, users cannot verify their additional addresses, preventing them from using those addresses to send print jobs.

# Algorithm

**sendAdditionalEmailAddressValidationMail**

1. Create template data map with AddedEmailAddress, AuthenticationString (URL), and FIRST_NAME if provided
2. Call eosClient.sendResponsysTemplateMail with userId, from address, recipient email, template folder/name, list folder/name, and template data

# Business rules

- From address is donotreply@hpeprint.com
- Template is 2012_08_01_Email_Account_Confirm_US_EN
- Email list is TRANSACTIONAL_CONTACTS_LIST
