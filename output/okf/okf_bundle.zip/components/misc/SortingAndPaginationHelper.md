---
type: Component
title: SortingAndPaginationHelper
description: Helper class for sorting and paginating print history results.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |

# Business context

This helper applies sorting and pagination to print history results. It is invoked by print history resource handlers to limit result set size and order documents by date, sender, or other criteria. Incorrect pagination causes clients to receive incomplete or duplicate results, while incorrect sorting confuses users about the order of their print jobs.

# Algorithm

**sortPrintHistoryBasedOnSortCriteria**

1. Create UserHistoryComparator with sortCriteria and sortOrder
2. Call Collections.sort with documents and comparator

**paginateResultsBasedOnStartAndCountParams**

1. Normalize start parameter via getNormalizedStart
2. Normalize count parameter via getNormalizedCount
3. Calculate pagination end index via getPaginationEndIndexBasedOnStartAndCount
4. Create new list
5. Add documents from start to end index to new list
6. Return new list

**getPaginationEndIndexBasedOnStartAndCount**

1. Return documentsSize if paginationStart + normalizedCount exceeds it
2. Otherwise return paginationStart + normalizedCount

**getNormalizedCount**

1. Get maxCountPerPage from config
2. If count <= 0 or count > maxCountPerPage, return maxCountPerPage
3. Otherwise return count

# Business rules

- Start is 1-based in API, converted to 0-based for list indexing
- Count is capped at configured maximum
- API uses 1-based indexing, internal uses 0-based

# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
