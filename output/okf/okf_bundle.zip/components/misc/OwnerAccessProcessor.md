---
type: Component
title: OwnerAccessProcessor
description: Preprocessor that enforces ownership-based access control for printer resources.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\processors\OwnerAccessProcessor.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager |  |
| securityDirectory | SecurityDirectory |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| logger | EPrintLogger |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| preProcess | void | CPGMessage message, Request request |  |
| isAccessAllowed | boolean | String ownerUserId, List<String> allUserIdentities |  |
| getUIDFromTokens | String | AccessTokenEntity accessToken, TokenDO pumaToken |  |

# Business context

This preprocessor enforces ownership-based access control for printer resources. It is invoked before every request that operates on a printer, and it validates that the authenticated user is the printer's owner. It retrieves the printer owner, resolves all user identities (primary and additional email addresses) via PAM/ULS, and checks if any identity matches the owner. Access denial prevents unauthorized users from viewing or modifying printers they do not own. Failures in identity resolution or incorrect access logic cause either unauthorized access (security breach) or false denials (legitimate users blocked).

# Algorithm

**preProcess**

1. Extract printerId from request attributes
2. Call printerManager.getPrinterOwner to get printer owner
3. Throw AccessDeniedException with DEVICE_UNCLAIMED if owner not found
4. Extract accessToken and pumaToken from request attributes
5. Get userID from tokens via getUIDFromTokens
6. Get issuer from request attributes
7. If issuer is AUTHZ, call userEmailAddressHelper.getAllUserIdentities with userID
8. Otherwise call getAllUserIdentities with userID and email sync disabled
9. If allUserIdentities is null, use userID from token
10. If PAM failure code is 404, throw AccessDeniedException with PAM_CALL_FAILURE
11. If PAM failure code is other, throw InternalServerError with PAM_CALL_FAILURE
12. If ULS failure code is 404, throw AccessDeniedException with ULS_CALL_FAILURE
13. If ULS failure code is other, throw InternalServerError with ULS_CALL_FAILURE
14. Add all user IDs from allUserIdentities to userIdentitiesAsList
15. Call isAccessAllowed with ownerUserId and userIdentitiesAsList
16. Throw AccessDeniedException with SENDER_IS_NOT_OWNER if access not allowed

**isAccessAllowed**

1. Iterate over allUserIdentities
2. For each userId, compare with ownerUserId
3. Return true if any match found
4. Return false if no match

**getUIDFromTokens**

1. If accessToken is not null, return accessToken.getUser()
2. Else if pumaToken is not null, return pumaToken.getUid()
3. Return null if both are null

# Business rules

- Printer must have an owner
- User identity resolution via PAM/ULS is required
- 404 from PAM/ULS is treated as access denied
- Other PAM/ULS errors are treated as internal server errors
- Access is allowed if any user identity matches the owner
- Printer must have an owner to allow access
