---
type: Component
title: EmailAliasRetention
description: Enumeration defining whether an email alias is retained with the user or the device.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EmailAliasRetention.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.EmailAliasRetention`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAliasRetention | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EmailAliasRetention |  | String retentionChoice |  |
| getEnum | EmailAliasRetention | String value |  |

# Business context

This enum controls email alias lifecycle when a printer changes ownership. USER retention keeps the alias with the original owner, while DEVICE retention transfers it to the new owner. This decision affects whether users can continue receiving print jobs at the same email address after transferring a printer, and incorrect retention logic causes email delivery failures or privacy violations.

# Algorithm

**getEnum**

1. Iterate over all enum values
2. Return the value whose string matches (case-insensitive)
3. If no match, return DEVICE

# Business rules

- Default to DEVICE retention if value is unrecognized
