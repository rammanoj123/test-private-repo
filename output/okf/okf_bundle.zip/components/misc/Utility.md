---
type: Component
title: Utility
description: Utility class providing common functions for schema validation, date conversion, caching, and token parsing.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Utility.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| version | String |  |
| obj | Object |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getApiVersion | String |  |  |
| addCacheHeaderToResponse | Response | Response resp |  |
| createXMLGregorianCalendar | XMLGregorianCalendar | Date creationTime |  |
| extractUIDFromPUC | String | Map<String, Object> parameters |  |
| isServicePuc | boolean | Request request |  |

# Business context

This class provides shared utility functions used throughout the ePrint Center API, including XML schema loading, API version extraction, cache header management, date conversion, and user ID extraction from authentication tokens. It is invoked by resource handlers, validators, and response builders. Failures in schema loading prevent API startup, while incorrect date conversions or cache headers cause client-side bugs and stale data issues.

# Algorithm

**getSchema**

1. Check if schema is null
2. If null, synchronize and double-check
3. Load SchemaFactory for W3C XML Schema
4. Get schema name from config
5. Load schema from classpath
6. Return schema

**getApiVersion**

1. Check if version is null
2. If null, synchronize and double-check
3. Get schema file name from config
4. Parse schema file as XML document
5. Extract version attribute from root element
6. Return version

**addCacheHeaderToResponse**

1. Get or create HTTP headers form from response attributes
2. Add Cache-Control: no-cache
3. Add Pragma: no-cache
4. Add Expires: 0
5. Return response

**createXMLGregorianCalendar**

1. Return null if creationTime is null
2. Create GregorianCalendar from Date
3. Extract year, month, day, hour, minute, second, timezone offset
4. Create XMLGregorianCalendar with extracted fields
5. Return XMLGregorianCalendar

**extractUIDFromPUC**

1. Throw exception if parameters is null
2. Extract TokenDO from parameters
3. If TokenDO is null or extraction fails, return 'uid' parameter
4. Otherwise return tokenDO.getUid()

**isServicePuc**

1. Extract TokenDO from request attributes
2. Check if uid is null, empty, or 'null' string
3. Return true if uid is absent, false otherwise

# Business rules

- Schema is loaded once and cached
- Version is extracted once and cached
- Must prevent caching at all levels
- Month field is adjusted from 0-based to 1-based
- Must handle both TokenDO and plain uid parameter
- Schema must be loaded successfully before validation
- API version must be extractable from schema file

# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Participates in

- [UC-001 — Get Version](/usecases/uc-001-get-version.md)
- [UC-003 — Get Printer Cloudconfiguration](/usecases/uc-003-get-printer-cloudconfiguration.md)
- [UC-004 — Get Printer Emailaddress](/usecases/uc-004-get-printer-emailaddress.md)
- [UC-005 — Create Emailaddress Suggestions](/usecases/uc-005-create-emailaddress-suggestions.md)
- [UC-006 — Create Emailaddress](/usecases/uc-006-create-emailaddress.md)
- [UC-007 — Create Ownership Status](/usecases/uc-007-create-ownership-status.md)
- [UC-008 — Create Ownerships](/usecases/uc-008-create-ownerships.md)
- [UC-009 — Create Printer Ownerships](/usecases/uc-009-create-printer-ownerships.md)
