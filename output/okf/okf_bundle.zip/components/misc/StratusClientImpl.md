---
type: Component
title: StratusClientImpl
description: Unknown `StratusClientImpl`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClientImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.http.clients.StratusClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| pumaClientWrapper | PUMAClientWrapper |  |
| stratusHttpClient | StratusHttpClient |  |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| FQ_RESOURCE_NAME | String |  |
| EVENT_ADDED | String |  |
| SCOPE | String |  |
| DEVICE_ID | String |  |
| USER_ID | String |  |
| ACCOUNT_ID | String |  |
| STRATUS_ID | String |  |
| OWNERSHIP_ID | String |  |
| EVENT_DELETED | String |  |
| OCTOKEN_EXPECTED_ISSUER_URL | String |  |
| httpHeaders | HashMap |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPumaClientWrapper | PUMAClientWrapper |  |  |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| getStratusHttpClient | StratusHttpClient |  |  |
| setStratusHttpClient | void | StratusHttpClient stratusHttpClient |  |
| publishAddOwnershipToStratus | void | Ownership ownership, String tokenid |  |
| getAuthAccessToken | String | String userID |  |
| getPayloadForClaim | String | Ownership ownership, String tokenid |  |
| getEventAttributeValueMap | Map | Map<String, String> eventMap |  |
| getTenantIdFromToken | Token | String token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  tokenid |  |
| getPayloadForUnClaim | String | Ownership ownership, String tokenid |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |
| getPayloadForDeviceClaimByPuc | String | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
