---
type: Component
title: StratusHttpClient
description: Unknown `StratusHttpClient`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusHttpClient.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.http.clients.StratusHttpClient`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| httpClient | CloseableHttpClient |  |
| appConfig | HttpClientConfig |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| StratusHttpClient |  |  |  |
| getAppConfig | HttpClientConfig |  |  |
| setAppConfig | void | HttpClientConfig appConfig |  |
| init | void |  |  |
| getHttpClient | CloseableHttpClient |  |  |
| doGet | HttpResponse | String url, Map<String, String> headers |  |
| addLoggerForHttpCalls | void | long entryTimeInMilliseconds, long exitTimeInMilliseconds, HttpResponse response, long diffTimeInSec, String url, String methodType |  |
| createGetRequest | HttpGet | String url, Map<String, String> headers |  |
| doPost | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| createPostRequest | HttpPost | String url, Map<String, String> headers, HttpEntity entity |  |
| doPut | HttpResponse | String url, Map<String, String> headers, byte[] content |  |
| doPatch | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| doDelete | HttpResponse | String url, Map<String, String> headers |  |
| createPutRequest | HttpPut | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createPatchRequest | HttpPatch | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createDeleteRequest | HttpDelete | String url, Map<String, String> headers |  |
| createResponse | HttpResponseUtil | HttpResponse resp |  |
| setHeaders | void | Map<String, String> headers, HttpUriRequest request |  |
