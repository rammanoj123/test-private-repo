# Other classes

# Concepts

* [CalypsoClientImpl](CalypsoClientImpl.md) - Unknown `CalypsoClientImpl`. (Description pending enrichment.)
* [ClaimStatus](ClaimStatus.md) - Unknown `ClaimStatus`. (Description pending enrichment.)
* [CustomHttpStatus](CustomHttpStatus.md) - Unknown `CustomHttpStatus`. (Description pending enrichment.)
* [EmailAliasRetention](EmailAliasRetention.md) - Unknown `EmailAliasRetention`. (Description pending enrichment.)
* [EventAttribute](EventAttribute.md) - Unknown `EventAttribute`. (Description pending enrichment.)
* [EventAttribute](EventAttribute-eprintcenter.md) - Unknown `EventAttribute`. (Description pending enrichment.)
* [JAXBObjectCreationHelper](JAXBObjectCreationHelper.md) - Unknown `JAXBObjectCreationHelper`. (Description pending enrichment.)
* [LoggingInitializer](LoggingInitializer.md) - Unknown `LoggingInitializer`. (Description pending enrichment.)
* [OptinClientSchedulesMap](OptinClientSchedulesMap.md) - Unknown `OptinClientSchedulesMap`. (Description pending enrichment.)
* [OutEmailHelper](OutEmailHelper.md) - Unknown `OutEmailHelper`. (Description pending enrichment.)
* [OwnerAccessProcessor](OwnerAccessProcessor.md) - Unknown `OwnerAccessProcessor`. (Description pending enrichment.)
* [SortingAndPaginationHelper](SortingAndPaginationHelper.md) - Unknown `SortingAndPaginationHelper`. (Description pending enrichment.)
* [StratusClientImpl](StratusClientImpl.md) - Unknown `StratusClientImpl`. (Description pending enrichment.)
* [StratusEventInfo](StratusEventInfo.md) - Unknown `StratusEventInfo`. (Description pending enrichment.)
* [StratusEventInfo](StratusEventInfo-eprintcenter.md) - Unknown `StratusEventInfo`. (Description pending enrichment.)
* [StratusHttpClient](StratusHttpClient.md) - Unknown `StratusHttpClient`. (Description pending enrichment.)
* [Tenant](Tenant.md) - Unknown `Tenant`. (Description pending enrichment.)
* [Token](Token.md) - Unknown `Token`. (Description pending enrichment.)
* [URIHelper](URIHelper.md) - Unknown `URIHelper`. (Description pending enrichment.)
* [Utility](Utility.md) - Unknown `Utility`. (Description pending enrichment.)
