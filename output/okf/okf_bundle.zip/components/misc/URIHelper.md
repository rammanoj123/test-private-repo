---
type: Component
title: URIHelper
description: Utility class providing centralized URI construction for all ePrint Center REST API endpoints.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\URIHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.URIHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| OPTIN_TYPE | String |  |
| SCHEDULE | String |  |
| UriSeperator | String |  |
| PRINTER_ID | String |  |
| OWNERSHIP_ID | String |  |
| JOBID | String |  |
| DOCUMENTID | String |  |
| PAGE_QUERYSTRING | String |  |
| RESULTS_PER_PAGE | String |  |
| WHITELIST_ID | String |  |
| EmailId | String |  |
| OWNER_ID | String |  |
| GET_FAVORITES | String |  |
| GET_MORE_PRINTER_DETAILS | String |  |
| ParameterLeftDelimiter | String |  |
| ParameterRightDelimiter | String |  |
| OwnershipsUri | String |  |
| PrintJobStatusUri | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintJobURI | String | String jobId |  |
| getCancelURI | String | String jobId |  |
| getPrintJobsURI | String |  |  |
| getPrintJobStatusURI | String | String jobId |  |
| getEmailAddressURIOnRamp | String | String printerId |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getPrintersURIOnRamp | String |  |  |
| getPrinterURIOnRamp | String | String printerId |  |
| getCloudConfigURI | String | String printerId |  |
| getWhiteListURI | String | String printerId |  |
| getWhiteListEntryURI | String | String printerId, String WhiteListID |  |
| getPrinterPrintJobsURI | String | String printerId |  |
| getPrinterSupportedProcesssingElementsURI | String | String printerId |  |
| getPrinterStatusURI | String | String printerId |  |
| getPrinterDefaultProcessingElementsURI | String | String printerId |  |
| getBlackListURI | String | String printerId, String blackListID |  |
| getOwnerAdditionalEmailAddressLink | String | String ownerAdditionalEmailAddressID |  |

# Business context

This class generates consistent URI paths for all REST API resources in the ePrint Center service. It is invoked by resource handlers, entity converters, and link builders to construct URLs for printers, ownerships, print jobs, whitelists, blacklists, and email addresses. Incorrect URI construction breaks hypermedia links in API responses, causing client navigation failures and broken integrations.

# Algorithm

**getParameterURI**

1. Concatenate '{' + parameterName + '}'

**getPrintJobURI**

1. Call getPrintJobsURI()
2. Append jobId and separator

**getCancelURI**

1. Call getPrintJobURI(jobId)
2. Append 'cancel/'

**getPrintJobStatusURI**

1. Call getPrintJobURI(jobId)
2. Append 'status'

**getEmailAddressURIOnRamp**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'emailaddress/'

**getOwnerShipURI**

1. Call getOwnerShipsURI()
2. Append separator, ownerShipId, and separator

**getPrinterURIOnRamp**

1. Call getPrintersURIOnRamp()
2. Append printerId and separator

**getCloudConfigURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'cloudconfiguration/'

**getWhiteListURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'whitelist/'

**getWhiteListEntryURI**

1. Call getWhiteListURI(printerId)
2. Append WhiteListID and '/'

**getPrinterPrintJobsURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'printjobs/'

**getPrinterSupportedProcesssingElementsURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'supportedprocessingelements/'

**getPrinterStatusURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'status/'

**getPrinterDefaultProcessingElementsURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'defaultprocessingelements/'

**getBlackListURI**

1. Call getPrinterURIOnRamp(printerId)
2. Append 'blacklist', separator, and blackListID

**getOwnerAdditionalEmailAddressLink**

1. Concatenate '/users/AdditionalEmailAddress/' with ownerAdditionalEmailAddressID

# Participates in

- [UC-002 — Update Job Printjobs](/usecases/uc-002-update-job-printjobs.md)
- [UC-003 — Get Printer Cloudconfiguration](/usecases/uc-003-get-printer-cloudconfiguration.md)
- [UC-007 — Create Ownership Status](/usecases/uc-007-create-ownership-status.md)
- [UC-008 — Create Ownerships](/usecases/uc-008-create-ownerships.md)
- [UC-009 — Create Printer Ownerships](/usecases/uc-009-create-printer-ownerships.md)
- [UC-010 — Create Printer Ownerships](/usecases/uc-010-create-printer-ownerships.md)
- [UC-012 — Get Device Printer](/usecases/uc-012-get-device-printer.md)
- [UC-013 — Get Device](/usecases/uc-013-get-device.md)
