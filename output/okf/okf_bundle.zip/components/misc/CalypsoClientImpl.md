---
type: Component
title: CalypsoClientImpl
description: Unknown `CalypsoClientImpl`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClientImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.http.clients.CalypsoClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| logger | Logger |  |
| EMAILADDRESS_URL | String |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| httpclient | HttpClientUtil |  |
| pumaClientWrapper | PUMAClientWrapper |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
| executeHttpCall | HttpResponseUtil | String emailAddressUrl, HTTPMethods method, HttpEntity entity |  |
| getMarkedForExpiry | Boolean | String responseBody |  |
| prepareErrorMessage | String | HTTPMethods method, String url, String status |  |
| prepareJsonBody | String | long expiryInMills |  |
| prepareHeaders | Map |  |  |
| trimDomainFromEmailAddress | String | String emailAdddress |  |
| getHttpclient | HttpClientUtil |  |  |
| setHttpclient | void | HttpClientUtil httpclient |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
