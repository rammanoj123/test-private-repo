---
type: Component
title: EventAttribute
description: Data transfer object for event attribute metadata in Stratus event publishing.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\EventAttribute.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.EventAttribute`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |

# Business context

This class carries typed attribute values for events published to the Stratus eventing system. It enables the application to attach structured metadata to business events such as printer state changes or user actions. When event attributes are malformed or missing, downstream analytics and monitoring systems lose visibility into critical operational data.
