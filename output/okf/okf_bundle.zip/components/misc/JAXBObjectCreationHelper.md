---
type: Component
title: JAXBObjectCreationHelper
description: Helper class for creating and populating JAXB response objects from domain entities and external service data.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\JAXBObjectCreationHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| storageEndPoint | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserPrintHistory | PrintHistory | List<com.hp.cloudprint.entities.Document>  documentsBasedOnCriteria, UserHistorySearchCriteria historySearchCriteria, long total, UserIdentities userIdentities, boolean userEmailVerified |  |
| createDocumentForResponse | Document | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities, boolean userEmailVerified |  |
| isDocumentRejectedOrAbortedBecauseOfInputContent | boolean | Document printHistoryDocument |  |
| wasTermsAndConditionsAcceptedWhenJobWasProcessed | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| getStorageEndPoint | String |  |  |
| formNewLinkElement | Link | String name, String href |  |
| isDocumentInPendingState | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| isCurrentUserTheDocumentOwner | boolean | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities |  |
| verifyOriginator | boolean | List<String> allEmailIds, String originatingUserId |  |
| getXMLEncodedDate | XMLGregorianCalendar | Date date |  |
| mapPLSPrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo printerInfo |  |
| mapPLSCompletePrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo completePrinterInfo |  |
| overrideInkCapability | void | PrinterDescription printerDesc |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | String supportedAppPlayerVersions |  |
| getImageListSize | Object | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images imagesFromPLS |  |
| generatePrinterCloudConfigurationJAXBObject | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | PrinterCloudConfiguration printerCloudConfiguration |  |
| configureInkSubscription | void | PrinterDescription printerDesc, byte consumableSubscription |  |
| setDocumentStateAndStateReason | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| setDocumentStateAndStateReasonForError | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| populateOptinSubscriptionDetails | OptinConfig | DataCollectionGroupType dataCollectionGroupType, OptinConfig optinConfig |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Business context

This helper transforms domain entities and external service responses into JAXB schema objects for API responses. It is invoked by every resource that returns printer descriptions, print history, cloud configuration, or opt-in settings. It handles complex mappings including document state translation, access control logic, printer metadata enrichment from PLS, and Instant Ink capability overrides. Incorrect transformations cause API responses to be incomplete, malformed, or to expose data users should not see.

# Algorithm

**getUserPrintHistory**

1. Create new PrintHistory instance
2. For each document entity, call createDocumentForResponse and add to history
3. Set total count
4. Return history

**createDocumentForResponse**

1. Create new Document schema instance
2. Set documentId, name, fileType, sender, fileSize, numberOfPages, printerId
3. Call setDocumentStateAndStateReason to map state
4. Determine if current user is document owner via isCurrentUserTheDocumentOwner
5. Determine if document is pending via isDocumentInPendingState
6. Determine if document is rejected/aborted via isDocumentRejectedOrAbortedBecauseOfInputContent
7. Check if T&C was accepted via wasTermsAndConditionsAcceptedWhenJobWasProcessed
8. If user is owner, doc not pending, not rejected, T&C accepted, and email verified, grant access
9. Set print date and expiration date (creation date + sunset period)
10. If access granted and urlMapper exists, add INPUT, PREVIEW, DOWNLOAD links and set havingAccessToDocument true
11. Otherwise set havingAccessToDocument false
12. If not pending, add DELETE link and set possibleToDeleteDocument true
13. Return document

**isDocumentRejectedOrAbortedBecauseOfInputContent**

1. Check if status is REJECTED
2. Or if status is ABORTED and reason is not PRINTER_OFFLINE or PRINTER_ERROR
3. Return true if either condition holds

**wasTermsAndConditionsAcceptedWhenJobWasProcessed**

1. Check if job's tncVersion equals '2.0'
2. Return true if match, false otherwise

**formNewLinkElement**

1. Create new Link instance
2. Set name and href
3. Return link

**isDocumentInPendingState**

1. Check if document state is CANCELLED, COMPLETED, or ERROR
2. Return false if any match, true otherwise

**isCurrentUserTheDocumentOwner**

1. Check if job's userId matches historySearchCriteria.userId
2. If not, return false
3. If userIdentities is null, return true
4. If additionalEmailAddressEntries is null, return true
5. Call verifyOriginator with all email IDs and originatingUserId
6. Return true if originator matches any email, false otherwise

**verifyOriginator**

1. Iterate over allEmailIds
2. Return true if any email matches originatingUserId (case-insensitive)
3. Return false if no match

**getXMLEncodedDate**

1. Create GregorianCalendar from date
2. Extract year, month+1, day, hour, minute, second, timezone offset
3. Create XMLGregorianCalendar with extracted fields
4. Return calendar

**mapPLSPrinterInfoToPrinterDescriptionForResponse**

1. Throw exception if printerDesc is null
2. Get printerInfo from map by model number
3. Throw exception if not found
4. Set epcTabName, fullName, sbsModelName, suppliesName from printerInfo
5. Create Images instance
6. For each image in printerInfo, create Image schema object and add to Images
7. Set images on printerDesc

**mapPLSCompletePrinterInfoToPrinterDescriptionForResponse**

1. Throw exception if printerDesc is null
2. Get printerInfo from map by model number
3. Throw exception if not found
4. Set epcTabName, fullName, sbsModelName, suppliesName from printerInfo
5. Create Images and populate from printerInfo
6. If sipsDeviceClasses contains SD_APP_DEVICE_CLASS and appPlayerCapabilities exists, set supportedPlayerVersions
7. If sipsDeviceClasses contains SD_APP_DEVICE_CLASS but appPlayerCapabilities is null, create it with supportedPlayerVersions
8. If printerVersion is null, create with launchDate and minSupportedFirmwareVersion
9. Set instantInkCapability and ezSampler from printerInfo

**overrideInkCapability**

1. Build dynamic key with model number
2. Get firmware versions from config
3. If not found, return
4. Extract firmware version substring from printer revision
5. If config value contains firmware version, override instantInkCapability to INK_USAGE_COLLECTION_V2

**getSupportedPlayerVersions**

1. Create SupportedPlayerVersions instance
2. Split supportedAppPlayerVersions by comma
3. Add each version to supportedPlayerVersions
4. Return supportedPlayerVersions

**generatePrinterCloudConfigurationJAXBObject**

1. Create PrinterCloudConfiguration schema instance
2. Set allowsEmail, allowsMobileApps, allowsSips, allowsGoogleServices, protectionMode from entity
3. Return schema object

**configureInkSubscription**

1. Switch on consumableSubscription value
2. If 0, set instantInkCapability to INK_USAGE_COLLECTION_DEFAULT
3. If 1, set instantInkCapability to INK_USAGE_COLLECTION_V2
4. If -1 or other, do not override

**setDocumentStateAndStateReason**

1. Switch on document state
2. Map ACCEPTED to OPENED
3. Map DEVICE_NOTIFIED_FOR_PRINT to SENDING_FILE_TO_PRINTER
4. Map OUTPUT_CREATED to RENDERED
5. Map COMPLETED to COMPLETED
6. Map DEVICE_BUSY/OFFLINE/ERROR/DISCONNECTED to PENDING
7. Map CANCELLED to CANCELED
8. Map ERROR to setDocumentStateAndStateReasonForError
9. Map UNKNOWN to UNKNOWN
10. Default to PROCESSING

**setDocumentStateAndStateReasonForError**

1. Get document state reason
2. If not a known DocumentComments value, set ABORTED with ABORTED_BY_SYSTEM
3. Switch on DocumentComments enum
4. Map each comment to corresponding JobState and StateReason
5. Examples: REJECTED_SPAM_EMAIL_CONTENT -> REJECTED/SPAM_EMAIL_CONTENT
6. DELIVERY_NOTIFY_DEVICE_OFFLINE -> ABORTED/PRINTER_OFFLINE

**populateOptinSubscriptionDetails**

1. If dataCollectionGroupType is null, set both inkSubscription and inkSubscriptionV2 to false
2. If INK_USAGE_COLLECTION, set inkSubscription true and inkSubscriptionV2 false
3. If INK_USAGE_COLLECTION_V2, set inkSubscription false and inkSubscriptionV2 true
4. Return optinConfig

# Business rules

- Access to document content requires ownership, non-pending state, T&C acceptance, and verified email
- Expiration date is creation date plus configured sunset period
- Delete is only possible for non-pending documents
- Only T&C version 2.0 is accepted
- User ID in job must match token user ID
- Originating email must be primary or additional email of user
- Month is adjusted from 0-based to 1-based
- SD app support is enabled if sipsDeviceClasses contains configured device class
- Default ezSampler is 0 if not provided
- Override only applies if model and firmware match config
- 0 disables Instant Ink
- 1 enables Instant Ink V2
- -1 means no override

# Participates in

- [UC-011 — Get Ownership](/usecases/uc-011-get-ownership.md)
- [UC-012 — Get Device Printer](/usecases/uc-012-get-device-printer.md)
- [UC-013 — Get Device](/usecases/uc-013-get-device.md)
- [UC-014 — Get Device Printers](/usecases/uc-014-get-device-printers.md)
- [UC-023 — Get Printers](/usecases/uc-023-get-printers.md)
