---
type: Component
title: OptinClientSchedulesMap
description: Configuration class mapping opt-in types to their allowed schedules.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |

# Business context

This class defines the mapping between opt-in types (CDCA, ACR) and their allowed schedules. It is used by opt-in schedule resources to validate schedule parameters and return available schedules to clients. Incorrect schedule mappings cause validation failures or expose invalid schedule options to users.

# Algorithm

**init**

1. Create EnumMap for OptInEnum to schedule map
2. Create schedule map for CDCA with DEFAULT and S1-S6 schedules
3. Create schedule map for ACR with DEFAULT and S1-S6 schedules
4. Put both maps into clientSchedules

# Business rules

- CDCA and ACR both support DEFAULT and S1-S6 schedules
- Each schedule defines a 4-hour UTC window

# Participates in

- [UC-031 — Get Printer](/usecases/uc-031-get-printer.md)
- [UC-032 — Get Printer Schedules](/usecases/uc-032-get-printer-schedules.md)
