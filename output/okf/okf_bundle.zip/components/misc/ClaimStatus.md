---
type: Component
title: ClaimStatus
description: Enumeration representing the ownership claim state of a printer.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`

# Business context

This enum distinguishes whether a printer is unclaimed, claimed by the current user, or claimed by another user. It drives UI flows for printer registration and prevents multiple users from simultaneously claiming the same device. Incorrect claim status leads to ownership conflicts and users being unable to manage their printers.

# Participates in

- [UC-007 — Create Ownership Status](/usecases/uc-007-create-ownership-status.md)
