---
type: Component
title: CustomHttpStatus
description: Defines custom HTTP status codes not present in standard Restlet status set.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |

# Business context

This class provides a custom 520 status code to signal invalid printer registration attempts. It enables the API to communicate specific error conditions that standard HTTP codes cannot express, allowing clients to distinguish registration failures from other server errors. Misuse of this status code can confuse clients and break error handling logic.
