---
type: Component
title: WpConfigurationServiceProvider
description: Singleton provider for WpConfigurationService used by health checks.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\WpConfigurationServiceProvider.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |

# Business context

This singleton provider manages the WpConfigurationService instance used by the health check controller. It ensures that the configuration service is loaded once and shared across all health checks. If the provider fails to initialize, health checks cannot retrieve configuration values, causing startup failures.

# Business rules

- WpConfigurationService must be initialized at startup
