---
type: Component
title: OwnershipStatusServiceImpl
description: Service implementation for retrieving ownership status of printers.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipStatusServiceImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| version | String |  |
| self | String |  |
| printerManager | IPrinterManager | @Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
| getOwnershipStatusResponse | OwnershipStatusResponse | Ownership ownershipEntity, ClaimStatus claimStatus, String rootUrl |  |

# Depends on

* `IPrinterManager`

# Business context

This service implementation determines whether a printer is claimed, and if so, by whom. It is invoked by ownership status resource handlers when a device attempts to register or a user checks printer availability. It coordinates device lookup, ownership validation, and UUID verification. Incorrect status responses cause registration failures, allow duplicate claims, or expose ownership information to unauthorized users.

# Algorithm

**getOwnershipsForPrinter**

1. Call printerManager.getPrinterBySerialAndModelNumber to get device data
2. Throw DeviceNotFoundExcpeption if device data is null
3. Call printerManager.getActivePrinterByPrinterID to get printer entity
4. Throw InvalidUUIDException if printer entity or additionalInfo is null
5. Throw InvalidUUIDException if printer UUID is null
6. Throw InvalidUUIDException if printer UUID does not match request UUID
7. Try to get ownership for user and printer via getOwnershipEntryForPrinterUserCombination
8. If ownership found and not marked for delete, return claimed status
9. If ownership not found, try to get printer owner via getPrinterOwner
10. If owner found and not marked for delete, return claimed_by_other status
11. If no owner found, return not_claimed status

**getOwnershipStatusResponse**

1. Create OwnershipStatusResponse
2. Set version, ownership_id, ownershipStatus, printer_id from ownership entity
3. Create Link with href = rootUrl + ownership URI and rel = 'self'
4. Add link to response
5. Return response

# Business rules

- UUID in request must match printer's stored UUID
- Ownership marked for delete is treated as non-existent
- Printer UUID must match the UUID in the request

# Participates in

- [UC-007 — Create Ownership Status](/usecases/uc-007-create-ownership-status.md)
