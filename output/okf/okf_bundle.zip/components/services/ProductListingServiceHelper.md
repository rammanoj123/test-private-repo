---
type: Component
title: ProductListingServiceHelper
description: Helper class for retrieving printer metadata from the Product Listing Service (PLS).
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\ProductListingServiceHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| plsClient | PLSClient | @Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPlsClient | void | PLSClient plsClient |  |
| getPrinterInfoFromPLS | Map | String userId, List<String> modelNumbers |  |
| getPrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber |  |
| getCompletePrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber, String firmwareVersion |  |
| getPrinterInfoAsList | List | String modelNumber, PrinterInfoList completePrinterInfoList |  |
| filterPrinterInfoBasedOnFirmwareVersion | PrinterInfo | List<PrinterInfo> printerInfoAsList, String firmwareVersion |  |
| reCreatePrinterInfo | PrinterInfo | AppPlayerEntry matchingPlayerEntry, List<PrinterInfo> printerInfoAsList |  |
| convertToAppPlayerEntries | List | List<PrinterInfo> printerInfoAsList |  |

# Depends on

* `PLSClient`

# Business context

This helper retrieves printer metadata from the Product Listing Service (PLS), including model names, images, firmware requirements, and Instant Ink capabilities. It is invoked by resource handlers when building printer descriptions for API responses. PLS data enriches the basic printer information stored in the database. If PLS is unavailable or returns incomplete data, API responses lack critical metadata, breaking UI rendering and feature detection.

# Algorithm

**getPrinterInfoFromPLS**

1. Call plsClient.getPrinterInfo with userId and modelNumber
2. Throw exception if response is null
3. Iterate over printerInfos in response
4. Return the PrinterInfo whose id contains the modelNumber
5. Return null if no match

**getCompletePrinterInfoFromPLS**

1. Call plsClient.getCompletePrinterInfo with userId and modelNumber
2. Throw exception if response is null
3. Call getPrinterInfoAsList to filter by model number
4. If firmwareVersion is provided, call filterPrinterInfoBasedOnFirmwareVersion
5. If filtering fails or returns null, return first entry from list
6. Return filtered PrinterInfo

**getPrinterInfoAsList**

1. Create empty list
2. Iterate over printerInfos in completePrinterInfoList
3. Add each PrinterInfo whose id contains modelNumber to list
4. Throw exception if list is empty
5. Return list

**filterPrinterInfoBasedOnFirmwareVersion**

1. Convert printerInfoAsList to AppPlayerEntry list
2. Call AppPlayerEntryFinder.findMatchingAppPlayerElements with firmwareVersion
3. Call reCreatePrinterInfo to map matching entry back to PrinterInfo
4. Return PrinterInfo

**reCreatePrinterInfo**

1. Return null if matchingPlayerEntry or printerInfoAsList is null
2. Get PrinterInfo at index matchingPlayerEntry.getId()
3. Return PrinterInfo

**convertToAppPlayerEntries**

1. Create empty AppPlayerEntry list
2. For each PrinterInfo, create AppPlayerEntry with index as id and minSupportedFirmwareVersion
3. Return list

# Business rules

- Firmware version filtering is best-effort; falls back to first entry if filtering fails

# Participates in

- [UC-011 — Get Ownership](/usecases/uc-011-get-ownership.md)
- [UC-012 — Get Device Printer](/usecases/uc-012-get-device-printer.md)
- [UC-013 — Get Device](/usecases/uc-013-get-device.md)
- [UC-014 — Get Device Printers](/usecases/uc-014-get-device-printers.md)
