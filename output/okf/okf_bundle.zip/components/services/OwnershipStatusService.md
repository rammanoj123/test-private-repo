---
type: Component
title: OwnershipStatusService
description: Service interface for retrieving ownership status of printers.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipStatusService.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipStatusService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |

# Business context

This service interface defines the contract for retrieving ownership status of a printer. It is implemented by service classes that coordinate between device lookup, ownership validation, and response building. Clients call this to determine if a printer is claimed, and by whom, which drives UI flows for printer registration and transfer.

# Participates in

- [UC-007 — Create Ownership Status](/usecases/uc-007-create-ownership-status.md)
