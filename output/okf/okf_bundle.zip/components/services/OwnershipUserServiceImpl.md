---
type: Component
title: OwnershipUserServiceImpl
description: Service implementation for managing printer ownerships for users.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipUserServiceImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| printerManager | IPrinterManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnerShipsUsingShardcodeMap | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso, List<String> shardCodeList |  |
| getOwnerShipsUsingAllShard | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| getShardsFromPrinterOwnerShardMap | List | List<String> ownerUserId |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |

# Depends on

* `IPrinterManager`
* [CalypsoClient](/components/services/CalypsoClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Business context

This service implementation manages the lifecycle of printer ownerships from a user's perspective. It is invoked by ownership resource handlers to create, delete, and retrieve ownerships. It coordinates between printer manager, user directory, and Calypso for email alias management. It implements shard-aware ownership lookup to optimize database queries across a multi-tenant architecture. Failures in ownership management prevent users from claiming, transferring, or releasing printers, and can cause cross-tenant data leakage if shard routing is incorrect.

# Algorithm

**addOwnership**

1. Call printerManager.addOwnerForPrinter with ownership, expiry duration, and email IDs
2. Get EprintUserDirectory instance
3. Call addPrinterOwnerShardMapEntry with userId, printerId, and current shard
4. Log and continue if entry already exists or directory exception occurs

**addOwnershipByPrinterId**

1. Call printerManager.addOwnerForPrinterByPrinterId with ownership
2. Get EprintUserDirectory instance
3. Call addPrinterOwnerShardMapEntry with userId, printerId, and current shard
4. Log and continue if entry already exists or directory exception occurs

**deleteOwnership**

1. Determine if email alias should be retained for user based on emailAliasRetention parameter
2. If USER retention, get ownership details and check if printer has friendly email alias (FEA)
3. Set retainAliasForUser flag to true only if USER retention AND printer has FEA
4. Call printerManager.markAndReturnOwnershipForDeletion with ownershipId and retention flag
5. Get EprintUserDirectory instance
6. Call deletePrinterOwnerShardMapEntry with userId and printerId
7. If retaining alias for user and printer has FEA, call calypsoClient.patchEmailAddress with TTL
8. Return rows updated count

**getOwnershipsForUser**

1. Get all user IDs from ownerUserIdentities
2. If ownerships shard map is enabled via isOwnershipsEnabledForGetShardFromMap
3. Get shard codes from PrinterOwnerShardMap via getShardsFromPrinterOwnerShardMap
4. If shard codes are empty and fallback is required, call getOwnerShipsUsingAllShard
5. Otherwise call getOwnerShipsUsingShardcodeMap with shard codes
6. If shard map is disabled, call getOwnerShipsUsingAllShard
7. Return ownerships or empty list

**getOwnerShipsUsingShardcodeMap**

1. Get all user IDs from ownerUserIdentities
2. If ownerUserIdentities is not null, call printerManager.getOwnershipByMultipleOwnerUserIDs with shard codes
3. Otherwise call printerManager.getOwnershipsForUser with userId and shard codes
4. Log performance metrics if enabled
5. Log warning if ownerships are empty (stale shard map entry)
6. Return ownerships

**getOwnerShipsUsingAllShard**

1. Get all user IDs from ownerUserIdentities
2. If ownerUserIdentities is not null, call printerManager.getOwnershipByMultipleOwnerUserIDs without shard codes
3. Otherwise call printerManager.getOwnershipsForUser without shard codes
4. Log performance metrics if enabled
5. Log ownership details if found
6. Return ownerships

**getShardsFromPrinterOwnerShardMap**

1. Get EprintUserDirectory instance
2. Call getShardsFromPrinterOwnerShardMap with ownerUserId list
3. Log performance metrics if enabled
4. Log warning if shard map is empty
5. Return shard map or null on exception

**getOwnershipsForUserToDelete**

1. Call printerManager.getOwnershipForId with ownerShipId
2. Return ownership details

# Business rules

- Shard map entry is best-effort; failure is logged but does not fail the operation
- Email alias is retained for user only if USER retention is requested AND printer has a friendly email alias
- Shard map deletion failure is logged but does not fail the operation
- Shard map optimization is controlled by configuration flag
- Fallback to all-shard query is controlled by configuration flag

# Participates in

- [UC-008 — Create Ownerships](/usecases/uc-008-create-ownerships.md)
- [UC-009 — Create Printer Ownerships](/usecases/uc-009-create-printer-ownerships.md)
- [UC-010 — Create Printer Ownerships](/usecases/uc-010-create-printer-ownerships.md)
