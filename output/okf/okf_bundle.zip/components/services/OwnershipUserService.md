---
type: Component
title: OwnershipUserService
description: Service interface for managing printer ownerships for users.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipUserService.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |

# Business context

This service interface defines the contract for managing printer ownerships from a user perspective. It is implemented by service classes that coordinate between ownership creation, deletion, and retrieval, and is invoked by ownership resource handlers. It abstracts the printer manager layer, enabling ownership operations to be tested and extended independently. Failures in ownership management prevent users from claiming, transferring, or releasing printers.

# Business rules

- Email alias retention determines whether alias stays with user or device

# Participates in

- [UC-008 — Create Ownerships](/usecases/uc-008-create-ownerships.md)
- [UC-009 — Create Printer Ownerships](/usecases/uc-009-create-printer-ownerships.md)
- [UC-010 — Create Printer Ownerships](/usecases/uc-010-create-printer-ownerships.md)
