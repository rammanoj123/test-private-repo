---
type: Component
title: InvalidUUIDException
description: Exception thrown when a printer UUID is invalid or does not exist.
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |

# Business context

This exception signals that a printer ID provided in a request does not match any known device. It is thrown by resource handlers when validating printer identifiers and enables the API to return a 404 response with a descriptive error message. Incorrect exception handling causes generic 500 errors instead of actionable 404s, confusing clients and users.
