---
type: Component
title: EPrintCenterAPIConfig
description: Centralized configuration manager for the ePrint Center API service.
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EPrintCenterAPIConfig.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| objectInstance | EPrintCenterAPIConfig |  |
| wpConfigurationService | WpConfigurationService | @Resource |
| SERVICE_NAME | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EPrintCenterAPIConfig |  |  |  |
| getInstance | EPrintCenterAPIConfig |  |  |
| init | void |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getBooleanValue | boolean | String key |  |
| getStringValue | String | String key |  |
| getIntValue | int | String key |  |
| getMaxCountForUserPrintHistory | int |  |  |
| getDocumentSunsetNumberOfDays | int |  |  |
| enableMigrationDateCheck | boolean |  |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getRetryAfterInSecs | String |  |  |
| getKeys | Iterator | String prefix |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |
| getInstantInkOverrideValue | int |  |  |
| isCalypsoEmailAddressReplicationEnabled | boolean |  |  |
| isCalypsoEmailAddressValidationEnabled | boolean |  |  |
| getCalypsoUrl | String |  |  |
| getCalypsoRetryCount | int |  |  |
| getCalypsoAuthToken | String |  |  |
| getFeaTTL | Long |  |  |
| getDomain | String |  |  |
| getStratusPublishUrl | String |  |  |

# Depends on

* `WpConfigurationService`

# Business context

This singleton provides access to all runtime configuration properties, including feature flags, external service URLs, retry counts, and business rule parameters. It abstracts configuration sources (XML files or WpConfigurationService) and is queried by every component that needs environment-specific settings. Configuration errors or missing values cause service startup failures, incorrect behavior, or integration breakdowns with external systems like Calypso and Stratus.

# Algorithm

**getInstance**

1. Check if objectInstance is null
2. If null, synchronize on class and double-check
3. Create new instance and call init()
4. Return objectInstance

**init**

1. Check if wpConfigurationService is null
2. If null, load XMLConfiguration from EPrintCenterAPIConfig.xml
3. Throw CpFaultException if loading fails

**getBooleanValue**

1. If wpConfigurationService is available, delegate to it
2. Otherwise call super.getBooleanValue

**getStringValue**

1. If wpConfigurationService is available, delegate to it
2. Otherwise call super.getStringValue

**getIntValue**

1. If wpConfigurationService is available, delegate to it
2. Otherwise call super.getIntValue

**getMaxCountForUserPrintHistory**

1. Call getIntValue with key MAX_COUNT_FOR_USER_PRINT_HISTORY and default -1

**getDocumentSunsetNumberOfDays**

1. Call getIntValue with key FILE_SUNSET_PERIOD and default 30

**getKeys**

1. If wpConfigurationService is available, delegate to it
2. Otherwise return hardcoded list with 'uph.history.client.EmailGW'

# Business rules

- Must be thread-safe for concurrent initialization
- XML file must be present if WpConfigurationService is not injected
- Singleton instance must be initialized before any configuration access
- Configuration source must be available at startup

# Participates in

- [UC-001 — Get Version](/usecases/uc-001-get-version.md)
- [UC-006 — Create Emailaddress](/usecases/uc-006-create-emailaddress.md)
- [UC-008 — Create Ownerships](/usecases/uc-008-create-ownerships.md)
- [UC-010 — Create Printer Ownerships](/usecases/uc-010-create-printer-ownerships.md)
- [UC-011 — Get Ownership](/usecases/uc-011-get-ownership.md)
- [UC-012 — Get Device Printer](/usecases/uc-012-get-device-printer.md)
- [UC-013 — Get Device](/usecases/uc-013-get-device.md)
- [UC-014 — Get Device Printers](/usecases/uc-014-get-device-printers.md)
