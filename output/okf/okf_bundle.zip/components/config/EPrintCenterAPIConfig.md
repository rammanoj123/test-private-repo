---
type: Component
title: EPrintCenterAPIConfig
description: Config `EPrintCenterAPIConfig`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EPrintCenterAPIConfig.java
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

`com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| objectInstance | EPrintCenterAPIConfig |  |
| wpConfigurationService | WpConfigurationService | @Resource |
| SERVICE_NAME | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EPrintCenterAPIConfig |  |  |  |
| getInstance | EPrintCenterAPIConfig |  |  |
| init | void |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getBooleanValue | boolean | String key |  |
| getStringValue | String | String key |  |
| getIntValue | int | String key |  |
| getMaxCountForUserPrintHistory | int |  |  |
| getDocumentSunsetNumberOfDays | int |  |  |
| enableMigrationDateCheck | boolean |  |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getRetryAfterInSecs | String |  |  |
| getKeys | Iterator | String prefix |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |
| getInstantInkOverrideValue | int |  |  |
| isCalypsoEmailAddressReplicationEnabled | boolean |  |  |
| isCalypsoEmailAddressValidationEnabled | boolean |  |  |
| getCalypsoUrl | String |  |  |
| getCalypsoRetryCount | int |  |  |
| getCalypsoAuthToken | String |  |  |
| getFeaTTL | Long |  |  |
| getDomain | String |  |  |
| getStratusPublishUrl | String |  |  |

# Depends on

* `WpConfigurationService`
