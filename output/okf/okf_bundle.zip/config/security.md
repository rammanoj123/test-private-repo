---
type: Configuration
title: Security
description: Configures security through jwt_present, oauth2_providers, ldap_url.
tags: [config, security]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Key | Value |
| --- | --- |
| jwt_present | False |
| oauth2_providers | [] |
| ldap_url | None |

# Purpose

`Security` carries 3 configuration key(s) for this service, 0 of them set in the scanned configuration and 3 left at their default.

Present but unset (default applies): `jwt_present`, `oauth2_providers`, `ldap_url`.
