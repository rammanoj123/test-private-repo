---
type: Configuration
title: Application context
description: Profiles and legacy XML wiring.
tags: [config, xml]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

# Legacy XML beans

| Bean id | Class | Scope | Source |
| --- | --- | --- | --- |
| jefDAO | com.hp.cloudprint.jef.entities.dao.impl.JEFDAOImpl | prototype | applicationContext-eprintcenter.xml |
| jobDAO | com.hp.cloudprint.entities.dao.impl.JobDAOImpl | prototype | applicationContext-eprintcenter.xml |
| jobService | com.hp.cloudprint.pjp.common.jobservice.JobService | prototype | applicationContext-eprintcenter.xml |
| jobCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-eprintcenter.xml |
| printCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-eprintcenter.xml |
| renderCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-eprintcenter.xml |
| printService | com.hp.cloudprint.pjp.jobservice.PrintServiceImpl | prototype | applicationContext-eprintcenter.xml |
| scanService | com.hp.cloudprint.pjp.scan.impl.ScanServiceImpl | prototype | applicationContext-eprintcenter.xml |
| securityManager | com.hp.cloudprint.security.impl.SecurityManagerImpl | prototype | applicationContext-eprintcenter.xml |
| securityDirectory | com.hp.cloudprint.eprintdirectory.security.impl.SecurityDirectoryImpl | prototype | applicationContext-eprintcenter.xml |
| securityDAO | com.hp.cloudprint.entities.dao.impl.SecurityDAOImpl | singleton | applicationContext-eprintcenter.xml |
| eprintCenterExporter | org.springframework.jmx.export.MBeanExporter | singleton | applicationContext-eprintcenter.xml |
| metricsHolder | com.hp.cloudprint.metrics.MetricsHolder | singleton | applicationContext-eprintcenter.xml |
| emailAddressGenerator | com.hp.cloudprint.eprintdirectory.emailaddressgenerator.impl.EmailAddressGeneratorImpl | singleton | applicationContext-eprintcenter.xml |
| requestProcessor | com.hp.cloudprint.api.processors.CPGRequestProcessor | singleton | applicationContext-eprintcenter.xml |
| securityProcessor | com.hp.cloudprint.api.processors.CPGSecurityProcessor | singleton | applicationContext-eprintcenter.xml |
| logProcessor | com.hp.cloudprint.api.processors.CPGLogProcessor | singleton | applicationContext-eprintcenter.xml |
| abstractCPGResourceHandler | com.hp.cloudprint.api.common.CPGResourceHandler | singleton | applicationContext-eprintcenter.xml |
| ownerSecureAbstractCPGResourceHandler | com.hp.cloudprint.api.common.CPGResourceHandler | singleton | applicationContext-eprintcenter.xml |
| papiConfig | com.hp.cloud.eprint.papi.services.common.config.PAPIConfigAppConfigImpl | singleton | applicationContext-eprintcenter.xml |
| pumaClientWrapper | com.hp.cloud.eprint.papi.services.common.PUMAClientWrapper | singleton | applicationContext-eprintcenter.xml |
| pdsClientWrapper | com.hp.cloud.eprint.papi.services.common.PDSClientWrapper | singleton | applicationContext-eprintcenter.xml |
| httpClient | com.hp.cloudprint.util.url.CpHttpClient | prototype | applicationContext-eprintcenter.xml |
| plsClient | com.hp.cloud.eprint.papi.services.pls.client.impl.PLSClientImpl | prototype | applicationContext-eprintcenter.xml |
| eosClient | com.hp.cloud.eprint.papi.services.eos.client.impl.EOSClientImpl | prototype | applicationContext-eprintcenter.xml |
| pamClient | com.hp.cloud.eprint.papi.services.pam.client.impl.PamClientImpl | prototype | applicationContext-eprintcenter.xml |
| ulsClient | com.hp.cloud.eprint.papi.services.uls.client.impl.ULSClientImpl | prototype | applicationContext-eprintcenter.xml |
| productListingServiceHelper | com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper | prototype | applicationContext-eprintcenter.xml |
| jaxbObjectCreationHelper | com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper | prototype | applicationContext-eprintcenter.xml |
| sortingAndPaginationHelper | com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper | prototype | applicationContext-eprintcenter.xml |
| outEmailHelper | com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper | prototype | applicationContext-eprintcenter.xml |
| userEmailAddressHelper | com.hp.cloud.eprint.papi.user.helper.UserEmailAddressHelper | singleton | applicationContext-eprintcenter.xml |
| ePrintCenterAPIConfig | com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig | prototype | applicationContext-eprintcenter.xml |
| pjpAppConfig | com.hp.cloudprint.pjp.common.AppConfig | singleton | applicationContext-eprintcenter.xml |
| mcsMasterClient | com.sun.jersey.api.client.Client | singleton | applicationContext-eprintcenter.xml |
| ownershipUserService | com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl | singleton | applicationContext-eprintcenter.xml |
| ownershipStatusService | com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl | singleton | applicationContext-eprintcenter.xml |
| eprintUserDirectoryContextFactory | com.hp.cloudprint.eprintuserdirectory.util.EprintUserDirectoryContextFactory | singleton | applicationContext-eprintcenter.xml |
| httpClientAppConfig | com.hp.cloudprint.httpclient.config.HttpClientConfig | singleton | applicationContext-eprintcenter.xml |
| httpClientUtil | com.hp.cloudprint.httpclient.HttpClientUtil | singleton | applicationContext-eprintcenter.xml |
| calypsoClient | com.hp.cloudprint.http.clients.CalypsoClientImpl | singleton | applicationContext-eprintcenter.xml |
| pumaClientTokenGenerator | com.hp.cloud.eprint.papi.services.common.PumaClientTokenGenerator | singleton | applicationContext-eprintcenter.xml |
| stratusHttpClient | com.hp.cloudprint.http.clients.StratusHttpClient | singleton | applicationContext-eprintcenter.xml |
| stratusClient | com.hp.cloudprint.http.clients.StratusClientImpl | prototype | applicationContext-eprintcenter.xml |
| root | org.restlet.ext.spring.SpringRouter | singleton | applicationContext-restlet.xml |
| resourceMap | java.util.HashMap | singleton | applicationContext-restlet.xml |
| version | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| cancelPrint | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| cloudConfiguration | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| emailAddress | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| suggestions | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| availability | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| ownerShips | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| ownerShip | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| deviceOwnership | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| deviceOwnershipStratus | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| solutionOptIn | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| optinSchedule | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| ownershipStatus | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printer | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printerStatus | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| whiteList | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printerDefaultsProcessingElements | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| whiteListEntry | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printJobs | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printerSupportedProcessingElements | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| appPlayerEvent | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| printerOwner | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| optInConfig | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| consumableSubscriptionConfig | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| optinInkLevel | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| optinCDCA | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| optinSuppliesInfo | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| versionResource | com.hp.cloudprint.api.eprintcenter.resources.VersionResource | prototype | applicationContext-restlet.xml |
| cancelPrintResource | com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource | prototype | applicationContext-restlet.xml |
| cloudConfigurationResource | com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource | prototype | applicationContext-restlet.xml |
| emailAddressResource | com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource | prototype | applicationContext-restlet.xml |
| suggestionsResource | com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource | prototype | applicationContext-restlet.xml |
| availabilityResource | com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource | prototype | applicationContext-restlet.xml |
| ownerShipsResource | com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource | prototype | applicationContext-restlet.xml |
| ownerShipResource | com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource | prototype | applicationContext-restlet.xml |
| deviceOwnershipResource | com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource | prototype | applicationContext-restlet.xml |
| deviceOwnershipStratusResource | com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource | prototype | applicationContext-restlet.xml |
| ownershipsStatusResource | com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource | prototype | applicationContext-restlet.xml |
| printerResource | com.hp.cloudprint.api.eprintcenter.resources.PrinterResource | prototype | applicationContext-restlet.xml |
| printerStatusResource | com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource | prototype | applicationContext-restlet.xml |
| whiteListResource | com.hp.cloudprint.api.eprintcenter.resources.WhiteListResource | prototype | applicationContext-restlet.xml |
| printerDefaultsProcessingElementsResource | com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource | prototype | applicationContext-restlet.xml |
| whiteListEntryResource | com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource | prototype | applicationContext-restlet.xml |
| printJobsResource | com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource | prototype | applicationContext-restlet.xml |
| printerSupportedProcessingElementsResource | com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource | prototype | applicationContext-restlet.xml |
| appPlayerEventResource | com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource | prototype | applicationContext-restlet.xml |
| printerOwnerResource | com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource | prototype | applicationContext-restlet.xml |
| optInConfigResource | com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource | prototype | applicationContext-restlet.xml |
| consumableSubscriptionConfigResource | com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource | prototype | applicationContext-restlet.xml |
| optinInkLevelResource | com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource | prototype | applicationContext-restlet.xml |
| optinCDCAResource | com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource | prototype | applicationContext-restlet.xml |
| solutionOptInResource | com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource | prototype | applicationContext-restlet.xml |
| optInScheduleResource | com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource | prototype | applicationContext-restlet.xml |
| optinSuppliesInfoResource | com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource | prototype | applicationContext-restlet.xml |
| blackListsFinder | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| blackListsHandler | None | prototype | applicationContext-restlet.xml |
| blackListFinder | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| blackListHandler | None | prototype | applicationContext-restlet.xml |
| whiteListFinder | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml |
| whiteListHandler | None | prototype | applicationContext-restlet.xml |
| springSecurityFilterChain | org.springframework.security.web.FilterChainProxy | singleton | applicationContext-security.xml |
| authHeaderAnalyzingFilter | com.hp.cloudprint.security.filters.AuthHeaderAnalyzingFilter | singleton | applicationContext-security.xml |
| basicAuthenticationFilter | com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilter | singleton | applicationContext-security.xml |
| oAuth2Filter | com.hp.cloudprint.security.filters.AuthorizationFilter | singleton | applicationContext-security.xml |
| x509AuthFilter | com.hp.cloudprint.security.filters.AuthorizationFilter | singleton | applicationContext-security.xml |
| oAuth1Filter | com.hp.cloudprint.security.filters.AuthorizationFilter | singleton | applicationContext-security.xml |
| exceptionTranslationFilter | com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter | singleton | applicationContext-security.xml |
| x509Filter | org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter | singleton | applicationContext-security.xml |
| ProtectedResourceProcessingFilter | com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceProcessingFilter_DraftHammer | singleton | applicationContext-security.xml |
| consumerDetails | com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider | singleton | applicationContext-security.xml |
| OAuthSignatureFactory | com.hp.cloudprint.api.eprintcenter.security.CoreOAuthSignatureMethodFactory_DraftHammer | singleton | applicationContext-security.xml |
| ProtectedResourceAccessTokenService | com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService | singleton | applicationContext-security.xml |
| OAuthProcessingFilterEntryPoint | org.springframework.security.oauth.provider.OAuthProcessingFilterEntryPoint | singleton | applicationContext-security.xml |
| x509AuthenticationManager | org.springframework.security.authentication.ProviderManager | singleton | applicationContext-security.xml |
| jdbcMutableAclService | com.hp.cloudprint.security.JdbcMutableAclService_withFixes | singleton | applicationContext-security.xml |
| basicLookupStrategy | com.hp.cloudprint.security.BasicLookupStrategy_withFixes | singleton | applicationContext-security.xml |
| NullAclCache | com.hp.cloudprint.security.NullAclCache | singleton | applicationContext-security.xml |
| httpSessionContextIntegrationFilter | org.springframework.security.web.context.SecurityContextPersistenceFilter | singleton | applicationContext-security.xml |
| x509NullAuthenticationFilter | com.hp.cloudprint.api.eprintcenter.security.X509NullAuthenticationFilter | singleton | applicationContext-security.xml |
| channelDecisionManager | org.springframework.security.web.access.channel.ChannelDecisionManagerImpl | singleton | applicationContext-security.xml |
| secureChannelProcessor | org.springframework.security.web.access.channel.SecureChannelProcessor | singleton | applicationContext-security.xml |
| pumaValidateFilter | com.hp.cloudprint.api.puma.validate.filters.PUMAValidateFilter | singleton | applicationContext-security.xml |
| ownerAccessProcessor | com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor | singleton | applicationContext-security.xml |
| shardPersistenceFilter | com.hp.cloudprint.api.eprintcenter.security.ShardPersistenceFilter | singleton | applicationContext-security.xml |
| urlProcessorUtility | com.hp.cloudprint.util.impl.URLProcessorUtilityImpl | singleton | applicationContext-security.xml |
| wpConfigurationService | com.hp.ipg.iws.wp.common.config.WpConfigurationServiceImpl | singleton | applicationContext-wpConfigService.xml |
| wpPropertyPlaceholderConfigurer | com.hp.ipg.iws.wp.common.config.WpPropertyPlaceholderConfigurer | singleton | applicationContext-wpConfigService.xml |
| serviceName | java.lang.String | singleton | applicationContext-wpConfigService.xml |
| ePrintDirectoryConfig | com.hp.cloudprint.eprintdirectory.config.EPrintDirectoryConfig | singleton | applicationContext-wpConfigService.xml |

# Purpose

`Application context` is a Configuration in this bundle. The generator recorded no key/value detail for it, so what it configures is not stated in the scanned sources.
