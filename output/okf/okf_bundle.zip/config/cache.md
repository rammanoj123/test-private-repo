---
type: Configuration
title: Cache
description: Configures cache through type, redis_host.
tags: [config, cache]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Key | Value |
| --- | --- |
| type | None |
| redis_host | None |

# Purpose

`Cache` carries 2 configuration key(s) for this service, 0 of them set in the scanned configuration and 2 left at their default.

Present but unset (default applies): `type`, `redis_host`.
