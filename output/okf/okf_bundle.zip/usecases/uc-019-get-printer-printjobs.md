---
type: Use Case
title: UC-019 — Get Printer Printjobs
description: Carries out Get Printer Printjobs triggered by GET /devices/printers/{PrinterID}/printjobs/ entering at PrintJobsResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-019
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-019 |
| Trigger | GET /devices/printers/{PrinterID}/printjobs/ |
| Actor | API Client |
| Entry point | PrintJobsResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `EprintShardHolder`.`setShard()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 2 | `ShardUtil`.`getShardCodeFromIdString()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 3 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 4 | `PrintService`.`getActiveJobsFromCurrentShard()` | library `com.hp.cloudprint.pjp` |
| 5 | [PrintJobsResource](/components/controllers/PrintJobsResource.md).`setCorrespondingJobStateAndStateReasonInJobReference()` | this service |
| 6 | ↳ `StateReasons`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 7 | [URIHelper](/components/misc/URIHelper.md).`getPrintJobURI()` | this service |
| 8 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [PrintJobsResource](/components/controllers/PrintJobsResource.md).
