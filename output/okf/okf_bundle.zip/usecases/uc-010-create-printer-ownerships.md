---
type: Use Case
title: UC-010 — Create Printer Ownerships
description: Carries out Create Printer Ownerships triggered by POST /v1/devices/printers/ownerships entering at DeviceOwnershipStratusResource.acceptRepresentation.
tags: [usecase]
status: draft
usecase_id: UC-010
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-010 |
| Trigger | POST /v1/devices/printers/ownerships |
| Actor | API Client |
| Entry point | DeviceOwnershipStratusResource.acceptRepresentation |
| Entry resolved by | Restlet dispatch convention (`acceptRepresentation`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC`, `Logger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 2 | ↳ `WpConfigurationService`.`getBoolean()` | library `com.hp.ipg.iws.wp.common.config` |
| 3 | ↳ `ApplicationConfig`.`getBooleanValue()` | library `com.hp.cloudprint.util.config` |
| 4 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` | this service |
| 5 | ↳ [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`getErrorResponse()` | this service |
| 6 | ↳ ↳ `Errors`.`toJsonAsString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |
| 7 | ↳ [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`getResponse()` | this service |
| 8 | ↳ ↳ [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`getRequest()` | this service |
| 9 | ↳ ↳ [URIHelper](/components/misc/URIHelper.md).`getOwnerShipURI()` | this service |
| 10 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`unMarshalAndValidateOwnershipsInput()` | this service |
| 11 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 12 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`fetchPrinterDetails()` | this service |
| 13 | ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 14 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`getOwnership()` | this service |
| 15 | ↳ `ShardUtil`.`getIdStringFromIdAsString()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 16 | [OwnershipUserService](/components/services/OwnershipUserService.md).`addOwnershipByPrinterId()` | this service |
| 17 | ↳ `IPrinterManager`.`addOwnerForPrinterByPrinterId()` | library `com.hp.cloudprint.devices.printer` |
| 18 | ↳ [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md).`getEprintUserDirectory()` | this service |
| 19 | ↳ ↳ `EprintUserDirectoryContextFactory`.`getEprintUserDirectory()` | library `com.hp.cloudprint.eprintuserdirectory.util` |
| 20 | ↳ `EprintUserDirectory`.`addPrinterOwnerShardMapEntry()` | library `com.hp.cloudprint.eprintuserdirectory.service` |
| 21 | ↳ `EprintShardHolder`.`getShard()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 22 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`getRequest()` | this service |
| 23 | [StratusClient](/components/services/StratusClient.md).`publishAddOwnershipToStratus()` | this service |
| 24 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStratusPublishUrl()` | this service |
| 25 | ↳ ↳ `WpConfigurationService`.`getString()` | library `com.hp.ipg.iws.wp.common.config` |
| 26 | ↳ [StratusClientImpl](/components/misc/StratusClientImpl.md).`getAuthAccessToken()` | this service |
| 27 | ↳ ↳ `PUMAClientWrapper`.`getAccessToken()` | library `com.hp.cloud.eprint.papi.services.common` |
| 28 | ↳ [StratusClientImpl](/components/misc/StratusClientImpl.md).`getPayloadForClaim()` | this service |
| 29 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStringValue()` | this service |
| 30 | ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`doPost()` | this service |
| 31 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`createPostRequest()` | this service |
| 32 | ↳ ↳ `HttpClientConfig`.`getRetryThreshold()` | library `com.hp.cloudprint.httpclient.config` |
| 33 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` | this service |
| 34 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` _(error path)_ | this service |
| 35 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` _(error path)_ | this service |
| 36 | [StratusClient](/components/services/StratusClient.md).`publishAddOwnershipToStratusForPucToken()` | this service |
| 37 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStratusPublishUrl()` | this service |
| 38 | ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`doPost()` | this service |
| 39 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 40 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 41 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 42 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 43 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 44 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 45 | [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).`returnErrorResponse()` | this service |

Implemented by [DeviceOwnershipStratusResource](/components/controllers/DeviceOwnershipStratusResource.md).
