---
type: Use Case
title: UC-023 — Get Printers
description: Carries out Get Printers triggered by GET /devices/printers/{PrinterID}/optin/ entering at OptInConfigResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-023
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-023 |
| Trigger | GET /devices/printers/{PrinterID}/optin/ |
| Actor | API Client |
| Entry point | OptInConfigResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `PrinterCloudConfigurationManager`.`getOptInDataCollectionGroupType()` | library `com.hp.cloudprint.devices.management` |
| 2 | [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`populateOptinSubscriptionDetails()` | this service |
| 3 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [OptInConfigResource](/components/controllers/OptInConfigResource.md).
