---
type: Use Case
title: UC-030 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} entering at BlackListHandler.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-030
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-030 |
| Trigger | GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} |
| Actor | API Client |
| Entry point | BlackListHandler.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, DELETE → `handleDelete` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [EntityConverter](/domain/EntityConverter.md).`createBlackListEntry()` | this service |
| 2 | `IPrinterManager`.`getBlackListEntry()` | library `com.hp.cloudprint.devices.printer` |

Implemented by [BlackListHandler](/components/controllers/BlackListHandler.md).
