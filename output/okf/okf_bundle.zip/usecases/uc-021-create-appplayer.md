---
type: Use Case
title: UC-021 — Create Appplayer
description: Carries out Create Appplayer triggered by POST /devices/printers/{PrinterID}/appplayer/event/ entering at AppPlayerEventResource.acceptRepresentation.
tags: [usecase]
status: draft
usecase_id: UC-021
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-021 |
| Trigger | POST /devices/printers/{PrinterID}/appplayer/event/ |
| Actor | API Client |
| Entry point | AppPlayerEventResource.acceptRepresentation |
| Entry resolved by | Restlet dispatch convention (`acceptRepresentation`) |
| Cross-cutting | `EPrintLogger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 2 | ↳ `WpConfigurationService`.`getBoolean()` | library `com.hp.ipg.iws.wp.common.config` |
| 3 | ↳ `ApplicationConfig`.`getBooleanValue()` | library `com.hp.cloudprint.util.config` |
| 4 | [Utility](/components/misc/Utility.md).`unMarshalAndValidate()` | this service |
| 5 | [Utility](/components/misc/Utility.md).`getSchema()` | this service |
| 6 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getInstance()` | this service |
| 7 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`init()` | this service |
| 8 | [Utility](/components/misc/Utility.md).`unmarshal()` | this service |
| 9 | `PrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 10 | `PrinterManager`.`deleteScreenCache()` | library `com.hp.cloudprint.devices.printer` |

Implemented by [AppPlayerEventResource](/components/controllers/AppPlayerEventResource.md).
