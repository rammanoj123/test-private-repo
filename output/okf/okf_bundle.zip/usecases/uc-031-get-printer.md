---
type: Use Case
title: UC-031 — Get Printer
description: Carries out Get Printer triggered by GET /v2/devices/printers/{PrinterID}/optin/{optinType} entering at SolutionOptInResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-031
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-031 |
| Trigger | GET /v2/devices/printers/{PrinterID}/optin/{optinType} |
| Actor | API Client |
| Entry point | SolutionOptInResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`handleMethod()` | this service |
| 2 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`getPrinter()` | this service |
| 3 | ↳ ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 4 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`validateOptInTypeAndSchedule()` | this service |
| 5 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 6 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 7 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`putPrinterCloudConfiguration()` | this service |
| 8 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 9 | ↳ ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`putPrinterCloudConfigurationOptin()` | this service |
| 10 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 11 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`deletePrinterCloudConfiguration()` | this service |
| 12 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 13 | ↳ ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`deletePrinterCloudConfigurationOptin()` | this service |
| 14 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 15 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`getPrinterCloudConfiguration()` | this service |
| 16 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 17 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 18 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 19 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 20 | ↳ ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 21 | ↳ [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).`getErrorResponse()` _(error path)_ | this service |
| 22 | ↳ ↳ `Errors`.`toJsonAsString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |

Implemented by [SolutionOptInResource](/components/controllers/SolutionOptInResource.md).
