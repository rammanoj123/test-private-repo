---
type: Use Case
title: UC-008 — Create Ownerships
description: Carries out Create Ownerships triggered by POST /ownerships entering at OwnerShipsResource.acceptRepresentation.
tags: [usecase]
status: draft
usecase_id: UC-008
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-008 |
| Trigger | POST /ownerships |
| Actor | API Client |
| Entry point | OwnerShipsResource.acceptRepresentation |
| Entry resolved by | Restlet dispatch convention (`acceptRepresentation`) |
| Handlers | POST → `acceptRepresentation`, PUT → `storeRepresentation`, GET → `handleGet` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC`, `Logger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).`unMarshalAndValidateOwnershipsInput()` | this service |
| 2 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 3 | ↳ ↳ `WpConfigurationService`.`getBoolean()` | library `com.hp.ipg.iws.wp.common.config` |
| 4 | ↳ ↳ `ApplicationConfig`.`getBooleanValue()` | library `com.hp.cloudprint.util.config` |
| 5 | ↳ [Utility](/components/misc/Utility.md).`unMarshalAndValidate()` | this service |
| 6 | ↳ [Utility](/components/misc/Utility.md).`getSchema()` | this service |
| 7 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getInstance()` | this service |
| 8 | ↳ [Utility](/components/misc/Utility.md).`unmarshal()` | this service |
| 9 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 10 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 11 | [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).`verifyPrinterStatus()` | this service |
| 12 | ↳ `IPrinterManager`.`getActivePrinterByEmailAddress()` | library `com.hp.cloudprint.devices.printer` |
| 13 | ↳ `IPrinterManager`.`getActivePrinterByClaimCode()` | library `com.hp.cloudprint.devices.printer` |
| 14 | `ShardUtil`.`getIdStringFromIdAsString()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 15 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getIntValue()` | this service |
| 16 | ↳ `WpConfigurationService`.`getInt()` | library `com.hp.ipg.iws.wp.common.config` |
| 17 | ↳ `ApplicationConfig`.`getIntValue()` | library `com.hp.cloudprint.util.config` |
| 18 | `UserEmailAddressHelper`.`getAllPrimaryAndAdditionalUserIdentitiesBasedOnUserId()` | library `com.hp.cloud.eprint.papi.user.helper` |
| 19 | [OwnershipUserService](/components/services/OwnershipUserService.md).`addOwnership()` | this service |
| 20 | ↳ `IPrinterManager`.`addOwnerForPrinter()` | library `com.hp.cloudprint.devices.printer` |
| 21 | ↳ [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md).`getEprintUserDirectory()` | this service |
| 22 | ↳ ↳ `EprintUserDirectoryContextFactory`.`getEprintUserDirectory()` | library `com.hp.cloudprint.eprintuserdirectory.util` |
| 23 | ↳ `EprintUserDirectory`.`addPrinterOwnerShardMapEntry()` | library `com.hp.cloudprint.eprintuserdirectory.service` |
| 24 | ↳ `EprintShardHolder`.`getShard()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 25 | [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).`getRequest()` | this service |
| 26 | [URIHelper](/components/misc/URIHelper.md).`getOwnerShipURI()` | this service |
| 27 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 28 | [StratusClient](/components/services/StratusClient.md).`publishAddOwnershipToStratus()` | this service |
| 29 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStratusPublishUrl()` | this service |
| 30 | ↳ ↳ `WpConfigurationService`.`getString()` | library `com.hp.ipg.iws.wp.common.config` |
| 31 | ↳ [StratusClientImpl](/components/misc/StratusClientImpl.md).`getAuthAccessToken()` | this service |
| 32 | ↳ ↳ `PUMAClientWrapper`.`getAccessToken()` | library `com.hp.cloud.eprint.papi.services.common` |
| 33 | ↳ [StratusClientImpl](/components/misc/StratusClientImpl.md).`getPayloadForClaim()` | this service |
| 34 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStringValue()` | this service |
| 35 | ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`doPost()` | this service |
| 36 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`createPostRequest()` | this service |
| 37 | ↳ ↳ `HttpClientConfig`.`getRetryThreshold()` | library `com.hp.cloudprint.httpclient.config` |
| 38 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` | this service |
| 39 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` _(error path)_ | this service |
| 40 | ↳ ↳ [StratusHttpClient](/components/misc/StratusHttpClient.md).`addLoggerForHttpCalls()` _(error path)_ | this service |


Guards:

* Guard: when [userIdentities == null] → throw UserIdRetrievalException
* Guard: when [allEmailIdsForUser == null \|\| allEmailIdsForUser.size(] → throw UserIdRetrievalException
Implemented by [OwnerShipsResource](/components/controllers/OwnerShipsResource.md).
