---
type: Use Case
title: UC-018 — Get Printer
description: Carries out Get Printer triggered by GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ entering at WhiteListEntryResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-018
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-018 |
| Trigger | GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ |
| Actor | API Client |
| Entry point | WhiteListEntryResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 2 | `IPrinterManager`.`getWhiteListEntryByWhiteListIDAndInternalPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 3 | `FeatureType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 4 | `PrivilegeType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 5 | `ObjectFactory`.`createWhiteListEntry()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 6 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [WhiteListEntryResource](/components/controllers/WhiteListEntryResource.md).
