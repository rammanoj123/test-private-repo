---
type: Use Case
title: UC-002 — Update Job Printjobs
description: Carries out Update Job Printjobs triggered by PUT /jobs/printjobs/{JobID}/cancel/ entering at CancelPrintResource.handlePut.
tags: [usecase]
status: draft
usecase_id: UC-002
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-002 |
| Trigger | PUT /jobs/printjobs/{JobID}/cancel/ |
| Actor | API Client |
| Entry point | CancelPrintResource.handlePut |
| Entry resolved by | Restlet dispatch convention (`handlePut`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `EprintShardHolder`.`setShard()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 2 | `ShardUtil`.`getShardCodeFromIdString()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 3 | [CancelPrintResource](/components/controllers/CancelPrintResource.md).`doWork()` | this service |
| 4 | ↳ `PrintService`.`cancelJob()` | library `com.hp.cloudprint.pjp` |
| 5 | [URIHelper](/components/misc/URIHelper.md).`getPrintJobStatusURI()` | this service |

Implemented by [CancelPrintResource](/components/controllers/CancelPrintResource.md).
