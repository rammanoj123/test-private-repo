---
type: Use Case
title: UC-007 — Create Ownership Status
description: Carries out Create Ownership Status triggered by POST /ownerships/status entering at OwnershipStatusResource.acceptRepresentation.
tags: [usecase]
status: draft
usecase_id: UC-007
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-007 |
| Trigger | POST /ownerships/status |
| Actor | API Client |
| Entry point | OwnershipStatusResource.acceptRepresentation |
| Entry resolved by | Restlet dispatch convention (`acceptRepresentation`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`getRequest()` | this service |
| 2 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` | this service |
| 3 | ↳ [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`getErrorResponse()` | this service |
| 4 | ↳ ↳ `Errors`.`toJsonAsString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |
| 5 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` | this service |
| 6 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`getRequest()` | this service |
| 7 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`unMarshalAndValidateInputForOwnershipStatus()` | this service |
| 8 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 9 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 10 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 11 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 12 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 13 | ↳ `OwnershipStatusRequest`.`toString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |
| 14 | [OwnershipStatusService](/components/services/OwnershipStatusService.md).`getOwnershipsForPrinter()` | this service |
| 15 | ↳ `IPrinterManager`.`getPrinterBySerialAndModelNumber()` | library `com.hp.cloudprint.devices.printer` |
| 16 | ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 17 | ↳ `IPrinterManager`.`getOwnershipEntryForPrinterUserCombination()` | library `com.hp.cloudprint.devices.printer` |
| 18 | ↳ [OwnershipStatusServiceImpl](/components/services/OwnershipStatusServiceImpl.md).`getOwnershipStatusResponse()` | this service |
| 19 | ↳ ↳ [ClaimStatus](/components/misc/ClaimStatus.md).`toString()` | this service |
| 20 | ↳ ↳ [URIHelper](/components/misc/URIHelper.md).`getOwnerShipURI()` | this service |
| 21 | ↳ `IPrinterManager`.`getPrinterOwner()` _(error path)_ | library `com.hp.cloudprint.devices.printer` |
| 22 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnResponse()` | this service |
| 23 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 24 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 25 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 26 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 27 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 28 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 29 | [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).`returnErrorResponse()` _(error path)_ | this service |

Implemented by [OwnershipStatusResource](/components/controllers/OwnershipStatusResource.md).
