---
type: Use Case
title: UC-022 — Get Printers
description: Carries out Get Printers triggered by GET /devices/printers/{PrinterID}/owner/ entering at PrinterOwnerResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-022
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-022 |
| Trigger | GET /devices/printers/{PrinterID}/owner/ |
| Actor | API Client |
| Entry point | PrinterOwnerResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getPrinterOwner()` | library `com.hp.cloudprint.devices.printer` |
| 2 | [EntityConverter](/domain/EntityConverter.md).`createOwnerFromOwnershipEntity()` | this service |
| 3 | ↳ `ObjectFactory`.`createOwner()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 4 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [PrinterOwnerResource](/components/controllers/PrinterOwnerResource.md).
