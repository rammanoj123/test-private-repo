---
type: Use Case
title: UC-013 — Get Device
description: Carries out Get Device triggered by GET /devices/printersDel/{PrinterID}/ entering at PrinterResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-013
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-013 |
| Trigger | GET /devices/printersDel/{PrinterID}/ |
| Actor | API Client |
| Entry point | PrinterResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `storeRepresentation`, POST → `acceptRepresentation`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC`, `Logger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [PrinterResource](/components/controllers/PrinterResource.md).`getRequest()` | this service |
| 2 | [PrinterResource](/components/controllers/PrinterResource.md).`verifyPrinterOwner()` | this service |
| 3 | ↳ `IPrinterManager`.`getPrinterOwner()` | library `com.hp.cloudprint.devices.printer` |
| 4 | `IPrinterManager`.`setShardByPrinterId()` | library `com.hp.cloudprint.devices.printer` |
| 5 | `IPrinterManager`.`getPrinterConnectionState()` | library `com.hp.cloudprint.devices.printer` |
| 6 | `DeviceCapabilitiesManager`.`reDiscoverDevice()` | library `com.hp.cloudprint.devices.devicecapabilities` |
| 7 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 8 | [PrinterResource](/components/controllers/PrinterResource.md).`getPrinterDescription()` | this service |
| 9 | ↳ [URIHelper](/components/misc/URIHelper.md).`getEmailAddressURIOnRamp()` | this service |
| 10 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 11 | ↳ ↳ `WpConfigurationService`.`getBoolean()` | library `com.hp.ipg.iws.wp.common.config` |
| 12 | ↳ ↳ `ApplicationConfig`.`getBooleanValue()` | library `com.hp.cloudprint.util.config` |
| 13 | ↳ `DeviceCapabilitiesManager`.`getPrinterAppPlayerElements()` | library `com.hp.cloudprint.devices.devicecapabilities` |
| 14 | [PrinterResource](/components/controllers/PrinterResource.md).`addPrinterDetailsFromPLS()` | this service |
| 15 | ↳ [Utility](/components/misc/Utility.md).`extractUIDFromPUC()` | this service |
| 16 | ↳ [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md).`getCompletePrinterInfoFromPLS()` | this service |
| 17 | ↳ ↳ `PLSClient`.`getCompletePrinterInfo()` | library `com.hp.cloud.eprint.papi.services.pls.client` |
| 18 | ↳ ↳ [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md).`filterPrinterInfoBasedOnFirmwareVersion()` | this service |
| 19 | ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`mapPLSCompletePrinterInfoToPrinterDescriptionForResponse()` | this service |
| 20 | ↳ ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`mapPLSCompletePrinterInfoToPrinterDescriptionForResponse()` | this service |
| 21 | [PrinterResource](/components/controllers/PrinterResource.md).`addPrinterCloudConfiguration()` | this service |
| 22 | ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 23 | ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`generatePrinterCloudConfigurationJAXBObject()` | this service |
| 24 | ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`configureInkSubscription()` | this service |
| 25 | ↳ [PrinterResource](/components/controllers/PrinterResource.md).`addOptinConfigDetails()` | this service |
| 26 | ↳ ↳ `PrinterCloudConfigurationManager`.`getOptInDataCollectionGroupType()` | library `com.hp.cloudprint.devices.management` |
| 27 | ↳ ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`populateOptinSubscriptionDetails()` | this service |
| 28 | [URIHelper](/components/misc/URIHelper.md).`getPrinterSupportedProcesssingElementsURI()` | this service |
| 29 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [PrinterResource](/components/controllers/PrinterResource.md).
