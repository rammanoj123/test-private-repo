---
type: Use Case
title: UC-005 — Create Emailaddress Suggestions
description: Carries out Create Emailaddress Suggestions triggered by POST /devices/printers/{PrinterID}/emailaddress/suggestions/ entering at SuggestionsResource.handlePost.
tags: [usecase]
status: draft
usecase_id: UC-005
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-005 |
| Trigger | POST /devices/printers/{PrinterID}/emailaddress/suggestions/ |
| Actor | API Client |
| Entry point | SuggestionsResource.handlePost |
| Entry resolved by | Restlet dispatch convention (`handlePost`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`unmarshal()` | this service |
| 2 | `EmailAddressManager`.`getSuggestions()` | library `com.hp.cloudprint.devices.management` |
| 3 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [SuggestionsResource](/components/controllers/SuggestionsResource.md).
