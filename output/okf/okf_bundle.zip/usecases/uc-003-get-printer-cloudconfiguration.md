---
type: Use Case
title: UC-003 — Get Printer Cloudconfiguration
description: Carries out Get Printer Cloudconfiguration triggered by GET /devices/printers/{PrinterID}/cloudconfiguration/ entering at CloudConfigurationResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-003
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-003 |
| Trigger | GET /devices/printers/{PrinterID}/cloudconfiguration/ |
| Actor | API Client |
| Entry point | CloudConfigurationResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 2 | `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 3 | [URIHelper](/components/misc/URIHelper.md).`getCloudConfigURI()` | this service |
| 4 | [Utility](/components/misc/Utility.md).`marshal()` | this service |
| 5 | `ObjectFactory`.`createPrinterCloudConfig()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |

Implemented by [CloudConfigurationResource](/components/controllers/CloudConfigurationResource.md).
