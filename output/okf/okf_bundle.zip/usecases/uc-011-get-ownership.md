---
type: Use Case
title: UC-011 — Get Ownership
description: Carries out Get Ownership triggered by GET /ownerships/{OwnershipID}/ entering at OwnerShipResource.represent.
tags: [usecase]
status: draft
usecase_id: UC-011
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-011 |
| Trigger | GET /ownerships/{OwnershipID}/ |
| Actor | API Client |
| Entry point | OwnerShipResource.represent |
| Entry resolved by | Restlet dispatch convention (`represent`) |
| Handlers | GET → `represent`, DELETE → `removeRepresentations` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getOwnershipForId()` | library `com.hp.cloudprint.devices.printer` |
| 2 | [OwnerShipResource](/components/controllers/OwnerShipResource.md).`getOwnerShipClaimDate()` | this service |
| 3 | ↳ [Utility](/components/misc/Utility.md).`createXMLGregorianCalendar()` | this service |
| 4 | [OwnerShipResource](/components/controllers/OwnerShipResource.md).`getPrinterDescription()` | this service |
| 5 | ↳ `CountryCode`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 6 | ↳ `CountryCode`.`value()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 7 | ↳ `RegionName`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 8 | ↳ `RegionName`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 9 | ↳ `RegionName`.`value()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 10 | ↳ `CountryCode`.`value()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 11 | ↳ [OwnerShipResource](/components/controllers/OwnerShipResource.md).`setShardCode()` | this service |
| 12 | ↳ ↳ `IPrinterManager`.`setShardByPrinterId()` | library `com.hp.cloudprint.devices.printer` |
| 13 | ↳ `IPrinterManager`.`getPrinterConnectionState()` | library `com.hp.cloudprint.devices.printer` |
| 14 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getBooleanValue()` | this service |
| 15 | ↳ ↳ `WpConfigurationService`.`getBoolean()` | library `com.hp.ipg.iws.wp.common.config` |
| 16 | ↳ ↳ `ApplicationConfig`.`getBooleanValue()` | library `com.hp.cloudprint.util.config` |
| 17 | ↳ `DeviceCapabilitiesManager`.`getPrinterAppPlayerElements()` | library `com.hp.cloudprint.devices.devicecapabilities` |
| 18 | ↳ [OwnerShipResource](/components/controllers/OwnerShipResource.md).`getAppPlayerCapabilities()` | this service |
| 19 | ↳ ↳ `InputType`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 20 | ↳ [OwnerShipResource](/components/controllers/OwnerShipResource.md).`addPrinterDetailsFromPLS()` | this service |
| 21 | ↳ ↳ [Utility](/components/misc/Utility.md).`extractUIDFromPUC()` | this service |
| 22 | ↳ ↳ [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md).`getCompletePrinterInfoFromPLS()` | this service |
| 23 | ↳ ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`mapPLSCompletePrinterInfoToPrinterDescriptionForResponse()` | this service |
| 24 | ↳ [OwnerShipResource](/components/controllers/OwnerShipResource.md).`addPrinterCloudConfiguration()` | this service |
| 25 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 26 | ↳ ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`generatePrinterCloudConfigurationJAXBObject()` | this service |
| 27 | ↳ ↳ [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md).`configureInkSubscription()` | this service |
| 28 | ↳ ↳ [OwnerShipResource](/components/controllers/OwnerShipResource.md).`addOptinConfigDetails()` | this service |
| 29 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [OwnerShipResource](/components/controllers/OwnerShipResource.md).
