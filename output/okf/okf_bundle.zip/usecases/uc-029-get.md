---
type: Use Case
title: UC-029 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/printerwhitelist/ entering at WhitelistHandler.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-029
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-029 |
| Trigger | GET /devices/printers/{PrinterID}/printerwhitelist/ |
| Actor | API Client |
| Entry point | WhitelistHandler.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, POST → `handlePost` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`extractUIDFromPUC()` | this service |
| 2 | [EntityConverter](/domain/EntityConverter.md).`createWhiteList()` | this service |
| 3 | ↳ [EntityConverter](/domain/EntityConverter.md).`createWhiteListEntry()` | this service |
| 4 | ↳ ↳ `FeatureType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 5 | ↳ ↳ `PrivilegeType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 6 | ↳ ↳ [URIHelper](/components/misc/URIHelper.md).`getWhiteListEntryURI()` | this service |
| 7 | `IPrinterManager`.`getWhiteListByInternalPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 8 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |

Implemented by [WhitelistHandler](/components/controllers/WhitelistHandler.md).
