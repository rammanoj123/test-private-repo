---
type: Use Case
title: UC-026 — Get Optin
description: Carries out Get Optin triggered by GET /devices/printers/{PrinterID}/optin/cDCA entering at CDCASubscriptionResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-026
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-026 |
| Trigger | GET /devices/printers/{PrinterID}/optin/cDCA |
| Actor | API Client |
| Entry point | CDCASubscriptionResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`handleMethod()` | this service |
| 2 | ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`getPrinter()` | this service |
| 3 | ↳ ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 4 | ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`putPrinterCloudConfiguration()` | this service |
| 5 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 6 | ↳ ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`putPrinterCloudConfigurationCDCAOptin()` | this service |
| 7 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 8 | ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`deletePrinterCloudConfiguration()` | this service |
| 9 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 10 | ↳ ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`deletePrinterCloudConfigurationCDCAOptin()` | this service |
| 11 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 12 | ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`getPrinterCloudConfiguration()` | this service |
| 13 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 14 | ↳ [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).`getErrorXML()` _(error path)_ | this service |
| 15 | ↳ ↳ [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [CDCASubscriptionResource](/components/controllers/CDCASubscriptionResource.md).
