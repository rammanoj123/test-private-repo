---
type: Use Case
title: UC-015 — Get Printer Status
description: Carries out Get Printer Status triggered by GET /devices/printers/{PrinterID}/status/ entering at PrinterStatusResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-015
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-015 |
| Trigger | GET /devices/printers/{PrinterID}/status/ |
| Actor | API Client |
| Entry point | PrinterStatusResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 2 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`getRequest()` | this service |
| 3 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`verifyPrinterOwner()` | this service |
| 4 | ↳ `IPrinterManager`.`getPrinterOwner()` | library `com.hp.cloudprint.devices.printer` |
| 5 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 6 | `IPrinterManager`.`getPrinterConnectionState()` | library `com.hp.cloudprint.devices.printer` |
| 7 | `IPrinterManager`.`getPrinterStatusAsynchWithoutWait()` | library `com.hp.cloudprint.devices.printer` |
| 8 | `IPrinterManager`.`getPrinterStatusAsynch()` | library `com.hp.cloudprint.devices.printer` |
| 9 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getRetryAfterInSecs()` _(error path)_ | this service |
| 10 | ↳ `WpConfigurationService`.`getString()` | library `com.hp.ipg.iws.wp.common.config` |
| 11 | ↳ `ApplicationConfig`.`getStringValue()` | library `com.hp.cloudprint.util.config` |
| 12 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` _(error path)_ | this service |
| 13 | ↳ [Utility](/components/misc/Utility.md).`marshal()` | this service |
| 14 | ↳ `ObjectFactory`.`createPrinterStatus()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 15 | ↳ [Utility](/components/misc/Utility.md).`addCacheHeaderToResponse()` | this service |
| 16 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` _(error path)_ | this service |
| 17 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` _(error path)_ | this service |
| 18 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` _(error path)_ | this service |
| 19 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` _(error path)_ | this service |
| 20 | `PrintService`.`getQueuedJobsCount()` | library `com.hp.cloudprint.pjp` |
| 21 | `PrinterStateEnum`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 22 | `PrinterStateReasons`.`PrinterStateReason()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 23 | `PrinterStateReasonsEnum`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 24 | [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).`sendData()` | this service |


Guards:

* Guard: when [error condition] → throw RuntimeException
Implemented by [PrinterStatusResource](/components/controllers/PrinterStatusResource.md).
