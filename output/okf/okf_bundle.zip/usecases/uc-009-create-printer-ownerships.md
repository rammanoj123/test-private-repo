---
type: Use Case
title: UC-009 — Create Printer Ownerships
description: Carries out Create Printer Ownerships triggered by POST /devices/printers/ownerships entering at DeviceOwnershipResource.acceptRepresentation.
tags: [usecase]
status: draft
usecase_id: UC-009
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-009 |
| Trigger | POST /devices/printers/ownerships |
| Actor | API Client |
| Entry point | DeviceOwnershipResource.acceptRepresentation |
| Entry resolved by | Restlet dispatch convention (`acceptRepresentation`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` | this service |
| 2 | ↳ [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`getErrorResponse()` | this service |
| 3 | ↳ ↳ `Errors`.`toJsonAsString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |
| 4 | ↳ [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`getResponse()` | this service |
| 5 | ↳ ↳ [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`getRequest()` | this service |
| 6 | ↳ ↳ [URIHelper](/components/misc/URIHelper.md).`getOwnerShipURI()` | this service |
| 7 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`getRequest()` | this service |
| 8 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` | this service |
| 9 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`unMarshalAndValidateOwnershipsInput()` | this service |
| 10 | ↳ [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 11 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`fetchPrinterDetails()` | this service |
| 12 | ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 13 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`getOwnership()` | this service |
| 14 | ↳ `ShardUtil`.`getIdStringFromIdAsString()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 15 | [OwnershipUserService](/components/services/OwnershipUserService.md).`addOwnershipByPrinterId()` | this service |
| 16 | ↳ `IPrinterManager`.`addOwnerForPrinterByPrinterId()` | library `com.hp.cloudprint.devices.printer` |
| 17 | ↳ [OwnershipUserServiceImpl](/components/services/OwnershipUserServiceImpl.md).`getEprintUserDirectory()` | this service |
| 18 | ↳ ↳ `EprintUserDirectoryContextFactory`.`getEprintUserDirectory()` | library `com.hp.cloudprint.eprintuserdirectory.util` |
| 19 | ↳ `EprintUserDirectory`.`addPrinterOwnerShardMapEntry()` | library `com.hp.cloudprint.eprintuserdirectory.service` |
| 20 | ↳ `EprintShardHolder`.`getShard()` | library `com.hp.cloudprint.eprintdirectory.util` |
| 21 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 22 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 23 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 24 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 25 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |
| 26 | [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).`returnErrorResponse()` _(error path)_ | this service |

Implemented by [DeviceOwnershipResource](/components/controllers/DeviceOwnershipResource.md).
