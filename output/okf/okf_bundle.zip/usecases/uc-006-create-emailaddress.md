---
type: Use Case
title: UC-006 — Create Emailaddress
description: Carries out Create Emailaddress triggered by POST /devices/printers/{PrinterID}/emailaddress/availability/ entering at AvailabilityResource.handlePost.
tags: [usecase]
status: draft
usecase_id: UC-006
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-006 |
| Trigger | POST /devices/printers/{PrinterID}/emailaddress/availability/ |
| Actor | API Client |
| Entry point | AvailabilityResource.handlePost |
| Entry resolved by | Restlet dispatch convention (`handlePost`) |
| Cross-cutting | `EPrintLogger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`unMarshalAndValidate()` | this service |
| 2 | [Utility](/components/misc/Utility.md).`getSchema()` | this service |
| 3 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getInstance()` | this service |
| 4 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`init()` | this service |
| 5 | `EmailAddressManager`.`isAliasAvailable()` | library `com.hp.cloudprint.devices.management` |

Implemented by [AvailabilityResource](/components/controllers/AvailabilityResource.md).
