---
type: Use Case
title: UC-020 — Get Printer Supportedprocessingelements
description: Carries out Get Printer Supportedprocessingelements triggered by GET /devices/printers/{PrinterID}/supportedprocessingelements/ entering at PrinterSupportedProcessingElementsResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-020
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-020 |
| Trigger | GET /devices/printers/{PrinterID}/supportedprocessingelements/ |
| Actor | API Client |
| Entry point | PrinterSupportedProcessingElementsResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 2 | `DeviceCapabilitiesManager`.`getPrinterSupportedProcessingElements()` | library `com.hp.cloudprint.devices.devicecapabilities` |
| 3 | `InputBinType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 4 | `InputBinSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 5 | `InputBinSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 6 | `PlexSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 7 | `MediaSizeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 8 | `MediaSizeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 9 | `MediaTypeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 10 | `MediaTypeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 11 | `PrintQualitySupported`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 12 | `PrintQuality`.`name()` | library `com.hp.cloudprint.entities.common.Enums` |
| 13 | [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getStringValue()` | this service |
| 14 | ↳ `WpConfigurationService`.`getString()` | library `com.hp.ipg.iws.wp.common.config` |
| 15 | ↳ `ApplicationConfig`.`getStringValue()` | library `com.hp.cloudprint.util.config` |
| 16 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [PrinterSupportedProcessingElementsResource](/components/controllers/PrinterSupportedProcessingElementsResource.md).
