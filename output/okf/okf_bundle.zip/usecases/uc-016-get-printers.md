---
type: Use Case
title: UC-016 — Get Printers
description: Carries out Get Printers triggered by GET /devices/printers/{PrinterID}/whitelist/ entering at WhiteListResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-016
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-016 |
| Trigger | GET /devices/printers/{PrinterID}/whitelist/ |
| Actor | API Client |
| Entry point | WhiteListResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, POST → `handlePost` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 2 | `IPrinterManager`.`getWhiteListByInternalPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 3 | [URIHelper](/components/misc/URIHelper.md).`getWhiteListEntryURI()` | this service |
| 4 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [WhiteListResource](/components/controllers/WhiteListResource.md).
