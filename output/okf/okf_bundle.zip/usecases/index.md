# Use cases

# Concepts

* [UC-001 — Get Version](uc-001-get-version.md) - GET /version/ (pending enrichment).
* [UC-002 — Update Job Printjobs](uc-002-update-job-printjobs.md) - PUT /jobs/printjobs/{JobID}/cancel/ (pending enrichment).
* [UC-003 — Get Printer Cloudconfiguration](uc-003-get-printer-cloudconfiguration.md) - GET /devices/printers/{PrinterID}/cloudconfiguration/ (pending enrichment).
* [UC-004 — Get Printer Emailaddress](uc-004-get-printer-emailaddress.md) - GET /devices/printers/{PrinterID}/emailaddress/ (pending enrichment).
* [UC-005 — Create Emailaddress Suggestions](uc-005-create-emailaddress-suggestions.md) - POST /devices/printers/{PrinterID}/emailaddress/suggestions/ (pending enrichment).
* [UC-006 — Create Emailaddress](uc-006-create-emailaddress.md) - POST /devices/printers/{PrinterID}/emailaddress/availability/ (pending enrichment).
* [UC-007 — Create Ownership Status](uc-007-create-ownership-status.md) - POST /ownerships/status (pending enrichment).
* [UC-008 — Create Ownerships](uc-008-create-ownerships.md) - POST /ownerships (pending enrichment).
* [UC-009 — Create Printer Ownerships](uc-009-create-printer-ownerships.md) - POST /devices/printers/ownerships (pending enrichment).
* [UC-010 — Create Printer Ownerships](uc-010-create-printer-ownerships.md) - POST /v1/devices/printers/ownerships (pending enrichment).
* [UC-011 — Get Ownership](uc-011-get-ownership.md) - GET /ownerships/{OwnershipID}/ (pending enrichment).
* [UC-012 — Get Device Printer](uc-012-get-device-printer.md) - GET /devices/printers/{PrinterID}/ (pending enrichment).
* [UC-013 — Get Device](uc-013-get-device.md) - GET /devices/printersDel/{PrinterID}/ (pending enrichment).
* [UC-014 — Get Device Printers](uc-014-get-device-printers.md) - GET /devices/printers (pending enrichment).
* [UC-015 — Get Printer Status](uc-015-get-printer-status.md) - GET /devices/printers/{PrinterID}/status/ (pending enrichment).
* [UC-016 — Get Printers](uc-016-get-printers.md) - GET /devices/printers/{PrinterID}/whitelist/ (pending enrichment).
* [UC-017 — Get Printer Defaultprocessingelements](uc-017-get-printer-defaultprocessingelements.md) - GET /devices/printers/{PrinterID}/defaultprocessingelements/ (pending enrichment).
* [UC-018 — Get Printer](uc-018-get-printer.md) - GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ (pending enrichment).
* [UC-019 — Get Printer Printjobs](uc-019-get-printer-printjobs.md) - GET /devices/printers/{PrinterID}/printjobs/ (pending enrichment).
* [UC-020 — Get Printer Supportedprocessingelements](uc-020-get-printer-supportedprocessingelements.md) - GET /devices/printers/{PrinterID}/supportedprocessingelements/ (pending enrichment).
* [UC-021 — Create Appplayer](uc-021-create-appplayer.md) - POST /devices/printers/{PrinterID}/appplayer/event/ (pending enrichment).
* [UC-022 — Get Printers](uc-022-get-printers.md) - GET /devices/printers/{PrinterID}/owner/ (pending enrichment).
* [UC-023 — Get Printers](uc-023-get-printers.md) - GET /devices/printers/{PrinterID}/optin/ (pending enrichment).
* [UC-024 — Get Printer Consumablesubscription](uc-024-get-printer-consumablesubscription.md) - GET /devices/printers/{PrinterID}/consumablesubscription/ (pending enrichment).
* [UC-025 — Get Optin](uc-025-get-optin.md) - GET /devices/printers/{PrinterID}/optin/inklevel/ (pending enrichment).
* [UC-026 — Get Optin](uc-026-get-optin.md) - GET /devices/printers/{PrinterID}/optin/cDCA (pending enrichment).
* [UC-027 — Get Optin](uc-027-get-optin.md) - GET /devices/printers/{optinParameter}/optin/suppliesinfo/ (pending enrichment).
* [UC-028 — Get](uc-028-get.md) - GET /devices/printers/{PrinterID}/blacklist/ (pending enrichment).
* [UC-029 — Get](uc-029-get.md) - GET /devices/printers/{PrinterID}/printerwhitelist/ (pending enrichment).
* [UC-030 — Get](uc-030-get.md) - GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} (pending enrichment).
* [UC-031 — Get Printer](uc-031-get-printer.md) - GET /v2/devices/printers/{PrinterID}/optin/{optinType} (pending enrichment).
* [UC-032 — Get Printer Schedules](uc-032-get-printer-schedules.md) - GET /v2/devices/printers/{optinType}/schedules (pending enrichment).
* [UC-033 — Start Https Test](uc-033-start-https-test.md) - main(String[] args) in HttpsTest (pending enrichment).
