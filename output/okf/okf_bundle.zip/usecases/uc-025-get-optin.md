---
type: Use Case
title: UC-025 — Get Optin
description: Carries out Get Optin triggered by GET /devices/printers/{PrinterID}/optin/inklevel/ entering at OptinInkLevelResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-025
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-025 |
| Trigger | GET /devices/printers/{PrinterID}/optin/inklevel/ |
| Actor | API Client |
| Entry point | OptinInkLevelResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`handleMethod()` | this service |
| 2 | ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`getPrinter()` | this service |
| 3 | ↳ ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 4 | ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`putPrinterCloudConfiguration()` | this service |
| 5 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 6 | ↳ ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`putPrinterCloudConfigurationInkLevelOptin()` | this service |
| 7 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 8 | ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`deletePrinterCloudConfiguration()` | this service |
| 9 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 10 | ↳ ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`deletePrinterCloudConfigurationInkLevelOptin()` | this service |
| 11 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 12 | ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`getPrinterCloudConfiguration()` | this service |
| 13 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 14 | ↳ [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).`getErrorXML()` _(error path)_ | this service |
| 15 | ↳ ↳ [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [OptinInkLevelResource](/components/controllers/OptinInkLevelResource.md).
