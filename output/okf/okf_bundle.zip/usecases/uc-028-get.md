---
type: Use Case
title: UC-028 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/blacklist/ entering at BlackListsHandler.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-028
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-028 |
| Trigger | GET /devices/printers/{PrinterID}/blacklist/ |
| Actor | API Client |
| Entry point | BlackListsHandler.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, POST → `handlePost` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [EntityConverter](/domain/EntityConverter.md).`createBlacklist()` | this service |
| 2 | ↳ [EntityConverter](/domain/EntityConverter.md).`createBlackListEntryType()` | this service |
| 3 | ↳ ↳ `ObjectFactory`.`createBlackListEntryType()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 4 | ↳ ↳ `FeatureType`.`fromValue()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 5 | ↳ ↳ [URIHelper](/components/misc/URIHelper.md).`getBlackListURI()` | this service |
| 6 | `IPrinterManager`.`getBlackListEntries()` | library `com.hp.cloudprint.devices.printer` |

Implemented by [BlackListsHandler](/components/controllers/BlackListsHandler.md).
