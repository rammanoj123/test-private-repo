---
type: Use Case
title: UC-004 — Get Printer Emailaddress
description: Carries out Get Printer Emailaddress triggered by GET /devices/printers/{PrinterID}/emailaddress/ entering at EmailAddressResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-004
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-004 |
| Trigger | GET /devices/printers/{PrinterID}/emailaddress/ |
| Actor | API Client |
| Entry point | EmailAddressResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, POST → `handlePost` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 2 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [EmailAddressResource](/components/controllers/EmailAddressResource.md).
