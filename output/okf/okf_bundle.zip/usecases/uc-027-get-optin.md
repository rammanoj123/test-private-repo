---
type: Use Case
title: UC-027 — Get Optin
description: Carries out Get Optin triggered by GET /devices/printers/{optinParameter}/optin/suppliesinfo/ entering at OptinSuppliesInfoResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-027
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-027 |
| Trigger | GET /devices/printers/{optinParameter}/optin/suppliesinfo/ |
| Actor | API Client |
| Entry point | OptinSuppliesInfoResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut`, DELETE → `handleDelete` |
| Cross-cutting | `EPrintLogger` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getPrinter()` | this service |
| 2 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getPrinterFromEmail()` | this service |
| 3 | ↳ ↳ `IPrinterManager`.`getActivePrinterByEmailAddress()` | library `com.hp.cloudprint.devices.printer` |
| 4 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getPrinterFromClaimCode()` | this service |
| 5 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getDomain()` | this service |
| 6 | ↳ ↳ `IPrinterManager`.`getActivePrinterByClaimCode()` | library `com.hp.cloudprint.devices.printer` |
| 7 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getPrinterFromPrinterId()` | this service |
| 8 | ↳ ↳ `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 9 | [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`handleRequestMethod()` | this service |
| 10 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`putPrinterCloudConfiguration()` | this service |
| 11 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 12 | ↳ ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`putPrinterCloudConfigurationSuppliesInfoOptin()` | this service |
| 13 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 14 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`deletePrinterCloudConfiguration()` | this service |
| 15 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 16 | ↳ ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`deletePrinterCloudConfigurationSuppliesInfoOptin()` | this service |
| 17 | ↳ ↳ `PrinterCloudConfigurationManager`.`updatePrinterCloudConfiguration()` | library `com.hp.cloudprint.devices.management` |
| 18 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getPrinterCloudConfiguration()` | this service |
| 19 | ↳ ↳ `PrinterCloudConfigurationManager`.`getPrinterCloudConfig()` | library `com.hp.cloudprint.devices.management` |
| 20 | ↳ [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).`getErrorXML()` _(error path)_ | this service |
| 21 | ↳ ↳ [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [OptinSuppliesInfoResource](/components/controllers/OptinSuppliesInfoResource.md).
