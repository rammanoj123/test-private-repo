---
type: Use Case
title: UC-001 — Get Version
description: Carries out Get Version triggered by GET /version/ entering at VersionResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-001
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-001 |
| Trigger | GET /version/ |
| Actor | API Client |
| Entry point | VersionResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`getApiVersion()` | this service |
| 2 | ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`getInstance()` | this service |
| 3 | ↳ ↳ [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md).`init()` | this service |
| 4 | [Utility](/components/misc/Utility.md).`marshal()` | this service |

Implemented by [VersionResource](/components/controllers/VersionResource.md).
