---
type: Use Case
title: UC-032 — Get Printer Schedules
description: Carries out Get Printer Schedules triggered by GET /v2/devices/printers/{optinType}/schedules entering at OptInScheduleResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-032
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-032 |
| Trigger | GET /v2/devices/printers/{optinType}/schedules |
| Actor | API Client |
| Entry point | OptInScheduleResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [OptInScheduleResource](/components/controllers/OptInScheduleResource.md).`handleMethod()` | this service |
| 2 | ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 3 | ↳ [OptInScheduleResource](/components/controllers/OptInScheduleResource.md).`getErrorResponse()` | this service |
| 4 | ↳ ↳ `Errors`.`toJsonAsString()` | library `com.hp.cloudprint.api.eprintcenter.schemas.json` |
| 5 | ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |
| 6 | ↳ [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md).`getClientSchedules()` | this service |

Implemented by [OptInScheduleResource](/components/controllers/OptInScheduleResource.md).
