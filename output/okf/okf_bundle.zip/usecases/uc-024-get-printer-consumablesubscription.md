---
type: Use Case
title: UC-024 — Get Printer Consumablesubscription
description: Carries out Get Printer Consumablesubscription triggered by GET /devices/printers/{PrinterID}/consumablesubscription/ entering at ConsumableSubscriptionConfigResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-024
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-024 |
| Trigger | GET /devices/printers/{PrinterID}/consumablesubscription/ |
| Actor | API Client |
| Entry point | ConsumableSubscriptionConfigResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call |
| --- | --- |
| 1 | ConsumableSubscriptionConfigResource |

Implemented by [ConsumableSubscriptionConfigResource](/components/controllers/ConsumableSubscriptionConfigResource.md).
