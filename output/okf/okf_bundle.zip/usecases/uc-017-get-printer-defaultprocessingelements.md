---
type: Use Case
title: UC-017 — Get Printer Defaultprocessingelements
description: Carries out Get Printer Defaultprocessingelements triggered by GET /devices/printers/{PrinterID}/defaultprocessingelements/ entering at PrinterDefaultsProcessingElementsResource.handleGet.
tags: [usecase]
status: draft
usecase_id: UC-017
generated: { by: okf_generator/1.0, at: 2026-09-30T10:08:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-017 |
| Trigger | GET /devices/printers/{PrinterID}/defaultprocessingelements/ |
| Actor | API Client |
| Entry point | PrinterDefaultsProcessingElementsResource.handleGet |
| Entry resolved by | Restlet dispatch convention (`handleGet`) |
| Handlers | GET → `handleGet`, PUT → `handlePut` |
| Cross-cutting | `EPrintLogger`, `EPrintMDC` |

# Steps

| # | Call | Where |
| --- | --- | --- |
| 1 | [Utility](/components/misc/Utility.md).`IsStringNullOrEmpty()` | this service |
| 2 | `IPrinterManager`.`getActivePrinterByPrinterID()` | library `com.hp.cloudprint.devices.printer` |
| 3 | [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md).`getPrinterDefaultsProcessingElements()` | this service |
| 4 | ↳ `PrintingType`.`values()` | library `com.hp.cloudprint.entities.common.Enums` |
| 5 | ↳ `PrintingType`.`name()` | library `com.hp.cloudprint.entities.common.Enums` |
| 6 | ↳ `DeviceCapabilitiesManager`.`getPrinterDefaultProcessingElements()` | library `com.hp.cloudprint.devices.devicecapabilities` |
| 7 | ↳ `ColorSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 8 | ↳ `MarginTypeSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 9 | ↳ `MediaSizeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 10 | ↳ `MediaTypeSupported`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 11 | ↳ `PlexMode`.`fromName()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 12 | ↳ `PrintQualitySupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 13 | ↳ `PrintingTypeSupported`.`valueOf()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |
| 14 | [Utility](/components/misc/Utility.md).`marshal()` | this service |
| 15 | `ObjectFactory`.`createPrinterDefaultsProcessingElements()` | library `com.hp.cloudprint.api.eprintcenter.schemas` |

Implemented by [PrinterDefaultsProcessingElementsResource](/components/controllers/PrinterDefaultsProcessingElementsResource.md).
