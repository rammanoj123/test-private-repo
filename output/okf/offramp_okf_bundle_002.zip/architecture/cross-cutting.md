---
type: Reference
title: Cross-cutting behaviour
description: Declared transactions, caches, scheduling, listeners and AOP.
tags: [architecture, cross-cutting]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T12:00:00Z }
sources:
  - { id: cross-cutting-md, resource: /architecture/cross-cutting.md, title: Cross-cutting behaviour concept }
---

Declared cross-cutting behaviour extracted from the codebase and Spring XML. The code generator must preserve these when modifying the affected methods.



# Transactions

The following methods are wrapped in Spring declarative transactions. The generator MUST preserve these transaction boundaries when modifying or refactoring the affected methods.

| Class | Method | Propagation | Read Only | Business Purpose | Use Case | Rule |
| --- | --- | --- | --- | --- | --- | --- |
| [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md) | authorizeRequestToken | REQUIRED | False | Authorizes an OAuth request token for a user, creating or updating the authorization record. | [OAuth token authorization flow](/usecases/uc-014-get.md) | MUST run in a transaction to ensure atomicity of token state changes. If authorization fails mid-process, the transaction rolls back to prevent orphaned or inconsistent token records. |
| [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md) | getToken | REQUIRED | False | Retrieves an OAuth token by key, potentially updating access timestamps or usage counts. | [OAuth token retrieval](/usecases/uc-014-get.md) | MUST run in a transaction because token retrieval may trigger side effects (e.g., updating last-accessed time). Write operations require transactional consistency. |
| [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md) | setAuthoritiesToVerify | REQUIRED | False | Persists the set of authorities (roles/permissions) that must be verified for a token. | [OAuth token authority management](/usecases/uc-014-get.md) | MUST run in a transaction to ensure the authority list is atomically updated. Partial writes could leave tokens in an inconsistent security state. |
| [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md) | getAuthoritiesToVerify | REQUIRED | False | Retrieves the authorities to verify for a token, potentially logging or auditing the access. | [OAuth token authority retrieval](/usecases/uc-014-get.md) | MUST run in a transaction because the method may perform write operations (e.g., audit logging) alongside the read. Transactional context ensures audit consistency. |

**Generator rules**:
1. **Preserve transaction annotations**: Do not remove `@Transactional` or equivalent XML `<tx:method>` declarations from these methods.
2. **Respect propagation**: `REQUIRED` means the method must run within a transaction. If called from a transactional context, it joins that transaction; otherwise, it starts a new one.
3. **Read-only flag**: All listed methods have `readOnly=false`, indicating they may perform writes. Do not change this to `true`.
4. **Refactoring**: If splitting or renaming these methods, ensure the new methods inherit the same transactional semantics. If extracting logic into a helper, decide whether the helper should be transactional or rely on the caller's transaction.
5. **Testing**: When generating tests for these methods, mock the transaction manager or use `@Transactional` in the test to simulate the production transaction context.
