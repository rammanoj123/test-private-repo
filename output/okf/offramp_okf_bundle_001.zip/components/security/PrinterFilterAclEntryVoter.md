---
type: Component
title: Printer Filter ACL Entry Voter
description: Votes on printer resource access by extracting printer ID from request and checking ACL permissions.
tags: [component, security, acl, voter, authorization]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\PrinterFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.PrinterFilterAclEntryVoter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| aclService | AclService |  |
| processConfigAttribute | String |  |
| requirePermission | List |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| urlMatcher | AntPathRequestMatcher |  |
| sidExtractionFilter | String |  |
| printerManager | PrinterManager |  |
| objectIdentity | ObjectIdentity |  |
| printerId | String |  |
| requestUrl | String |  |
| pattern | Pattern |  |
| matcher | Matcher |  |
| parts | String[] |  |
| domainObject | Object | @Override |
| objectIdentity | ObjectIdentity | @Override |
| sids | List | @Override |
| acl | Acl |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| PrinterFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
| getDomainObjectURIFilter | String |  |  |
| setSidExtractionFilter | void | String sidExtractionFilter |  |
| getSidExtractionFilter | String |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getPrinterManager | PrinterManager |  |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| extractPrinterIdFromRequest | String | FilterInvocation filterInvocation |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> attributes |  |
| supports | boolean | ConfigAttribute attribute |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setProcessDomainObjectClass | void | Class<?> processDomainObjectClass |  |
| getProcessDomainObjectClass | Class |  |  |
