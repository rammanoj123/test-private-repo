---
type: Component
title: Temp Token Authorization Filter ACL Entry Voter
description: Votes on temporary token access by validating request token and checking ACL permissions.
tags: [component, security, acl, voter, token]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\TempTokenAuthorizationFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.TempTokenAuthorizationFilterAclEntryVoter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Log |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| sidParameterName | String |  |
| securityManager | SecurityManager |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| requestTokenStr | String |  |
| reqToken | RequestTokenEntity |  |
| tempToken | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| TempTokenAuthorizationFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getProcessDomainObjectClass2 | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getProcessDomainObjectClass | Class |  |  |
