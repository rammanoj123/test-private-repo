---
type: Component
title: TempTokenAuthorizationFilterAclEntryVoter
description: Security `TempTokenAuthorizationFilterAclEntryVoter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\TempTokenAuthorizationFilterAclEntryVoter.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.TempTokenAuthorizationFilterAclEntryVoter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Log |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| sidParameterName | String |  |
| securityManager | SecurityManager |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| requestTokenStr | String |  |
| reqToken | RequestTokenEntity |  |
| tempToken | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| TempTokenAuthorizationFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getProcessDomainObjectClass2 | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getProcessDomainObjectClass | Class |  |  |
