---
type: Component
title: RegistrationAuthenticationProvider
description: Security `RegistrationAuthenticationProvider`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationAuthenticationProvider.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.RegistrationAuthenticationProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| KEY_SEPERATOR_REGEX | String |  |
| LOG | EPrintLogger |  |
| presentedPassword | String | @Override |
| userPasswords | String[] | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| additionalAuthenticationChecks | void | UserDetails userDetails, UsernamePasswordAuthenticationToken authentication |  |
