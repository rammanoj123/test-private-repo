---
type: Component
title: Registration Authentication Provider
description: Authenticates printer registration requests by validating credentials against stored domain keys.
tags: [component, security, authentication, registration, provider]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationAuthenticationProvider.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.RegistrationAuthenticationProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| KEY_SEPERATOR_REGEX | String |  |
| LOG | EPrintLogger |  |
| presentedPassword | String | @Override |
| userPasswords | String[] | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| additionalAuthenticationChecks | void | UserDetails userDetails, UsernamePasswordAuthenticationToken authentication |  |
