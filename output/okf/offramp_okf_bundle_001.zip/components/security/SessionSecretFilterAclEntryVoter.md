---
type: Component
title: SessionSecretFilterAclEntryVoter
description: Security `SessionSecretFilterAclEntryVoter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\SessionSecretFilterAclEntryVoter.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.SessionSecretFilterAclEntryVoter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| securityManager | SecurityManager |  |
| sidParameterName | String |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| sessionTokenStr | String |  |
| shardCode | String |  |
| sessionToken | SessionToken |  |
| printerIdentity | ObjectIdentity |  |
| userSid | List |  |
| printerAcl | Acl |  |
| sessionToken | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SessionSecretFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getSecurityManager | SecurityManager |  |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| getProcessDomainObjectClass | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
