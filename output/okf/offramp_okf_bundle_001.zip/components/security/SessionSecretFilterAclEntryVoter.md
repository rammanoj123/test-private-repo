---
type: Component
title: Session Secret Filter ACL Entry Voter
description: Votes on session secret access by validating session token and checking printer ACL permissions.
tags: [component, security, acl, voter, session]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\SessionSecretFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.SessionSecretFilterAclEntryVoter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| securityManager | SecurityManager |  |
| sidParameterName | String |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| sessionTokenStr | String |  |
| shardCode | String |  |
| sessionToken | SessionToken |  |
| printerIdentity | ObjectIdentity |  |
| userSid | List |  |
| printerAcl | Acl |  |
| sessionToken | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SessionSecretFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getSecurityManager | SecurityManager |  |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| getProcessDomainObjectClass | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
