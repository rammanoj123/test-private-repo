---
type: Component
title: Custom User Authorization Processing Filter
description: Initializes custom user authorization processing filter with success handler for OAuth flows.
tags: [component, security, oauth, filter, authorization]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\CustomUserAuthorizationProcessingFilter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.CustomUserAuthorizationProcessingFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| userAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |  |
| setUserAuthorizationSuccessfulAuthenticationHandler | void | UserAuthorizationSuccessfulAuthenticationHandler userAuthorizationSuccessfulAuthenticationHandler |  |
| init | void |  |  |
