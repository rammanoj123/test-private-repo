---
type: Component
title: CustomUserAuthorizationProcessingFilter
description: Security `CustomUserAuthorizationProcessingFilter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\CustomUserAuthorizationProcessingFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.CustomUserAuthorizationProcessingFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| userAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |  |
| setUserAuthorizationSuccessfulAuthenticationHandler | void | UserAuthorizationSuccessfulAuthenticationHandler userAuthorizationSuccessfulAuthenticationHandler |  |
| init | void |  |  |
