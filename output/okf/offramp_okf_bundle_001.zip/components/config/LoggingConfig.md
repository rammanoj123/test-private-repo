---
type: Component
title: Logging Config
description: Initializes logging configuration for the offramp application.
tags: [component, config, logging, initialization]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\config\LoggingConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.config.LoggingConfig`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
