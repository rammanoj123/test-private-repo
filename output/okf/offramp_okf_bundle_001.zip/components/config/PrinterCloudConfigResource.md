---
type: Component
title: Printer Cloud Config Resource
description: Handles GET and PUT requests for printer cloud configuration including usage data collection and feature flags.
tags: [component, config, resource, printer, restlet]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterCloudConfigResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#GET") |
| version | String |  |
| cloudConfig | com.hp.cloudprint.entities.PrinterCloudConfiguration |  |
| cloudConfiguration | CloudConfiguration |  |
| requiredAccountsClaimStatuFeatureEnabled | boolean |  |
| ownership | Ownership |  |
| rep | Representation |  |
| headerValues | Form |  |
| customHeaderValues | Map |  |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#PUT") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#PUT") |
| cloudConfig | CloudConfiguration |  |
| inputStream | InputStream |  |
| data | String |  |
| cloudConfig1 | PrinterCloudConfiguration |  |
| udcFlag | Integer |  |
| writer | Writer |  |
| buffer | char[] |  |
| reader | Reader |  |
| n | int |  |
| isLFPPrinter | boolean |  |
| printerModelListForLFP | String |  |
| modelList | String[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| isPrinterFromDesignJetFamily | boolean | String modelNumber |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getAPIVersionFromRequestHeader | String |  |  |
| itSupportsClaimStatus | boolean | String version |  |
| itSupportsConsumableSubscription | boolean | String version |  |
| handlePut | void |  |  |
| getSchema | Schema |  |  |
| convertStreamToString | String | InputStream is |  |
| getUDCvalue | int | boolean isAllowsUsageDataCollection, String printerModel |  |
| isUDCFlagEnabled | boolean |  |  |
| isPrinterModelsInLFP | boolean | String printerModel |  |

# Depends on

* `PrinterManager`
* `PrinterCloudConfigurationManager`
