---
type: Component
title: XMPP Configuration Resource
description: Handles GET requests to retrieve XMPP configuration for a printer from the directory.
tags: [component, config, resource, xmpp, restlet]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\XMPPConfigurationResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.XMPPConfigurationResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ORG_RESTLET_HTTP_HEADERS | String |  |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| eprintDirectory | EprintDirectory | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| headerValues | Form | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| htHeaderValues | HashMap | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| deviceData | DeviceData |  |
| xmppConfig | XmppConfig |  |
| rep | Representation |  |
| xmppConfig | XmppConfig |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setEprintDirectory | void | EprintDirectory eprintDirectory |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getXMPPConfiguration | XmppConfig | String printerID, HashMap<String, String> htHeaderValues, DeviceData deviceData |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |

# Depends on

* `EprintDirectory`
