---
type: Component
title: XMPPConfigurationResource
description: Config `XMPPConfigurationResource`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\XMPPConfigurationResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.XMPPConfigurationResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ORG_RESTLET_HTTP_HEADERS | String |  |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| eprintDirectory | EprintDirectory | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| headerValues | Form | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| htHeaderValues | HashMap | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| deviceData | DeviceData |  |
| xmppConfig | XmppConfig |  |
| rep | Representation |  |
| xmppConfig | XmppConfig |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setEprintDirectory | void | EprintDirectory eprintDirectory |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getXMPPConfiguration | XmppConfig | String printerID, HashMap<String, String> htHeaderValues, DeviceData deviceData |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |

# Depends on

* `EprintDirectory`
