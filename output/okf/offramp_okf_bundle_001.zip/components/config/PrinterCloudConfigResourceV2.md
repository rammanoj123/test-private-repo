---
type: Component
title: Printer Cloud Config Resource V2
description: Handles GET requests for v2 printer cloud configuration with version-specific response formatting.
tags: [component, config, resource, printer, v2]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterCloudConfigResourceV2.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResourceV2`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| cloudConfig | PrinterCloudConfiguration |  |
| cloudConfiguration | CloudConfiguration |  |
| rep | Representation |  |
| headerValues | Form |  |
| customHeaderValues | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getAPIVersionFromRequestHeader | String |  |  |

# Depends on

* `PrinterManager`
* `PrinterCloudConfigurationManager`
