---
type: Component
title: PrinterCloudConfigResourceV2
description: Config `PrinterCloudConfigResourceV2`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterCloudConfigResourceV2.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResourceV2`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| cloudConfig | PrinterCloudConfiguration |  |
| cloudConfiguration | CloudConfiguration |  |
| rep | Representation |  |
| headerValues | Form |  |
| customHeaderValues | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getAPIVersionFromRequestHeader | String |  |  |

# Depends on

* `PrinterManager`
* `PrinterCloudConfigurationManager`
