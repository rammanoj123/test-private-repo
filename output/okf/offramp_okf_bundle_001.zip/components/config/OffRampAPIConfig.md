---
type: Component
title: OffRamp API Config
description: Provides centralized access to offramp API configuration properties including XMPP, security, and feature flags.
tags: [component, config, api, singleton, properties]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\OffRampAPIConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.OffRampAPIConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| instance | OffRampAPIConfig |  |
| ORG_RESTLET_HTTP_HEADERS | String |  |
| OFF_RAMP_VERSION | String |  |
| CLOUD_PRINT_JABBER_ID | String |  |
| XMPP_VERSION | String |  |
| LEDM_RESOURCE_NAME | String |  |
| JABBER_ID_APPEND | String |  |
| MAX_XMPP_BACK_OFF_LIMIT_IN_SECONDS | String |  |
| WHITESPACE_INTERVAL_IN_SECONDS | String |  |
| BKOFF_WSPACEINTRVL_NA_FOR_VERSIONS | String |  |
| CLAIM_STATUS_NA_FOR_VERSIONS | String |  |
| REQUIRED_ACCOUNTS_CLAIM_STATUS_FEATURE_ENABLED | String |  |
| SECURITY_CHECK_REQUIRED | String |  |
| DESIGNJET_PRINTER_MODEL_LIST | String |  |
| RESTRICTED_SERIAL_NUMBERS_LIST | String |  |
| CONSUMABLE_SUBSCRIPTION_NA_FOR_VERSIONS | String |  |
| XSD_VALIDATION | String |  |
| XSD_OFFRAMP_API_SPEC | String |  |
| XSD_OFFRAMP_API_V2_SPEC | String |  |
| SUPPORTS_SERIAL_NUMBER_ENCRYPTION | String |  |
| REGISTRATION_TESTDOMAIN_KEY_REFRESH_CONFIG | String |  |
| REGISTRATION_SHUTDOWNHOOK_DELAY_IN_SECS | String |  |
| IS_DOMAIN_KEY_HASH_CHECK_ENABLED | String |  |
| LFP_PRINTER_MODEL_LIST | String |  |
| IS_UDC_FOR_LFP_ENABLED | String |  |
| BLOCK_PRINTER_THESHOLD | String |  |
| SIMPLECACHE_SERVER_INSTANCES | String |  |
| PBUT_DISABLE_COUNTRY | String |  |
| STRATUS_EVENTING_ENABLED | String |  |
| wpConfigurationService | WpConfigurationService |  |
| serviceName | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OffRampAPIConfig |  |  |  |
| getInstance | OffRampAPIConfig |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setServiceName | void | String serviceName |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getLongValue | long | String key |  |
| getStringValue | String | String key |  |
| getBooleanValue | boolean | String key |  |
| getIntValue | int | String key |  |
| getListValue | List | String key |  |
| getDoubleValue | double | String key |  |
| getFloatValue | float | String key |  |
| isPullNode | boolean |  |  |
| getShutDownHookDelay | int |  |  |
| isDomainKeyHashCheckEnabled | boolean |  |  |
| getBlockPrinterThreshold | int |  |  |
