---
type: Component
title: PrinterConfiguration
description: Config `PrinterConfiguration`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterConfiguration.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterConfiguration`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerID | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| printerKey | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| xmppConfig | XmppConfig | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerKey;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerKey;     @XmlElement(namespace = "http:     protected XmppConfig xmppConfig;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterID | String |  |  |
| setPrinterID | void | String value |  |
| getPrinterKey | String |  |  |
| setPrinterKey | void | String value |  |
| getXmppConfig | XmppConfig |  |  |
| setXmppConfig | void | XmppConfig value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
