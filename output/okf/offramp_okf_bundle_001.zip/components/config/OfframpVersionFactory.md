---
type: Component
title: OfframpVersionFactory
description: Config `OfframpVersionFactory`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersionFactory.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.OfframpVersionFactory`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INSTANCE | OfframpVersionFactory |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OfframpVersionFactory |  |  |  |
| getInstance | OfframpVersionFactory |  |  |
| getOfframpVersionImpl | OfframpVersion | boolean v2Compatible |  |
