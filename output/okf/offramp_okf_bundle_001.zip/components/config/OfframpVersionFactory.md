---
type: Component
title: Offramp Version Factory
description: Returns version-specific offramp implementation based on v2 compatibility flag.
tags: [component, config, factory, versioning, singleton]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersionFactory.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.OfframpVersionFactory`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INSTANCE | OfframpVersionFactory |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OfframpVersionFactory |  |  |  |
| getInstance | OfframpVersionFactory |  |  |
| getOfframpVersionImpl | OfframpVersion | boolean v2Compatible |  |
