---
type: Component
title: XMPP Config
description: Holds XMPP server connection details including hostname, ports, Jabber IDs, backoff limits, and whitespace intervals.
tags: [component, config, xmpp, messaging, xml-schema]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\XmppConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.XmppConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| xmppVersion | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| serverHostname | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| jabberIDs | XmppConfig.JabberIDs | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http: |
| tcpPorts | XmppConfig.TcpPorts | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http:     protected XmppConfig.TcpPorts tcpPorts;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| maxXMPPBackoffLimit | BigInteger | @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http:     protected XmppConfig.TcpPorts tcpPorts;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String version;     @XmlElement(name = "maxXMPPBackoffLimit", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger") |
| whitespaceInterval | BigInteger | @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String version;     @XmlElement(name = "maxXMPPBackoffLimit", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger")     protected BigInteger maxXMPPBackoffLimit;     @XmlElement(name = "whitespaceInterval", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger") |
| serverDomainName | String | @XmlElement(namespace = "http: |
| serverNodeName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| printerNodeName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String serverNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| ledmResourceName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String serverNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String printerNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| tcpPort | List | @XmlElement(namespace = "http: |
| priority | BigInteger | @XmlElement(namespace = "http:             @XmlSchemaType(name = "positiveInteger") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getXmppVersion | String |  |  |
| setXmppVersion | void | String value |  |
| getServerHostname | String |  |  |
| setServerHostname | void | String value |  |
| getJabberIDs | XmppConfig.JabberIDs |  |  |
| setJabberIDs | void | XmppConfig.JabberIDs value |  |
| getTcpPorts | XmppConfig.TcpPorts |  |  |
| setTcpPorts | void | XmppConfig.TcpPorts value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getMaxXMPPBackoffLimit | BigInteger |  |  |
| setMaxXMPPBackoffLimit | void | BigInteger value |  |
| getWhitespaceInterval | BigInteger |  |  |
| setWhitespaceInterval | void | BigInteger value |  |
| getServerDomainName | String |  |  |
| setServerDomainName | void | String value |  |
| getServerNodeName | String |  |  |
| setServerNodeName | void | String value |  |
| getPrinterNodeName | String |  |  |
| setPrinterNodeName | void | String value |  |
| getLedmResourceName | String |  |  |
| setLedmResourceName | void | String value |  |
| getTcpPort | List |  |  |

# Depends on

* `String`
