---
type: Component
title: Collection Config Resource
description: Handles POST requests to configure cloud signaling session for collection service integration.
tags: [component, config, resource, collection, restlet]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\CollectionConfigResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.CollectionConfigResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| collectionServiceClient | ICollectionServiceClient |  |
| LOG | EPrintLogger |  |
| printerId | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudSignaling/SignalSession#POST") |
| collectionConfig | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudSignaling/SignalSession#POST") |
| rep | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| handlePost | void |  |  |
| serviceUnavailable | void |  |  |
| handleNoContentResource | void |  |  |
