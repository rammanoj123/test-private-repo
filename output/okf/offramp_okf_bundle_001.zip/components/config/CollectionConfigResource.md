---
type: Component
title: CollectionConfigResource
description: Config `CollectionConfigResource`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\CollectionConfigResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.CollectionConfigResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| collectionServiceClient | ICollectionServiceClient |  |
| LOG | EPrintLogger |  |
| printerId | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudSignaling/SignalSession#POST") |
| collectionConfig | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudSignaling/SignalSession#POST") |
| rep | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| handlePost | void |  |  |
| serviceUnavailable | void |  |  |
| handleNoContentResource | void |  |  |
