---
type: Component
title: Object Factory
description: Creates JAXB schema objects for printer configuration, XMPP, state reports, and cloud settings.
tags: [component, config, jaxb, factory, xml]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\ObjectFactory.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.ObjectFactory`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| _InstructionType_QNAME | QName |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ObjectFactory |  |  |  |
| createPrinterConfiguration | PrinterConfiguration |  |  |
| createStateReportState | StateReport.State |  |  |
| createXmppConfigTcpPorts | XmppConfig.TcpPorts |  |  |
| createXmppConfigTcpPortsTcpPort | XmppConfig.TcpPorts.TcpPort |  |  |
| createXmppConfigJabberIDs | XmppConfig.JabberIDs |  |  |
| createStateReportStateError | StateReport.State.Error |  |  |
| createSessionSecret | SessionSecret |  |  |
| createXmppConfig | XmppConfig |  |  |
| createPrinterEmailAddress | PrinterEmailAddress |  |  |
| createStateReport | StateReport |  |  |
| createPrinterIdentification | PrinterIdentification |  |  |
| createCloudConfiguration | CloudConfiguration |  |  |
| createPrinterClaimInfo | PrinterClaimInfo |  |  |
| createInstructionType | JAXBElement | String value |  |
