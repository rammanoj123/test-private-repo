---
type: Component
title: ObjectFactory
description: Config `ObjectFactory`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\ObjectFactory.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.ObjectFactory`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| _InstructionType_QNAME | QName |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ObjectFactory |  |  |  |
| createPrinterConfiguration | PrinterConfiguration |  |  |
| createStateReportState | StateReport.State |  |  |
| createXmppConfigTcpPorts | XmppConfig.TcpPorts |  |  |
| createXmppConfigTcpPortsTcpPort | XmppConfig.TcpPorts.TcpPort |  |  |
| createXmppConfigJabberIDs | XmppConfig.JabberIDs |  |  |
| createStateReportStateError | StateReport.State.Error |  |  |
| createSessionSecret | SessionSecret |  |  |
| createXmppConfig | XmppConfig |  |  |
| createPrinterEmailAddress | PrinterEmailAddress |  |  |
| createStateReport | StateReport |  |  |
| createPrinterIdentification | PrinterIdentification |  |  |
| createCloudConfiguration | CloudConfiguration |  |  |
| createPrinterClaimInfo | PrinterClaimInfo |  |  |
| createInstructionType | JAXBElement | String value |  |
