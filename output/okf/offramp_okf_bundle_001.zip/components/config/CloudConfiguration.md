---
type: Component
title: Cloud Configuration
description: Holds cloud printing configuration settings including SIPs, mobile apps, email, protection mode, and subscription flags.
tags: [component, config, cloud, printer-settings, xml-schema]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\CloudConfiguration.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.CloudConfiguration`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| allowsSips | Boolean | @XmlElement(namespace = "http: |
| allowsMobileApps | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http: |
| allowsEmail | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http: |
| protectionMode | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http: |
| claimStatus | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http: |
| allowsUsageDataCollection | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http: |
| consumableSubscription | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http:     protected Boolean allowsUsageDataCollection; 	@XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http:     protected Boolean allowsUsageDataCollection; 	@XmlElement(namespace = "http:     protected Boolean consumableSubscription;     @XmlAttribute(required = true)     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| isAllowsSips | Boolean |  |  |
| setAllowsSips | void | Boolean value |  |
| isAllowsMobileApps | Boolean |  |  |
| setAllowsMobileApps | void | Boolean value |  |
| isAllowsEmail | Boolean |  |  |
| setAllowsEmail | void | Boolean value |  |
| isProtectionMode | Boolean |  |  |
| setProtectionMode | void | Boolean value |  |
| isClaimStatus | Boolean |  |  |
| setClaimStatus | void | Boolean value |  |
| isAllowsUsageDataCollection | Boolean |  |  |
| setAllowsUsageDataCollection | void | Boolean value |  |
| getConsumableSubscription | Boolean |  |  |
| setConsumableSubscription | void | Boolean value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
