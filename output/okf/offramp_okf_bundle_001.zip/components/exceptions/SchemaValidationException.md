---
type: Component
title: Schema Validation Exception
description: Signals that XML schema validation failed for a request payload.
tags: [component, exception, xml, validation]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\SchemaValidationException.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: SchemaValidationException.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/exceptions/SchemaValidationException.java, title: SchemaValidationException.java }
---

`com.hp.cloudprint.api.offramp.exceptions.SchemaValidationException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SchemaValidationException |  | String message |  |

# Business context

Signals that XML schema validation failed for a request payload. Extends CpInternalContingencyException to indicate a client error that should be handled as a contingency rather than a fatal error.

# Algorithm

**Constructor (String message)**
1. Accept message string parameter
2. Call super(message) to initialize CpInternalContingencyException with message

**Constructor (Exception e)**
1. Accept exception parameter
2. Call super(e) to initialize CpInternalContingencyException with exception

# Business rules

• Thrown when XML payload does not conform to expected schema.
• Results in 400 BAD_REQUEST response with "Invalid Request Data. Please check X-HP-Custom-Header's value too."
• Can be constructed with a message string or a causing exception (IOException, JAXBException, SAXException).
