---
type: Component
title: SchemaValidationException
description: Exception `SchemaValidationException`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\SchemaValidationException.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.exceptions.SchemaValidationException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SchemaValidationException |  | String message |  |
