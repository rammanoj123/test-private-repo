---
type: Component
title: Stratus Client Exception
description: Signals that an error occurred while communicating with the Stratus eventing service.
tags: [component, exception, stratus, integration]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\StratusClientException.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: StratusClientException.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/exceptions/StratusClientException.java, title: StratusClientException.java }
---

`com.hp.cloudprint.api.offramp.exceptions.StratusClientException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| StratusClientException |  | String message |  |

# Business context

Signals that an error occurred while communicating with the Stratus eventing service. Extends CpInternalContingencyException to indicate an integration error that should be handled as a contingency rather than a fatal error.

# Algorithm

**Constructor**
1. Accept message string parameter
2. Call super(message) to initialize CpInternalContingencyException with message

# Business rules

• Thrown when Stratus client operations fail (e.g., publishing delete ownership events).
• Does not fail the primary operation; logged and handled gracefully.
