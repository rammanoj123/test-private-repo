---
type: Component
title: StratusClientException
description: Exception `StratusClientException`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\StratusClientException.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.exceptions.StratusClientException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| StratusClientException |  | String message |  |
