---
type: Component
title: Registration Data Invalid Exception
description: Signals that printer registration data is invalid or incomplete.
tags: [component, exception, registration, validation]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\RegistrationDataInvalidException.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: RegistrationDataInvalidException.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/exceptions/RegistrationDataInvalidException.java, title: RegistrationDataInvalidException.java }
---

`com.hp.cloudprint.api.offramp.exceptions.RegistrationDataInvalidException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| RegistrationDataInvalidException |  | String message |  |

# Business context

Signals that printer registration data is invalid or incomplete. Extends CpInternalContingencyException to indicate a client error that should be handled as a contingency rather than a fatal error.

# Algorithm

**Constructor**
1. Accept message string parameter
2. Call super(message) to initialize CpInternalContingencyException with message

# Business rules

• Thrown when required registration attributes are missing (registrationID, printerUUID, serialNumber).
• Thrown when serial number is in the restricted serial numbers list.
• Results in 400 BAD_REQUEST response with "Invalid Request Data. Required Attributes are missing in request payload."
