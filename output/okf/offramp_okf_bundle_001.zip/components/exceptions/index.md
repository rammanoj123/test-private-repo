# Exceptions

# Concepts

* [BadHeaderPassedException](BadHeaderPassedException.md) - Exception `BadHeaderPassedException`. (Description pending enrichment.)
* [BlockedPrinterException](BlockedPrinterException.md) - Exception `BlockedPrinterException`. (Description pending enrichment.)
* [RegistrationDataInvalidException](RegistrationDataInvalidException.md) - Exception `RegistrationDataInvalidException`. (Description pending enrichment.)
* [SchemaValidationException](SchemaValidationException.md) - Exception `SchemaValidationException`. (Description pending enrichment.)
* [StratusClientException](StratusClientException.md) - Exception `StratusClientException`. (Description pending enrichment.)
