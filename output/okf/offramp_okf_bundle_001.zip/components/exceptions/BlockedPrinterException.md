---
type: Component
title: Blocked Printer Exception
description: Signals that a printer is blocked and cannot perform the requested operation.
tags: [component, exception, printer, security]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\BlockedPrinterException.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: BlockedPrinterException.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/exceptions/BlockedPrinterException.java, title: BlockedPrinterException.java }
---

`com.hp.cloudprint.api.offramp.exceptions.BlockedPrinterException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| BlockedPrinterException |  | String msg, Throwable t |  |

# Business context

Signals that a printer is blocked and cannot perform the requested operation. Extends Spring Security's AuthenticationException to integrate with the security framework and trigger authentication failure handling.

# Algorithm

**Constructor (String msg, Throwable t)**
1. Accept message string and throwable parameters
2. Call super(msg, t) to initialize AuthenticationException with message and cause

**Constructor (String msg)**
1. Accept message string parameter
2. Call super(msg) to initialize AuthenticationException with message

# Business rules

• Thrown when a printer is blocked from accessing the system.
• Results in authentication failure response.
• Can be constructed with or without a causing exception.
