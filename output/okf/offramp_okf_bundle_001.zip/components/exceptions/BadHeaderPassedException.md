---
type: Component
title: Bad Header Passed Exception
description: Signals that an invalid or malformed HTTP header was received.
tags: [component, exception, http, validation]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\offramp\exceptions\BadHeaderPassedException.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: BadHeaderPassedException.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/exceptions/BadHeaderPassedException.java, title: BadHeaderPassedException.java }
---

`com.hp.cloudprint.api.offramp.exceptions.BadHeaderPassedException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| BadHeaderPassedException |  | String message |  |

# Algorithm

**Constructor**
1. Accept message string parameter
2. Call super(message) to initialize CpInternalContingencyException with message

# Business context

Signals that an invalid or malformed HTTP header was received in a request. Extends CpInternalContingencyException to indicate a client error that should be handled as a contingency rather than a fatal error.

# Business rules

• Thrown when custom HP header is invalid or incomplete.
• Results in 400 BAD_REQUEST response with "Invalid Request Data. Please check X-HP-Custom-Header's value too."
