---
type: Component
title: Version
description: Unknown `Version`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\Version.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.Version`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| revision | String | @XmlElement(name = "Revision",  namespace = "http: |
| date | XMLGregorianCalendar | @XmlElement(name = "Revision",  namespace = "http:     protected String revision;     @XmlElement(name = "Date" , namespace = "http: |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRevision | String |  |  |
| setRevision | void | String value |  |
| getDate | XMLGregorianCalendar |  |  |
| setDate | void | XMLGregorianCalendar value |  |
