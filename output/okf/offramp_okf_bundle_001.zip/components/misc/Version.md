---
type: Component
title: Version
description: Holds firmware version information including revision string and date.
tags: [component, unknown, data, version, firmware, xml-schema]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\Version.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.Version`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| revision | String | @XmlElement(name = "Revision",  namespace = "http: |
| date | XMLGregorianCalendar | @XmlElement(name = "Revision",  namespace = "http:     protected String revision;     @XmlElement(name = "Date" , namespace = "http: |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRevision | String |  |  |
| setRevision | void | String value |  |
| getDate | XMLGregorianCalendar |  |  |
| setDate | void | XMLGregorianCalendar value |  |
