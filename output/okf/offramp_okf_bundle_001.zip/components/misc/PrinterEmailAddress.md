---
type: Component
title: PrinterEmailAddress
description: Unknown `PrinterEmailAddress`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterEmailAddress.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterEmailAddress`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| version | String | @XmlAttribute(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
