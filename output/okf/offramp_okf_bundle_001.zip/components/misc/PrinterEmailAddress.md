---
type: Component
title: Printer Email Address
description: Holds printer email address with version attribute for XML serialization.
tags: [component, unknown, data, email, printer, xml-schema]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterEmailAddress.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterEmailAddress`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| version | String | @XmlAttribute(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
