---
type: Component
title: Registration Shutdown Hook
description: Registers shutdown hook to gracefully wait for in-flight instruction jobs to complete before termination.
tags: [component, unknown, shutdown, lifecycle, graceful, registration]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\gracefullshutdown\RegistrationShutDownHook.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.gracefullshutdown.RegistrationShutDownHook`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| instructionJobThreadMetricsCollector | InstructionJobThreadMetricsCollector |  |
| shutDownInitiated | Long |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setInstructionJobThreadMetricsCollector | void | InstructionJobThreadMetricsCollector instructionJobThreadMetricsCollector |  |
| registerShoutDownHookHandler | void |  |  |
| isRegNode | boolean |  |  |
| execute | void |  |  |
| isWaitOver | boolean |  |  |
