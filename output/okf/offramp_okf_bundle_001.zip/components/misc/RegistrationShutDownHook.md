---
type: Component
title: RegistrationShutDownHook
description: Unknown `RegistrationShutDownHook`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\gracefullshutdown\RegistrationShutDownHook.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.gracefullshutdown.RegistrationShutDownHook`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| instructionJobThreadMetricsCollector | InstructionJobThreadMetricsCollector |  |
| shutDownInitiated | Long |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setInstructionJobThreadMetricsCollector | void | InstructionJobThreadMetricsCollector instructionJobThreadMetricsCollector |  |
| registerShoutDownHookHandler | void |  |  |
| isRegNode | boolean |  |  |
| execute | void |  |  |
| isWaitOver | boolean |  |  |
