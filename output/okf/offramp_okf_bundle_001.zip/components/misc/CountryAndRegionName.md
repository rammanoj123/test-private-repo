---
type: Component
title: CountryAndRegionName
description: Unknown `CountryAndRegionName`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\CountryAndRegionName.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.CountryAndRegionName`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| peid | String | @XmlAttribute(name = "PEID"), @XmlSchemaType(name = "anySimpleType") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getPEID | String |  |  |
| setPEID | void | String value |  |
