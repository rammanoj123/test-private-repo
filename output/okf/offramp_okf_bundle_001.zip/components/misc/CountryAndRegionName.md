---
type: Component
title: Country And Region Name
description: Holds country and region name with PEID attribute for localization data.
tags: [component, unknown, data, localization, xml-schema, misc]
status: stable
component_type: Schema
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\CountryAndRegionName.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: CountryAndRegionName.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/dictionaries/CountryAndRegionName.java, title: CountryAndRegionName.java }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.CountryAndRegionName`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| peid | String | @XmlAttribute(name = "PEID"), @XmlSchemaType(name = "anySimpleType") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getPEID | String |  |  |
| setPEID | void | String value |  |

# Business context

JAXB-generated schema class representing a country and region name with optional PEID (Product Element ID) attribute for localization. Used in XML serialization/deserialization of printer identification and configuration data.

# Algorithm

**getValue**
1. Return value field

**setValue**
1. Set value field to provided string

**getPEID**
1. Return peid field

**setPEID**
1. Set peid field to provided string

# Business rules

• Value holds the country and region name string.
• PEID is an optional attribute for product element identification.
• Generated from XML schema definition; modifications will be lost upon recompilation.
