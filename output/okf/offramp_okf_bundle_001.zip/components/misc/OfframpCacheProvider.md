---
type: Component
title: Offramp Cache Provider
description: Provides singleton access to the simple cache client from the Spring application context.
tags: [component, unknown, cache, provider, singleton, spring]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\OfframpCacheProvider.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpCacheProvider.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/healthcheck/OfframpCacheProvider.java, title: OfframpCacheProvider.java }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpCacheProvider`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| applicationContext | ApplicationContext |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setApplicationContext | void | ApplicationContext applicationContext |  |
| getInstance | OfframpCacheProvider |  |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |

# Algorithm

**setApplicationContext (ApplicationContext applicationContext)**
1. Set static applicationContext field to provided applicationContext

**getInstance**
1. Get bean "offrampCacheProvider" from applicationContext
2. Cast to OfframpCacheProvider and return

**getSimpleCacheClient**
1. Get bean "simpleCacheClient" from applicationContext
2. Cast to SimpleCacheClient and return

# Business context

Implements Spring's ApplicationContextAware to provide singleton access to SimpleCacheClient from the Spring application context. Used by health checks and other components to access the cache client without direct dependency injection.

# Business rules

• Stores static reference to Spring ApplicationContext.
• Provides singleton instance of OfframpCacheProvider via getInstance().
• Retrieves SimpleCacheClient bean from application context on demand.
• Must be configured as a Spring bean to receive ApplicationContext injection.
