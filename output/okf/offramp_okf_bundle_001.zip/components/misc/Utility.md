---
type: Component
title: Utility
description: Provides utility methods for XML schema loading and printer claim info generation.
tags: [component, unknown, utility, xml, schema]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\Utility.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| schemaV2 | Schema |  |
| obj | Object |  |
| schemaName | String |  |
| schemaName | String |  |
| printerClaimInfo | PrinterClaimInfo |  |
| printerCrypticEmailAddress | String |  |
| index | int |  |
| printerName | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getSchemaV2 | Schema |  |  |
| getPrinterClaimInfo | PrinterClaimInfo | Printer printer, String ePCURL, String specVersion |  |
