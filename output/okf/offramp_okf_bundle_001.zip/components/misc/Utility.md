---
type: Component
title: Utility
description: Unknown `Utility`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\Utility.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| schemaV2 | Schema |  |
| obj | Object |  |
| schemaName | String |  |
| schemaName | String |  |
| printerClaimInfo | PrinterClaimInfo |  |
| printerCrypticEmailAddress | String |  |
| index | int |  |
| printerName | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getSchemaV2 | Schema |  |  |
| getPrinterClaimInfo | PrinterClaimInfo | Printer printer, String ePCURL, String specVersion |  |
