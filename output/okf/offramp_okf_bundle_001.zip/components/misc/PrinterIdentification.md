---
type: Component
title: PrinterIdentification
description: Unknown `PrinterIdentification`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterIdentification.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterIdentification`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| modelName | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| modelNumber | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelName;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| serialNumber | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelName;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| registrationDomain | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String serialNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| ledmDiscoveryTreeUrl | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String serialNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI") |
| associatedPrinterId | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| countryAndRegionName | CountryAndRegionName | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http: |
| deviceLanguage | String | @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| hardwareAddress | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http: |
| firmwareVersion | Version | @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http: |
| printInfoPage | Boolean | @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http: |
| immutableID | String | @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http: |
| printerUUID | String | @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http: |
| registrationID | String | @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http: |
| cloudConfiguration | CloudConfiguration | @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http:     protected String registrationID;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http:     protected String registrationID;     @XmlElement(namespace = "http:     protected CloudConfiguration cloudConfiguration;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| printerFwVersion | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getModelName | String |  |  |
| setModelName | void | String value |  |
| getModelNumber | String |  |  |
| setModelNumber | void | String value |  |
| getSerialNumber | String |  |  |
| setSerialNumber | void | String value |  |
| getRegistrationDomain | String |  |  |
| setRegistrationDomain | void | String value |  |
| getLedmDiscoveryTreeUrl | String |  |  |
| setLedmDiscoveryTreeUrl | void | String value |  |
| getAssociatedPrinterId | String |  |  |
| setAssociatedPrinterId | void | String value |  |
| getCountryAndRegionName | CountryAndRegionName |  |  |
| setCountryAndRegionName | void | CountryAndRegionName value |  |
| getDeviceLanguage | String |  |  |
| setDeviceLanguage | void | String value |  |
| getHardwareAddress | String |  |  |
| setHardwareAddress | void | String value |  |
| getFirmwareVersion | Version |  |  |
| setFirmwareVersion | void | Version value |  |
| isPrintInfoPage | Boolean |  |  |
| setPrintInfoPage | void | Boolean value |  |
| getImmutableID | String |  |  |
| setImmutableID | void | String value |  |
| getPrinterUUID | String |  |  |
| setPrinterUUID | void | String value |  |
| getRegistrationID | String |  |  |
| setRegistrationID | void | String value |  |
| getCloudConfiguration | CloudConfiguration |  |  |
| setCloudConfiguration | void | CloudConfiguration value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getFirmwareRevision | String |  |  |
