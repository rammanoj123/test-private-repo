---
type: Component
title: OfframpCacheHealthCheck
description: Unknown `OfframpCacheHealthCheck`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\OfframpCacheHealthCheck.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpCacheHealthCheck`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| SERVER_LIST_SPLIT_REGEX | String |  |
| configuredServers | String | @Override |
| activeServers | List | @Override |
| inactiveServers | List | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OfframpCacheHealthCheck |  | String name, String description, Scope scope, Type type |  |
| getHealth | HealthTest |  |  |
| getConfiguredServerList | String |  |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |
