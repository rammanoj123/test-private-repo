---
type: Component
title: Offramp Cache Health Check
description: Performs health checks on cache servers by comparing configured and active server lists.
tags: [component, unknown, health-check, cache, monitoring]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\OfframpCacheHealthCheck.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpCacheHealthCheck.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/healthcheck/OfframpCacheHealthCheck.java, title: OfframpCacheHealthCheck.java }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpCacheHealthCheck`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| SERVER_LIST_SPLIT_REGEX | String |  |
| configuredServers | String | @Override |
| activeServers | List | @Override |
| inactiveServers | List | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OfframpCacheHealthCheck |  | String name, String description, Scope scope, Type type |  |
| getHealth | HealthTest |  |  |
| getConfiguredServerList | String |  |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |

# Business context

Extends BaseHealthCheck to monitor cache server availability. Compares configured cache servers against active servers reported by SimpleCacheClient, identifying any inactive servers. Used by health check framework to report cache infrastructure status.

# Algorithm

**Constructor (String name, String description, Scope scope, Type type)**
1. Set this.name to provided name
2. Set this.description to provided description
3. Set this.scope to provided scope
4. Set this.type to provided type

**getHealth**
1. Get configured server list via getConfiguredServerList()
2. Get active servers list via getSimpleCacheClient().getActiveServers()
3. Create empty inactive servers list
4. Split configured servers string by whitespace regex
5. For each configured server:
   a. If server is not in active servers list, add to inactive servers list
6. If inactive servers list is not empty, return unhealthy with "Active Servers: {active} Inactive Servers: {inactive}"
7. Else return healthy with "Active Servers: {active}"

**getConfiguredServerList**
1. Get WpConfigurationService instance via getWpConfigurationServiceinstance()
2. Return configuration string for "OFFRAMP.SIMPLECACHE_SERVER_INSTANCES"

**getSimpleCacheClient**
1. Get OfframpCacheProvider singleton instance
2. Return SimpleCacheClient from provider

**getWpConfigurationServiceinstance**
1. Get WpConfigurationServiceProvider singleton instance
2. Return WpConfigurationService from provider

# Business rules

• Health check is healthy if all configured cache servers are active.
• Health check is unhealthy if any configured cache server is inactive.
• Configured servers are read from OFFRAMP.SIMPLECACHE_SERVER_INSTANCES configuration.
• Server list is split by whitespace to identify individual servers.
• Active servers are retrieved from SimpleCacheClient.
