---
type: Component
title: Offramp Version
description: Validates printer identification XML against schema and checks registration metadata for version 1.x.
tags: [component, unknown, validation, xml, registration, version]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersion.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpVersion.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/OfframpVersion.java, title: OfframpVersion.java }
---

`com.hp.cloudprint.api.offramp.OfframpVersion`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| printerIdentification | PrinterIdentification |  |
| isValidationRequired | boolean |  |
| stream | InputStream |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateXMLSchema | PrinterIdentification | String xml |  |
| validateRegistrationMetadata | void | PrinterIdentification printerIdentification |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |

# Algorithm

**validateXMLSchema (String xml, Schema schema)**
1. Create new PrinterIdentification object
2. Get XSD_VALIDATION flag from OffRampAPIConfig
3. Create ByteArrayInputStream from xml string bytes
4. If XSD validation is required:
   a. Unmarshal and validate XML against schema via Utility.unMarshalAndValidate
5. Else:
   a. Unmarshal XML without validation via Utility.unmarshal
6. If immutableID is not null and is empty after trim, throw SchemaValidationException
7. If any exception occurs, wrap in SchemaValidationException and throw
8. Return PrinterIdentification

**getOfframpAPIConfigInstance**
1. Return OffRampAPIConfig.getInstance()

# Business context

Abstract base class for version-specific printer identification XML validation. Provides common validation logic for XML schema validation and delegates version-specific metadata validation to subclasses (OfframpVersion and OfframpVersion2).

# Business rules

• XSD validation is controlled by OffRampAPIConfig.XSD_VALIDATION flag.
• If XSD validation is enabled, XML is validated against provided schema.
• If XSD validation is disabled, XML is unmarshalled without validation.
• ImmutableID must not be empty if present; empty ImmutableID throws SchemaValidationException.
• Subclasses must implement validateXMLSchema(String xml) and validateRegistrationMetadata(PrinterIdentification).
