---
type: Component
title: OfframpVersion
description: Unknown `OfframpVersion`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersion.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.OfframpVersion`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| printerIdentification | PrinterIdentification |  |
| isValidationRequired | boolean |  |
| stream | InputStream |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateXMLSchema | PrinterIdentification | String xml |  |
| validateRegistrationMetadata | void | PrinterIdentification printerIdentification |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
