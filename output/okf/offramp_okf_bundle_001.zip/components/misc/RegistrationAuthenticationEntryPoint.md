---
type: Component
title: Registration Authentication Entry Point
description: Handles registration authentication failures by logging printer details and returning HTTP 401 responses.
tags: [component, unknown, security, authentication, registration, entry-point]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\log\RegistrationAuthenticationEntryPoint.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.log.RegistrationAuthenticationEntryPoint`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| authentication | Authentication |  |
| authHeader | String |  |
| username | String |  |
| arrParams | String[] |  |
| modelNumber | String |  |
| domain | String |  |
| id | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| commence | void | HttpServletRequest  request, HttpServletResponse  response, AuthenticationException authException |  |
