---
type: Component
title: CountryName
description: Unknown `CountryName`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\CountryName.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.CountryName`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| CountryName |  | String v |  |
| fromValue | CountryName | String v |  |
