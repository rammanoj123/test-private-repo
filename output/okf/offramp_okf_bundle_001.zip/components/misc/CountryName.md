---
type: Component
title: Country Name
description: Represents country name enumeration for localization and validation.
tags: [component, unknown, data, enum, localization, misc]
status: stable
component_type: Enum
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\CountryName.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: CountryName.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/dictionaries/CountryName.java, title: CountryName.java }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.CountryName`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| CountryName |  | String v |  |
| fromValue | CountryName | String v |  |

# Business context

JAXB-generated enumeration of all supported country names for localization and validation. Used in XML serialization/deserialization of printer identification and configuration data. Provides mapping between XML string values and Java enum constants.

# Algorithm

**Constructor (String v)**
1. Set value field to provided string

**value**
1. Return value field

**fromValue (String v)**
1. Iterate over all CountryName enum values
2. If enum value's string equals provided string v, return that enum constant
3. If no match found, throw IllegalArgumentException with provided string

# Business rules

• Contains 242 country name constants including "unknown".
• Each enum constant has a camelCase XML value (e.g., "unitedStates").
• fromValue throws IllegalArgumentException if country name is not recognized.
• Generated from XML schema definition; modifications will be lost upon recompilation.
