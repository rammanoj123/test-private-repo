---
type: Component
title: State Report
description: Holds printer state report information including state, errors, and application details.
tags: [component, unknown, data, state, printer, xml-schema]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\StateReport.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.StateReport`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| state | List | @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected List<State> state;     @XmlAttribute(required = true)     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| state | String | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| error | Error | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String state;         @XmlElement(namespace = "http: |
| application | String | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String state;         @XmlElement(namespace = "http:         protected Error error;         @XmlElement(namespace = "http:         protected String reason;         @XmlAttribute         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| any | Object | @XmlAnyElement(lax = true) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getState | List |  |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getState | String |  |  |
| setState | void | String value |  |
| getError | Error |  |  |
| setError | void | Error value |  |
| getReason | String |  |  |
| setReason | void | String value |  |
| getApplication | String |  |  |
| setApplication | void | String value |  |
