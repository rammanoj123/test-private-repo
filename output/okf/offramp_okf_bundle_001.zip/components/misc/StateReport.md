---
type: Component
title: StateReport
description: Unknown `StateReport`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\StateReport.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.StateReport`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| state | List | @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected List<State> state;     @XmlAttribute(required = true)     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| state | String | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| error | Error | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String state;         @XmlElement(namespace = "http: |
| application | String | @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String state;         @XmlElement(namespace = "http:         protected Error error;         @XmlElement(namespace = "http:         protected String reason;         @XmlAttribute         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| any | Object | @XmlAnyElement(lax = true) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getState | List |  |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getState | String |  |  |
| setState | void | String value |  |
| getError | Error |  |  |
| setError | void | Error value |  |
| getReason | String |  |  |
| setReason | void | String value |  |
| getApplication | String |  |  |
| setApplication | void | String value |  |
