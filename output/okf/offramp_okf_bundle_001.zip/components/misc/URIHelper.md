---
type: Component
title: URI Helper
description: Provides utility methods to construct URI paths for offramp API resources.
tags: [component, unknown, utility, uri, helper]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\URIHelper.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.URIHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| OFF_RAMP_LEFT_OVER_URL | String |  |
| PRINTER_ID | String |  |
| EMAIL_ADDRESS | String |  |
| OWNERSHIP_ID | String |  |
| OwernershipsUri | String |  |
| JOBID | String |  |
| DOCUMENTID | String |  |
| PAGE | String |  |
| SESSION_TOKEN | String |  |
| HOST_NAME | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintersURI | String |  |  |
| getPrinterURI | String | String printerId |  |
| getEmailAddressURI | String | String opaqueURI |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getInstructionURI | String | String parameter |  |
| getXMPPConfigURI | String | String parameter |  |
| getPrinterCloudConfigURI | String | String parameter |  |
| getPrinterStateReportURI | String | String parameter |  |
| getOutputURI | String | String jobID, String documentID |  |
