---
type: Component
title: URIHelper
description: Unknown `URIHelper`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\URIHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.URIHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| OFF_RAMP_LEFT_OVER_URL | String |  |
| PRINTER_ID | String |  |
| EMAIL_ADDRESS | String |  |
| OWNERSHIP_ID | String |  |
| OwernershipsUri | String |  |
| JOBID | String |  |
| DOCUMENTID | String |  |
| PAGE | String |  |
| SESSION_TOKEN | String |  |
| HOST_NAME | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintersURI | String |  |  |
| getPrinterURI | String | String printerId |  |
| getEmailAddressURI | String | String opaqueURI |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getInstructionURI | String | String parameter |  |
| getXMPPConfigURI | String | String parameter |  |
| getPrinterCloudConfigURI | String | String parameter |  |
| getPrinterStateReportURI | String | String parameter |  |
| getOutputURI | String | String jobID, String documentID |  |
