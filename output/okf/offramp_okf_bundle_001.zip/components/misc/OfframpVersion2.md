---
type: Component
title: OfframpVersion2
description: Unknown `OfframpVersion2`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersion2.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.OfframpVersion2`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| SCHEMA_VERSION_2_0 | String |  |
| schema | Schema |  |
| userName | String | @Override |
| arrParams | String[] |  |
| modelNumberInSecurityContext | String |  |
| registrationDomainInSecurityContext | String |  |
| registrationIDInSecurityContext | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateXMLSchema | PrinterIdentification | String xml |  |
| validateRegistrationMetadata | void | PrinterIdentification printerIdentification |  |
