---
type: Component
title: tunnelConnectionTimers
description: Unknown `tunnelConnectionTimers`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\tunnelConnectionTimers.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.tunnelConnectionTimers`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| delayBeforeFirstConnection | Integer |  |
| delayAfterConnectionFailure | Integer |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDelayBeforeFirstConnection | Integer |  |  |
| setDelayBeforeFirstConnection | void | Integer delayBeforeFirstConnection |  |
| getDelayAfterConnectionFailure | Integer |  |  |
| setDelayAfterConnectionFailure | void | Integer delayAfterConnectionFailure |  |
