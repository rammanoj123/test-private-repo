---
type: Component
title: Tunnel Connection Timers
description: Holds tunnel connection timing configuration for first connection and retry delays.
tags: [component, unknown, data, tunnel, configuration, timers]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\tunnelConnectionTimers.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.tunnelConnectionTimers`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| delayBeforeFirstConnection | Integer |  |
| delayAfterConnectionFailure | Integer |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDelayBeforeFirstConnection | Integer |  |  |
| setDelayBeforeFirstConnection | void | Integer delayBeforeFirstConnection |  |
| getDelayAfterConnectionFailure | Integer |  |  |
| setDelayAfterConnectionFailure | void | Integer delayAfterConnectionFailure |  |
