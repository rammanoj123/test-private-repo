---
type: Component
title: Cache Client Monitor
description: Monitors and reconfigures cache server connections for the simple cache client.
tags: [component, unknown, monitoring, cache, configuration, misc]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\oam\CacheClientMonitor.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: CacheClientMonitor.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/oam/CacheClientMonitor.java, title: CacheClientMonitor.java }
---

`com.hp.cloudprint.api.offramp.oam.CacheClientMonitor`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| simpleCacheClient | SimpleCacheClient |  |
| serverConfig | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| reconfigureCacheServers | int |  |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |

# Business context

Monitors and reconfigures cache server connections for the simple cache client. Provides JMX management interface (via CacheClientMonitorMBean) to dynamically reconfigure cache servers without restarting the application.

# Algorithm

**reconfigureCacheServers**
1. Get server configuration string from OffRampAPIConfig.SIMPLECACHE_SERVER_INSTANCES
2. Call simpleCacheClient.configureCacheServers(serverConfig) to reconfigure cache servers
3. If exception thrown, wrap in MBeanException and throw
4. Return count of active servers via simpleCacheClient.getActiveServers().size()

**getOfframpAPIConfigInstance**
1. Return OffRampAPIConfig.getInstance()

# Business rules

• Cache server configuration is read from OffRampAPIConfig.SIMPLECACHE_SERVER_INSTANCES.
• Reconfiguration can fail and throws MBeanException to JMX clients.
• Returns the count of active cache servers after reconfiguration.

# Depends on

• [SimpleCacheClient](/components/services/SimpleCacheClient.md) — configures cache servers and provides active server list
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) — provides cache server configuration
