---
type: Component
title: CacheClientMonitor
description: Unknown `CacheClientMonitor`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\oam\CacheClientMonitor.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.oam.CacheClientMonitor`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| simpleCacheClient | SimpleCacheClient |  |
| serverConfig | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| reconfigureCacheServers | int |  |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
