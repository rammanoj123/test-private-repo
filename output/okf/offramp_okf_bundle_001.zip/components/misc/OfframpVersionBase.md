---
type: Component
title: OfframpVersionBase
description: Unknown `OfframpVersionBase`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersionBase.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.OfframpVersionBase`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| SCHEMA_VERSION_16 | String |  |
| schema | Schema |  |
| userName | String | @Override |
| arrParams | String[] |  |
| modelNumberInSecurityContext | String |  |
| registrationDomainInSecurityContext | String |  |
| serialNumberInSecurityContext | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateXMLSchema | PrinterIdentification | String xml |  |
| validateRegistrationMetadata | void | PrinterIdentification printerIdentification |  |
