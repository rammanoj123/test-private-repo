---
type: Component
title: Offramp Version Base
description: Validates printer identification XML against schema and checks registration metadata for version 1.6.
tags: [component, unknown, validation, xml, registration, base]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersionBase.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpVersionBase.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/OfframpVersionBase.java, title: OfframpVersionBase.java }
---

`com.hp.cloudprint.api.offramp.OfframpVersionBase`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| SCHEMA_VERSION_16 | String |  |
| schema | Schema |  |
| userName | String | @Override |
| arrParams | String[] |  |
| modelNumberInSecurityContext | String |  |
| registrationDomainInSecurityContext | String |  |
| serialNumberInSecurityContext | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateXMLSchema | PrinterIdentification | String xml |  |
| validateRegistrationMetadata | void | PrinterIdentification printerIdentification |  |

# Algorithm

**Static initializer**
1. Load schema from "schemas/CloudPrinterRegistration.xsd" via Utility.getSchema
2. If SAXException thrown, log error and throw ExceptionInInitializerError

**validateXMLSchema (String xml)**
1. Call parent validateXMLSchema(xml, schema) with v1.6 schema
2. Return PrinterIdentification

**validateRegistrationMetadata (PrinterIdentification printerIdentification)**
1. If SECURITY_CHECK_REQUIRED config is false, return immediately
2. Get username from Spring SecurityContext (authenticated principal)
3. If exception getting username, throw BadHeaderPassedException
4. Split username by "+" delimiter to get array of parameters
5. If array length < 3, throw RegistrationDataMismatchException
6. Extract modelNumber, registrationDomain, and serialNumber from array (indices 0, 1, 2)
7. Compare extracted values with printerIdentification fields:
   a. If modelNumber does not match, throw RegistrationDataMismatchException
   b. If serialNumber does not match, throw RegistrationDataMismatchException
   c. If registrationDomain does not match, throw RegistrationDataMismatchException
8. If all match, return successfully

# Business context

Extends OfframpVersion to provide version 1.6-specific validation. Validates XML against CloudPrinterRegistration.xsd schema and enforces that registration metadata in the request matches the authenticated user's credentials (encoded in username as modelNumber+registrationDomain+serialNumber).

# Business rules

• Uses CloudPrinterRegistration.xsd schema for XML validation.
• Security check is controlled by OffRampAPIConfig.SECURITY_CHECK_REQUIRED flag.
• If security check is disabled, metadata validation is skipped.
• Username format: "{modelNumber}+{registrationDomain}+{serialNumber}".
• Username must have at least 3 parts separated by "+"; otherwise throw RegistrationDataMismatchException.
• modelNumber, serialNumber, and registrationDomain in request must match authenticated username; mismatch throws RegistrationDataMismatchException.
• Differs from OfframpVersion2 by using serialNumber instead of registrationID for authentication.
