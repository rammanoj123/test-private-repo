---
type: Component
title: Legacy SHA-256 Password Encoder
description: Encodes passwords using legacy SHA-256 hashing for backward compatibility with existing printer credentials.
tags: [component, unknown, security, password, encoder, sha256]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\LegacySha256PasswordEncoder.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: LegacySha256PasswordEncoder.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/LegacySha256PasswordEncoder.java, title: LegacySha256PasswordEncoder.java }
---

`com.hp.cloudprint.api.offramp.security.LegacySha256PasswordEncoder`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| digest | MessageDigest | @Override |
| hash | byte[] | @Override |
| hashedPassword | String | @Override |
| result | boolean |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| encode | String | CharSequence rawPassword |  |
| matches | boolean | CharSequence rawPassword, String encodedPassword |  |

# Business context

Implements Spring Security's PasswordEncoder interface using legacy SHA-256 hashing for backward compatibility with existing printer credentials. Supports both direct password matching (for API calls with pre-hashed passwords) and hash-then-compare matching (for registration calls with plaintext passwords).

# Algorithm

**encode (CharSequence rawPassword)**
1. Get MessageDigest instance for "SHA-256" algorithm
2. Convert rawPassword to string and get UTF-8 bytes
3. Compute SHA-256 hash of password bytes via digest.digest
4. Encode hash bytes to Base64 string via Base64.getEncoder().encodeToString
5. Return Base64-encoded hash string
6. If NoSuchAlgorithmException thrown, wrap in IllegalStateException with "SHA-256 algorithm not available"

**matches (CharSequence rawPassword, String encodedPassword)**
1. Log rawPassword and encodedPassword for debugging
2. If rawPassword as string equals encodedPassword (direct match), log "Api call validation" and return true
3. Encode rawPassword via encode(rawPassword) to get hashedPassword
4. Compare hashedPassword with encodedPassword
5. Log "Registration call validation" with result
6. Return comparison result

# Business rules

• If rawPassword directly equals encodedPassword, accept as valid (API call scenario).
• Otherwise, hash rawPassword with SHA-256 and compare with encodedPassword (registration scenario).
• SHA-256 hash is Base64-encoded for storage and comparison.
• If SHA-256 algorithm is unavailable, throw IllegalStateException.
