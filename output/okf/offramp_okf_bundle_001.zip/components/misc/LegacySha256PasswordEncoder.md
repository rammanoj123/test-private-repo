---
type: Component
title: LegacySha256PasswordEncoder
description: Unknown `LegacySha256PasswordEncoder`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\LegacySha256PasswordEncoder.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.LegacySha256PasswordEncoder`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| digest | MessageDigest | @Override |
| hash | byte[] | @Override |
| hashedPassword | String | @Override |
| result | boolean |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| encode | String | CharSequence rawPassword |  |
| matches | boolean | CharSequence rawPassword, String encodedPassword |  |
