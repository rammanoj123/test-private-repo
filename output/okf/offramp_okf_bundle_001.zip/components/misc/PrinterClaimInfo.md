---
type: Component
title: PrinterClaimInfo
description: Unknown `PrinterClaimInfo`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterClaimInfo.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterClaimInfo`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAddress | String | @XmlElement(required = true) |
| claimCode | String | @XmlElement(name = "ClaimCode", required = true) |
| epcUrl | String | @XmlElement(name = "ePCUrl", required = true) |
| version | String | @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEmailAddress | String |  |  |
| setEmailAddress | void | String value |  |
| getClaimCode | String |  |  |
| setClaimCode | void | String value |  |
| getEPCUrl | String |  |  |
| setEPCUrl | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
