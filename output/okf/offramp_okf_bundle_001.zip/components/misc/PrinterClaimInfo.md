---
type: Component
title: Printer Claim Info
description: Holds printer claim information including email address, claim code, and ePrint Center URL.
tags: [component, unknown, data, claim, printer, xml-schema]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterClaimInfo.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterClaimInfo`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAddress | String | @XmlElement(required = true) |
| claimCode | String | @XmlElement(name = "ClaimCode", required = true) |
| epcUrl | String | @XmlElement(name = "ePCUrl", required = true) |
| version | String | @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEmailAddress | String |  |  |
| setEmailAddress | void | String value |  |
| getClaimCode | String |  |  |
| setClaimCode | void | String value |  |
| getEPCUrl | String |  |  |
| setEPCUrl | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
