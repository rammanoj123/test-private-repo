---
type: Component
title: StratusClientImpl
description: Unknown `StratusClientImpl`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\StratusClientImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.StratusClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| notificationServiceClientHelper | NotificationServiceClientHelper | @Resource |
| AUTHORIZATION | String | @Resource |
| BEARER | String | @Resource |
| httpHeaders | HashMap |  |
| stratusEventPayload | StratusEventPayload |  |
| maxRetries | int |  |
| retryDelay | long |  |
| i | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setNotificationServiceClientHelper | void | NotificationServiceClientHelper notificationServiceClientHelper |  |
| getPrinterConfigInstance | PrinterConfig |  |  |
| publishDeleteOwnershipToStratus | void | String ownershipId, String  printerId |  |
| sleep | void | long timeSpan, String id |  |

# Depends on

* `NotificationServiceClientHelper`
* `String`
