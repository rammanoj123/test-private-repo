---
type: Component
title: Stratus Client Implementation
description: Publishes printer ownership deletion events to Stratus eventing service with retry logic.
tags: [component, unknown, integration, stratus, eventing, client]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\StratusClientImpl.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.StratusClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| notificationServiceClientHelper | NotificationServiceClientHelper | @Resource |
| AUTHORIZATION | String | @Resource |
| BEARER | String | @Resource |
| httpHeaders | HashMap |  |
| stratusEventPayload | StratusEventPayload |  |
| maxRetries | int |  |
| retryDelay | long |  |
| i | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setNotificationServiceClientHelper | void | NotificationServiceClientHelper notificationServiceClientHelper |  |
| getPrinterConfigInstance | PrinterConfig |  |  |
| publishDeleteOwnershipToStratus | void | String ownershipId, String  printerId |  |
| sleep | void | long timeSpan, String id |  |

# Depends on

* `NotificationServiceClientHelper`
* `String`
