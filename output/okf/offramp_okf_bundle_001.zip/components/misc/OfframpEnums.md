---
type: Component
title: Offramp Enums
description: Defines enumeration types used across offramp resources and operations.
tags: [component, unknown, enum, constants]
status: stable
component_type: Enum
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\OfframpEnums.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpEnums.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/OfframpEnums.java, title: OfframpEnums.java }
---

`com.hp.cloudprint.api.offramp.resources.OfframpEnums`

# Algorithm

**UDCValue Constructor (int value)**
1. Set this.value to provided integer value

**getValue**
1. Return value field

# Business context

Defines enumeration for Usage Data Collection (UDC) settings. Used in printer registration to determine whether usage data collection is enabled, disabled, or enabled for Large Format Printers (LFP).

# Business rules

• DISABLED_UDC (0) — usage data collection is disabled.
• ENABLED_UDC (1) — usage data collection is enabled.
• LFP_ENABLED_UDC (2) — usage data collection is enabled for Large Format Printers.
• Used in PrintersResource to set allowsUsageDataCollection flag.
