---
type: Component
title: Offramp Authentication Entry Point
description: Handles authentication failures by logging and returning HTTP 401 Unauthorized responses.
tags: [component, unknown, security, authentication, entry-point, http]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\log\OfframpAuthenticationEntryPoint.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpAuthenticationEntryPoint.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/log/OfframpAuthenticationEntryPoint.java, title: OfframpAuthenticationEntryPoint.java }
---

`com.hp.cloudprint.api.offramp.security.log.OfframpAuthenticationEntryPoint`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| httpResponse | HttpServletResponse | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| commence | void | HttpServletRequest  request, HttpServletResponse  response, AuthenticationException authException |  |

# Business context

Extends Spring Security's BasicAuthenticationEntryPoint to handle authentication failures. Differentiates between service unavailability (503) and authentication failures (401), providing appropriate HTTP responses and WWW-Authenticate headers for Basic authentication.

# Algorithm

**commence (HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)**
1. Cast response to HttpServletResponse
2. If authException is instance of AuthenticationServiceException:
   a. Set HTTP status to 503 SERVICE_UNAVAILABLE
3. Else:
   a. Add WWW-Authenticate header with Basic realm and realm name
   b. Set HTTP status to 401 UNAUTHORIZED

# Business rules

• If authentication fails due to service unavailability (AuthenticationServiceException), return 503 SERVICE_UNAVAILABLE.
• For all other authentication failures, return 401 UNAUTHORIZED with WWW-Authenticate Basic header.
• Realm name is included in WWW-Authenticate header for Basic authentication challenges.
