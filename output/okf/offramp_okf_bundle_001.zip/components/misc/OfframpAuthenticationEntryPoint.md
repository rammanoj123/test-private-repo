---
type: Component
title: OfframpAuthenticationEntryPoint
description: Unknown `OfframpAuthenticationEntryPoint`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\log\OfframpAuthenticationEntryPoint.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.log.OfframpAuthenticationEntryPoint`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| httpResponse | HttpServletResponse | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| commence | void | HttpServletRequest  request, HttpServletResponse  response, AuthenticationException authException |  |
