---
type: Component
title: Offramp Helper
description: Provides utility methods for parsing custom headers, building XMPP configuration, and validating API versions.
tags: [component, unknown, helper, xmpp, configuration, utility]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpHelper.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpHelper.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/OfframpHelper.java, title: OfframpHelper.java }
---

`com.hp.cloudprint.api.offramp.OfframpHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| NAMESPACE | String |  |
| SCHEMA_VERSION | String |  |
| API_VERSION | String |  |
| HP_CUSTOM_HEADER_NAME | String |  |
| HP_CUSTOM_HEADER_NAME_FOR_OLD_PRINTER | String |  |
| DELIMITER | String |  |
| API_VERSIONS_STRINGS_DELIMITER | String |  |
| VERSION_17 | String |  |
| VERSION_2_0 | String |  |
| arrHeaderValues | String[] |  |
| htParsedValues | HashMap |  |
| key | String |  |
| xmppConfig | XmppConfig |  |
| config | OffRampAPIConfig |  |
| jabberId | String |  |
| temp | String[] |  |
| currentOfframpAPIVersionInRestrictedList | boolean |  |
| jabberIds | JabberIDs |  |
| temp | String[] |  |
| tcpValues | List |  |
| tcpPorts | TcpPorts |  |
| tcpPort | TcpPort |  |
| priority | BigInteger |  |
| offrampAPIVersionList | List |  |
| apiVersions | String |  |
| version | Float |  |
| versionV2 | Float |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValuesFromCustomHPHeader | HashMap | String headerValue |  |
| getCustomHPHeader | String | Form headerValues |  |
| getXMPPConfiguration | XmppConfig | String version, JabberIDs jabberIds, TcpPorts tcpPorts, String xmppServerHostName, String offrampAPIVersion |  |
| setXMPPBackOffAndWhitespaceInterval | void | String offrampAPIVersion, XmppConfig xmppConfig, OffRampAPIConfig config |  |
| getJabberIDs | JabberIDs | String jabberIdOfDevice |  |
| getTCPPorts | TcpPorts |  |  |
| getDateTimeFromGregorianCalendar | Date | XMLGregorianCalendar date |  |
| isValidOfframpAPIVersion | boolean | String offrampConfigParamName, String currentOfframpAPIVersion |  |
| isV2Compatible | boolean | String versionString |  |

# Algorithm

**getValuesFromCustomHPHeader (String headerValue)**
1. If headerValue is null or empty, throw BadHeaderPassedException
2. Split headerValue by space to get array of key-value pairs
3. Create empty HashMap for parsed values
4. For each key-value pair:
   a. Split by "=" to get key and value
   b. Extract value between quotes
   c. If IndexOutOfBoundsException, throw BadHeaderPassedException with "Bad header passed"
   d. Convert key to lowercase
   e. If key is "namespace", "schema-version", or "api-version", add to map
   f. Else throw BadHeaderPassedException with "unknown key present"
5. If map does not contain "api-version", throw BadHeaderPassedException
6. Return parsed HashMap

**getCustomHPHeader (Form headerValues)**
1. Get value for HP_CUSTOM_HEADER_NAME ("X-HP-CLOUD-VERSION") from form
2. If null or empty, get value for HP_CUSTOM_HEADER_NAME_FOR_OLD_PRINTER ("X-HP-CLOUD_VERSION")
3. Return header value

**getXMPPConfiguration (String version, JabberIDs jabberIds, TcpPorts tcpPorts, String xmppServerHostName, String offrampAPIVersion)**
1. Create new XmppConfig and set version, jabberIds, tcpPorts
2. Get OffRampAPIConfig instance
3. Get CLOUD_PRINT_JABBER_ID from config
4. Split jabber ID by "@" delimiter
5. Set serverNodeName to first part, serverDomainName to second part
6. Set serverHostname to xmppServerHostName
7. Set xmppVersion from config
8. Call setXMPPBackOffAndWhitespaceInterval to set backoff and whitespace values
9. Return XmppConfig

**setXMPPBackOffAndWhitespaceInterval (String offrampAPIVersion, XmppConfig xmppConfig, OffRampAPIConfig config)**
1. If offrampAPIVersion is not null or empty:
   a. Check if current API version is in restricted list via isValidOfframpAPIVersion
   b. If in restricted list, set maxXMPPBackoffLimit and whitespaceInterval from config

**getJabberIDs (String jabberIdOfDevice)**
1. Create new JabberIDs object
2. Set ledmResourceName from config LEDM_RESOURCE_NAME
3. Split jabberIdOfDevice by "@" delimiter
4. Set printerNodeName to first part
5. Return JabberIDs

**getTCPPorts**
1. Get TCPPortValueArray list from config
2. Create new TcpPorts object
3. For each value in list:
   a. Create TcpPort with priority (i+1) and value
   b. Add to tcpPorts list
4. Return TcpPorts

**getDateTimeFromGregorianCalendar (XMLGregorianCalendar date)**
1. Convert XMLGregorianCalendar to GregorianCalendar
2. Get time as Date and return

**isValidOfframpAPIVersion (String offrampConfigParamName, String currentOfframpAPIVersion)**
1. Get API versions string from config using offrampConfigParamName
2. If not null, split by ";" delimiter to get list
3. Return true if currentOfframpAPIVersion is NOT in list (valid), false otherwise

**isV2Compatible (String versionString)**
1. Parse versionString to Float
2. Parse VERSION_2_0 ("2.0") to Float
3. Return true if versionString >= 2.0, false otherwise

# Business context

Provides utility methods for parsing custom HP headers, building XMPP configuration, and validating API versions. Central helper for printer registration and configuration workflows, handling version-specific logic and header parsing.

# Business rules

• Custom HP header format: "namespace=\"{value}\" schema-version=\"{value}\" api-version=\"{value}\"".
• api-version is required in custom header; missing api-version throws BadHeaderPassedException.
• Supports both "X-HP-CLOUD-VERSION" and legacy "X-HP-CLOUD_VERSION" (underscore) headers.
• XMPP backoff and whitespace interval are only set for API versions NOT in restricted list.
• API version 2.0 or higher is considered v2 compatible.
• Jabber IDs are split by "@" delimiter into node and domain parts.
• TCP ports are assigned sequential priorities starting from 1.
