---
type: Component
title: OfframpHelper
description: Unknown `OfframpHelper`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.OfframpHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| NAMESPACE | String |  |
| SCHEMA_VERSION | String |  |
| API_VERSION | String |  |
| HP_CUSTOM_HEADER_NAME | String |  |
| HP_CUSTOM_HEADER_NAME_FOR_OLD_PRINTER | String |  |
| DELIMITER | String |  |
| API_VERSIONS_STRINGS_DELIMITER | String |  |
| VERSION_17 | String |  |
| VERSION_2_0 | String |  |
| arrHeaderValues | String[] |  |
| htParsedValues | HashMap |  |
| key | String |  |
| xmppConfig | XmppConfig |  |
| config | OffRampAPIConfig |  |
| jabberId | String |  |
| temp | String[] |  |
| currentOfframpAPIVersionInRestrictedList | boolean |  |
| jabberIds | JabberIDs |  |
| temp | String[] |  |
| tcpValues | List |  |
| tcpPorts | TcpPorts |  |
| tcpPort | TcpPort |  |
| priority | BigInteger |  |
| offrampAPIVersionList | List |  |
| apiVersions | String |  |
| version | Float |  |
| versionV2 | Float |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValuesFromCustomHPHeader | HashMap | String headerValue |  |
| getCustomHPHeader | String | Form headerValues |  |
| getXMPPConfiguration | XmppConfig | String version, JabberIDs jabberIds, TcpPorts tcpPorts, String xmppServerHostName, String offrampAPIVersion |  |
| setXMPPBackOffAndWhitespaceInterval | void | String offrampAPIVersion, XmppConfig xmppConfig, OffRampAPIConfig config |  |
| getJabberIDs | JabberIDs | String jabberIdOfDevice |  |
| getTCPPorts | TcpPorts |  |  |
| getDateTimeFromGregorianCalendar | Date | XMLGregorianCalendar date |  |
| isValidOfframpAPIVersion | boolean | String offrampConfigParamName, String currentOfframpAPIVersion |  |
| isV2Compatible | boolean | String versionString |  |
