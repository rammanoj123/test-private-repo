---
type: Component
title: RegionName
description: Unknown `RegionName`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\RegionName.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.RegionName`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| RegionName |  | String v |  |
| fromValue | RegionName | String v |  |
