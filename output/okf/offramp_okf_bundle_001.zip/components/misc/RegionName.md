---
type: Component
title: Region Name
description: Represents region name enumeration for localization and validation.
tags: [component, unknown, data, enum, localization]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\RegionName.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.RegionName`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| RegionName |  | String v |  |
| fromValue | RegionName | String v |  |
