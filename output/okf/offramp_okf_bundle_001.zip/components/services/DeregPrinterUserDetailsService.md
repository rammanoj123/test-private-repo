---
type: Component
title: DeregPrinterUserDetailsService
description: Service `DeregPrinterUserDetailsService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\DeregPrinterUserDetailsService.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.DeregPrinterUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| LOGGER | Logger |  |
| VIP_PRINTER | String |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |
| BLOCKED_ATTEMPTS_COUNTER_ID_STR | String |  |
| simpleCacheKey | String |  |
| simpleCacheKeyObj | Object |  |
| extendedCacheKey | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| deleteFromCache | void | String printerID |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |
