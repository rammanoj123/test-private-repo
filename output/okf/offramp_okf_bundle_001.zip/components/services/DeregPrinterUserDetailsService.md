---
type: Component
title: Deregistration Printer User Details Service
description: Loads printer user details for deregistration, checking blocked status via cache before database lookup.
tags: [component, service, security, user-details, deregistration]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\DeregPrinterUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.DeregPrinterUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| LOGGER | Logger |  |
| VIP_PRINTER | String |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |
| BLOCKED_ATTEMPTS_COUNTER_ID_STR | String |  |
| simpleCacheKey | String |  |
| simpleCacheKeyObj | Object |  |
| extendedCacheKey | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| deleteFromCache | void | String printerID |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |
