---
type: Component
title: PrinterUserDetailsService
description: Service `PrinterUserDetailsService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\PrinterUserDetailsService.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.PrinterUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| LOGGER | Logger |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |
