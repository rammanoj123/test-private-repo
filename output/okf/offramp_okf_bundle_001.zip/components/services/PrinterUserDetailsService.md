---
type: Component
title: Printer User Details Service
description: Loads printer user details from database for authentication during normal operations.
tags: [component, service, security, user-details, authentication]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\PrinterUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.PrinterUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| LOGGER | Logger |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |
