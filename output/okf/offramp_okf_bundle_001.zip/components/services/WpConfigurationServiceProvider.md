---
type: Component
title: WP Configuration Service Provider
description: Provides singleton access to WpConfigurationService from Spring application context.
tags: [component, service, provider, configuration, singleton]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\WpConfigurationServiceProvider.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.WpConfigurationServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
