---
type: Component
title: Stratus Client
description: Defines interface for publishing printer ownership deletion events to Stratus eventing service.
tags: [component, service, interface, stratus, eventing]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\StratusClient.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.StratusClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishDeleteOwnershipToStratus | void | String ownershipId, String  printerid |  |
