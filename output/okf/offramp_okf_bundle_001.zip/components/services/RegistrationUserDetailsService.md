---
type: Component
title: Registration User Details Service
description: Loads registration credentials from cache or database, validates domain keys, and tracks failed attempts.
tags: [component, service, security, registration, user-details]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.RegistrationUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| SIMPLECACHE_WEIGHT_INCREMENT | int |  |
| LOGGER | Logger |  |
| SEPARATOR | String |  |
| TEST_DOMAIN | String |  |
| cachedTestDomainMasterKey | String |  |
| cachedKeyRefreshConfigValue | int |  |
| lock | Lock |  |
| KEY_SEPERATOR | String |  |
| securityManager | SecurityManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| arrParams | String[] | @Override |
| modelNumber | String | @Override |
| registrationDomain | String | @Override |
| id | String | @Override |
| memcacheKey | String |  |
| blockThreshold | int |  |
| key | String |  |
| regAttemptsObj | Object |  |
| regAttempts | Integer |  |
| domain | PrinterRegistrationDomain |  |
| key | String |  |
| keyRefreshConfigValue | int |  |
| key | String |  |
| validationResult | boolean |  |
| digest | MessageDigest |  |
| hash | byte[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| RegistrationUserDetailsService |  |  |  |
| loadUserByUsername | UserDetails | String userName |  |
| readFromCache | void | String memcacheKey, String modelNumber, String id, int blockThreshold |  |
| getUserKeyFromDB | String | String userName, String modelNumber, String registrationDomain |  |
| getTestDomainUserKey | String | String userName, String modelNumber |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getTestDomainKeyRefreshConfig | int |  |  |
| getCachedTestDomainMasterKey | String |  |  |
| getCachedKeyRefreshConfigValue | int |  |  |
| isDomainKeyHashCheckEnabled | boolean |  |  |
| getSHA256Hash | String | String key |  |

# Depends on

* `Lock`
