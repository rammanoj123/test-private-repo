---
type: Component
title: RegistrationUserDetailsService
description: Service `RegistrationUserDetailsService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationUserDetailsService.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.security.RegistrationUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| SIMPLECACHE_WEIGHT_INCREMENT | int |  |
| LOGGER | Logger |  |
| SEPARATOR | String |  |
| TEST_DOMAIN | String |  |
| cachedTestDomainMasterKey | String |  |
| cachedKeyRefreshConfigValue | int |  |
| lock | Lock |  |
| KEY_SEPERATOR | String |  |
| securityManager | SecurityManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| arrParams | String[] | @Override |
| modelNumber | String | @Override |
| registrationDomain | String | @Override |
| id | String | @Override |
| memcacheKey | String |  |
| blockThreshold | int |  |
| key | String |  |
| regAttemptsObj | Object |  |
| regAttempts | Integer |  |
| domain | PrinterRegistrationDomain |  |
| key | String |  |
| keyRefreshConfigValue | int |  |
| key | String |  |
| validationResult | boolean |  |
| digest | MessageDigest |  |
| hash | byte[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| RegistrationUserDetailsService |  |  |  |
| loadUserByUsername | UserDetails | String userName |  |
| readFromCache | void | String memcacheKey, String modelNumber, String id, int blockThreshold |  |
| getUserKeyFromDB | String | String userName, String modelNumber, String registrationDomain |  |
| getTestDomainUserKey | String | String userName, String modelNumber |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getTestDomainKeyRefreshConfig | int |  |  |
| getCachedTestDomainMasterKey | String |  |  |
| getCachedKeyRefreshConfigValue | int |  |  |
| isDomainKeyHashCheckEnabled | boolean |  |  |
| getSHA256Hash | String | String key |  |

# Depends on

* `Lock`
