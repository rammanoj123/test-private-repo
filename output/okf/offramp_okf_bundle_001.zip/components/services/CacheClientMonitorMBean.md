---
type: Component
title: Cache Client Monitor MBean
description: Exposes JMX operation to reconfigure cache server connections at runtime.
tags: [component, service, jmx, cache, monitoring]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\oam\CacheClientMonitorMBean.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.oam.CacheClientMonitorMBean`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| reconfigureCacheServers | int |  |  |
