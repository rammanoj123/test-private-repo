---
type: Component
title: CacheClientMonitorMBean
description: Service `CacheClientMonitorMBean`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\oam\CacheClientMonitorMBean.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.oam.CacheClientMonitorMBean`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| reconfigureCacheServers | int |  |  |
