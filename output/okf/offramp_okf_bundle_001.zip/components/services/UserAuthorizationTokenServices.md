---
type: Component
title: User Authorization Token Services
description: Manages OAuth request tokens, authorization, and access token creation for user authorization flows.
tags: [component, service, oauth, token, authorization]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\UserAuthorizationTokenServices.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.security.UserAuthorizationTokenServices`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| authoritiesToVerify | List |  |
| securityManager | SecurityManager |  |
| token | RequestTokenEntity | @Override, @Transactional |
| tokenToVerify | RequestTokenEntity | @Override, @Transactional |
| grantedAuthority | String | @Override, @Transactional |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | RequestTokenEntity | String token |  |
| removeToken | void | String token |  |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication | @Transactional |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token | @Transactional |
| isExpired | boolean | RequestTokenEntity tokenToVerify | @Transactional |
| setAuthoritiesToVerify | void | List<String> authoritiesToVerify | @Transactional |
| getAuthoritiesToVerify | List |  | @Transactional |

# Cross-cutting

* Transactional: `authorizeRequestToken`, `getToken`, `isExpired`, `setAuthoritiesToVerify`, `getAuthoritiesToVerify`
