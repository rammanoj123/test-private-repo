---
type: Component
title: PrintersResource
description: Controller `PrintersResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrintersResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.PrintersResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| BAD_REQUEST_MESSAGE | String |  |
| REUSE_EXISTING_IDENTITY_HEADER | String |  |
| INTERNAL_ERROR_MESSAGE | String |  |
| INVALID_PRINTER_MESSAGE | String |  |
| REGISTRATION_DATA_MISMATCH_MESSAGE | String |  |
| REGISTRATION_DATA_INVALID_MESSAGE | String |  |
| statCollector | StatisticsCollector |  |
| LANG_ENGLISH | String |  |
| MODEL_TOKEN | String |  |
| MODEL_NAME_TOKEN | String |  |
| SERIAL_TOKEN | String |  |
| REGISTRATION_DOMAIN_TOKEN | String |  |
| PRINTER_ASSOCIATED_IDENTITY | String |  |
| PRINTER_FIRMWARE_VERSION | String |  |
| DEFUALT_COUNTY_AND_REGION_NAME | String |  |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| collectionServiceClient | ICollectionServiceClient | @javax.annotation.Resource |
| simpleCacheClient | SimpleCacheClient | @javax.annotation.Resource |
| finalExp | Exception | @Override, @Auditable(name="/Printers#POST") |
| printerIdentification | PrinterIdentification | @Override, @Auditable(name="/Printers#POST") |
| printerIdentityKnown | boolean | @Override, @Auditable(name="/Printers#POST") |
| printerId | String | @Override, @Auditable(name="/Printers#POST") |
| registrationMode | PrinterRegistrationMode | @Override, @Auditable(name="/Printers#POST") |
| headerValues | Form | @Override, @Auditable(name="/Printers#POST") |
| customHeaderValues | HashMap | @Override, @Auditable(name="/Printers#POST") |
| version | String |  |
| v2Compatible | boolean |  |
| offrampVersion | OfframpVersion |  |
| repXml | String |  |
| printer | Printer |  |
| printerRegConfig | PrinterRegistrationConfiguration |  |
| printerCloudConfig | PrinterCloudConfiguration |  |
| testDomainStatus | boolean |  |
| printerConfiguration | PrinterConfiguration |  |
| configXml | String |  |
| curSerialNumber | String |  |
| appConfigSerialNumber | String |  |
| invalidSerialNumberList | List |  |
| reRegFlag | int |  |
| status | String |  |
| testDomainStatus | boolean |  |
| uniqueIdentifier | String |  |
| regID | String |  |
| secureSerialNumber | String |  |
| printerDetails | PrinterIdentification |  |
| modelName | String |  |
| modelNumber | String |  |
| serialNumber | String |  |
| registrationDomain | String |  |
| associatedId | String |  |
| firmwareVersion | String |  |
| version | Version |  |
| p | Pattern |  |
| m | Matcher |  |
| rep | Representation |  |
| cloudConfig | CloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| udcFlag | int |  |
| serialNumber | String |  |
| printerSecureInfo | PrinterSecureInfo |  |
| printerUUID | String |  |
| regID | String |  |
| printerAdditionalInfo | PrinterAdditionalInfo |  |
| supportsSerialNumberEncryption | boolean |  |
| printer | Printer |  |
| secureSerialNumber | String |  |
| uiLanguage | String |  |
| address | PrinterLocationAddress |  |
| printerVersion | PrinterVersion |  |
| firmwareVersionDate | Date |  |
| printer | Printer |  |
| jabberIds | JabberIDs |  |
| xmppServerHostName | String |  |
| tcpPorts | TcpPorts |  |
| xmppConfig | XmppConfig |  |
| xmppConfig | XmppConfig |  |
| tcpPorts | TcpPorts |  |
| jabberIds | JabberIDs |  |
| printerConfiguration | PrinterConfiguration |  |
| isLFPPrinter | boolean |  |
| printerModelListForLFP | String |  |
| modelList | String[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simple |  |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| PrintersResource |  |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowPost | boolean |  |  |
| acceptRepresentation | void | Representation rep |  |
| getRegistrationMode | PrinterRegistrationMode | final PrinterCloudConfiguration cloudPrinterProfile |  |
| createPrinterConfigurationResponse | void | PrinterRegistrationConfiguration printerRegConfig, Printer printer, boolean printerIdentityKnown, String apiVersion |  |
| validateSerialNumber | void | PrinterIdentification printerIdentification |  |
| actOnRegRequestFailure | void | Exception e, PrinterIdentification printerDetails, boolean reRegistration, PrinterRegistrationMode registrationMode, String printerId |  |
| getPrinterUniqueIdentifier | String | PrinterIdentification printerIdentification |  |
| createPrinterIdentification | PrinterIdentification | String xml |  |
| getXMLData | String | String xml, String pattern |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getOfframpVersionFactory | OfframpVersionFactory |  |  |
| createPrinterResource | void | String printerConfigurationXML, Printer printer |  |
| isPrinterIdentityKnown | boolean | PrinterIdentification printerIdentification |  |
| checkRequiredAttributes | void | final PrinterRegistrationMode registrationMode, final PrinterIdentification printerIdentification |  |
| getPrinterCloudConfiguration | PrinterCloudConfiguration | final Printer printer, final PrinterIdentification printerIdentification |  |
| updatePrinterSecureInfo | void | final Printer printer, final PrinterIdentification printerIdentification |  |
| updatePrinterAdditionalInfo | void | final Printer printer, final PrinterIdentification printerIdentification |  |
| incrementReRegFailureCounter | void |  |  |
| getSchema | Schema |  |  |
| getPrinterFromPrinterIdentification | Printer | PrinterIdentification printerIdentification |  |
| getSecureSerialNumber | String | String serialNumber |  |
| setUILanguage | void | String language, Printer printer |  |
| setCountryAndRegionName | void | String countryAndRegionName, Printer printer |  |
| setPrinterFirmwareVersion | void | PrinterIdentification printerIdentification, Printer printer |  |
| getPrinterConfiguration | PrinterConfiguration | PrinterRegistrationConfiguration printerRegistrationConfiguration, String offrampAPIVersion |  |
| getXMPPConfiguration | XmppConfig | String offrampAPIVersion, JabberIDs jabberIds, String xmppServerHostName, TcpPorts tcpPorts |  |
| getTCPPorts | TcpPorts |  |  |
| getJabberIDs | JabberIDs | PrinterRegistrationConfiguration printerRegistrationConfiguration |  |
| createPrinterConfiguration | PrinterConfiguration | Printer printer, XmppConfig xmppConfig |  |
| incrementRegRequestCounter | void |  |  |
| incrementRegRequestFailureCounter | void |  |  |
| getUDCvalue | int | boolean isAllowsUsageDataCollection, String printerModel |  |
| isUDCFlagEnabled | boolean |  |  |
| isPrinterModelsInLFP | boolean | String printerModel |  |

# Depends on

* `PrinterManager`
* `ICollectionServiceClient`
* `SimpleCacheClient`
* `StatisticsCollector`
