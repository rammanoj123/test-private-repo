---
type: Component
title: Printers Resource
description: Handles POST requests to register new printers, validate identification, and return configuration including XMPP settings.
tags: [component, controller, resource, registration, printer]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrintersResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrintersResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/PrintersResource.java, title: PrintersResource.java }
---

`com.hp.cloudprint.api.offramp.resources.PrintersResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| BAD_REQUEST_MESSAGE | String |  |
| REUSE_EXISTING_IDENTITY_HEADER | String |  |
| INTERNAL_ERROR_MESSAGE | String |  |
| INVALID_PRINTER_MESSAGE | String |  |
| REGISTRATION_DATA_MISMATCH_MESSAGE | String |  |
| REGISTRATION_DATA_INVALID_MESSAGE | String |  |
| statCollector | StatisticsCollector |  |
| LANG_ENGLISH | String |  |
| MODEL_TOKEN | String |  |
| MODEL_NAME_TOKEN | String |  |
| SERIAL_TOKEN | String |  |
| REGISTRATION_DOMAIN_TOKEN | String |  |
| PRINTER_ASSOCIATED_IDENTITY | String |  |
| PRINTER_FIRMWARE_VERSION | String |  |
| DEFUALT_COUNTY_AND_REGION_NAME | String |  |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| collectionServiceClient | ICollectionServiceClient | @javax.annotation.Resource |
| simpleCacheClient | SimpleCacheClient | @javax.annotation.Resource |
| finalExp | Exception | @Override, @Auditable(name="/Printers#POST") |
| printerIdentification | PrinterIdentification | @Override, @Auditable(name="/Printers#POST") |
| printerIdentityKnown | boolean | @Override, @Auditable(name="/Printers#POST") |
| printerId | String | @Override, @Auditable(name="/Printers#POST") |
| registrationMode | PrinterRegistrationMode | @Override, @Auditable(name="/Printers#POST") |
| headerValues | Form | @Override, @Auditable(name="/Printers#POST") |
| customHeaderValues | HashMap | @Override, @Auditable(name="/Printers#POST") |
| version | String |  |
| v2Compatible | boolean |  |
| offrampVersion | OfframpVersion |  |
| repXml | String |  |
| printer | Printer |  |
| printerRegConfig | PrinterRegistrationConfiguration |  |
| printerCloudConfig | PrinterCloudConfiguration |  |
| testDomainStatus | boolean |  |
| printerConfiguration | PrinterConfiguration |  |
| configXml | String |  |
| curSerialNumber | String |  |
| appConfigSerialNumber | String |  |
| invalidSerialNumberList | List |  |
| reRegFlag | int |  |
| status | String |  |
| testDomainStatus | boolean |  |
| uniqueIdentifier | String |  |
| regID | String |  |
| secureSerialNumber | String |  |
| printerDetails | PrinterIdentification |  |
| modelName | String |  |
| modelNumber | String |  |
| serialNumber | String |  |
| registrationDomain | String |  |
| associatedId | String |  |
| firmwareVersion | String |  |
| version | Version |  |
| p | Pattern |  |
| m | Matcher |  |
| rep | Representation |  |
| cloudConfig | CloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| udcFlag | int |  |
| serialNumber | String |  |
| printerSecureInfo | PrinterSecureInfo |  |
| printerUUID | String |  |
| regID | String |  |
| printerAdditionalInfo | PrinterAdditionalInfo |  |
| supportsSerialNumberEncryption | boolean |  |
| printer | Printer |  |
| secureSerialNumber | String |  |
| uiLanguage | String |  |
| address | PrinterLocationAddress |  |
| printerVersion | PrinterVersion |  |
| firmwareVersionDate | Date |  |
| printer | Printer |  |
| jabberIds | JabberIDs |  |
| xmppServerHostName | String |  |
| tcpPorts | TcpPorts |  |
| xmppConfig | XmppConfig |  |
| xmppConfig | XmppConfig |  |
| tcpPorts | TcpPorts |  |
| jabberIds | JabberIDs |  |
| printerConfiguration | PrinterConfiguration |  |
| isLFPPrinter | boolean |  |
| printerModelListForLFP | String |  |
| modelList | String[] |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simple |  |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| PrintersResource |  |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowPost | boolean |  |  |
| acceptRepresentation | void | Representation rep |  |
| getRegistrationMode | PrinterRegistrationMode | final PrinterCloudConfiguration cloudPrinterProfile |  |
| createPrinterConfigurationResponse | void | PrinterRegistrationConfiguration printerRegConfig, Printer printer, boolean printerIdentityKnown, String apiVersion |  |
| validateSerialNumber | void | PrinterIdentification printerIdentification |  |
| actOnRegRequestFailure | void | Exception e, PrinterIdentification printerDetails, boolean reRegistration, PrinterRegistrationMode registrationMode, String printerId |  |
| getPrinterUniqueIdentifier | String | PrinterIdentification printerIdentification |  |
| createPrinterIdentification | PrinterIdentification | String xml |  |
| getXMLData | String | String xml, String pattern |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getOfframpVersionFactory | OfframpVersionFactory |  |  |
| createPrinterResource | void | String printerConfigurationXML, Printer printer |  |
| isPrinterIdentityKnown | boolean | PrinterIdentification printerIdentification |  |
| checkRequiredAttributes | void | final PrinterRegistrationMode registrationMode, final PrinterIdentification printerIdentification |  |
| getPrinterCloudConfiguration | PrinterCloudConfiguration | final Printer printer, final PrinterIdentification printerIdentification |  |
| updatePrinterSecureInfo | void | final Printer printer, final PrinterIdentification printerIdentification |  |
| updatePrinterAdditionalInfo | void | final Printer printer, final PrinterIdentification printerIdentification |  |
| incrementReRegFailureCounter | void |  |  |
| getSchema | Schema |  |  |
| getPrinterFromPrinterIdentification | Printer | PrinterIdentification printerIdentification |  |
| getSecureSerialNumber | String | String serialNumber |  |
| setUILanguage | void | String language, Printer printer |  |
| setCountryAndRegionName | void | String countryAndRegionName, Printer printer |  |
| setPrinterFirmwareVersion | void | PrinterIdentification printerIdentification, Printer printer |  |
| getPrinterConfiguration | PrinterConfiguration | PrinterRegistrationConfiguration printerRegistrationConfiguration, String offrampAPIVersion |  |
| getXMPPConfiguration | XmppConfig | String offrampAPIVersion, JabberIDs jabberIds, String xmppServerHostName, TcpPorts tcpPorts |  |
| getTCPPorts | TcpPorts |  |  |
| getJabberIDs | JabberIDs | PrinterRegistrationConfiguration printerRegistrationConfiguration |  |
| createPrinterConfiguration | PrinterConfiguration | Printer printer, XmppConfig xmppConfig |  |
| incrementRegRequestCounter | void |  |  |
| incrementRegRequestFailureCounter | void |  |  |
| getUDCvalue | int | boolean isAllowsUsageDataCollection, String printerModel |  |
| isUDCFlagEnabled | boolean |  |  |
| isPrinterModelsInLFP | boolean | String printerModel |  |


# Depends on

• [PrinterManager](/components/services/PrinterManager.md) — registers printers (v1 and v2), sets default cloud printer profile, checks claim status
• [ICollectionServiceClient](/components/services/ICollectionServiceClient.md) — adds and deletes device data asynchronously
• [SimpleCacheClient](/components/services/SimpleCacheClient.md) — used by PrinterManager for caching
• [StatisticsCollector](/components/services/StatisticsCollector.md) — increments registration request and failure counters
• [OfframpVersionFactory](/components/config/OfframpVersionFactory.md) — provides version-specific validation implementations
• [OfframpHelper](/components/misc/OfframpHelper.md) — extracts custom headers, validates API version, creates XMPP configuration

# Algorithm

**acceptRepresentation (POST)**
1. Increment registration request counter via statCollector.incrementRegistrationRequestCount()
2. Extract custom HP header values from request headers via OfframpHelper.getValuesFromCustomHPHeader
3. Get API version from custom header
4. Determine if v2 compatible via OfframpHelper.isV2Compatible(version)
5. Get OfframpVersion implementation from factory based on v2 compatibility
6. Extract XML from request representation
7. Create PrinterIdentification from XML via createPrinterIdentification(repXml)
8. Check if printer identity is known via isPrinterIdentityKnown (checks for "reuseExistingIdentity" header)
9. Validate XML schema via offrampVersion.validateXMLSchema(repXml)
10. Validate registration metadata via offrampVersion.validateRegistrationMetadata(printerIdentification)
11. Validate serial number via validateSerialNumber(printerIdentification)
12. Create Printer object from PrinterIdentification via getPrinterFromPrinterIdentification
13. Set MDC device model name and secure serial number for logging
14. Set SimpleCacheClient on printerManager
15. If v2 compatible:
    a. Get PrinterCloudConfiguration via getPrinterCloudConfiguration
    b. Determine registration mode via getRegistrationMode (UDC_ONLY, WS_AND_UDC, or WS_ONLY)
    c. Set registration mode on printer
    d. Check required attributes via checkRequiredAttributes
    e. Call printerManager.registerPrinterV2 with cloud configuration
16. Else (v1):
    a. Set registration mode to WS_ONLY
    b. Call printerManager.registerPrinter without cloud configuration
17. Set MDC printer ID for logging
18. Create printer configuration response via createPrinterConfigurationResponse
19. Get printer ID and test domain status
20. Log "Printer Registration (MODE=REST_API_SUCCESS)" with registration mode, model number, unique ID, device ID, test domain status, firmware version, re-registration flag, and registration attempts
21. On any exception, set finalExp and handle in finally block
22. In finally block, call actOnRegRequestFailure to log failure and set appropriate HTTP status

**createPrinterConfigurationResponse**
1. Get PrinterConfiguration from printerRegConfig via getPrinterConfiguration
2. Marshal PrinterConfiguration to XML
3. If printer identity is known, call collectionServiceClient.deleteDeviceAsynch(printerID)
4. Create printer resource with XML via createPrinterResource
5. Call collectionServiceClient.addDeviceAsynch(printerID)

**validateSerialNumber**
1. Get current serial number from printerIdentification
2. Get restricted serial numbers list from OffRampAPIConfig.RESTRICTED_SERIAL_NUMBERS_LIST
3. If current serial number is not null and restricted list is not empty:
   a. Split restricted list by comma
   b. If current serial number is in restricted list, throw RegistrationDataInvalidException

**actOnRegRequestFailure**
1. If exception is null, return
2. Determine re-registration flag (0 for new registration, 1 for re-registration)
3. If not re-registration, increment registration failure counter; else increment re-registration failure counter
4. Map exception type to status string and HTTP status:
   - SchemaValidationException -> "SCHEMA_VALIDATION_FAILED", 400 BAD_REQUEST
   - RegistrationDataInvalidException -> "REGISTRATION_DATA_INVALID", 400 BAD_REQUEST
   - RegistrationDataMismatchException -> "REGISTRATION_DATA_MISMATCH", 409 CONFLICT
   - BadHeaderPassedException -> "HEADER_VALIDATION_FAILED", 400 BAD_REQUEST
   - DeviceNotFoundExcpeption -> "DEVICE_NOT_FOUND", 498 custom status
   - InvalidPrinterException -> "INVALID_PRINTER", 409 CONFLICT
   - Other -> "INTERNAL_ERROR", 503 SERVICE_UNAVAILABLE
5. Log "Printer Registration (MODE=ENDED)" with registration mode, model number, unique ID, device ID, test domain status, firmware version, failure reason, re-registration flag, status, error message, shard, and registration attempts

**getRegistrationMode**
1. If UDC is enabled (not DISABLED_UDC) and all web services are disabled, return UDC_ONLY
2. Else if UDC is enabled, return WS_AND_UDC
3. Else return WS_ONLY

**checkRequiredAttributes**
1. If registration mode is UDC_ONLY:
   a. If registrationID or printerUUID is null/empty, throw RegistrationDataInvalidException
2. Else:
   a. If registrationID, printerUUID, or serialNumber is null/empty, throw RegistrationDataInvalidException

**getPrinterCloudConfiguration**
1. Get CloudConfiguration from printerIdentification
2. Create new PrinterCloudConfiguration
3. Set default cloud printer profile via printerManager.setDefaultCloudPritnerProfile
4. If CloudConfiguration is not null:
   a. Set printFromEmail from allowsEmail
   b. Set printFromMobile from allowsMobileApps
   c. Set printFromSIPServer from allowsSips
   d. Set protectionMode from isProtectionMode
   e. Get UDC value via getUDCvalue; if country is PBUT_DISABLE_COUNTRY, set to DISABLED_UDC
   f. Set consumableSubscription from ConsumableSubscription
5. Return PrinterCloudConfiguration

**getPrinterFromPrinterIdentification**
1. Get SUPPORTS_SERIAL_NUMBER_ENCRYPTION flag from config
2. Create new Printer object
3. Set registration domain, discovery tree URL, UI language, make and model, hardware address, model number
4. If serial number encryption is supported:
   a. Set secure serial number via getSecureSerialNumber
   b. Update printer secure info via updatePrinterSecureInfo
5. Else set serial number directly
6. If firmware version is not null, set printer firmware version via setPrinterFirmwareVersion
7. If immutableID is not null, set immutableId
8. If countryAndRegionName is not null, set country and region name via setCountryAndRegionName
9. Set printInfoPageRequired from printerIdentification
10. Update printer additional info via updatePrinterAdditionalInfo
11. Return Printer

**getPrinterConfiguration**
1. Get Printer from printerRegistrationConfiguration
2. Get JabberIDs via getJabberIDs
3. Get XMPP server host name from printerRegistrationConfiguration
4. Get TCP ports via getTCPPorts
5. Get XmppConfig via getXMPPConfiguration
6. Create PrinterConfiguration via createPrinterConfiguration
7. Return PrinterConfiguration

**getUDCvalue**
1. If isAllowsUsageDataCollection is true:
   a. If UDC flag is enabled for LFP and printer model is in LFP list, return LFP_ENABLED_UDC (2)
   b. Else return ENABLED_UDC (1)
2. Else return DISABLED_UDC (0)

# Business context

Handles printer registration requests. Owns the complete registration workflow including XML validation, schema validation, serial number validation, printer entity creation, cloud configuration setup, XMPP configuration, and collection service integration. Enforces registration mode determination based on UDC and web service flags. Supports both v1 and v2 API versions with different validation and configuration requirements.

# Business rules

• If serial number is in restricted list, reject registration with 400 BAD_REQUEST.
• If schema validation fails, return 400 BAD_REQUEST.
• If registration data is invalid or missing required attributes, return 400 BAD_REQUEST.
• If registration data mismatches authorization header, return 409 CONFLICT.
• If custom HP header is invalid, return 400 BAD_REQUEST.
• If device is not found, return 498 custom status.
• If printer model is invalid, return 409 CONFLICT.
• If internal error occurs, return 503 SERVICE_UNAVAILABLE.
• Registration mode is UDC_ONLY if UDC is enabled and all web services are disabled.
• Registration mode is WS_AND_UDC if UDC is enabled and at least one web service is enabled.
• Registration mode is WS_ONLY if UDC is disabled.
• For UDC_ONLY mode, registrationID and printerUUID are required.
• For WS_ONLY and WS_AND_UDC modes, registrationID, printerUUID, and serialNumber are required.
• If country is PBUT_DISABLE_COUNTRY (Italy), UDC is disabled regardless of request.
• If printer identity is known (re-registration), delete device from collection service before re-adding.
• If countryAndRegionName is "unknown", default to "unitedStates".
• If UI language is null or empty, default to "en" (English).
• Serial number encryption is controlled by SUPPORTS_SERIAL_NUMBER_ENCRYPTION config flag.
• Only POST method is allowed; GET, PUT, and DELETE return 405 METHOD_NOT_ALLOWED.
