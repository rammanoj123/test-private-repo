---
type: Component
title: OfframpHealthControllerResource
description: Controller `OfframpHealthControllerResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\OfframpHealthControllerResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpHealthControllerResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOGGER | Logger |  |
| dependencyLocater | DependencyLocater |  |
| MIN_SUCCESS_THRESHOLD | int |  |
| NOTIFICATION_ROOT_URL | String |  |
| jdbcUrl | String |  |
| hostName | String |  |
| SHARD_HEALTH_CHECK_NAME_PREFIX | String |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| CPGDB_HEALTH_CHECK | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| hostName | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardMap | Map |  |
| shardCode | String |  |
| shard | Shard |  |
| healthType | Type |  |
| shardDS | ComboPooledDataSource |  |
| hostName | String |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardList | List |  |
| shardMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| shardDS | DataSource |  |
| shard | Shard |  |
| shardUpCountMinThreshold | int |  |
| shardDSMap | Map |  |
| xmppDirectory | XMPPDirectory |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardMap | Map |  |
| shardCode | String |  |
| shard | Shard |  |
| xmppServerGroup | XmppServerGroup |  |
| channelEndPoint | String |  |
| healthType | Type |  |
| configService | WpConfigurationService |  |
| MASTER_ROOT_URL | String |  |
| configService | WpConfigurationService |  |
| notificationServiceUrl | String |  |
| uri | URI |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| isPullNode | boolean |  |  |
| initializeRegistrationDependencies | void |  |  |
| initializePullDependencies | void |  |  |
| cacheServersHealthCheck | void |  |  |
| cpgDBHealthCheck | void |  |  |
| cpgDBHealthCheckReq | void |  |  |
| shardDBHealthCheck | void | boolean considerOnlyOpenShards |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| channelEndPointHealthcheck | void |  |  |
| masterHealthCheck | void | Type criticality |  |
| notificationServiceHealthCheck | void |  |  |
| snoobeHealthCheck | void |  |  |
| getHostName | String | String url |  |
| getDepdencyLocator | DependencyLocater |  |  |
| getAppconfig | WpConfigurationService |  |  |
