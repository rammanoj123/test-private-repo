---
type: Component
title: Offramp Health Controller Resource
description: Performs health checks on cache servers, databases, XMPP channels, and external services.
tags: [component, controller, health-check, monitoring, dependencies]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\healthcheck\OfframpHealthControllerResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpHealthControllerResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/healthcheck/OfframpHealthControllerResource.java, title: OfframpHealthControllerResource.java }
---

`com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpHealthControllerResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOGGER | Logger |  |
| dependencyLocater | DependencyLocater |  |
| MIN_SUCCESS_THRESHOLD | int |  |
| NOTIFICATION_ROOT_URL | String |  |
| jdbcUrl | String |  |
| hostName | String |  |
| SHARD_HEALTH_CHECK_NAME_PREFIX | String |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| CPGDB_HEALTH_CHECK | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| hostName | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardMap | Map |  |
| shardCode | String |  |
| shard | Shard |  |
| healthType | Type |  |
| shardDS | ComboPooledDataSource |  |
| hostName | String |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardList | List |  |
| shardMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| shardDS | DataSource |  |
| shard | Shard |  |
| shardUpCountMinThreshold | int |  |
| shardDSMap | Map |  |
| xmppDirectory | XMPPDirectory |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardMap | Map |  |
| shardCode | String |  |
| shard | Shard |  |
| xmppServerGroup | XmppServerGroup |  |
| channelEndPoint | String |  |
| healthType | Type |  |
| configService | WpConfigurationService |  |
| MASTER_ROOT_URL | String |  |
| configService | WpConfigurationService |  |
| notificationServiceUrl | String |  |
| uri | URI |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| isPullNode | boolean |  |  |
| initializeRegistrationDependencies | void |  |  |
| initializePullDependencies | void |  |  |
| cacheServersHealthCheck | void |  |  |
| cpgDBHealthCheck | void |  |  |
| cpgDBHealthCheckReq | void |  |  |
| shardDBHealthCheck | void | boolean considerOnlyOpenShards |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| channelEndPointHealthcheck | void |  |  |
| masterHealthCheck | void | Type criticality |  |
| notificationServiceHealthCheck | void |  |  |
| snoobeHealthCheck | void |  |  |
| getHostName | String | String url |  |
| getDepdencyLocator | DependencyLocater |  |  |
| getAppconfig | WpConfigurationService |  |  |

# Business context

Orchestrates health checks for all Offramp dependencies including databases, cache servers, XMPP channels, and external services. Differentiates between Registration and Pull node configurations, applying appropriate criticality levels and thresholds. Enforces minimum success thresholds for shard database and channel health to ensure service availability.

# Algorithm

**initialize**
1. Check if node is Pull node via OffRampAPIConfig.getInstance().isPullNode()
2. If Pull node, log "Initializing Pull Node Dependencies" and call initializePullDependencies()
3. If Registration node, log "Initializing Registration Node Dependencies" and call initializeRegistrationDependencies()

**initializeRegistrationDependencies**
1. Call cpgDBHealthCheck() for central database
2. Call shardDBHealthCheck(true) to check only open shards with CRITICAL type
3. Call channelEndPointHealthcheck() for XMPP channels
4. Call masterHealthCheck(Type.CRITICAL) for master service
5. Call snoobeHealthCheck() (currently TODO)
6. Call notificationServiceHealthCheck() for notification service
7. Call cacheServersHealthCheck() for cache servers

**initializePullDependencies**
1. Call cpgDBHealthCheckReq() for central database with NON_CRITICAL type
2. Call shardDBHealthCheck() to check all shards with CRITICAL type
3. Call masterHealthCheck(Type.NON_CRITICAL) for master service

**shardDBHealthCheck(boolean considerOnlyOpenShards)**
1. Get shard datasource map from dependencyLocater.getshardDBDataSourceMap()
2. Get shard map from dependencyLocater.getShardMap()
3. Iterate over each shard code in datasource map
4. For each shard, retrieve Shard object from shard map
5. Set healthType to CRITICAL by default
6. If considerOnlyOpenShards is true and shard is not open for registration, set healthType to NON_CRITICAL
7. Get ComboPooledDataSource for shard and extract hostname from JDBC URL
8. Add database check with name "cpgDB_SHARD Healthcheck for shard: {shardCode}", healthType, and GroupType.SHARD_DB
9. Set strategy for GroupType.SHARD_DB with MIN_SUCCESS_THRESHOLD (1)

**shardDBHealthCheck (Pull node variant)**
1. Get ShardDataSourceProvider instance
2. Get datasource map and shard list from provider
3. If datasource map is null or empty, log warning and return
4. If shard list is null or empty, log error and return
5. Build shard map from shard list keyed by shard code
6. Iterate over each shard code in datasource map
7. For each shard, get DataSource and Shard object
8. Extract hostname from shard JDBC URL
9. Add database check with name "Shard_{shardCode}_HealthCheck", Type.CRITICAL, and getGroupType()
10. Get threshold from config "OFFRAMP.SHARD_UP_COUNT_MIN_THRESHOLD" (default 1)
11. Set strategy for getGroupType() with threshold

**channelEndPointHealthcheck**
1. Get shard datasource map and shard map from dependencyLocater
2. Get XMPPDirectory instance from dependencyLocater
3. Iterate over each shard code
4. For each shard, get XmppServerGroup and extract channelEndPoint
5. Set healthType to CRITICAL by default
6. If shard is not open for registration, set healthType to NON_CRITICAL
7. Add EPrint dependent service check for channel endpoint with GroupType.CHANNEL_HTTP
8. Set strategy for GroupType.CHANNEL_HTTP with MIN_SUCCESS_THRESHOLD (1)

**cpgDBHealthCheck**
1. Get ComboPooledDataSource from dependencyLocater
2. Extract hostname from JDBC URL
3. Add database check with name "cpgDB Healthcheck", Type.CRITICAL, and Scope.INTERNAL

**cpgDBHealthCheckReq (Pull node)**
1. Get ComboPooledDataSource bean "eprintDirDS" from application context
2. If null, log warning and return
3. Extract JDBC URL and hostname
4. Add database check with name "CPGDB_HealthCheck", Type.NON_CRITICAL, and Scope.INTERNAL

**masterHealthCheck(Type criticality)**
1. Get WpConfigurationService from getAppconfig()
2. Get MASTER_ROOT_URL from config "OFFRAMP.MASTER_ROOT_URL"
3. Add EPrint dependent service check for master URL with provided criticality

**notificationServiceHealthCheck**
1. Get WpConfigurationService from getAppconfig()
2. Get notification service URL from config "NOTIFICATION-SERVICE.NOTIFICATION_SERVICE_ENDPOINT" + NOTIFICATION_ROOT_URL
3. Add EPrint dependent service check with Type.NON_CRITICAL

**cacheServersHealthCheck**
1. Add OfframpCacheHealthCheck with name "Offramp Cache Servers Health", Scope.INTERNAL, and Type.NON_CRITICAL

**getHostName(String url)**
1. If URL is null or empty, log info and return null
2. Create URI from url.substring(5) to strip "jdbc:" prefix
3. Return uri.getHost()

# Business rules

• If node is Pull node, only cpgDB, shards, and master are checked; master is NON_CRITICAL.
• If node is Registration node, all dependencies are checked; master and channels are CRITICAL.
• For Registration nodes with considerOnlyOpenShards=true, closed shards are marked NON_CRITICAL.
• Shard health requires at least MIN_SUCCESS_THRESHOLD (1) shard to be up.
• Channel health requires at least MIN_SUCCESS_THRESHOLD (1) channel to be up.
• Cache server health is always NON_CRITICAL.
• Notification service health is always NON_CRITICAL.
• Pull node cpgDB health is NON_CRITICAL; Registration node cpgDB health is CRITICAL.

# Depends on

• [DependencyLocater](/components/misc/DependencyLocater.md) — locates and provides datasources, shard maps, and configuration services
• [OfframpCacheHealthCheck](/components/misc/OfframpCacheHealthCheck.md) — performs cache server health checks
• [WpConfigurationService](/components/config/WpConfigurationService.md) — provides configuration values for endpoints and thresholds
• [ShardDataSourceProvider](/components/services/ShardDataSourceProvider.md) — provides shard datasources and shard lists
• [XMPPDirectory](/components/services/XMPPDirectory.md) — provides XMPP server group information
