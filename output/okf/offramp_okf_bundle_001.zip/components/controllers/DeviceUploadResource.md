---
type: Component
title: DeviceUploadResource
description: Controller `DeviceUploadResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\DeviceUploadResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.DeviceUploadResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| scanService | ScanService | @javax.annotation.Resource |
| tmpFile | File | @javax.annotation.Resource |
| LOG | Logger | @javax.annotation.Resource |
| jobId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| documentId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| pageNo | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| entityStream | InputStream |  |
| offRampAPIConfig | OffRampAPIConfig | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#PUT") |
| CHUNK_SIZE | int |  |
| MAX_POSSIBLE_MEMORY | long |  |
| totalSize | long |  |
| inStream | InputStream |  |
| byteOutStream | ByteArrayOutputStream |  |
| chunk | byte[] |  |
| readBytes | int |  |
| doContinue | boolean |  |
| outStream | OutputStream |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setScanService | void | ScanService scanService |  |
| DeviceUploadResource |  |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| getShardCodeFromJobId | String | String jobId |  |
| acceptRepresentation | void | Representation entity |  |
| storeRepresentation | void | Representation entity |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| convertToInputStream | InputStream | InputStream entityStream, String documentId |  |

# Depends on

* `ScanService`
* `File`
* `Logger`
