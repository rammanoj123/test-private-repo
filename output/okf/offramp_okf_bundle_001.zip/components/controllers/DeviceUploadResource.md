---
type: Component
title: Device Upload Resource
description: Handles POST and PUT requests to upload scanned document pages to the scan service.
tags: [component, controller, resource, scan, upload]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\DeviceUploadResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.DeviceUploadResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| scanService | ScanService | @javax.annotation.Resource |
| tmpFile | File | @javax.annotation.Resource |
| LOG | Logger | @javax.annotation.Resource |
| jobId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| documentId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| pageNo | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| entityStream | InputStream |  |
| offRampAPIConfig | OffRampAPIConfig | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#PUT") |
| CHUNK_SIZE | int |  |
| MAX_POSSIBLE_MEMORY | long |  |
| totalSize | long |  |
| inStream | InputStream |  |
| byteOutStream | ByteArrayOutputStream |  |
| chunk | byte[] |  |
| readBytes | int |  |
| doContinue | boolean |  |
| outStream | OutputStream |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setScanService | void | ScanService scanService |  |
| DeviceUploadResource |  |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| getShardCodeFromJobId | String | String jobId |  |
| acceptRepresentation | void | Representation entity |  |
| storeRepresentation | void | Representation entity |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| convertToInputStream | InputStream | InputStream entityStream, String documentId |  |

# Depends on

* `ScanService`
* `File`
* `Logger`
