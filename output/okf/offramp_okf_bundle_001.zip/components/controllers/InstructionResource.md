---
type: Component
title: Instruction Resource
description: Handles POST requests to submit print job instructions for a printer.
tags: [component, controller, resource, print-job, instructions]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\InstructionResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: InstructionResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/InstructionResource.java, title: InstructionResource.java }
---

`com.hp.cloudprint.api.offramp.resources.InstructionResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOGGER | Logger |  |
| MDC | EPrintMDC |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| daoUtil | DaoUtil | @javax.annotation.Resource |
| printer | Printer | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/PrintJobs/Instructions#POST") |
| instructionType | JAXBElement | @Override, @Auditable(name = "/Printers/{PrinterID}/PrintJobs/Instructions#POST") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| doWork | void |  |  |
| execute | void |  |  |
| acceptRepresentation | void | Representation entity |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| setDaoUtil | void | DaoUtil daoUtil |  |


# Depends on

• [PrinterManager](/components/services/PrinterManager.md) — retrieves active printers, creates instruction jobs, and records admin operations
• [DaoUtil](/components/services/DaoUtil.md) — executes transactional operations

# Business context

Handles print job instruction requests for printers. Owns the creation of instruction page print jobs and associated admin operations. Enforces transactional boundaries via DaoUtil and implements retry logic for transient failures.

# Algorithm

**acceptRepresentation (POST)**
1. Extract printerID from request URI attributes
2. Set MDC device ID for logging
3. Validate printerID is not null or empty; if invalid, return 404 NOT_FOUND
4. Unmarshal instruction type from request entity stream using ObjectFactory
5. If unmarshalling fails, log exception and return 400 BAD_REQUEST
6. Retrieve active printer by printerID via printerManager.getActivePrinterByPrinterID
7. If DeviceNotFoundExcpeption thrown, return 404 NOT_FOUND with message
8. If any other exception during retrieval, return 500 INTERNAL_SERVER_ERROR
9. If printer is null, return 404 NOT_FOUND with "Printer not found"
10. Call doWork() to execute transactional instruction job creation
11. If exception message equals PrinterManager.INFO_JOB_FLOOD_ERROR, return 401 UNAUTHORIZED
12. If any other exception during doWork, return 500 INTERNAL_SERVER_ERROR
13. Return 202 ACCEPTED on success

**doWork (transactional with retry)**
1. Annotated with @EPrintRetriable(retries = 3)
2. Use RetryHandler.executeWithRetry with 3 retries
3. Call daoUtil.executeInTransaction(this) to execute within transaction
4. Wrap CpExternalContingencyException and MustRetryException as RuntimeException for lambda

**execute (DaoCallBack implementation)**
1. Call printerManager.createPrintInstructionJob(printer, PrinterManager.instructionPageTitle)
2. Call printerManager.createAdminOperation(printer) to insert timestamp for instruction page

# Business rules

• If printerID is null or empty, return 404 NOT_FOUND.
• If printer does not exist, return 404 NOT_FOUND.
• If job flood error occurs, return 401 UNAUTHORIZED.
• Instruction job creation is transactional and retried up to 3 times on transient failures.
• Only POST method is allowed; GET, PUT, and DELETE return 405 METHOD_NOT_ALLOWED.
• Admin operation timestamp is recorded after instruction job creation.
