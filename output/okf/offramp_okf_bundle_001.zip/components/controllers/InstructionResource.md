---
type: Component
title: InstructionResource
description: Controller `InstructionResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\InstructionResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.InstructionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOGGER | Logger |  |
| MDC | EPrintMDC |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| daoUtil | DaoUtil | @javax.annotation.Resource |
| printer | Printer | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/PrintJobs/Instructions#POST") |
| instructionType | JAXBElement | @Override, @Auditable(name = "/Printers/{PrinterID}/PrintJobs/Instructions#POST") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| doWork | void |  |  |
| execute | void |  |  |
| acceptRepresentation | void | Representation entity |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| setDaoUtil | void | DaoUtil daoUtil |  |

# Depends on

* `PrinterManager`
* `DaoUtil`
* `Printer`
