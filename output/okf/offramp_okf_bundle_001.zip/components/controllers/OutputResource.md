---
type: Component
title: OutputResource
description: Controller `OutputResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\OutputResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.OutputResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printService | PrintService | @javax.annotation.Resource |
| jobId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| documentId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| pcl3GuiStream | InputStream | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| opDocSize | long |  |
| timestamp | Timestamp |  |
| timestamp | Timestamp |  |
| pcl3GuiRep | InputRepresentation |  |
| jobId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| documentId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| opDocSize | long | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| pcl3GuiStream | InputStream | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| timestamp | Timestamp | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| timestamp | Timestamp |  |
| ranges | List |  |
| pcl3GuiRep | InputRepresentation |  |
| pcl3GuiRep | InputRepresentation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrintService | void | PrintService printService |  |
| allowOptions | boolean |  |  |
| allowGet | boolean |  |  |
| allowHead | boolean |  |  |
| handleHead | void |  |  |
| handleGet | void |  |  |
| getShardCode | String | String jobId |  |

# Depends on

* `PrintService`
