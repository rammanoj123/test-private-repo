---
type: Component
title: Output Resource
description: Handles GET and HEAD requests to retrieve print job output documents from cache.
tags: [component, controller, resource, print-job, output]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\OutputResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OutputResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/OutputResource.java, title: OutputResource.java }
---

`com.hp.cloudprint.api.offramp.resources.OutputResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printService | PrintService | @javax.annotation.Resource |
| jobId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| documentId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| pcl3GuiStream | InputStream | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#HEAD") |
| opDocSize | long |  |
| timestamp | Timestamp |  |
| timestamp | Timestamp |  |
| pcl3GuiRep | InputRepresentation |  |
| jobId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| documentId | String | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| opDocSize | long | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| pcl3GuiStream | InputStream | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| timestamp | Timestamp | @Override, @Auditable(name = "/Printers/PrintJobs/Output/{CACHEID}#GET") |
| timestamp | Timestamp |  |
| ranges | List |  |
| pcl3GuiRep | InputRepresentation |  |
| pcl3GuiRep | InputRepresentation |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrintService | void | PrintService printService |  |
| allowOptions | boolean |  |  |
| allowGet | boolean |  |  |
| allowHead | boolean |  |  |
| handleHead | void |  |  |
| handleGet | void |  |  |
| getShardCode | String | String jobId |  |


# Depends on

• [PrintService](/components/services/PrintService.md) — fetches document data and size from cache

# Business context

Delivers print job output documents to printers from cache storage. Owns the retrieval of rendered documents and supports both full document delivery and HTTP range requests for partial content. Enforces shard-aware data access by setting the shard context based on job ID.

# Algorithm

**handleHead (HEAD)**
1. Log "Head Range request: get length of the output document"
2. Extract jobId and documentId from query parameters
3. Set MDC job ID and document ID for logging
4. Set shard context via EprintShardHolder.setShard(getShardCode(jobId))
5. If debug enabled, log performance timestamp "Going to deliver the document to the printer"
6. Call printService.fetchDocumentData(documentId, jobId) to get InputStream
7. Call printService.fetchDocumetSize(documentId, jobId) to get document size
8. Log document size
9. If NotFoundException thrown, return 400 BAD_REQUEST with "Job/Document doesn't exist"
10. If debug enabled, log performance timestamp "Delivery of the document to the printer complete"
11. Create InputRepresentation with InputStream and MediaType.ALL
12. Set entity on response and set size to opDocSize
13. Return 200 OK

**handleGet (GET)**
1. Extract jobId and documentId from query parameters
2. Set MDC job ID and document ID for logging
3. Set shard context via EprintShardHolder.setShard(getShardCode(jobId))
4. If debug enabled, log performance timestamp "Going to deliver the document to the printer"
5. Call printService.fetchDocumentData(documentId, jobId) to get InputStream
6. Call printService.fetchDocumetSize(documentId, jobId) to get document size
7. Log output document size
8. If NotFoundException thrown, return 400 BAD_REQUEST with "Job/Document doesn't exist"
9. If debug enabled, log performance timestamp "Delivery of the document to the printer complete"
10. Get ranges from request via getRequest().getRanges()
11. If ranges exist and size > 0, log "Range request", create InputRepresentation with MediaType.ALL, set size, and return (status commented out)
12. Else log "Non-Range request", create InputRepresentation with MediaType.APPLICATION_OCTET_STREAM, and return 200 OK

**getShardCode(String jobId)**
1. Call ShardUtil.getShardCodeFromIdString(jobId)
2. Return shard code extracted from job ID

# Business rules

• If job or document does not exist, return 400 BAD_REQUEST.
• HEAD request returns document metadata (size) without body.
• GET request returns full document or partial content based on Range header.
• If Range header is present, respond with partial content (206 status commented out in code).
• If Range header is absent, respond with full document and 200 OK.
• Shard context must be set based on job ID before accessing document data.
• Only GET, HEAD, and OPTIONS methods are allowed.
