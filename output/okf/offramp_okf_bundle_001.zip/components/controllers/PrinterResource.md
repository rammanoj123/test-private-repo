---
type: Component
title: Printer Resource
description: Handles DELETE requests to deregister a printer and clean up collection service and Stratus events.
tags: [component, controller, resource, printer, deletion]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/PrinterResource.java, title: PrinterResource.java }
---

`com.hp.cloudprint.api.offramp.resources.PrinterResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| collectionServiceClient | ICollectionServiceClient | @javax.annotation.Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| printerToBeDeleted | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| testDomainStatus | boolean | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| stratusEventing | boolean |  |
| ownership | Ownership |  |
| eprintUserDirectory | EprintUserDirectory |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| removeRepresentations | void |  |  |
| deletePrinterOwnerShardMapEntry | void | String printerID |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |


# Depends on

• [PrinterManager](/components/services/PrinterManager.md) — retrieves active printers, checks claim status, gets printer owner, and unregisters printers
• [ICollectionServiceClient](/components/services/ICollectionServiceClient.md) — deletes device data asynchronously
• [StratusClient](/components/services/StratusClient.md) — publishes delete ownership events to Stratus
• [EprintUserDirectory](/components/services/EprintUserDirectory.md) — deletes printer-owner shard map entries

# Algorithm

**removeRepresentations (DELETE)**
1. Extract printerID from request URI attributes
2. Set MDC device ID for logging
3. Validate printerID is not null or empty; if invalid, return 404 NOT_FOUND
4. Get Stratus eventing enabled flag from OffRampAPIConfig.STRATUS_EVENTING_ENABLED
5. Initialize ownership to null
6. Retrieve active printer by printerID via printerManager.getActivePrinterByPrinterID
7. Check if registration domain is test domain via CloudUtil.isTestDomain
8. If Stratus eventing is enabled:
   a. Check if printer is claimed via printerManager.isPrinterClaimed
   b. If claimed, get ownership via printerManager.getPrinterOwner(printerID)
   c. If not claimed, log "Printer is not claimed by user so delete event is not sent to Stratus Eventing"
9. Log "Printer DeRegistration (MODE=STARTED)" with model number, unique ID, and device ID
10. Call printerManager.unregisterPrinter(printerID)
11. Log "Printer DeRegistration (MODE=ENDED)" with model number, unique ID, device ID, test domain status, firmware version, "USERINITIATED=1; STATUS=0; STATUSMESSAGE=SUCCESS"
12. Call deletePrinterOwnerShardMapEntry(printerID)
13. If DeviceNotFoundExcpeption thrown, log "MODE=ENDED" with status=1 and STATUSMESSAGE=DEVICE_NOT_FOUND, return 400 BAD_REQUEST
14. If any other exception thrown, log "MODE=ENDED" with status=1 and STATUSMESSAGE=FAILED_TO_UNREGISTER, return 500 INTERNAL_SERVER_ERROR
15. Call collectionServiceClient.deleteDeviceAsynch(printerID) for async cleanup
16. Return 200 OK
17. If Stratus eventing is enabled and ownership.ownerUserId is not null:
    a. Log "Printer is claimed by user pushing notification to notification service for Stratus Eventing for Delete event"
    b. Call stratusClient.publishDeleteOwnershipToStratus(ownerUserId, printerID)
    c. Catch and print stack trace on exception

**deletePrinterOwnerShardMapEntry(String printerID)**
1. Get EprintUserDirectory via getEprintUserDirectory()
2. If eprintUserDirectory is not null, call eprintUserDirectory.deletePrinterOwnerShardMapEntry(printerID)
3. If Throwable thrown, log warning FAILED_TO_REMOVE_PRINTER_OWNER_SHARD_MAP_Entry with printerID

**getEprintUserDirectory**
1. Call EprintUserDirectoryContextFactory.getEprintUserDirectory()
2. If Throwable thrown, log error FAILED_TO_LOAD_EPRINT_USER_DIRECTORY
3. Return null on error

# Business context

Handles printer deregistration by printer ID. Owns the complete cleanup process including printer unregistration, printer-owner shard map entry deletion, collection service cleanup, and optional Stratus eventing for claimed printers. Enforces that only active printers can be deregistered and logs detailed deregistration metrics.

# Business rules

• If printer ID is null or empty, return 404 NOT_FOUND.
• If printer does not exist for printer ID, return 400 BAD_REQUEST.
• If unregistration fails, return 500 INTERNAL_SERVER_ERROR.
• Deregistration logs include model number, unique ID, device ID, test domain status, firmware version, and user-initiated flag.
• Printer-owner shard map entry deletion is best-effort; failure is logged but does not fail the request.
• Collection service cleanup is asynchronous and does not block the response.
• If Stratus eventing is enabled and printer is claimed, publish delete ownership event to Stratus after successful unregistration.
• Only DELETE method is allowed; GET, POST, and PUT return 405 METHOD_NOT_ALLOWED.
