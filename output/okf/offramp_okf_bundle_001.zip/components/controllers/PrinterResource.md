---
type: Component
title: PrinterResource
description: Controller `PrinterResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.PrinterResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| collectionServiceClient | ICollectionServiceClient | @javax.annotation.Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| printerToBeDeleted | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| testDomainStatus | boolean | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/#DELETE") |
| stratusEventing | boolean |  |
| ownership | Ownership |  |
| eprintUserDirectory | EprintUserDirectory |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| removeRepresentations | void |  |  |
| deletePrinterOwnerShardMapEntry | void | String printerID |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |

# Depends on

* `PrinterManager`
* `ICollectionServiceClient`
* [StratusClient](/components/services/StratusClient.md)
