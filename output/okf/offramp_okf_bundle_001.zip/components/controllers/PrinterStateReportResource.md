---
type: Component
title: PrinterStateReportResource
description: Controller `PrinterStateReportResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterStateReportResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.PrinterStateReportResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/StateReport#POST") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handlePut | void |  |  |
| acceptRepresentation | void | Representation rep |  |
| addStateReport | void |  |  |

# Depends on

* `PrinterManager`
