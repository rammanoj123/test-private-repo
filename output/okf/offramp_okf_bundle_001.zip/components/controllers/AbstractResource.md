---
type: Component
title: Abstract Resource
description: Provides base HTTP method allowance logic for Restlet resources.
tags: [component, controller, base-class, restlet, http]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\AbstractResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.AbstractResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |
