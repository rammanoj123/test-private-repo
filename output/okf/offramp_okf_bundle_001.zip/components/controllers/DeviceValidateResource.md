---
type: Component
title: DeviceValidateResource
description: Controller `DeviceValidateResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\DeviceValidateResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.DeviceValidateResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| securityContext | SecurityContext | @Override, @Auditable(name = "/ValidatePrinter#POST") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceValidateResource |  |  |  |
| allowPost | boolean |  |  |
| allowGet | boolean |  |  |
| allowPut | boolean |  |  |
| allowDelete | boolean |  |  |
| acceptRepresentation | void | Representation rep |  |
| validateResource | void |  |  |
| getSecurityContext | SecurityContext |  |  |
