---
type: Component
title: Device Validate Resource
description: Validates printer authentication and authorization via POST requests.
tags: [component, controller, resource, validation, security]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\DeviceValidateResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.DeviceValidateResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| securityContext | SecurityContext | @Override, @Auditable(name = "/ValidatePrinter#POST") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceValidateResource |  |  |  |
| allowPost | boolean |  |  |
| allowGet | boolean |  |  |
| allowPut | boolean |  |  |
| allowDelete | boolean |  |  |
| acceptRepresentation | void | Representation rep |  |
| validateResource | void |  |  |
| getSecurityContext | SecurityContext |  |  |
