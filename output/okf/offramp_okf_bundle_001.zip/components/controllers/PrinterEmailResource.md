---
type: Component
title: Printer Email Resource
description: Handles DELETE requests to remove printer by email address and clean up associated data.
tags: [component, controller, resource, email, deletion]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterEmailResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterEmailResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/PrinterEmailResource.java, title: PrinterEmailResource.java }
---

`com.hp.cloudprint.api.offramp.resources.PrinterEmailResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| collectionServiceClient | ICollectionServiceClient | @javax.annotation.Resource |
| printerToBeDeleted | Printer | @Override, @Auditable(name = "/EmailAddress/{EmailAddress}/#DELETE") |
| testDomainStatus | boolean | @Override, @Auditable(name = "/EmailAddress/{EmailAddress}/#DELETE") |
| emailAddress | String | @Override, @Auditable(name = "/EmailAddress/{EmailAddress}/#DELETE") |
| printerID | String | @Override, @Auditable(name = "/EmailAddress/{EmailAddress}/#DELETE") |
| eprintUserDirectory | EprintUserDirectory |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setCollectionServiceClient | void | ICollectionServiceClient collectionServiceClient |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| removeRepresentations | void |  |  |
| deletePrinterOwnerShardMapEntry | void | String printerID |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |


# Depends on

• [PrinterManager](/components/services/PrinterManager.md) — retrieves active printers by email and unregisters printers
• [ICollectionServiceClient](/components/services/ICollectionServiceClient.md) — deletes device data asynchronously
• [EprintUserDirectory](/components/services/EprintUserDirectory.md) — deletes printer-owner shard map entries

# Business context

Handles printer deregistration by email address. Owns the complete cleanup process including printer unregistration, printer-owner shard map entry deletion, and asynchronous collection service cleanup. Enforces that only active printers can be deregistered and logs detailed deregistration metrics.

# Algorithm

**removeRepresentations (DELETE)**
1. Extract emailAddress from request URI attributes
2. Set MDC device ID to emailAddress for logging
3. Validate emailAddress is not null or empty; if invalid, return 404 NOT_FOUND
4. Initialize printerID to null
5. Call printerManager.getActivePrinterByEmailAddress(emailAddress) to get printer
6. Check if registration domain is test domain via CloudUtil.isTestDomain
7. Get printerID from printer object
8. Log "Printer DeRegistration (MODE=STARTED)" with model number, unique ID, device ID, and email address
9. Call printerManager.unregisterPrinter(printerID)
10. Log "Printer DeRegistration (MODE=ENDED)" with model number, unique ID, device ID, email, test domain status, firmware version, "USERINITIATED=1; STATUS=0; STATUSMESSAGE=SUCCESS"
11. Call deletePrinterOwnerShardMapEntry(printerID)
12. If DeviceNotFoundExcpeption thrown, log "MODE=ENDED" with status=1 and STATUSMESSAGE=DEVICE_NOT_FOUND, return 400 BAD_REQUEST
13. If any other exception thrown, log "MODE=ENDED" with status=1 and STATUSMESSAGE=FAILED_TO_UNREGISTER, return 500 INTERNAL_SERVER_ERROR
14. Call collectionServiceClient.deleteDeviceAsynch(printerID) for async cleanup
15. Return 200 OK

**deletePrinterOwnerShardMapEntry(String printerID)**
1. Get EprintUserDirectory via getEprintUserDirectory()
2. If eprintUserDirectory is not null, call eprintUserDirectory.deletePrinterOwnerShardMapEntry(printerID)
3. If Throwable thrown, log warning FAILED_TO_REMOVE_PRINTER_OWNER_SHARD_MAP_Entry with printerID

**getEprintUserDirectory**
1. Call EprintUserDirectoryContextFactory.getEprintUserDirectory()
2. If Throwable thrown, log error FAILED_TO_LOAD_EPRINT_USER_DIRECTORY
3. Return null on error

# Business rules

• If email address is null or empty, return 404 NOT_FOUND.
• If printer does not exist for email address, return 400 BAD_REQUEST.
• If unregistration fails, return 500 INTERNAL_SERVER_ERROR.
• Deregistration logs include model number, unique ID, device ID, email, test domain status, firmware version, and user-initiated flag.
• Printer-owner shard map entry deletion is best-effort; failure is logged but does not fail the request.
• Collection service cleanup is asynchronous and does not block the response.
• Only DELETE method is allowed; GET, POST, and PUT return 405 METHOD_NOT_ALLOWED.
