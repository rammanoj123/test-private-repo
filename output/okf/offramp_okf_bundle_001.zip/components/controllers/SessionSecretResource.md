---
type: Component
title: Session Secret Resource
description: Handles GET requests to retrieve session secret tokens for authenticated sessions.
tags: [component, controller, resource, session, security]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\SessionSecretResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: SessionSecretResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/SessionSecretResource.java, title: SessionSecretResource.java }
---

`com.hp.cloudprint.api.offramp.resources.SessionSecretResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| LOGGER | Logger |  |
| securityManager | SecurityManager | @javax.annotation.Resource |
| form | Form | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| sessionToken | String | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| hostName | String | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| shardCode | String |  |
| tokenEntity | SessionToken |  |
| sessionSecret | SessionSecret |  |
| rep | Representation |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowGet | boolean |  |  |
| allowOptions | boolean |  |  |
| handleGet | void |  |  |
| getIdAsStringFromIdString | String | String sessionToken |  |
| getShardCode | String | String sessionToken |  |
| getOffRampVersion | String |  |  |


# Depends on

• [SecurityManager](/components/services/SecurityManager.md) — retrieves session tokens and generates session secrets

# Algorithm

**handleGet (GET)**
1. Get query form from request resource reference
2. If form is empty, return 400 BAD_REQUEST with "sessionToken not passed"
3. Extract sessionToken from query parameter
4. Extract hostName from query parameter
5. If hostName is null or empty, return 400 BAD_REQUEST with "Hostname is not passed"
6. If sessionToken is null or empty, return 400 BAD_REQUEST with "Invalid sessionToken passed"
7. Get shard code from session token via getShardCode(sessionToken)
8. Set shard context via EprintShardHolder.setShard(shardCode)
9. Get session token ID via getIdAsStringFromIdString(sessionToken)
10. Retrieve SessionToken entity via securityManager.getSessionToken(sessionTokenId)
11. Generate session secret via securityManager.generateSessionSecretForToken(hostName, tokenEntity)
12. If tokenEntity is null, return 404 NOT_FOUND with "Session token not found in the DB or the host name is not registered with the client of that token"
13. Create SessionSecret schema object and set value to tokenEntity.secret
14. Set version from OffRampAPIConfig
15. Marshal to XML and return as StringRepresentation with 200 OK
16. On exception, log error and return 500 INTERNAL_SERVER_ERROR

**getShardCode(String sessionToken)**
1. Call ShardUtil.getShardCodeFromIdString(sessionToken)
2. Return shard code extracted from session token

**getIdAsStringFromIdString(String sessionToken)**
1. Call ShardUtil.getIdAsStringFromIdString(sessionToken)
2. Return ID as string from session token

# Business context

Retrieves session secret tokens for authenticated sessions. Owns the generation and retrieval of session secrets based on session tokens and hostnames. Enforces shard-aware data access by setting the shard context based on session token.

# Business rules

• If query form is empty, return 400 BAD_REQUEST.
• If sessionToken is null or empty, return 400 BAD_REQUEST.
• If hostName is null or empty, return 400 BAD_REQUEST.
• If session token is not found in database or hostname is not registered with the client, return 404 NOT_FOUND.
• Shard context must be set based on session token before accessing session data.
• Only GET and OPTIONS methods are allowed; POST, PUT, and DELETE return 405 METHOD_NOT_ALLOWED.
