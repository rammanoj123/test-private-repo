---
type: Component
title: SessionSecretResource
description: Controller `SessionSecretResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\SessionSecretResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.SessionSecretResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| LOGGER | Logger |  |
| securityManager | SecurityManager | @javax.annotation.Resource |
| form | Form | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| sessionToken | String | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| hostName | String | @Override, @Auditable(name = "/tokens/session/secret#GET") |
| shardCode | String |  |
| tokenEntity | SessionToken |  |
| sessionSecret | SessionSecret |  |
| rep | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowGet | boolean |  |  |
| allowOptions | boolean |  |  |
| handleGet | void |  |  |
| getIdAsStringFromIdString | String | String sessionToken |  |
| getShardCode | String | String sessionToken |  |
| getOffRampVersion | String |  |  |

# Depends on

* `SecurityManager`
* `Form`
