---
type: Component
title: ClaimCodeResource
description: Controller `ClaimCodeResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\ClaimCodeResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.ClaimCodeResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager | @javax.annotation.Resource |
| LOGGER | Logger | @javax.annotation.Resource |
| daoUtil | DaoUtil | @javax.annotation.Resource |
| printer | Printer | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| strClaimCodeXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| printerClaimInfo | PrinterClaimInfo |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | PrinterManager printerManager |  |
| ClaimCodeResource |  |  |  |
| setDaoUtil | void | DaoUtil daoUtil |  |
| allowGet | boolean |  |  |
| handleGet | void |  |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| doWork | void |  |  |
| execute | void |  |  |

# Depends on

* `PrinterManager`
* `Logger`
* `DaoUtil`
* `Printer`
