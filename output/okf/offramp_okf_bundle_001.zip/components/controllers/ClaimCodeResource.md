---
type: Component
title: Claim Code Resource
description: Handles GET requests to retrieve printer claim code information for registration.
tags: [component, controller, resource, claim-code, printer]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\ClaimCodeResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
---

`com.hp.cloudprint.api.offramp.resources.ClaimCodeResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager | @javax.annotation.Resource |
| LOGGER | Logger | @javax.annotation.Resource |
| daoUtil | DaoUtil | @javax.annotation.Resource |
| printer | Printer | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| strClaimCodeXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| printerClaimInfo | PrinterClaimInfo |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | PrinterManager printerManager |  |
| ClaimCodeResource |  |  |  |
| setDaoUtil | void | DaoUtil daoUtil |  |
| allowGet | boolean |  |  |
| handleGet | void |  |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| doWork | void |  |  |
| execute | void |  |  |

# Depends on

* `PrinterManager`
* `Logger`
* `DaoUtil`
* `Printer`
