---
type: Component
title: Email Address Resource
description: Handles GET and POST requests to retrieve and update printer email addresses.
tags: [component, controller, resource, email, printer]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\EmailAddressResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: EmailAddressResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/EmailAddressResource.java, title: EmailAddressResource.java }
---

`com.hp.cloudprint.api.offramp.resources.EmailAddressResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| emailAddress | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | PrinterManager printerManager |  |
| EmailAddressResource |  |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowGet | boolean |  |  |
| allowOptions | boolean |  |  |
| acceptRepresentation | void | Representation entity |  |
| handleGet | void |  |  |
| getOffRampVersion | String |  |  |


# Depends on

• [PrinterManager](/components/services/PrinterManager.md) — retrieves active printers and updates cryptic email addresses

# Business context

Manages printer email addresses through REST endpoints. Owns the lifecycle of both cryptic (auto-generated) and friendly email addresses for printers. Enforces that only active printers can have their email addresses retrieved or regenerated.

# Algorithm

**acceptRepresentation (POST)**
1. Extract printerID from request URI attributes
2. Set MDC device ID for logging
3. Retrieve active printer by printerID via PrinterManager
4. If printer not found, return 404 NOT_FOUND
5. Call printerManager.updatePrinterCrypticEmailAddress(printer) to auto-generate new cryptic email
6. If InvalidArgumentException thrown, return 400 BAD_REQUEST with "Invalid email address"
7. Create PrinterEmailAddress schema object and set value to printer's cryptic email
8. Set version from OffRampAPIConfig
9. Marshal to XML and return as StringRepresentation with 200 OK
10. On DeviceNotFoundExcpeption, return 404 NOT_FOUND
11. On any other exception, return 500 INTERNAL_SERVER_ERROR

**handleGet (GET)**
1. Extract printerID from request URI attributes
2. Set MDC device ID for logging
3. Retrieve active printer by printerID via PrinterManager
4. If printer not found, return 404 NOT_FOUND
5. Create PrinterEmailAddress object
6. Call printer.getPrinterActiveEmailAddress() to get friendly email if exists, otherwise cryptic
7. Set email address value and log to MDC
8. Set version from OffRampAPIConfig
9. Marshal to XML and return as StringRepresentation with 200 OK
10. On DeviceNotFoundExcpeption, return 404 NOT_FOUND
11. On any other exception, return 500 INTERNAL_SERVER_ERROR

# Business rules

• If printer does not exist, return 404 NOT_FOUND.
• If email address is invalid during generation, return 400 BAD_REQUEST.
• POST generates a new cryptic email address for the printer.
• GET returns the friendly email address if it exists; otherwise returns the cryptic email address.
• Only POST and GET methods are allowed; PUT and DELETE return 405 METHOD_NOT_ALLOWED.
