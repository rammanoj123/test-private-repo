---
type: Component
title: EmailAddressResource
description: Controller `EmailAddressResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\EmailAddressResource.java
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

`com.hp.cloudprint.api.offramp.resources.EmailAddressResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#POST") |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/EmailAddress#GET") |
| emailAddress | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | PrinterManager printerManager |  |
| EmailAddressResource |  |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowGet | boolean |  |  |
| allowOptions | boolean |  |  |
| acceptRepresentation | void | Representation entity |  |
| handleGet | void |  |  |
| getOffRampVersion | String |  |  |

# Depends on

* `PrinterManager`
