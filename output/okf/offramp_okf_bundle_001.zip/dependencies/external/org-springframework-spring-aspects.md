---
type: Dependency
title: org.springframework:spring-aspects
description: Spring Aspects module for AspectJ-based aspects.
resource: https://central.sonatype.com/artifact/org.springframework/spring-aspects
tags: [dependency, external]
status: stable
artifact_id: spring-aspects
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-aspects:${spring.framework.version}`.


# Used by

Used for AspectJ-based transaction management and domain object dependency injection.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides AspectJ-based aspects for advanced AOP scenarios including load-time weaving.
