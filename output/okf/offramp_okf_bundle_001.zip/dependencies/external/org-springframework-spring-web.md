---
type: Dependency
title: org.springframework:spring-web
description: Spring Web module for web application support.
resource: https://central.sonatype.com/artifact/org.springframework/spring-web
tags: [dependency, external]
status: stable
artifact_id: spring-web
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-web:${spring.framework.version}`.


# Used by

Foundation for web layer including REST resources and servlet integration configured in `web.xml`.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides web application context, multipart file upload, and HTTP client support for Spring web applications.
