---
type: Dependency
title: org.apache.httpcomponents:httpclient
description: Third-party dependency `org.apache.httpcomponents:httpclient:4.5.13` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.apache.httpcomponents/httpclient
tags: [dependency, external]
status: draft
artifact_id: httpclient
group_id: org.apache.httpcomponents
scope: compile
version: 4.5.13
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `org.apache.httpcomponents:httpclient:4.5.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
