---
type: Dependency
title: org.apache.httpcomponents:httpclient
description: Apache HttpClient library for HTTP protocol support and client operations.
resource: https://central.sonatype.com/artifact/org.apache.httpcomponents/httpclient
tags: [dependency, external]
status: stable
artifact_id: httpclient
group_id: org.apache.httpcomponents
scope: compile
version: 4.5.13
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.apache.httpcomponents:httpclient:4.5.13`.


# Used by

Used by [StratusClientImpl](/components/clients/StratusClientImpl.md) and other HTTP clients for making outbound HTTP calls to dependent services.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides robust HTTP client implementation with connection pooling, authentication, and advanced HTTP protocol features.
