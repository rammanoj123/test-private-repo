---
type: Dependency
title: com.sun.jersey.contribs:jersey-multipart
description: Jersey extension for handling multipart/form-data requests.
resource: https://central.sonatype.com/artifact/com.sun.jersey.contribs/jersey-multipart
tags: [dependency, external]
status: stable
artifact_id: jersey-multipart
group_id: com.sun.jersey.contribs
scope: compile
version: "1.10"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.sun.jersey.contribs:jersey-multipart:1.10`.


# Used by

Used by [DeviceUploadResource](/components/resources/DeviceUploadResource.md) for handling printer device capability uploads and document uploads.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides multipart MIME support for handling file uploads and multipart form data in Jersey REST services.
