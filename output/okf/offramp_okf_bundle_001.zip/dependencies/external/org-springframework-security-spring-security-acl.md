---
type: Dependency
title: org.springframework.security:spring-security-acl
description: Spring Security ACL module for access control list support.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-acl
tags: [dependency, external]
status: stable
artifact_id: spring-security-acl
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework.security:spring-security-acl:${springframework.security.version}`.


# Used by

Used by ACL voters including [PrinterFilterAclEntryVoter](/components/security/PrinterFilterAclEntryVoter.md), [SessionSecretFilterAclEntryVoter](/components/security/SessionSecretFilterAclEntryVoter.md), and [TempTokenAuthorizationFilterAclEntryVoter](/components/security/TempTokenAuthorizationFilterAclEntryVoter.md).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides domain object security with fine-grained access control lists for resource-level authorization.
