---
type: Dependency
title: ch.qos.logback:logback-core
description: Core Logback module providing foundational logging infrastructure.
resource: https://central.sonatype.com/artifact/ch.qos.logback/logback-core
tags: [dependency, external]
status: stable
artifact_id: logback-core
group_id: ch.qos.logback
scope: compile
version: 1.5.18
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `ch.qos.logback:logback-core:1.5.18`.


# Used by

Transitive dependency through logback-classic, providing the underlying logging framework infrastructure.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Core logging infrastructure for Logback, providing appenders, layouts, and encoders.
