---
type: Dependency
title: org.springframework:spring-jdbc
description: Spring JDBC module for JDBC data access support.
resource: https://central.sonatype.com/artifact/org.springframework/spring-jdbc
tags: [dependency, external]
status: stable
artifact_id: spring-jdbc
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-jdbc:${spring.framework.version}`.


# Used by

Used for database access operations with simplified JDBC handling and transaction management.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides JDBC abstraction layer with JdbcTemplate, exception translation, and transaction support.
