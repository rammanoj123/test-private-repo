---
type: Dependency
title: org.springframework.security.oauth:spring-security-oauth
description: Third-party dependency `org.springframework.security.oauth:spring-security-oauth:1.0.5.RELEASE` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.springframework.security.oauth/spring-security-oauth
tags: [dependency, external]
status: draft
artifact_id: spring-security-oauth
group_id: org.springframework.security.oauth
scope: compile
version: 1.0.5.RELEASE
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `org.springframework.security.oauth:spring-security-oauth:1.0.5.RELEASE`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
