---
type: Dependency
title: org.springframework.security.oauth:spring-security-oauth
description: Spring Security OAuth module for OAuth 1.0 authentication and authorization.
resource: https://central.sonatype.com/artifact/org.springframework.security.oauth/spring-security-oauth
tags: [dependency, external]
status: stable
artifact_id: spring-security-oauth
group_id: org.springframework.security.oauth
scope: compile
version: 1.0.5.RELEASE
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework.security.oauth:spring-security-oauth:1.0.5.RELEASE`.


# Used by

Used by [UserAuthorizationTokenServices](/components/security/UserAuthorizationTokenServices.md) and OAuth security configuration for printer authentication and authorization.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides OAuth 1.0 protocol support for securing REST APIs with token-based authentication.
