---
type: Dependency
title: commons-cli:commons-cli
description: Apache Commons CLI library for command-line argument parsing.
resource: https://central.sonatype.com/artifact/commons-cli/commons-cli
tags: [dependency, external]
status: stable
artifact_id: commons-cli
group_id: commons-cli
scope: compile
version: "1.2"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `commons-cli:commons-cli:1.2`.


# Used by

Used for parsing command-line arguments in utility classes and standalone tools.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides command-line option parsing for Java applications with support for POSIX-style options.
