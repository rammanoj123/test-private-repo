---
type: Dependency
title: org.mockito:mockito-all
description: Mockito mocking framework for unit testing.
resource: https://central.sonatype.com/artifact/org.mockito/mockito-all
tags: [dependency, external]
status: stable
artifact_id: mockito-all
group_id: org.mockito
scope: test
version: 1.9.5
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.mockito:mockito-all:1.9.5`.


# Used by

Primary mocking framework used across test classes for creating mocks and stubs (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides behavior-driven mock object creation and verification for unit testing with clean syntax.
