---
type: Dependency
title: org.mockito:mockito-all
description: Third-party dependency `org.mockito:mockito-all:1.9.5` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.mockito/mockito-all
tags: [dependency, external]
status: draft
artifact_id: mockito-all
group_id: org.mockito
scope: test
version: 1.9.5
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `org.mockito:mockito-all:1.9.5`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
