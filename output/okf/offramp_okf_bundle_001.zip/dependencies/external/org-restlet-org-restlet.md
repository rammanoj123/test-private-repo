---
type: Dependency
title: org.restlet:org.restlet
description: Restlet framework core for building RESTful web services.
resource: https://central.sonatype.com/artifact/org.restlet/org.restlet
tags: [dependency, external]
status: stable
artifact_id: org.restlet
group_id: org.restlet
scope: compile
version: 1.1.6
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.restlet:org.restlet:1.1.6`.


# Used by

Alternative/complementary REST framework used alongside Noelios Restlet implementation for REST API endpoints.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Core Restlet framework providing REST resource abstractions, routing, and HTTP protocol support.
