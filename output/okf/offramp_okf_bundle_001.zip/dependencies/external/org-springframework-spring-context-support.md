---
type: Dependency
title: org.springframework:spring-context-support
description: Spring Context Support module for integration with third-party libraries.
resource: https://central.sonatype.com/artifact/org.springframework/spring-context-support
tags: [dependency, external]
status: stable
artifact_id: spring-context-support
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-context-support:${spring.framework.version}`.


# Used by

Used for Ehcache integration via [OfframpCacheProvider](/components/cache/OfframpCacheProvider.md) and scheduling support.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides integration classes for third-party libraries including caching, scheduling, and mail support.
