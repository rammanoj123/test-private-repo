---
type: Dependency
title: com.noelios.restlet:com.noelios.restlet
description: Restlet framework core implementation for building RESTful web services.
resource: https://central.sonatype.com/artifact/com.noelios.restlet/com.noelios.restlet
tags: [dependency, external]
status: stable
artifact_id: com.noelios.restlet
group_id: com.noelios.restlet
scope: compile
version: 1.1.6
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.noelios.restlet:com.noelios.restlet:1.1.6`.


# Used by

Foundation for REST API resources including [PrinterResource](/components/resources/PrinterResource.md), [ClaimCodeResource](/components/resources/ClaimCodeResource.md), and other API endpoints.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Core Restlet framework providing REST resource handling, routing, and HTTP protocol support for building RESTful APIs.
