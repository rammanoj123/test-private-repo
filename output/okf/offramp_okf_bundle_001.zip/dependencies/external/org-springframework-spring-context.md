---
type: Dependency
title: org.springframework:spring-context
description: Spring Context module for application context and enterprise services.
resource: https://central.sonatype.com/artifact/org.springframework/spring-context
tags: [dependency, external]
status: stable
artifact_id: spring-context
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-context:${spring.framework.version}`.


# Used by

Core Spring infrastructure used in `applicationContext.xml` and other context files for application lifecycle management.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides application context, event propagation, resource loading, and enterprise services like scheduling and caching.
