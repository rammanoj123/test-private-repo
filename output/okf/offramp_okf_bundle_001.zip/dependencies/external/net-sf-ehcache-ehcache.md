---
type: Dependency
title: net.sf.ehcache:ehcache
description: Ehcache distributed caching library for application-level caching.
resource: https://central.sonatype.com/artifact/net.sf.ehcache/ehcache
tags: [dependency, external]
status: stable
artifact_id: ehcache
group_id: net.sf.ehcache
scope: compile
version: 1.3.0
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `net.sf.ehcache:ehcache:1.3.0`.


# Used by

Used by [OfframpCacheProvider](/components/cache/OfframpCacheProvider.md) and [CacheClientMonitor](/components/monitoring/CacheClientMonitor.md) for caching printer state, configurations, and session data.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides in-memory and distributed caching with features like TTL, eviction policies, and cache statistics.
