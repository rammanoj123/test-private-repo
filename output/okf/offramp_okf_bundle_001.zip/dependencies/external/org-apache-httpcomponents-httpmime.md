---
type: Dependency
title: org.apache.httpcomponents:httpmime
description: Apache HttpMime library for MIME multipart message support.
resource: https://central.sonatype.com/artifact/org.apache.httpcomponents/httpmime
tags: [dependency, external]
status: stable
artifact_id: httpmime
group_id: org.apache.httpcomponents
scope: compile
version: "4.0"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.apache.httpcomponents:httpmime:4.0`.


# Used by

Used for handling multipart HTTP requests in file upload scenarios and document processing.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides MIME multipart message handling for HTTP requests, enabling file uploads and multipart form data.
