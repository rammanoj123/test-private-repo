---
type: Dependency
title: com.sun.jersey:jersey-client
description: Jersey JAX-RS client library for building REST clients.
resource: https://central.sonatype.com/artifact/com.sun.jersey/jersey-client
tags: [dependency, external]
status: stable
artifact_id: jersey-client
group_id: com.sun.jersey
scope: compile
version: "1.10"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.sun.jersey:jersey-client:1.10`.


# Used by

Used by [StratusClientImpl](/components/clients/StratusClientImpl.md) and other service clients for outbound REST API calls to dependent services.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides JAX-RS client API implementation for making HTTP REST calls to external services.
