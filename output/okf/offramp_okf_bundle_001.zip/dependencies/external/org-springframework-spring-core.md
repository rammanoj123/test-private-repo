---
type: Dependency
title: org.springframework:spring-core
description: Spring Core module providing fundamental Spring Framework utilities.
resource: https://central.sonatype.com/artifact/org.springframework/spring-core
tags: [dependency, external]
status: stable
artifact_id: spring-core
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-core:${spring.framework.version}`.


# Used by

Foundation for all Spring modules, providing core utilities used throughout the application.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides core utilities including type conversion, resource loading, and fundamental abstractions for the Spring Framework.
