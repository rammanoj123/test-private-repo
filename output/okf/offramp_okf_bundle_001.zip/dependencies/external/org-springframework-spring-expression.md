---
type: Dependency
title: org.springframework:spring-expression
description: Spring Expression Language (SpEL) module for runtime expression evaluation.
resource: https://central.sonatype.com/artifact/org.springframework/spring-expression
tags: [dependency, external]
status: stable
artifact_id: spring-expression
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-expression:${spring.framework.version}`.


# Used by

Used in Spring configuration for dynamic property resolution and conditional bean definitions.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides Spring Expression Language for querying and manipulating object graphs at runtime.
