---
type: Dependency
title: org.apache.httpcomponents:httpcore
description: Apache HttpCore library providing low-level HTTP transport components.
resource: https://central.sonatype.com/artifact/org.apache.httpcomponents/httpcore
tags: [dependency, external]
status: stable
artifact_id: httpcore
group_id: org.apache.httpcomponents
scope: compile
version: 4.4.13
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.apache.httpcomponents:httpcore:4.4.13`.


# Used by

Transitive dependency through httpclient, providing the underlying HTTP protocol implementation.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides low-level HTTP transport abstractions including connection management, I/O reactors, and protocol handlers.
