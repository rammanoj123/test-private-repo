---
type: Dependency
title: org.springframework.security:spring-security-web
description: Spring Security web module for web application security.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-web
tags: [dependency, external]
status: stable
artifact_id: spring-security-web
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework.security:spring-security-web:${springframework.security.version}`.


# Used by

Used by [CustomUserAuthorizationProcessingFilter](/components/security/CustomUserAuthorizationProcessingFilter.md), [OfframpAuthenticationEntryPoint](/components/security/OfframpAuthenticationEntryPoint.md), and [RegistrationAuthenticationEntryPoint](/components/security/RegistrationAuthenticationEntryPoint.md).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides web security filters, authentication entry points, and session management for securing web applications.
