---
type: Dependency
title: com.sun.jersey:jersey-core
description: Jersey core JAX-RS implementation providing REST framework foundation.
resource: https://central.sonatype.com/artifact/com.sun.jersey/jersey-core
tags: [dependency, external]
status: stable
artifact_id: jersey-core
group_id: com.sun.jersey
scope: compile
version: "1.10"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.sun.jersey:jersey-core:1.10`.


# Used by

Foundation for Jersey-based components including multipart handling and client libraries.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Core Jersey JAX-RS implementation providing annotations, providers, and runtime for building RESTful web services.
