---
type: Dependency
title: org.testng:testng
description: Third-party dependency `org.testng:testng:5.14` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.testng/testng
tags: [dependency, external]
status: draft
artifact_id: testng
group_id: org.testng
scope: test
version: "5.14"
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `org.testng:testng:5.14`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
