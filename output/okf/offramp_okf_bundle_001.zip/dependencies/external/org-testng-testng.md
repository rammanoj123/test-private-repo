---
type: Dependency
title: org.testng:testng
description: TestNG testing framework for test automation.
resource: https://central.sonatype.com/artifact/org.testng/testng
tags: [dependency, external]
status: stable
artifact_id: testng
group_id: org.testng
scope: test
version: "5.14"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.testng:testng:5.14`.


# Used by

Primary testing framework used across all test classes including resource tests, service tests, and integration tests (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides testing framework with annotations, data providers, and parallel execution for comprehensive test automation.
