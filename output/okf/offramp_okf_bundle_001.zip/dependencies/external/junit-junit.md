---
type: Dependency
title: junit:junit
description: JUnit testing framework for unit testing.
resource: https://central.sonatype.com/artifact/junit/junit
tags: [dependency, external]
status: stable
artifact_id: junit
group_id: junit
scope: provided
version: "4.4"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `junit:junit:4.4`.


# Used by

Used across test classes for unit testing components, though TestNG is the primary testing framework (scope: provided).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides unit testing framework with assertions, test runners, and annotations for Java testing.
