---
type: Dependency
title: junit:junit
description: Third-party dependency `junit:junit:4.4` (pending enrichment).
resource: https://central.sonatype.com/artifact/junit/junit
tags: [dependency, external]
status: draft
artifact_id: junit
group_id: junit
scope: provided
version: "4.4"
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `junit:junit:4.4`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
