---
type: Dependency
title: ch.qos.logback:logback-classic
description: Logback Classic module providing SLF4J implementation for logging.
resource: https://central.sonatype.com/artifact/ch.qos.logback/logback-classic
tags: [dependency, external]
status: stable
artifact_id: logback-classic
group_id: ch.qos.logback
scope: compile
version: 1.5.18
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `ch.qos.logback:logback-classic:1.5.18`.


# Used by

Used throughout the offramp service for application logging. The service configures logback via `logback.xml` for structured logging output.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides the classic SLF4J logging implementation with advanced features like conditional processing, filters, and appenders.
