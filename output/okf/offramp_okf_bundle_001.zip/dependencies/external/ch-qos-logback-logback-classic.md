---
type: Dependency
title: ch.qos.logback:logback-classic
description: Third-party dependency `ch.qos.logback:logback-classic:1.5.18` (pending enrichment).
resource: https://central.sonatype.com/artifact/ch.qos.logback/logback-classic
tags: [dependency, external]
status: draft
artifact_id: logback-classic
group_id: ch.qos.logback
scope: compile
version: 1.5.18
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `ch.qos.logback:logback-classic:1.5.18`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
