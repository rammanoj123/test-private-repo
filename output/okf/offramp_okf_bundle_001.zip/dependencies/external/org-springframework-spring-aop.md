---
type: Dependency
title: org.springframework:spring-aop
description: Spring AOP module for aspect-oriented programming support.
resource: https://central.sonatype.com/artifact/org.springframework/spring-aop
tags: [dependency, external]
status: stable
artifact_id: spring-aop
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-aop:${spring.framework.version}`.


# Used by

Used throughout the application for declarative transaction management and security aspects.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides AOP framework for cross-cutting concerns like transaction management, security, and logging.
