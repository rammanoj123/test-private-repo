---
type: Dependency
title: com.noelios.restlet:com.noelios.restlet.ext.servlet
description: Restlet servlet extension for integrating Restlet with servlet containers.
resource: https://central.sonatype.com/artifact/com.noelios.restlet/com.noelios.restlet.ext.servlet
tags: [dependency, external]
status: stable
artifact_id: com.noelios.restlet.ext.servlet
group_id: com.noelios.restlet
scope: compile
version: 1.1.6
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.noelios.restlet:com.noelios.restlet.ext.servlet:1.1.6`.


# Used by

Configured in `web.xml` to integrate Restlet-based REST resources with the servlet container.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Bridges Restlet framework with servlet containers, enabling deployment of Restlet applications in standard Java EE servlet environments.
