---
type: Dependency
title: org.springframework:spring-tx
description: Spring Transaction module for declarative transaction management.
resource: https://central.sonatype.com/artifact/org.springframework/spring-tx
tags: [dependency, external]
status: stable
artifact_id: spring-tx
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-tx:${spring.framework.version}`.


# Used by

Used throughout the application for @Transactional annotations and programmatic transaction management.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides declarative transaction management with support for JTA, JDBC, Hibernate, and JPA transactions.
