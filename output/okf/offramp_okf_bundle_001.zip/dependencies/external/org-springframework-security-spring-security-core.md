---
type: Dependency
title: org.springframework.security:spring-security-core
description: Spring Security core module providing authentication and authorization infrastructure.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-core
tags: [dependency, external]
status: stable
artifact_id: spring-security-core
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework.security:spring-security-core:${springframework.security.version}`.


# Used by

Foundation for all security components including [PrinterUserDetailsService](/components/security/PrinterUserDetailsService.md), [RegistrationAuthenticationProvider](/components/security/RegistrationAuthenticationProvider.md), and custom authentication filters.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Core Spring Security framework providing authentication, authorization, and security context management.
