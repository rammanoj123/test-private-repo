---
type: Dependency
title: org.easymock:easymock
description: Third-party dependency `org.easymock:easymock:3.0` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.easymock/easymock
tags: [dependency, external]
status: draft
artifact_id: easymock
group_id: org.easymock
scope: test
version: "3.0"
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `org.easymock:easymock:3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
