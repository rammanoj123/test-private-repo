---
type: Dependency
title: org.easymock:easymock
description: EasyMock mocking framework for unit testing.
resource: https://central.sonatype.com/artifact/org.easymock/easymock
tags: [dependency, external]
status: stable
artifact_id: easymock
group_id: org.easymock
scope: test
version: "3.0"
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.easymock:easymock:3.0`.


# Used by

Used in test classes for creating mock objects and verifying interactions (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides mock object generation for unit testing with record-replay style mocking.
