---
type: Dependency
title: com.mchange:c3p0
description: JDBC connection pooling library for database connection management.
resource: https://central.sonatype.com/artifact/com.mchange/c3p0
tags: [dependency, external]
status: stable
artifact_id: c3p0
group_id: com.mchange
scope: compile
version: 0.9.5.5
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.mchange:c3p0:0.9.5.5`.


# Used by

Configured in Spring application contexts for database connection pooling to backend data stores.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides JDBC connection pooling to efficiently manage database connections with features like connection testing, statement caching, and automatic recovery.
