---
type: Dependency
title: org.springframework:spring-beans
description: Spring Beans module for bean factory and dependency injection.
resource: https://central.sonatype.com/artifact/org.springframework/spring-beans
tags: [dependency, external]
status: stable
artifact_id: spring-beans
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-beans:${spring.framework.version}`.


# Used by

Foundation for Spring DI used throughout the application for bean wiring in all Spring configuration files.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides bean factory and dependency injection container for managing application objects and their dependencies.
