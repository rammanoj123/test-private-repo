---
type: Dependency
title: com.noelios.restlet:com.noelios.restlet.ext.spring
description: Restlet Spring extension for Spring Framework integration.
resource: https://central.sonatype.com/artifact/com.noelios.restlet/com.noelios.restlet.ext.spring
tags: [dependency, external]
status: stable
artifact_id: com.noelios.restlet.ext.spring
group_id: com.noelios.restlet
scope: compile
version: 1.1.6
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6`.


# Used by

Configured in `RestletSpring-servlet.xml` to wire Restlet resources with Spring beans and enable DI for REST endpoints.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Integrates Restlet framework with Spring, enabling dependency injection and Spring-managed Restlet resources.
