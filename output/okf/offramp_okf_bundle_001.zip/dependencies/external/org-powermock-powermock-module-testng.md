---
type: Dependency
title: org.powermock:powermock-module-testng
description: PowerMock TestNG module for integrating PowerMock with TestNG.
resource: https://central.sonatype.com/artifact/org.powermock/powermock-module-testng
tags: [dependency, external]
status: stable
artifact_id: powermock-module-testng
group_id: org.powermock
scope: test
version: ${powermock.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.powermock:powermock-module-testng:${powermock.version}`.


# Used by

Used in TestNG-based test classes requiring PowerMock features (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Integrates PowerMock capabilities with TestNG test runner for advanced mocking in TestNG tests.
