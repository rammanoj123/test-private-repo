---
type: Dependency
title: org.powermock:powermock-api-mockito
description: PowerMock Mockito API for mocking static methods and constructors.
resource: https://central.sonatype.com/artifact/org.powermock/powermock-api-mockito
tags: [dependency, external]
status: stable
artifact_id: powermock-api-mockito
group_id: org.powermock
scope: test
version: ${powermock.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.powermock:powermock-api-mockito:${powermock.version}`.


# Used by

Used in test classes requiring static method mocking or final class testing (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Extends Mockito to enable mocking of static methods, constructors, and final classes for advanced testing scenarios.
