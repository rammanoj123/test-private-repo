# Third-party dependencies

# Concepts

* [ch.qos.logback:logback-classic](ch-qos-logback-logback-classic.md) - Third-party dependency `ch.qos.logback:logback-classic:1.5.18` (pending enrichment).
* [ch.qos.logback:logback-core](ch-qos-logback-logback-core.md) - Third-party dependency `ch.qos.logback:logback-core:1.5.18` (pending enrichment).
* [com.mchange:c3p0](com-mchange-c3p0.md) - Third-party dependency `com.mchange:c3p0:0.9.5.5` (pending enrichment).
* [com.noelios.restlet:com.noelios.restlet](com-noelios-restlet-com-noelios-restlet.md) - Third-party dependency `com.noelios.restlet:com.noelios.restlet:1.1.6` (pending enrichment).
* [com.noelios.restlet:com.noelios.restlet.ext.servlet](com-noelios-restlet-com-noelios-restlet-ext-servlet.md) - Third-party dependency `com.noelios.restlet:com.noelios.restlet.ext.servlet:1.1.6` (pending enrichment).
* [com.noelios.restlet:com.noelios.restlet.ext.spring](com-noelios-restlet-com-noelios-restlet-ext-spring.md) - Third-party dependency `com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6` (pending enrichment).
* [com.sun.jersey.contribs:jersey-multipart](com-sun-jersey-contribs-jersey-multipart.md) - Third-party dependency `com.sun.jersey.contribs:jersey-multipart:1.10` (pending enrichment).
* [com.sun.jersey:jersey-client](com-sun-jersey-jersey-client.md) - Third-party dependency `com.sun.jersey:jersey-client:1.10` (pending enrichment).
* [com.sun.jersey:jersey-core](com-sun-jersey-jersey-core.md) - Third-party dependency `com.sun.jersey:jersey-core:1.10` (pending enrichment).
* [commons-cli:commons-cli](commons-cli-commons-cli.md) - Third-party dependency `commons-cli:commons-cli:1.2` (pending enrichment).
* [junit:junit](junit-junit.md) - Third-party dependency `junit:junit:4.4` (pending enrichment).
* [net.sf.ehcache:ehcache](net-sf-ehcache-ehcache.md) - Third-party dependency `net.sf.ehcache:ehcache:1.3.0` (pending enrichment).
* [org.apache.httpcomponents:httpclient](org-apache-httpcomponents-httpclient.md) - Third-party dependency `org.apache.httpcomponents:httpclient:4.5.13` (pending enrichment).
* [org.apache.httpcomponents:httpcore](org-apache-httpcomponents-httpcore.md) - Third-party dependency `org.apache.httpcomponents:httpcore:4.4.13` (pending enrichment).
* [org.apache.httpcomponents:httpmime](org-apache-httpcomponents-httpmime.md) - Third-party dependency `org.apache.httpcomponents:httpmime:4.0` (pending enrichment).
* [org.easymock:easymock](org-easymock-easymock.md) - Third-party dependency `org.easymock:easymock:3.0` (pending enrichment).
* [org.mockito:mockito-all](org-mockito-mockito-all.md) - Third-party dependency `org.mockito:mockito-all:1.9.5` (pending enrichment).
* [org.powermock:powermock-api-mockito](org-powermock-powermock-api-mockito.md) - Third-party dependency `org.powermock:powermock-api-mockito:${powermock.version}` (pending enrichment).
* [org.powermock:powermock-module-testng](org-powermock-powermock-module-testng.md) - Third-party dependency `org.powermock:powermock-module-testng:${powermock.version}` (pending enrichment).
* [org.restlet:org.restlet](org-restlet-org-restlet.md) - Third-party dependency `org.restlet:org.restlet:1.1.6` (pending enrichment).
* [org.restlet:org.restlet.ext.spring](org-restlet-org-restlet-ext-spring.md) - Third-party dependency `org.restlet:org.restlet.ext.spring:1.1.6` (pending enrichment).
* [org.springframework.security.oauth:spring-security-oauth](org-springframework-security-oauth-spring-security-oauth.md) - Third-party dependency `org.springframework.security.oauth:spring-security-oauth:1.0.5.RELEASE` (pending enrichment).
* [org.springframework.security:spring-security-acl](org-springframework-security-spring-security-acl.md) - Third-party dependency `org.springframework.security:spring-security-acl:${springframework.security.version}` (pending enrichment).
* [org.springframework.security:spring-security-config](org-springframework-security-spring-security-config.md) - Third-party dependency `org.springframework.security:spring-security-config:${springframework.security.version}` (pending enrichment).
* [org.springframework.security:spring-security-core](org-springframework-security-spring-security-core.md) - Third-party dependency `org.springframework.security:spring-security-core:${springframework.security.version}` (pending enrichment).
* [org.springframework.security:spring-security-web](org-springframework-security-spring-security-web.md) - Third-party dependency `org.springframework.security:spring-security-web:${springframework.security.version}` (pending enrichment).
* [org.springframework:spring-aop](org-springframework-spring-aop.md) - Third-party dependency `org.springframework:spring-aop:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-aspects](org-springframework-spring-aspects.md) - Third-party dependency `org.springframework:spring-aspects:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-beans](org-springframework-spring-beans.md) - Third-party dependency `org.springframework:spring-beans:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-context](org-springframework-spring-context.md) - Third-party dependency `org.springframework:spring-context:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-context-support](org-springframework-spring-context-support.md) - Third-party dependency `org.springframework:spring-context-support:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-core](org-springframework-spring-core.md) - Third-party dependency `org.springframework:spring-core:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-expression](org-springframework-spring-expression.md) - Third-party dependency `org.springframework:spring-expression:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-jdbc](org-springframework-spring-jdbc.md) - Third-party dependency `org.springframework:spring-jdbc:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-orm](org-springframework-spring-orm.md) - Third-party dependency `org.springframework:spring-orm:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-test](org-springframework-spring-test.md) - Third-party dependency `org.springframework:spring-test:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-tx](org-springframework-spring-tx.md) - Third-party dependency `org.springframework:spring-tx:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-web](org-springframework-spring-web.md) - Third-party dependency `org.springframework:spring-web:${spring.framework.version}` (pending enrichment).
* [org.springframework:spring-webmvc](org-springframework-spring-webmvc.md) - Third-party dependency `org.springframework:spring-webmvc:${spring.framework.version}` (pending enrichment).
* [org.testng:testng](org-testng-testng.md) - Third-party dependency `org.testng:testng:5.14` (pending enrichment).
