---
type: Dependency
title: org.springframework:spring-orm
description: Spring ORM module for object-relational mapping integration.
resource: https://central.sonatype.com/artifact/org.springframework/spring-orm
tags: [dependency, external]
status: stable
artifact_id: spring-orm
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-orm:${spring.framework.version}`.


# Used by

Used for ORM integration and entity management in data access layers.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides integration with ORM frameworks like Hibernate and JPA for object-relational mapping.
