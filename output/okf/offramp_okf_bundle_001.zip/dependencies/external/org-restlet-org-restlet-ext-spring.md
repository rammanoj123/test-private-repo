---
type: Dependency
title: org.restlet:org.restlet.ext.spring
description: Restlet Spring extension for Spring Framework integration.
resource: https://central.sonatype.com/artifact/org.restlet/org.restlet.ext.spring
tags: [dependency, external]
status: stable
artifact_id: org.restlet.ext.spring
group_id: org.restlet
scope: compile
version: 1.1.6
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.restlet:org.restlet.ext.spring:1.1.6`.


# Used by

Provides Spring integration for Restlet-based REST resources, complementing the Noelios Restlet Spring extension.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Integrates Restlet framework with Spring for dependency injection and Spring-managed Restlet resources.
