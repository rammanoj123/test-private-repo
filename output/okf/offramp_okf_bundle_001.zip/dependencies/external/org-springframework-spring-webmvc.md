---
type: Dependency
title: org.springframework:spring-webmvc
description: Spring Web MVC module for Model-View-Controller web applications.
resource: https://central.sonatype.com/artifact/org.springframework/spring-webmvc
tags: [dependency, external]
status: stable
artifact_id: spring-webmvc
group_id: org.springframework
scope: compile
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-webmvc:${spring.framework.version}`.


# Used by

Used for MVC infrastructure and servlet configuration in `RestletSpring-servlet.xml`.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides Spring MVC framework for building web applications with controllers, view resolvers, and handler mappings.
