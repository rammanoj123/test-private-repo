---
type: Dependency
title: org.springframework.security:spring-security-config
description: Spring Security configuration module for XML and Java-based security configuration.
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-config
tags: [dependency, external]
status: stable
artifact_id: spring-security-config
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework.security:spring-security-config:${springframework.security.version}`.


# Used by

Configured in `applicationContext-security.xml` to define authentication providers, filters, and security rules.

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides namespace handlers and configuration support for declarative Spring Security setup.
