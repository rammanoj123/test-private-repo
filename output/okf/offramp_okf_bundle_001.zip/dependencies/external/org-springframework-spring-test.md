---
type: Dependency
title: org.springframework:spring-test
description: Spring Test module for testing Spring applications.
resource: https://central.sonatype.com/artifact/org.springframework/spring-test
tags: [dependency, external]
status: stable
artifact_id: spring-test
group_id: org.springframework
scope: test
version: ${spring.framework.version}
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

Maven coordinate: `org.springframework:spring-test:${spring.framework.version}`.


# Used by

Used across test classes for Spring context integration testing with TestNG (scope: test).

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.

# Purpose

Provides testing support for Spring applications including context caching, mock objects, and test annotations.
