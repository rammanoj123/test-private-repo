# Internal / custom libraries

# Concepts

* [channelinterfaces](channelinterfaces.md) - Custom/org library `com.hp.cloudprint:channelinterfaces:25.1.4` (pending enrichment).
* [cjputil](cjputil.md) - Custom/org library `com.hp.cloudprint:cjputil:25.1.4` (pending enrichment).
* [devicecapabilities](devicecapabilities.md) - Custom/org library `com.hp.cloudprint:devicecapabilities:25.1.7` (pending enrichment).
* [entities](entities.md) - Custom/org library `com.hp.cloudprint:entities:25.4.1` (pending enrichment).
* [eprintDirectory](eprintdirectory.md) - Custom/org library `com.hp.cloudprint:eprintDirectory:25.1.6` (pending enrichment).
* [ePrintLogger](eprintlogger.md) - Custom/org library `com.hp.cloudprint:ePrintLogger:25.1.4` (pending enrichment).
* [eprintUserDirectory](eprintuserdirectory.md) - Custom/org library `com.hp.cloudprint:eprintUserDirectory:25.1.4` (pending enrichment).
* [jefapi](jefapi.md) - Custom/org library `com.hp.cloudprint:jefapi:25.1.13` (pending enrichment).
* [metrics](metrics.md) - Custom/org library `com.hp.cloudprint:metrics:25.1.4` (pending enrichment).
* [notification-client](notification-client.md) - Custom/org library `com.hp.cloudprint:notification-client:25.2.4` (pending enrichment).
* [notification-common](notification-common.md) - Custom/org library `com.hp.cloudprint:notification-common:25.2.3` (pending enrichment).
* [pjpcommon](pjpcommon.md) - Custom/org library `com.hp.cloudprint:pjpcommon:25.1.10` (pending enrichment).
* [pjpservices](pjpservices.md) - Custom/org library `com.hp.cloudprint:pjpservices:25.1.10` (pending enrichment).
* [pjpworkstepsutil](pjpworkstepsutil.md) - Custom/org library `com.hp.cloudprint:pjpworkstepsutil:25.1.10` (pending enrichment).
* [printer](printer.md) - Custom/org library `com.hp.cloudprint:printer:25.1.10` (pending enrichment).
* [security](security.md) - Custom/org library `com.hp.cloudprint:security:25.1.4` (pending enrichment).
* [sjpservices](sjpservices.md) - Custom/org library `com.hp.cloudprint:sjpservices:25.1.10` (pending enrichment).
* [snoobe-client](snoobe-client.md) - Custom/org library `com.hp.cloudprint:snoobe-client:25.1.4` (pending enrichment).
* [util](util.md) - Custom/org library `com.hp.cloudprint:util:25.1.4` (pending enrichment).
* [wp-common](wp-common.md) - Custom/org library `com.hp.iws.wpp:wp-common:${wpp-version}` (pending enrichment).
* [wp-common-web](wp-common-web.md) - Custom/org library `com.hp.iws.wpp:wp-common-web:${wpp-version}` (pending enrichment).
* [wp-simplecache-client](wp-simplecache-client.md) - Custom/org library `com.hp.iws.wpp:wp-simplecache-client:${simplecache-client-version}` (pending enrichment).
* [wpp-base-schema](wpp-base-schema.md) - Custom/org library `com.hp.iws.wpp:wpp-base-schema:${wpp-version}` (pending enrichment).
* [wpp-json-logging-adaptor](wpp-json-logging-adaptor.md) - Custom/org library `com.hp.wpp:wpp-json-logging-adaptor:1.0.13` (pending enrichment).
* [wpp-logger](wpp-logger.md) - Custom/org library `com.hp.wpp:wpp-logger:2.2.14` (pending enrichment).
