---
type: Internal Library
title: wpp-logger
description: Custom/org library `com.hp.wpp:wpp-logger:2.2.14` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: wpp-logger
depends_on_bundle: hp/wpp-logger
group_id: com.hp.wpp
scope: compile
version: 2.2.14
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `com.hp.wpp:wpp-logger:2.2.14`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wpp-logger`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
