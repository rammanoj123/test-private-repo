---
type: Internal Library
title: wp-simplecache-client
description: Custom/org library `com.hp.iws.wpp:wp-simplecache-client:${simplecache-client-version}` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: wp-simplecache-client
depends_on_bundle: hp/wp-simplecache-client
group_id: com.hp.iws.wpp
scope: compile
version: ${simplecache-client-version}
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `com.hp.iws.wpp:wp-simplecache-client:${simplecache-client-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wp-simplecache-client`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
