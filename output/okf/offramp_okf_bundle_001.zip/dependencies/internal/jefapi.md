---
type: Internal Library
title: jefapi
description: Custom/org library `com.hp.cloudprint:jefapi:25.1.13` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: jefapi
depends_on_bundle: hp/jefapi
group_id: com.hp.cloudprint
scope: compile
version: 25.1.13
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Maven coordinate: `com.hp.cloudprint:jefapi:25.1.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/jefapi`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
