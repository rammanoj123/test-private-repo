---
okf_version: "0.2"
---

# offramp

# Concepts

* [offramp](service.md) - Spring service hp/offramp; entry point for the OKF bundle.

# Subdirectories

* [api/](api/) - API surface
* [architecture/](architecture/) - Architecture
* [components/](components/) - Spring components
* [config/](config/) - Configuration
* [dependencies/](dependencies/) - Dependencies & ecosystem
* [ecosystem/](ecosystem/) - Ecosystem registry
* [playbooks/](playbooks/) - Playbooks
* [references/](references/) - References
* [usecases/](usecases/) - Use cases
