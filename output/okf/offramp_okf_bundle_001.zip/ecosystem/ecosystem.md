---
type: System
title: Ecosystem & dependency registry
description: "Federation registry: this service plus every library and service it depends on."
tags: [ecosystem, registry, dependencies]
status: stable
okf_bundle_id: hp/offramp
generated: { by: dependency_ecosystem_enricher/1.0, at: 2026-09-13T14:30:00Z }
---

The registry of every bundle this service knows about. It is the spine of the federation: each internal library and dependent service is a concept here, and as each one is itself documented in OKF, its `okf_ref` is filled in and consumers can traverse the whole graph across bundles.


# Bundles

| Coordinate / name | Kind | Bundle id | Concept | Own bundle documented? |
| --- | --- | --- | --- | --- |
| **this** | Service | hp/offramp | [service.md](/service.md) | yes |
| com.hp.cloudprint:printer:25.1.10 | Internal Library | hp/printer | [printer](/dependencies/internal/printer.md) | no |
| com.hp.cloudprint:devicecapabilities:25.1.7 | Internal Library | hp/devicecapabilities | [devicecapabilities](/dependencies/internal/devicecapabilities.md) | no |
| com.hp.cloudprint:eprintDirectory:25.1.6 | Internal Library | hp/eprintdirectory | [eprintdirectory](/dependencies/internal/eprintdirectory.md) | no |
| com.hp.cloudprint:metrics:25.1.4 | Internal Library | hp/metrics | [metrics](/dependencies/internal/metrics.md) | no |
| junit:junit:4.4 | Dependency | — | [junit-junit](/dependencies/external/junit-junit.md) | n/a |
| org.restlet:org.restlet:1.1.6 | Dependency | — | [org-restlet-org-restlet](/dependencies/external/org-restlet-org-restlet.md) | n/a |
| com.noelios.restlet:com.noelios.restlet:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet](/dependencies/external/com-noelios-restlet-com-noelios-restlet.md) | n/a |
| com.noelios.restlet:com.noelios.restlet.ext.servlet:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet-ext-servlet](/dependencies/external/com-noelios-restlet-com-noelios-restlet-ext-servlet.md) | n/a |
| org.powermock:powermock-module-testng:${powermock.version} | Dependency | — | [org-powermock-powermock-module-testng](/dependencies/external/org-powermock-powermock-module-testng.md) | n/a |
| org.powermock:powermock-api-mockito:${powermock.version} | Dependency | — | [org-powermock-powermock-api-mockito](/dependencies/external/org-powermock-powermock-api-mockito.md) | n/a |
| org.springframework:spring-aspects:${spring.framework.version} | Dependency | — | [org-springframework-spring-aspects](/dependencies/external/org-springframework-spring-aspects.md) | n/a |
| com.hp.cloudprint:util:25.1.4 | Internal Library | hp/util | [util](/dependencies/internal/util.md) | no |
| com.hp.cloudprint:ePrintLogger:25.1.4 | Internal Library | hp/eprintlogger | [eprintlogger](/dependencies/internal/eprintlogger.md) | no |
| commons-cli:commons-cli:1.2 | Dependency | — | [commons-cli-commons-cli](/dependencies/external/commons-cli-commons-cli.md) | n/a |
| com.hp.cloudprint:eprintUserDirectory:25.1.4 | Internal Library | hp/eprintuserdirectory | [eprintuserdirectory](/dependencies/internal/eprintuserdirectory.md) | no |
| org.apache.httpcomponents:httpmime:4.0 | Dependency | — | [org-apache-httpcomponents-httpmime](/dependencies/external/org-apache-httpcomponents-httpmime.md) | n/a |
| com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet-ext-spring](/dependencies/external/com-noelios-restlet-com-noelios-restlet-ext-spring.md) | n/a |
| org.restlet:org.restlet.ext.spring:1.1.6 | Dependency | — | [org-restlet-org-restlet-ext-spring](/dependencies/external/org-restlet-org-restlet-ext-spring.md) | n/a |
| org.springframework.security:spring-security-core:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-core](/dependencies/external/org-springframework-security-spring-security-core.md) | n/a |
| org.springframework.security:spring-security-acl:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-acl](/dependencies/external/org-springframework-security-spring-security-acl.md) | n/a |
| com.hp.cloudprint:pjpservices:25.1.10 | Internal Library | hp/pjpservices | [pjpservices](/dependencies/internal/pjpservices.md) | no |
| com.hp.cloudprint:cjputil:25.1.4 | Internal Library | hp/cjputil | [cjputil](/dependencies/internal/cjputil.md) | no |
| com.hp.cloudprint:jefapi:25.1.13 | Internal Library | hp/jefapi | [jefapi](/dependencies/internal/jefapi.md) | no |
| com.hp.cloudprint:pjpworkstepsutil:25.1.10 | Internal Library | hp/pjpworkstepsutil | [pjpworkstepsutil](/dependencies/internal/pjpworkstepsutil.md) | no |
| com.hp.cloudprint:channelinterfaces:25.1.4 | Internal Library | hp/channelinterfaces | [channelinterfaces](/dependencies/internal/channelinterfaces.md) | no |
| com.hp.cloudprint:sjpservices:25.1.10 | Internal Library | hp/sjpservices | [sjpservices](/dependencies/internal/sjpservices.md) | no |
| com.hp.cloudprint:pjpcommon:25.1.10 | Internal Library | hp/pjpcommon | [pjpcommon](/dependencies/internal/pjpcommon.md) | no |
| com.hp.cloudprint:entities:25.4.1 | Internal Library | hp/entities | [entities](/dependencies/internal/entities.md) | no |
| org.testng:testng:5.14 | Dependency | — | [org-testng-testng](/dependencies/external/org-testng-testng.md) | n/a |
| org.mockito:mockito-all:1.9.5 | Dependency | — | [org-mockito-mockito-all](/dependencies/external/org-mockito-mockito-all.md) | n/a |
| org.easymock:easymock:3.0 | Dependency | — | [org-easymock-easymock](/dependencies/external/org-easymock-easymock.md) | n/a |
| com.hp.iws.wpp:wp-common:${wpp-version} | Internal Library | hp/wp-common | [wp-common](/dependencies/internal/wp-common.md) | no |
| com.hp.iws.wpp:wpp-base-schema:${wpp-version} | Internal Library | hp/wpp-base-schema | [wpp-base-schema](/dependencies/internal/wpp-base-schema.md) | no |
| com.hp.iws.wpp:wp-common-web:${wpp-version} | Internal Library | hp/wp-common-web | [wp-common-web](/dependencies/internal/wp-common-web.md) | no |
| net.sf.ehcache:ehcache:1.3.0 | Dependency | — | [net-sf-ehcache-ehcache](/dependencies/external/net-sf-ehcache-ehcache.md) | n/a |
| com.hp.cloudprint:security:25.1.4 | Internal Library | hp/security | [security](/dependencies/internal/security.md) | no |
| com.sun.jersey:jersey-client:1.10 | Dependency | — | [com-sun-jersey-jersey-client](/dependencies/external/com-sun-jersey-jersey-client.md) | n/a |
| com.sun.jersey.contribs:jersey-multipart:1.10 | Dependency | — | [com-sun-jersey-contribs-jersey-multipart](/dependencies/external/com-sun-jersey-contribs-jersey-multipart.md) | n/a |
| com.sun.jersey:jersey-core:1.10 | Dependency | — | [com-sun-jersey-jersey-core](/dependencies/external/com-sun-jersey-jersey-core.md) | n/a |
| com.hp.iws.wpp:wp-simplecache-client:${simplecache-client-version} | Internal Library | hp/wp-simplecache-client | [wp-simplecache-client](/dependencies/internal/wp-simplecache-client.md) | no |
| com.hp.wpp:wpp-json-logging-adaptor:1.0.13 | Internal Library | hp/wpp-json-logging-adaptor | [wpp-json-logging-adaptor](/dependencies/internal/wpp-json-logging-adaptor.md) | no |
| com.hp.wpp:wpp-logger:2.2.14 | Internal Library | hp/wpp-logger | [wpp-logger](/dependencies/internal/wpp-logger.md) | no |
| ch.qos.logback:logback-classic:1.5.18 | Dependency | — | [ch-qos-logback-logback-classic](/dependencies/external/ch-qos-logback-logback-classic.md) | n/a |
| ch.qos.logback:logback-core:1.5.18 | Dependency | — | [ch-qos-logback-logback-core](/dependencies/external/ch-qos-logback-logback-core.md) | n/a |
| org.springframework:spring-aop:${spring.framework.version} | Dependency | — | [org-springframework-spring-aop](/dependencies/external/org-springframework-spring-aop.md) | n/a |
| org.springframework:spring-core:${spring.framework.version} | Dependency | — | [org-springframework-spring-core](/dependencies/external/org-springframework-spring-core.md) | n/a |
| org.springframework:spring-beans:${spring.framework.version} | Dependency | — | [org-springframework-spring-beans](/dependencies/external/org-springframework-spring-beans.md) | n/a |
| org.springframework:spring-context:${spring.framework.version} | Dependency | — | [org-springframework-spring-context](/dependencies/external/org-springframework-spring-context.md) | n/a |
| org.springframework:spring-context-support:${spring.framework.version} | Dependency | — | [org-springframework-spring-context-support](/dependencies/external/org-springframework-spring-context-support.md) | n/a |
| org.springframework:spring-web:${spring.framework.version} | Dependency | — | [org-springframework-spring-web](/dependencies/external/org-springframework-spring-web.md) | n/a |
| org.springframework:spring-webmvc:${spring.framework.version} | Dependency | — | [org-springframework-spring-webmvc](/dependencies/external/org-springframework-spring-webmvc.md) | n/a |
| org.springframework:spring-test:${spring.framework.version} | Dependency | — | [org-springframework-spring-test](/dependencies/external/org-springframework-spring-test.md) | n/a |
| org.springframework:spring-expression:${spring.framework.version} | Dependency | — | [org-springframework-spring-expression](/dependencies/external/org-springframework-spring-expression.md) | n/a |
| org.springframework:spring-orm:${spring.framework.version} | Dependency | — | [org-springframework-spring-orm](/dependencies/external/org-springframework-spring-orm.md) | n/a |
| org.springframework:spring-tx:${spring.framework.version} | Dependency | — | [org-springframework-spring-tx](/dependencies/external/org-springframework-spring-tx.md) | n/a |
| org.springframework:spring-jdbc:${spring.framework.version} | Dependency | — | [org-springframework-spring-jdbc](/dependencies/external/org-springframework-spring-jdbc.md) | n/a |
| org.springframework.security:spring-security-config:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-config](/dependencies/external/org-springframework-security-spring-security-config.md) | n/a |
| org.springframework.security:spring-security-web:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-web](/dependencies/external/org-springframework-security-spring-security-web.md) | n/a |
| org.springframework.security.oauth:spring-security-oauth:1.0.5.RELEASE | Dependency | — | [org-springframework-security-oauth-spring-security-oauth](/dependencies/external/org-springframework-security-oauth-spring-security-oauth.md) | n/a |
| com.hp.cloudprint:notification-common:25.2.3 | Internal Library | hp/notification-common | [notification-common](/dependencies/internal/notification-common.md) | no |
| com.hp.cloudprint:notification-client:25.2.4 | Internal Library | hp/notification-client | [notification-client](/dependencies/internal/notification-client.md) | no |
| org.apache.httpcomponents:httpclient:4.5.13 | Dependency | — | [org-apache-httpcomponents-httpclient](/dependencies/external/org-apache-httpcomponents-httpclient.md) | n/a |
| org.apache.httpcomponents:httpcore:4.4.13 | Dependency | — | [org-apache-httpcomponents-httpcore](/dependencies/external/org-apache-httpcomponents-httpcore.md) | n/a |
| com.mchange:c3p0:0.9.5.5 | Dependency | — | [com-mchange-c3p0](/dependencies/external/com-mchange-c3p0.md) | n/a |
| com.hp.cloudprint:snoobe-client:25.1.4 | Internal Library | hp/snoobe-client | [snoobe-client](/dependencies/internal/snoobe-client.md) | no |


# How this stays extensible

* A new dependency appears in `codebase_context.json` → the generator adds a concept under `dependencies/` and a row here automatically.
* When that dependency publishes its own OKF bundle, the ecosystem cartographer agent sets the concept's `okf_ref` to its location and flips the last column to `yes`.
* Nothing in a consumer breaks when a row is unresolved: broken/absent cross-bundle refs are tolerated by the OKF spec (§11).

# Dependency Summary

The offramp service depends on:

**Third-party libraries (40):** Logging (Logback), REST frameworks (Restlet, Jersey), Spring Framework (core, web, security, data), HTTP clients (Apache HttpComponents), caching (Ehcache), connection pooling (C3P0), and testing frameworks (TestNG, JUnit, Mockito, EasyMock, PowerMock).

**Internal HP libraries (24):** Core services (printer, devicecapabilities, eprintDirectory, metrics, util, security), job processing (pjpservices, sjpservices, pjpcommon, pjpworkstepsutil), entities, notification (notification-client, notification-common), WPP platform (wp-common, wp-common-web, wpp-base-schema, wp-simplecache-client, wpp-logger, wpp-json-logging-adaptor), and specialized utilities (cjputil, jefapi, channelinterfaces, eprintLogger, eprintUserDirectory, snoobe-client).

**Dependent services:** The service integrates with external cloud services via HTTP clients, though specific service dependencies are not explicitly documented in the current bundle.

All third-party dependencies are documented above with their purpose and usage. Internal libraries are documented as concepts under `/dependencies/internal/` but do not yet have their own OKF bundles published.

# Consumed by

This bundle does not currently document upstream consumers. When other services depend on offramp, they should be listed here with links to their OKF bundles.
