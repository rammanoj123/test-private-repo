---
type: Service
title: offramp
description: Spring service hp/offramp; entry point for the OKF bundle.
tags: [service, root]
status: draft
artifact_id: offramp
group_id: com.hp.cloudprint
okf_bundle_id: hp/offramp
version: 25.1.11
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

offramp — a war service.

This is the root concept of the bundle — the *you-are-here* node. It links out to the architecture, API surface, components, domain model, and the ecosystem this service participates in.

# Coordinates

| Field | Value |
| --- | --- |
| Group | com.hp.cloudprint |
| Artifact | offramp |
| Version | 25.1.11 |
| Packaging | war |
| Bundle id | hp/offramp |

# Map

* [Architecture & layering](/architecture/layering.md)
* [Build & test (attested)](/architecture/build-and-test.md)
* API surface — see api/
* Components — see `components/`
* Domain model — see `domain/`
* Use cases — see `usecases/`
* Configuration — see `config/`
* [Ecosystem & dependencies](/ecosystem/ecosystem.md)
* [Playbook: JIRA ticket → code](/playbooks/jira-to-code.md)

# Layer inventory

| Layer | Types |
| --- | --- |
| config | OffRampAPIConfig, OfframpVersionFactory, LoggingConfig, CollectionConfigResource, PrinterCloudConfigResource, PrinterCloudConfigResourceV2, XMPPConfigurationResource, CloudConfiguration, ObjectFactory, PrinterConfiguration, XmppConfig, OffRampAPIConfigTest, CollectionConfigResourceTest, PrinterCloudConfigResourceTest, PrinterCloudConfigResourceV2Test, XMPPConfigurationResourceTest, CloudConfigurationInputTest, CloudConfigurationPotectionModeInputTest, WpPropertyPlaceholderConfigurer, AppConfig, WpPropertyPlaceholderConfigurer, AppConfig, MethodInvokingFactoryBean, AppConfig, FieldRetrievingFactoryBean, FieldRetrievingFactoryBean, FieldRetrievingFactoryBean, FieldRetrievingFactoryBean, WpPropertyPlaceholderConfigurer, EPrintDirectoryConfig |
| unknown | OfframpHelper, OfframpVersion, OfframpVersion2, OfframpVersionBase, StratusClientImpl, URIHelper, Utility, RegistrationShutDownHook, CacheClientMonitor, OfframpEnums, OfframpCacheHealthCheck, OfframpCacheProvider, PrinterClaimInfo, PrinterEmailAddress, PrinterIdentification, SessionSecret, StateReport, tunnelConnectionTimers, CountryAndRegionName, CountryName, RegionName, Version, LegacySha256PasswordEncoder, OfframpAuthenticationEntryPoint, RegistrationAuthenticationEntryPoint, OfframpHelperTest, OfframpResourceTest, URIHelperTest, UtilityTest, RegistrationShutdownHookTest, CacheClientMonitorTest, AbstractResourceTest, DeviceValidateResourceTest, EmailAddressResourceTest, OutputResourceTest, PrinterResourceTest, PrinterStateReportResourceTest, SessionSecretResourceTest, OfframpCacheHealthCheckTest, AuthenticationEntryPointTest, ClaimCodeResourceTest, InstructionResourceTest, JaxBMarshalTest, OfframpAPIResourceTest, OffRampRegistrationAPITest, MockEPrintDirectory, MockPrinterManager, EmailSenderImpl, CacheImpl, CacheImpl, CacheImpl, RoundRobinShardAllocator, String, EmailSenderImpl, CacheImpl, CacheImpl, CacheImpl, RoundRobinShardAllocator, String, XMemcachedClientWrapper, CacheImpl, CacheImpl, CacheImpl, SecurityDirectoryImpl, SecurityManagerImpl, MBeanExporter, MetricsHolder, PrinterRegistration, EmailAddressGeneratorImpl, ShardsLoader, RegistrationShardAllocator, SpringRouter, HashMap, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, ProviderManager, UnanimousBased, ProviderManager, ProviderManager, ProviderManager, UnanimousBased, UserAuthorizationSuccessfulAuthenticationHandler, BasicLookupStrategy_withFixes, NullAclCache, String, MockChannelManager |
| service | StratusClient, CacheClientMonitorMBean, WpConfigurationServiceProvider, DeregPrinterUserDetailsService, PrinterUserDetailsService, RegistrationUserDetailsService, UserAuthorizationTokenServices, PrinterUserDetailsServiceTest, RegistrationUserDetailsServiceTest, UserAuthorizationTokenServicesTest, PrintServiceImpl, JobService, WpConfigurationServiceImpl, PrintServiceImpl, JobService, WpConfigurationServiceImpl, JobService, PrintServiceImpl, ScanServiceImpl, RandomValueVerifierServices, JdbcMutableAclService_withFixes, WpConfigurationServiceImpl, MockPrintService |
| exception | BadHeaderPassedException, BlockedPrinterException, RegistrationDataInvalidException, SchemaValidationException, StratusClientException, BadHeaderPassedExceptionTest, ExceptionTranslationFilter, ExceptionTranslationFilter |
| controller | AbstractResource, ClaimCodeResource, DeviceUploadResource, DeviceValidateResource, EmailAddressResource, InstructionResource, OutputResource, PrinterEmailResource, PrinterResource, PrintersResource, PrinterStateReportResource, SessionSecretResource, OfframpHealthControllerResource, DeviceUploadResourceTest, PrintersResourceTest, OfframpHealthControllerResourceTest |
| security | CustomUserAuthorizationProcessingFilter, PrinterFilterAclEntryVoter, RegistrationAuthenticationProvider, SessionSecretFilterAclEntryVoter, TempTokenAuthorizationFilterAclEntryVoter, RegistrationAuthenticationProviderTest, FilterChainProxy, BasicAuthenticationFilter, FilterSecurityInterceptor, BasicAuthenticationFilter, BasicAuthenticationFilter, BasicAuthenticationFilter, FilterSecurityInterceptor |
| repository | MockDAOUtil, JEFDAOImpl, JobDAOImpl, EmailPrintJobDaoImpl, EmailRequestDAOImpl, JEFDAOImpl, JobDAOImpl, EmailPrintJobDaoImpl, EmailRequestDAOImpl, JEFDAOImpl, JobDAOImpl, SecurityDAOImpl |
| entity | MockEntityManagerFactory, MessageSupportPrinterModelEngine, FilterObjectIdentityRetrievalStrategy |
