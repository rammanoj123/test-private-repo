---
type: API Endpoint
title: DELETE Cloud Signaling Session
description: Terminates printer cloud signaling session.
resource: /Printers/{PrinterID}/CloudSignaling/SignalSession
tags: [api, endpoint, delete, signaling, session]
status: stable
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /Printers/{PrinterID}/CloudSignaling/SignalSession
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/Printers/{PrinterID}/CloudSignaling/SignalSession` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `PrinterID`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Empty or confirmation message

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
