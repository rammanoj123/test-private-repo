---
type: API Endpoint
title: DELETE /Printers/{PrinterID}/CloudSignaling/SignalSession
description: DELETE /Printers/{PrinterID}/CloudSignaling/SignalSession → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/CloudSignaling/SignalSession
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /Printers/{PrinterID}/CloudSignaling/SignalSession
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/Printers/{PrinterID}/CloudSignaling/SignalSession` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
