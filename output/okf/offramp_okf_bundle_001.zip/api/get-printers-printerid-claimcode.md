---
type: API Endpoint
title: GET /Printers/{PrinterID}/ClaimCode
description: GET /Printers/{PrinterID}/ClaimCode → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/ClaimCode
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/{PrinterID}/ClaimCode
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/{PrinterID}/ClaimCode` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
