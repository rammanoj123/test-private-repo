---
type: API Endpoint
title: GET /tokens/session/secret
description: GET /tokens/session/secret → SpringFinder.represent (description pending enrichment).
resource: /tokens/session/secret
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /tokens/session/secret
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/tokens/session/secret` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
