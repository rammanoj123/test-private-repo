---
type: API Endpoint
title: GET Session Secret
description: Retrieves session secret token for authenticated sessions.
resource: /tokens/session/secret
tags: [api, endpoint, get, session, token]
status: stable
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /tokens/session/secret
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/tokens/session/secret` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** No body required.

**Success Response:**
- Status: `200 OK`
- Body: Session secret token for authenticated sessions

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
