---
type: API Endpoint
title: DELETE /Printers/{PrinterID}/PrintJobs/Instructions
description: DELETE /Printers/{PrinterID}/PrintJobs/Instructions → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/PrintJobs/Instructions
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /Printers/{PrinterID}/PrintJobs/Instructions
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/Printers/{PrinterID}/PrintJobs/Instructions` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
