---
type: API Endpoint
title: PUT Email Address
description: Updates printer by email address identifier.
resource: /EmailAddress/{EmailAddress}/
tags: [api, endpoint, put]
status: stable
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /EmailAddress/{EmailAddress}/
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-001_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-001_Get.json, title: "Use Case UC-001: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/EmailAddress/{EmailAddress}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `EmailAddress`. Body contains updated printer information.

**Success Response:**
- Status: `200 OK`
- Body: Confirmation of update

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
