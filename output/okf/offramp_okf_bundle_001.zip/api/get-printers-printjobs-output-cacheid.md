---
type: API Endpoint
title: GET Print Job Output
description: Retrieves cached print job output document.
resource: /Printers/PrintJobs/Output/{CACHEID}
tags: [api, endpoint, get, output, cache]
status: stable
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/PrintJobs/Output/{CACHEID}
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/PrintJobs/Output/{CACHEID}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `CACHEID`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Cached print job output document

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
