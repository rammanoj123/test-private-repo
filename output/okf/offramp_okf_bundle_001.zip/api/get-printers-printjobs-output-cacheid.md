---
type: API Endpoint
title: GET /Printers/PrintJobs/Output/{CACHEID}
description: GET /Printers/PrintJobs/Output/{CACHEID} → SpringFinder.represent (description pending enrichment).
resource: /Printers/PrintJobs/Output/{CACHEID}
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/PrintJobs/Output/{CACHEID}
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/PrintJobs/Output/{CACHEID}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
