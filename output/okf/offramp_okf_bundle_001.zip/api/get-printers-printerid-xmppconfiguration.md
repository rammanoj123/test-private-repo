---
type: API Endpoint
title: GET Printer XMPP Configuration
description: Retrieves printer XMPP configuration for messaging.
resource: /Printers/{PrinterID}/XMPPConfiguration
tags: [api, endpoint, get, xmpp, printer]
status: stable
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/{PrinterID}/XMPPConfiguration
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/{PrinterID}/XMPPConfiguration` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `PrinterID`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Printer XMPP configuration for messaging

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
