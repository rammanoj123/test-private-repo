---
type: API Endpoint
title: POST Session Secret
description: Creates session secret token for authenticated sessions.
resource: /tokens/session/secret
tags: [api, endpoint, post, session, token]
status: stable
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /tokens/session/secret
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/tokens/session/secret` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Body contains session parameters.

**Success Response:**
- Status: `200 OK`
- Body: Created session secret token

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
