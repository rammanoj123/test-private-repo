---
type: API Endpoint
title: POST /tokens/session/secret
description: POST /tokens/session/secret → SpringFinder.represent (description pending enrichment).
resource: /tokens/session/secret
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /tokens/session/secret
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/tokens/session/secret` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
