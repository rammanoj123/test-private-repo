# API surface

# Concepts

* [DELETE /EmailAddress/{EmailAddress}/](delete-emailaddress-emailaddress.md) - DELETE /EmailAddress/{EmailAddress}/ → SpringFinder.represent (description pending enrichment).
* [DELETE /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}](delete-jobs-scanjobs-jobid-documents-documentid-upload-page.md) - DELETE /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/](delete-printers-printerid.md) - DELETE /Printers/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/ClaimCode](delete-printers-printerid-claimcode.md) - DELETE /Printers/{PrinterID}/ClaimCode → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/CloudConfiguration](delete-printers-printerid-cloudconfiguration.md) - DELETE /Printers/{PrinterID}/CloudConfiguration → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/CloudConfiguration/V2](delete-printers-printerid-cloudconfiguration-v2.md) - DELETE /Printers/{PrinterID}/CloudConfiguration/V2 → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/CloudSignaling/SignalSession](delete-printers-printerid-cloudsignaling-signalsession.md) - DELETE /Printers/{PrinterID}/CloudSignaling/SignalSession → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/EmailAddress](delete-printers-printerid-emailaddress.md) - DELETE /Printers/{PrinterID}/EmailAddress → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/PrintJobs/Instructions](delete-printers-printerid-printjobs-instructions.md) - DELETE /Printers/{PrinterID}/PrintJobs/Instructions → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/StateReport](delete-printers-printerid-statereport.md) - DELETE /Printers/{PrinterID}/StateReport → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/{PrinterID}/XMPPConfiguration](delete-printers-printerid-xmppconfiguration.md) - DELETE /Printers/{PrinterID}/XMPPConfiguration → SpringFinder.represent (description pending enrichment).
* [DELETE /Printers/PrintJobs/Output/{CACHEID}](delete-printers-printjobs-output-cacheid.md) - DELETE /Printers/PrintJobs/Output/{CACHEID} → SpringFinder.represent (description pending enrichment).
* [GET /EmailAddress/{EmailAddress}/](get-emailaddress-emailaddress.md) - GET /EmailAddress/{EmailAddress}/ → SpringFinder.represent (description pending enrichment).
* [GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}](get-jobs-scanjobs-jobid-documents-documentid-upload-page.md) - GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} → SpringFinder.represent (description pending enrichment).
* [GET /Printers](get-printers.md) - GET /Printers → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/](get-printers-printerid.md) - GET /Printers/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/ClaimCode](get-printers-printerid-claimcode.md) - GET /Printers/{PrinterID}/ClaimCode → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/CloudConfiguration](get-printers-printerid-cloudconfiguration.md) - GET /Printers/{PrinterID}/CloudConfiguration → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/CloudConfiguration/V2](get-printers-printerid-cloudconfiguration-v2.md) - GET /Printers/{PrinterID}/CloudConfiguration/V2 → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/CloudSignaling/SignalSession](get-printers-printerid-cloudsignaling-signalsession.md) - GET /Printers/{PrinterID}/CloudSignaling/SignalSession → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/EmailAddress](get-printers-printerid-emailaddress.md) - GET /Printers/{PrinterID}/EmailAddress → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/PrintJobs/Instructions](get-printers-printerid-printjobs-instructions.md) - GET /Printers/{PrinterID}/PrintJobs/Instructions → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/StateReport](get-printers-printerid-statereport.md) - GET /Printers/{PrinterID}/StateReport → SpringFinder.represent (description pending enrichment).
* [GET /Printers/{PrinterID}/XMPPConfiguration](get-printers-printerid-xmppconfiguration.md) - GET /Printers/{PrinterID}/XMPPConfiguration → SpringFinder.represent (description pending enrichment).
* [GET /Printers/PrintJobs/Output/{CACHEID}](get-printers-printjobs-output-cacheid.md) - GET /Printers/PrintJobs/Output/{CACHEID} → SpringFinder.represent (description pending enrichment).
* [GET /tokens/session/secret](get-tokens-session-secret.md) - GET /tokens/session/secret → SpringFinder.represent (description pending enrichment).
* [GET /ValidatePrinter](get-validateprinter.md) - GET /ValidatePrinter → SpringFinder.represent (description pending enrichment).
* [POST /Printers](post-printers.md) - POST /Printers → SpringFinder.represent (description pending enrichment).
* [POST /tokens/session/secret](post-tokens-session-secret.md) - POST /tokens/session/secret → SpringFinder.represent (description pending enrichment).
* [POST /ValidatePrinter](post-validateprinter.md) - POST /ValidatePrinter → SpringFinder.represent (description pending enrichment).
* [PUT /EmailAddress/{EmailAddress}/](put-emailaddress-emailaddress.md) - PUT /EmailAddress/{EmailAddress}/ → SpringFinder.represent (description pending enrichment).
* [PUT /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}](put-jobs-scanjobs-jobid-documents-documentid-upload-page.md) - PUT /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/](put-printers-printerid.md) - PUT /Printers/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/ClaimCode](put-printers-printerid-claimcode.md) - PUT /Printers/{PrinterID}/ClaimCode → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/CloudConfiguration](put-printers-printerid-cloudconfiguration.md) - PUT /Printers/{PrinterID}/CloudConfiguration → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/CloudConfiguration/V2](put-printers-printerid-cloudconfiguration-v2.md) - PUT /Printers/{PrinterID}/CloudConfiguration/V2 → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/CloudSignaling/SignalSession](put-printers-printerid-cloudsignaling-signalsession.md) - PUT /Printers/{PrinterID}/CloudSignaling/SignalSession → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/EmailAddress](put-printers-printerid-emailaddress.md) - PUT /Printers/{PrinterID}/EmailAddress → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/PrintJobs/Instructions](put-printers-printerid-printjobs-instructions.md) - PUT /Printers/{PrinterID}/PrintJobs/Instructions → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/StateReport](put-printers-printerid-statereport.md) - PUT /Printers/{PrinterID}/StateReport → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/{PrinterID}/XMPPConfiguration](put-printers-printerid-xmppconfiguration.md) - PUT /Printers/{PrinterID}/XMPPConfiguration → SpringFinder.represent (description pending enrichment).
* [PUT /Printers/PrintJobs/Output/{CACHEID}](put-printers-printjobs-output-cacheid.md) - PUT /Printers/PrintJobs/Output/{CACHEID} → SpringFinder.represent (description pending enrichment).
