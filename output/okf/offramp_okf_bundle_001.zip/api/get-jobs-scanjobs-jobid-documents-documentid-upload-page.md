---
type: API Endpoint
title: GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
description: GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} → SpringFinder.represent (description pending enrichment).
resource: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
