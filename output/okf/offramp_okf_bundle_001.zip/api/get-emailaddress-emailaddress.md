---
type: API Endpoint
title: GET /EmailAddress/{EmailAddress}/
description: GET /EmailAddress/{EmailAddress}/ → SpringFinder.represent (description pending enrichment).
resource: /EmailAddress/{EmailAddress}/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /EmailAddress/{EmailAddress}/
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/EmailAddress/{EmailAddress}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
