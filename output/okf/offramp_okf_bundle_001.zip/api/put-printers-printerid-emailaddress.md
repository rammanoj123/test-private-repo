---
type: API Endpoint
title: PUT Printer Email Address
description: Updates printer email address.
resource: /Printers/{PrinterID}/EmailAddress
tags: [api, endpoint, put]
status: stable
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /Printers/{PrinterID}/EmailAddress
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-002_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-002_Get.json, title: "Use Case UC-002: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/Printers/{PrinterID}/EmailAddress` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `PrinterID`. Body contains new email address.

**Success Response:**
- Status: `200 OK`
- Body: Update confirmation

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
