---
type: API Endpoint
title: PUT /Printers/{PrinterID}/CloudConfiguration
description: PUT /Printers/{PrinterID}/CloudConfiguration → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/CloudConfiguration
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /Printers/{PrinterID}/CloudConfiguration
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/Printers/{PrinterID}/CloudConfiguration` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
