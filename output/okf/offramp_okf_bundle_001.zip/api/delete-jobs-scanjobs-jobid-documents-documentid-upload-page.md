---
type: API Endpoint
title: DELETE /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
description: DELETE /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} → SpringFinder.represent (description pending enrichment).
resource: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
