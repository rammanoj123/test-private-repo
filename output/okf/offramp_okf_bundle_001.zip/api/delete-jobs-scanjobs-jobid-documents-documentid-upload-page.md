---
type: API Endpoint
title: DELETE Scan Job Upload Page
description: Deletes uploaded scan job document page.
resource: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
tags: [api, endpoint, delete, scan, upload]
status: stable
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-001_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-001_Get.json, title: "Use Case UC-001: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameters: `JOBID`, `DOCUMENTID`, `PAGE`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Empty or confirmation message

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
