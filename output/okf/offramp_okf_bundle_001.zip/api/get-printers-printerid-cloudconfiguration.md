---
type: API Endpoint
title: GET Printer Cloud Configuration
description: Retrieves printer cloud configuration settings.
resource: /Printers/{PrinterID}/CloudConfiguration
tags: [api, endpoint, get, cloud-config, printer]
status: stable
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/{PrinterID}/CloudConfiguration
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-003_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-003_Get.json, title: "Use Case UC-003: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/{PrinterID}/CloudConfiguration` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `PrinterID`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Printer cloud configuration settings

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
