---
type: API Endpoint
title: DELETE /Printers/{PrinterID}/CloudConfiguration
description: DELETE /Printers/{PrinterID}/CloudConfiguration → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/CloudConfiguration
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /Printers/{PrinterID}/CloudConfiguration
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/Printers/{PrinterID}/CloudConfiguration` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
