---
type: API Endpoint
title: POST /Printers
description: POST /Printers → SpringFinder.represent (description pending enrichment).
resource: /Printers
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /Printers
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/Printers` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
