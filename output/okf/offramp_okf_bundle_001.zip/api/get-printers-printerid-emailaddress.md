---
type: API Endpoint
title: GET Printer Email Address
description: Retrieves printer email address.
resource: /Printers/{PrinterID}/EmailAddress
tags: [api, endpoint, get, email, printer]
status: stable
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/{PrinterID}/EmailAddress
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-002_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-002_Get.json, title: "Use Case UC-002: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/{PrinterID}/EmailAddress` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameter: `PrinterID`. No body required.

**Success Response:**
- Status: `200 OK`
- Body: Printer email address

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
