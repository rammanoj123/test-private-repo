---
type: API Endpoint
title: GET /Printers/{PrinterID}/EmailAddress
description: GET /Printers/{PrinterID}/EmailAddress → SpringFinder.represent (description pending enrichment).
resource: /Printers/{PrinterID}/EmailAddress
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /Printers/{PrinterID}/EmailAddress
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/Printers/{PrinterID}/EmailAddress` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
