---
type: API Endpoint
title: PUT Scan Job Upload Page
description: Uploads scan job document page.
resource: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
tags: [api, endpoint, put]
status: stable
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}
generated: { by: gpt-4o-2024-05-13/api_usecase, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UC-001_Get.json, resource: okf_bundle/references/extraction/use_cases/UC-001_Get.json, title: "Use Case UC-001: Get" }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |


# Parameters

_None._

# Contract

**Request:** Path parameters: `JOBID`, `DOCUMENTID`, `PAGE`. Body contains page data.

**Success Response:**
- Status: `200 OK`
- Body: Upload confirmation

**Authentication:** None detected (public endpoint).

# Errors

| Status | Condition |
|--------|----------|
| 500 Internal Server Error | Unexpected error during processing |

# Realized by

Handler: `SpringFinder.represent()`
