---
type: Use Case
title: UC-009 — Get
description: GET /Printers (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-009
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Field | Value |
| --- | --- |
| Id | UC-009 |
| Trigger | GET /Printers |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
