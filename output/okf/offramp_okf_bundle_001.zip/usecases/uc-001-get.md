---
type: Use Case
title: UC-001 — Get
description: GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-001
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Field | Value |
| --- | --- |
| Id | UC-001 |
| Trigger | GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
