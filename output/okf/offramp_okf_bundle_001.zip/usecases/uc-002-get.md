---
type: Use Case
title: UC-002 — Get
description: GET /Printers/{PrinterID}/EmailAddress (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-002
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

| Field | Value |
| --- | --- |
| Id | UC-002 |
| Trigger | GET /Printers/{PrinterID}/EmailAddress |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
