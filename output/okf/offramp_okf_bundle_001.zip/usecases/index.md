# Use cases

# Concepts

* [UC-001 — Get](uc-001-get.md) - GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} (pending enrichment).
* [UC-002 — Get](uc-002-get.md) - GET /Printers/{PrinterID}/EmailAddress (pending enrichment).
* [UC-003 — Get](uc-003-get.md) - GET /Printers/{PrinterID}/ (pending enrichment).
* [UC-004 — Get](uc-004-get.md) - GET /EmailAddress/{EmailAddress}/ (pending enrichment).
* [UC-005 — Get](uc-005-get.md) - GET /Printers/{PrinterID}/PrintJobs/Instructions (pending enrichment).
* [UC-006 — Get](uc-006-get.md) - GET /Printers/{PrinterID}/XMPPConfiguration (pending enrichment).
* [UC-007 — Get](uc-007-get.md) - GET /Printers/{PrinterID}/CloudConfiguration (pending enrichment).
* [UC-008 — Get](uc-008-get.md) - GET /Printers/{PrinterID}/CloudConfiguration/V2 (pending enrichment).
* [UC-009 — Get](uc-009-get.md) - GET /Printers (pending enrichment).
* [UC-010 — Get](uc-010-get.md) - GET /Printers/{PrinterID}/StateReport (pending enrichment).
* [UC-011 — Get](uc-011-get.md) - GET /Printers/PrintJobs/Output/{CACHEID} (pending enrichment).
* [UC-012 — Get](uc-012-get.md) - GET /tokens/session/secret (pending enrichment).
* [UC-013 — Get](uc-013-get.md) - GET /Printers/{PrinterID}/ClaimCode (pending enrichment).
* [UC-014 — Get](uc-014-get.md) - GET /Printers/{PrinterID}/CloudSignaling/SignalSession (pending enrichment).
* [UC-015 — Get](uc-015-get.md) - GET /ValidatePrinter (pending enrichment).
