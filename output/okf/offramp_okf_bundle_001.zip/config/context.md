---
type: Configuration
title: Application context
description: Profiles and legacy XML wiring.
tags: [config, xml]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
sources:
  - { id: context-md, resource: /config/context.md, title: Application context concept }
  - { id: applicationContext-offramp-xml, resource: /offramp/src/main/resources/applicationContext-offramp.xml, title: Offramp application context }
  - { id: applicationContext-restlet-xml, resource: /offramp/src/main/resources/applicationContext-restlet.xml, title: Restlet routing context }
  - { id: applicationContext-security-xml, resource: /offramp/src/main/resources/applicationContext-security.xml, title: Security context }
  - { id: applicationContext-wpConfigService-xml, resource: /offramp/src/main/resources/applicationContext-wpConfigService.xml, title: WP configuration service context }
---

# Legacy XML beans

The table below groups beans by role. Understanding these groups helps the generator place new beans correctly and respect existing wiring patterns.

## DAO (Data Access Objects)
Beans that encapsulate database access. All are prototype-scoped to avoid shared state.

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| jefDAO | com.hp.cloudprint.jef.entities.dao.impl.JEFDAOImpl | prototype | applicationContext-offramp.xml | Job Execution Framework DAO; manages job metadata and execution state. |
| jobDAO | com.hp.cloudprint.entities.dao.impl.JobDAOImpl | prototype | applicationContext-offramp.xml | Job DAO; CRUD operations for print and scan jobs. |
| emailPrintJobDAO | com.hp.cloudprint.entities.dao.impl.EmailPrintJobDaoImpl | prototype | applicationContext-emailRequest.xml | Email print job DAO; manages jobs submitted via email. |
| emailRequestDAO | com.hp.cloudprint.entities.dao.impl.EmailRequestDAOImpl | prototype | applicationContext-emailRequest.xml | Email request DAO; tracks email-to-print requests. |
| securityDAO | com.hp.cloudprint.entities.dao.impl.SecurityDAOImpl | singleton | applicationContext-offramp.xml | Security DAO; manages ACLs, permissions, and user-device associations. |

## Services
Business logic and orchestration. Mix of singleton (stateless) and prototype (stateful or per-request).

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| printService | com.hp.cloudprint.pjp.jobservice.PrintServiceImpl | prototype | applicationContext-offramp.xml | Print job orchestration; coordinates job submission, rendering, and delivery. Links to [use cases](/usecases/uc-001-get.md) for printer job retrieval. |
| scanService | com.hp.cloudprint.pjp.scan.impl.ScanServiceImpl | prototype | applicationContext-offramp.xml | Scan job orchestration; handles scan-to-cloud workflows. |
| jobService | com.hp.cloudprint.pjp.common.jobservice.JobService | prototype | applicationContext-offramp.xml | Common job service; shared logic for print and scan jobs. |
| securityDirectory | com.hp.cloudprint.eprintdirectory.security.impl.SecurityDirectoryImpl | prototype | applicationContext-offramp.xml | Security directory; resolves user and device identities, checks permissions. |
| securityManager | com.hp.cloudprint.security.impl.SecurityManagerImpl | prototype | applicationContext-offramp.xml | Security manager; enforces ACLs and authorization policies. |
| emailSender | com.hp.cloudprint.emailoutbound.sender.EmailSenderImpl | prototype | applicationContext-emailRequest.xml | Email sender; dispatches outbound emails (notifications, print receipts). |

## Infrastructure
Singleton beans providing cross-cutting services (cache, configuration, monitoring, shutdown hooks).

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| simpleCacheClient | com.hp.ipg.iws.wp.simplecache.client.impl.XMemcachedClientWrapper | singleton | applicationContext-offramp.xml | Memcached client wrapper; provides distributed cache access. See [cache config](/config/cache.md). |
| offrampCacheProvider | com.hp.cloudprint.api.offramp.resources.healthcheck.OfframpCacheProvider | singleton | applicationContext-offramp.xml | Cache health provider; reports cache availability to health check endpoint. |
| jobCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-offramp.xml | Job metadata cache; reduces database load for active jobs. |
| printCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-offramp.xml | Print job cache; caches printer configurations and print requests. |
| renderCache | com.hp.cloudprint.util.CacheImpl | singleton | applicationContext-offramp.xml | Rendered output cache; stores rendered documents (PDFs, images). |
| wpConfigurationService | com.hp.ipg.iws.wp.common.config.WpConfigurationServiceImpl | singleton | applicationContext-wpConfigService.xml | WP configuration service; loads environment-specific properties from centralized config. |
| wpPropertyPlaceholderConfigurer | com.hp.ipg.iws.wp.common.config.WpPropertyPlaceholderConfigurer | singleton | applicationContext-wpConfigService.xml | Property placeholder configurer; resolves `${...}` placeholders in XML using WP config service. |
| offRampAPIConfig | com.hp.cloudprint.api.offramp.OffRampAPIConfig | singleton | applicationContext-offramp.xml | Offramp API configuration; holds service-level settings (timeouts, retry policies, feature flags). Links to [OffRampAPIConfig](/components/config/OffRampAPIConfig.md). |
| pjpAppConfig | com.hp.cloudprint.pjp.common.AppConfig | singleton | applicationContext-offramp.xml | PJP (Print Job Processor) application config; shared settings for print/scan job processing. |
| metricsHolder | com.hp.cloudprint.metrics.MetricsHolder | singleton | applicationContext-offramp.xml | Metrics holder; collects and exposes runtime metrics (request counts, latencies, error rates). |
| exporter | org.springframework.jmx.export.MBeanExporter | singleton | applicationContext-offramp.xml | JMX MBean exporter; exposes management beans for monitoring and operations. |
| simpleCacheClientMonitor | com.hp.cloudprint.api.offramp.oam.CacheClientMonitor | singleton | applicationContext-offramp.xml | Cache client monitor MBean; exposes cache statistics via JMX. Links to [CacheClientMonitor](/components/misc/CacheClientMonitor.md). |
| registrationShutdownHook | com.hp.cloudprint.api.offramp.gracefullshutdown.RegistrationShutDownHook | singleton | applicationContext-offramp.xml | Graceful shutdown hook; deregisters printers and flushes caches on shutdown. Links to [RegistrationShutDownHook](/components/misc/RegistrationShutDownHook.md). |
| printerRegistration | com.hp.cloudprint.devices.management.PrinterRegistration | singleton | applicationContext-offramp.xml | Printer registration manager; handles printer onboarding and claim code validation. |
| emailAddressGenerator | com.hp.cloudprint.eprintdirectory.emailaddressgenerator.impl.EmailAddressGeneratorImpl | singleton | applicationContext-offramp.xml | Email address generator; creates unique email addresses for printers. |
| messageSupportPrinterModelEngine | com.hp.cloudprint.devices.printer.messaging.MessageSupportPrinterModelEngine | singleton | applicationContext-offramp.xml | Printer model engine; determines messaging capabilities (XMPP, polling) based on printer model. |
| shardsLoader | com.hp.cloudprint.eprintdirectory.shard.ShardsLoader | singleton | applicationContext-offramp.xml | Shards loader; loads database shard configuration for multi-tenant partitioning. |
| registrationShardAllocator | com.hp.cloudprint.eprintdirectory.shard.RegistrationShardAllocator | singleton | applicationContext-offramp.xml | Shard allocator; assigns new printers to database shards based on load balancing rules. |
| shardAllocator | com.hp.cloudprint.emailrequest.shardallocator.impl.RoundRobinShardAllocator | singleton | applicationContext-emailRequest.xml | Email request shard allocator; round-robin allocation for email-to-print requests. |

## Restlet routing
Restlet framework beans that map URL patterns to resource classes (controllers).

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| root | org.restlet.ext.spring.SpringRouter | singleton | applicationContext-restlet.xml | Root router; top-level URL routing for the Restlet application. |
| resourceMap | java.util.HashMap | singleton | applicationContext-restlet.xml | Resource map; holds URL pattern → SpringFinder mappings. |
| validatePrinter | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for `/validateprinter`; routes to [DeviceValidateResource](/components/controllers/DeviceValidateResource.md). |
| collectionConfig | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for collection config endpoints; routes to [CollectionConfigResource](/components/controllers/CollectionConfigResource.md). |
| scanJobUpload | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for scan job upload; routes to [DeviceUploadResource](/components/controllers/DeviceUploadResource.md). |
| emailAddress | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for `/emailaddress/{emailaddress}`; routes to [EmailAddressResource](/components/controllers/EmailAddressResource.md). |
| printer | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for `/printers/{printerId}`; routes to [PrinterResource](/components/controllers/PrinterResource.md). |
| printerEmail | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for printer email endpoints; routes to [PrinterEmailResource](/components/controllers/PrinterEmailResource.md). |
| instructions | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for print job instructions; routes to [InstructionResource](/components/controllers/InstructionResource.md). |
| xMPPConfiguration | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for XMPP config endpoints; routes to [XMPPConfigurationResource](/components/controllers/XMPPConfigurationResource.md). |
| printerCloudConfig | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for cloud config v1; routes to [PrinterCloudConfigResource](/components/controllers/PrinterCloudConfigResource.md). |
| printerCloudConfigV2 | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for cloud config v2; routes to [PrinterCloudConfigResourceV2](/components/controllers/PrinterCloudConfigResourceV2.md). |
| printers | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for `/printers` collection; routes to [PrintersResource](/components/controllers/PrintersResource.md). |
| printerStateReport | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for state report endpoints; routes to [PrinterStateReportResource](/components/controllers/PrinterStateReportResource.md). |
| output | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for print job output; routes to [OutputResource](/components/controllers/OutputResource.md). |
| sessionSecret | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for session secret endpoints; routes to [SessionSecretResource](/components/controllers/SessionSecretResource.md). |
| claimCode | org.restlet.ext.spring.SpringFinder | singleton | applicationContext-restlet.xml | Finder for claim code endpoints; routes to [ClaimCodeResource](/components/controllers/ClaimCodeResource.md). |

## Restlet resources (controllers)
Prototype-scoped resource beans instantiated per request by the SpringFinder.

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| validatePrinterResource | com.hp.cloudprint.api.offramp.resources.DeviceValidateResource | prototype | applicationContext-restlet.xml | Validates printer credentials and registration status. Links to [DeviceValidateResource](/components/controllers/DeviceValidateResource.md). |
| scanJobUploadResource | com.hp.cloudprint.api.offramp.resources.DeviceUploadResource | prototype | applicationContext-restlet.xml | Handles scan job page uploads. Links to [DeviceUploadResource](/components/controllers/DeviceUploadResource.md). |
| collectionConfigResource | com.hp.cloudprint.api.offramp.resources.CollectionConfigResource | prototype | applicationContext-restlet.xml | Manages collection configuration. Links to [CollectionConfigResource](/components/controllers/CollectionConfigResource.md). |
| emailAddressResource | com.hp.cloudprint.api.offramp.resources.EmailAddressResource | prototype | applicationContext-restlet.xml | CRUD operations for printer email addresses. Links to [EmailAddressResource](/components/controllers/EmailAddressResource.md). |
| printerResource | com.hp.cloudprint.api.offramp.resources.PrinterResource | prototype | applicationContext-restlet.xml | CRUD operations for individual printers. Links to [PrinterResource](/components/controllers/PrinterResource.md). |
| printerEmailResource | com.hp.cloudprint.api.offramp.resources.PrinterEmailResource | prototype | applicationContext-restlet.xml | Manages printer email settings. Links to [PrinterEmailResource](/components/controllers/PrinterEmailResource.md). |
| instructionResource | com.hp.cloudprint.api.offramp.resources.InstructionResource | prototype | applicationContext-restlet.xml | Retrieves print job instructions for printers. Links to [InstructionResource](/components/controllers/InstructionResource.md). |
| xMPPConfigurationResource | com.hp.cloudprint.api.offramp.resources.XMPPConfigurationResource | prototype | applicationContext-restlet.xml | CRUD operations for XMPP configuration. Links to [XMPPConfigurationResource](/components/controllers/XMPPConfigurationResource.md). |
| printerCloudConfigResource | com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResource | prototype | applicationContext-restlet.xml | Manages cloud configuration (v1). Links to [PrinterCloudConfigResource](/components/controllers/PrinterCloudConfigResource.md). |
| printerCloudConfigResourceV2 | com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResourceV2 | prototype | applicationContext-restlet.xml | Manages cloud configuration (v2). Links to [PrinterCloudConfigResourceV2](/components/controllers/PrinterCloudConfigResourceV2.md). |
| printersResource | com.hp.cloudprint.api.offramp.resources.PrintersResource | prototype | applicationContext-restlet.xml | Handles printer collection operations (list, register). Links to [PrintersResource](/components/controllers/PrintersResource.md). |
| printerStateReportResource | com.hp.cloudprint.api.offramp.resources.PrinterStateReportResource | prototype | applicationContext-restlet.xml | Receives and processes printer state reports. Links to [PrinterStateReportResource](/components/controllers/PrinterStateReportResource.md). |
| outputResource | com.hp.cloudprint.api.offramp.resources.OutputResource | prototype | applicationContext-restlet.xml | Serves rendered print job output. Links to [OutputResource](/components/controllers/OutputResource.md). |
| sessionSecretResource | com.hp.cloudprint.api.offramp.resources.SessionSecretResource | prototype | applicationContext-restlet.xml | Manages session secrets for printer authentication. Links to [SessionSecretResource](/components/controllers/SessionSecretResource.md). |
| claimCodeResource | com.hp.cloudprint.api.offramp.resources.ClaimCodeResource | prototype | applicationContext-restlet.xml | Handles claim code generation and validation. Links to [ClaimCodeResource](/components/controllers/ClaimCodeResource.md). |

## Security
Spring Security beans defining authentication, authorization, and ACL enforcement. See [security config](/config/security.md) for detailed explanations.

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| springSecurityFilterChain | org.springframework.security.web.FilterChainProxy | singleton | applicationContext-security.xml | Top-level security filter chain; routes requests through authentication and authorization filters. |
| registrationBasicProcessingFilter | org.springframework.security.web.authentication.www.BasicAuthenticationFilter | singleton | applicationContext-security.xml | Basic auth filter for printer registration flow. |
| registrationExceptionTranslationFilter | org.springframework.security.web.access.ExceptionTranslationFilter | singleton | applicationContext-security.xml | Translates security exceptions to HTTP responses for registration flow. |
| registrationFilterSecurityInterceptor | org.springframework.security.web.access.intercept.FilterSecurityInterceptor | singleton | applicationContext-security.xml | Authorization interceptor for registration endpoints. |
| registrationAuthenticationEntryPoint | com.hp.cloudprint.api.offramp.security.log.RegistrationAuthenticationEntryPoint | singleton | applicationContext-security.xml | Custom entry point for registration auth failures; logs and returns 401. Links to [RegistrationAuthenticationEntryPoint](/components/misc/RegistrationAuthenticationEntryPoint.md). |
| passwordEncoder | com.hp.cloudprint.api.offramp.security.LegacySha256PasswordEncoder | singleton | applicationContext-security.xml | Legacy SHA-256 password encoder; used for backward compatibility with existing printer credentials. Links to [LegacySha256PasswordEncoder](/components/misc/LegacySha256PasswordEncoder.md). |
| registrationAuthenticationManager | org.springframework.security.authentication.ProviderManager | singleton | applicationContext-security.xml | Authentication manager for registration flow; delegates to [RegistrationAuthenticationProvider](/components/security/RegistrationAuthenticationProvider.md). |
| registrationAccessDecisionManager | org.springframework.security.access.vote.UnanimousBased | singleton | applicationContext-security.xml | Access decision manager for registration; requires unanimous approval from all voters. |
| offrampValidationBasicProcessingFilter | org.springframework.security.web.authentication.www.BasicAuthenticationFilter | singleton | applicationContext-security.xml | Basic auth filter for printer validation flow. |
| offrampBasicProcessingFilter | org.springframework.security.web.authentication.www.BasicAuthenticationFilter | singleton | applicationContext-security.xml | Basic auth filter for standard printer operations. |
| offrampDeregBasicProcessingFilter | org.springframework.security.web.authentication.www.BasicAuthenticationFilter | singleton | applicationContext-security.xml | Basic auth filter for printer deregistration. |
| offrampExceptionTranslationFilter | org.springframework.security.web.access.ExceptionTranslationFilter | singleton | applicationContext-security.xml | Translates security exceptions to HTTP responses for standard flow. |
| offrampFilterSecurityInterceptor | org.springframework.security.web.access.intercept.FilterSecurityInterceptor | singleton | applicationContext-security.xml | Authorization interceptor for standard endpoints. |
| offrampAuthenticationEntryPoint | com.hp.cloudprint.api.offramp.security.log.OfframpAuthenticationEntryPoint | singleton | applicationContext-security.xml | Custom entry point for standard auth failures; logs and returns 401. Links to [OfframpAuthenticationEntryPoint](/components/misc/OfframpAuthenticationEntryPoint.md). |
| offrampAuthenticationValidationManager | org.springframework.security.authentication.ProviderManager | singleton | applicationContext-security.xml | Authentication manager for validation flow. |
| offrampAuthenticationManager | org.springframework.security.authentication.ProviderManager | singleton | applicationContext-security.xml | Authentication manager for standard flow; delegates to [PrinterUserDetailsService](/components/services/PrinterUserDetailsService.md). |
| offrampDeregAuthenticationManager | org.springframework.security.authentication.ProviderManager | singleton | applicationContext-security.xml | Authentication manager for deregistration flow; delegates to [DeregPrinterUserDetailsService](/components/services/DeregPrinterUserDetailsService.md). |
| offrampAccessDecisionManager | org.springframework.security.access.vote.UnanimousBased | singleton | applicationContext-security.xml | Access decision manager for standard flow; requires unanimous approval from ACL voters. |
| offrampFilterAclEntryVoter_Read | com.hp.cloudprint.api.offramp.security.PrinterFilterAclEntryVoter | singleton | applicationContext-security.xml | ACL voter for READ permission; checks if the authenticated printer can read the requested resource. Links to [PrinterFilterAclEntryVoter](/components/security/PrinterFilterAclEntryVoter.md). |
| offrampFilterAclEntryVoter_Update | com.hp.cloudprint.api.offramp.security.PrinterFilterAclEntryVoter | singleton | applicationContext-security.xml | ACL voter for UPDATE permission. |
| offrampFilterAclEntryVoter_Delete | com.hp.cloudprint.api.offramp.security.PrinterFilterAclEntryVoter | singleton | applicationContext-security.xml | ACL voter for DELETE permission. |
| offrampFilterAclEntryVoter_SessionSecret | com.hp.cloudprint.api.offramp.security.SessionSecretFilterAclEntryVoter | singleton | applicationContext-security.xml | ACL voter for session secret access. Links to [SessionSecretFilterAclEntryVoter](/components/security/SessionSecretFilterAclEntryVoter.md). |
| offrampFilterAclEntryVoter_Authorization | com.hp.cloudprint.api.offramp.security.TempTokenAuthorizationFilterAclEntryVoter | singleton | applicationContext-security.xml | ACL voter for temporary token authorization. Links to [TempTokenAuthorizationFilterAclEntryVoter](/components/security/TempTokenAuthorizationFilterAclEntryVoter.md). |
| UserAuthorizationProcessingFilter | com.hp.cloudprint.api.offramp.security.CustomUserAuthorizationProcessingFilter | singleton | applicationContext-security.xml | OAuth user authorization filter. Links to [CustomUserAuthorizationProcessingFilter](/components/security/CustomUserAuthorizationProcessingFilter.md). |
| userAuthorizationSuccessfulAuthenticationHandler | org.springframework.security.oauth.provider.filter.UserAuthorizationSuccessfulAuthenticationHandler | singleton | applicationContext-security.xml | OAuth success handler; redirects after successful authorization. |
| UserAuthorizationTokenServices | com.hp.cloudprint.api.offramp.security.UserAuthorizationTokenServices | singleton | applicationContext-security.xml | OAuth token services; manages request and access tokens. Links to [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md). |
| verifierServices | org.springframework.security.oauth.provider.verifier.RandomValueVerifierServices | singleton | applicationContext-security.xml | OAuth verifier services; generates and validates OAuth verifiers. |
| jdbcMutableAclService | com.hp.cloudprint.security.JdbcMutableAclService_withFixes | singleton | applicationContext-security.xml | JDBC-backed ACL service with custom fixes for multi-tenant ACLs. |
| basicLookupStrategy | com.hp.cloudprint.security.BasicLookupStrategy_withFixes | singleton | applicationContext-security.xml | ACL lookup strategy with custom fixes. |
| filterObjectIdentityRetrievalStrategy | com.hp.cloudprint.security.FilterObjectIdentityRetrievalStrategy | singleton | applicationContext-security.xml | Retrieves object identity from filter invocation for ACL checks. |
| com.hp.cloudprint.security.EPrintPermission.READ_DEVICE | org.springframework.beans.factory.config.FieldRetrievingFactoryBean | singleton | applicationContext-security.xml | Constant bean for READ_DEVICE permission. |
| com.hp.cloudprint.security.EPrintPermission.UPDATE_DEVICE | org.springframework.beans.factory.config.FieldRetrievingFactoryBean | singleton | applicationContext-security.xml | Constant bean for UPDATE_DEVICE permission. |
| com.hp.cloudprint.security.EPrintPermission.DELETE_DEVICE | org.springframework.beans.factory.config.FieldRetrievingFactoryBean | singleton | applicationContext-security.xml | Constant bean for DELETE_DEVICE permission. |
| com.hp.cloudprint.security.EPrintPermission.ADMINISTER_DEVICE | org.springframework.beans.factory.config.FieldRetrievingFactoryBean | singleton | applicationContext-security.xml | Constant bean for ADMINISTER_DEVICE permission. |
| NullAclCache | com.hp.cloudprint.security.NullAclCache | singleton | applicationContext-security.xml | No-op ACL cache; disables ACL caching (performance trade-off for consistency). |

## Test mocks
Test-specific beans that replace production dependencies with mocks.

| Bean id | Class | Scope | Source | Purpose |
| --- | --- | --- | --- | --- |
| printerManager | com.hp.cloudprint.api.offramp.test.mocks.MockPrinterManager | prototype | applicationContext.xml (test) | Mock printer manager for unit tests. |
| eprintDirectory | com.hp.cloudprint.api.offramp.test.mocks.MockEPrintDirectory | singleton | applicationContext.xml (test) | Mock ePrint directory for unit tests. |
| printService | com.hp.cloudprint.api.offramp.test.mocks.MockPrintService | singleton | applicationContext.xml (test) | Mock print service for unit tests. |
| DAOUtil | com.hp.cloudprint.api.offramp.test.mocks.MockDAOUtil | singleton | applicationContext.xml (test) | Mock DAO utility for unit tests. |
| channelManager | com.hp.cloudprint.api.offramp.test.mocks.MockChannelManager | singleton | applicationContext.xml (test) | Mock channel manager for unit tests. |
| entityManagerFactory | com.hp.cloudprint.api.offramp.test.mocks.MockEntityManagerFactory | singleton | applicationContext.xml (test) | Mock JPA entity manager factory for unit tests. |

# Purpose

**What it controls**: This configuration defines the Spring application context, wiring together all components, services, repositories, and infrastructure beans. The context is assembled from multiple XML files, each responsible for a specific concern.

**XML files**:
- **applicationContext-offramp.xml**: Core business beans (DAOs, services, managers, cache, JMX exporters, shutdown hooks). This is the primary wiring file for the offramp service.
- **applicationContext-restlet.xml**: Restlet routing and resource beans. Maps URL patterns to resource classes (controllers). Each endpoint (e.g., `/printers/{printerId}`) is wired to a `SpringFinder` that instantiates the corresponding resource.
- **applicationContext-security.xml**: Spring Security filter chains, authentication managers, access decision managers, ACL services, and password encoders. Defines three authentication flows: registration, validation, and standard printer authentication.
- **applicationContext-wpConfigService.xml**: WP configuration service beans. Loads environment-specific properties from the centralized configuration service.
- **applicationContext.xml** (test): Test-specific context with mock implementations of external dependencies (printer manager, ePrint directory, print service, DAO utilities).

**Environment caveats**:
- **Development**: Uses local property files (`config.properties`) and may disable external services (e.g., Stratus, ePrint directory).
- **Production**: Relies on the WP configuration service (`wpConfigurationService`) to inject environment-specific properties (database URLs, cache hosts, API keys). Missing configuration causes startup failure.
- **Testing**: Test context (`src/test/resources/applicationContext.xml`) replaces production beans with mocks to isolate unit tests from external dependencies.

**Profiles**: The codebase does not use Spring profiles. Environment-specific behavior is controlled by property values injected at runtime.

**Generator rules**:
1. When adding a new component, define its bean in the appropriate XML file (e.g., new controllers in `applicationContext-restlet.xml`, new services in `applicationContext-offramp.xml`).
2. Respect existing bean scopes: `singleton` for stateless services and infrastructure, `prototype` for stateful resources and per-request components.
3. Use constructor injection for required dependencies, setter injection for optional dependencies.
4. Do not introduce circular dependencies. If a circular dependency is unavoidable, use setter injection or a `BeanFactoryAware` lookup.
5. When modifying security configuration, test all three authentication flows (registration, validation, standard) to ensure no flow is broken.
