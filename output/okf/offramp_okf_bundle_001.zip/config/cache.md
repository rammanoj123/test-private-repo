---
type: Configuration
title: Cache
description: Cache configuration (pending enrichment).
tags: [config, cache]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
sources:
  - { id: cache-md, resource: /config/cache.md, title: Cache configuration concept }
  - { id: applicationContext-offramp-xml, resource: /offramp/src/main/resources/applicationContext-offramp.xml, title: Offramp application context }
---

| Key | Value |
| --- | --- |
| type | None |
| redis_host | None |

# Purpose

**What it controls**: This configuration defines the distributed cache layer used for session state, printer metadata, job data, and rendered output. The cache reduces database load and improves response times for frequently accessed data.

**Cache provider**: The system uses **Memcached** via the `simpleCacheClient` bean (class `com.hp.ipg.iws.wp.simplecache.client.impl.XMemcachedClientWrapper`), configured in `applicationContext-offramp.xml`. This client wraps the XMemcached library and provides a consistent interface for cache operations.

**Cache instances**: Three distinct cache instances are defined:
- **jobCache** (`com.hp.cloudprint.util.CacheImpl`): Stores job metadata and state. Used by job services to avoid repeated database queries for active jobs.
- **printCache** (`com.hp.cloudprint.util.CacheImpl`): Caches print job data, including printer configurations and print requests. Reduces latency for printer polling operations.
- **renderCache** (`com.hp.cloudprint.util.CacheImpl`): Stores rendered document output (e.g., PDFs, images). Prevents redundant rendering of the same document.

All three caches are singleton-scoped and share the underlying `simpleCacheClient` connection pool.

**Health monitoring**: The [OfframpCacheProvider](/components/services/OfframpCacheProvider.md) and [OfframpCacheHealthCheck](/components/misc/OfframpCacheHealthCheck.md) components monitor cache availability. The health check endpoint (`/health`) reports cache status; failures trigger alerts.

**Environment caveats**:
- **Development**: Cache may be disabled or pointed to a local Memcached instance. Check `config.properties` for `cache.enabled` and `cache.host` overrides.
- **Production**: Cache is required. Memcached cluster addresses are injected via environment variables or the WP configuration service. Cache unavailability degrades performance but does not block requests; the system falls back to database queries.
- **Testing**: Unit tests use mock cache implementations (see `applicationContext.xml` in `src/test/resources`). Integration tests may use an embedded Memcached instance or skip cache-dependent tests.

**Generator rules**:
1. When adding cache-dependent logic, inject the appropriate cache bean (`jobCache`, `printCache`, or `renderCache`) via XML configuration.
2. Always provide a fallback path for cache misses or cache unavailability. Do not assume the cache is always available.
3. Use cache keys that include tenant/shard identifiers to prevent cross-tenant data leakage.
4. Respect cache TTLs defined in the cache implementation. Do not cache sensitive data (passwords, tokens) without encryption.
