---
type: Reference
title: Cross-cutting behaviour
description: Declared transactions, caches, scheduling, listeners and AOP.
tags: [architecture, cross-cutting]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-13T12:41:34Z }
---

Declared cross-cutting behaviour extracted from the codebase and Spring XML. The code generator must preserve these when modifying the affected methods.

# Transactions

| Class | Method | Propagation | Read Only |
| --- | --- | --- | --- |
| UserAuthorizationTokenServices | authorizeRequestToken | REQUIRED | False |
| UserAuthorizationTokenServices | getToken | REQUIRED | False |
| UserAuthorizationTokenServices | setAuthoritiesToVerify | REQUIRED | False |
| UserAuthorizationTokenServices | getAuthoritiesToVerify | REQUIRED | False |
