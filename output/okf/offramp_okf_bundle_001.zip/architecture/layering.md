---
type: Reference
title: Architecture & layering
description: XML-configured Spring layering and the conventions code generation must respect.
tags: [architecture, conventions]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
sources:
  - { id: layering-md, resource: /architecture/layering.md, title: Architecture and layering concept }
---

Wiring style: **XML-configured** (134 legacy XML beans present).


# Layers

Components are organized by responsibility. Requests flow inward (controller → service → repository) and never the reverse. This unidirectional flow ensures separation of concerns and testability.

| Layer | Directory | Role | Generator Rules |
| --- | --- | --- | --- |
| Controller | components/controllers/ | HTTP entry points; no business logic | Controllers MUST delegate to services. Do not place business rules, transaction logic, or direct persistence calls in controllers. Controllers handle request/response mapping, validation, and error translation only. |
| Service | components/services/ | Business rules, transactions | Services contain business logic and define transaction boundaries (see [cross-cutting](/architecture/cross-cutting.md)). Services MAY call repositories and other services. Do not call controllers from services. |
| Repository | components/repositories/ | Persistence access | Repositories encapsulate all database access. Do not perform business logic in repositories. Repositories MUST NOT call services or controllers. |
| Domain | domain/ | Entities, DTOs, value objects | Domain objects are data carriers with minimal behavior. Do not inject services or repositories into domain objects. |
| Config | components/config/ | Wiring, beans, cross-cutting | Configuration classes define Spring beans and cross-cutting concerns (transactions, security, caching). Do not place business logic in config classes. |

**Wiring style**: This codebase uses **XML-configured Spring** with 134 legacy XML beans (see [context](/config/context.md)). When generating new components:
- Add bean definitions to the appropriate XML file (`applicationContext-*.xml`).
- Use constructor injection or setter injection as declared in XML.
- Do not introduce `@Component`, `@Service`, or `@Repository` annotations unless migrating the entire module to annotation-based configuration.
- Respect existing bean scopes (singleton vs. prototype) documented in the XML bean table.

# Conventions

* Transaction boundaries live on service methods (see per-component `Cross-cutting` sections).
* Persistence goes through repositories only.
* New endpoints must link to a use case and reuse existing DTOs where possible.

See [coding standards](/references/conventions/coding-standards.md) for the full house style the code generator must follow.
