---
type: Attested Computation
title: Build & test
description: The blessed Maven build/test the codegen pipeline attests against.
tags: [build, test, ci]
status: stable
runtime: maven
parameters:
  - { name: module, type: string, required: false }
executor:
  resource: /references/skills/run-maven.md
  receipt: [exit_code, executed_goal, surefire_summary]
attester: { resource: /references/attesters/maven_build.py }
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
sources:
  - { id: build-and-test-md, resource: /architecture/build-and-test.md, title: Build and test concept }
---

Sanctioned build + unit-test invocation for this service. The code generator MUST run this after producing a change and MUST NOT display a change whose attestation fails.


# Computation

    mvn -B -q -DskipTests=false test

Binds only the declared parameters; the runner supplies `-pl <module>` when `module` is set. The attester compares the executed goal and the surefire summary in the receipt against this sanctioned invocation.

## Notes

**How to run**: Execute `mvn -B -q -DskipTests=false test` from the project root. The `-B` flag runs in batch mode (non-interactive), `-q` reduces output verbosity, and `-DskipTests=false` ensures unit tests execute.

**Receipt fields**:
- `exit_code`: 0 indicates success; non-zero signals build or test failure.
- `executed_goal`: Must match `test` to confirm the correct Maven lifecycle phase ran.
- `surefire_summary`: Reports test counts (run, failures, errors, skipped). A passing build requires zero failures and errors.

**What PASS attests**: A successful attestation confirms:
1. The code compiles without errors.
2. All unit tests pass (Surefire summary shows 0 failures, 0 errors).
3. The executed goal matches the sanctioned invocation (`test`).
4. The build completed with exit code 0.

The attester (`/references/attesters/maven_build.py`) validates these conditions. Any deviation—compilation failure, test failure, or goal mismatch—results in a FAIL, blocking code generation output.

**Generator obligation**: The code generator MUST invoke this computation after every change and MUST NOT present or commit changes whose attestation fails. This ensures all generated code is buildable and passes existing tests.
