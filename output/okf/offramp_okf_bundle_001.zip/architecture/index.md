# Architecture

# Concepts

* [Build & test](build-and-test.md) - The blessed Maven build/test the codegen pipeline attests against.
* [Cross-cutting behaviour](cross-cutting.md) - Declared transactions, caches, scheduling, listeners and AOP.
* [Architecture & layering](layering.md) - XML-configured Spring layering and the conventions code generation must respect.
