---
type: Playbook
title: JIRA ticket → code
description: How the multi-agent code generator consumes this bundle to fulfil a ticket.
tags: [playbook, codegen]
status: stable
generated: { by: gpt-4o/playbooks, at: 2025-01-13T10:30:00Z }
sources:
  - { id: service, resource: okf_bundle/service.md, title: offramp service }
  - { id: post-printers, resource: okf_bundle/api/post-printers.md, title: POST /Printers }
  - { id: uc-001, resource: okf_bundle/usecases/uc-001-get.md, title: UC-001 — Get }
  - { id: printers-resource, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource }
  - { id: printer-user-details, resource: okf_bundle/components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
---

This bundle is the knowledge source for a code-generation pipeline. Given a JIRA ticket (feature or bug), the pipeline traverses the OKF graph rather than re-reading raw source.


# Procedure

1. **Locate entry concepts.** Match ticket text against concept `title`/`description`/`tags`. Endpoints, use cases and components are the usual entry points.
2. **Assemble the impacted subgraph.** From each entry concept follow links: an endpoint → its handler component → the components it *Depends on* → the domain entities they touch → the internal libraries and services involved.
3. **Cross bundles when needed.** If an impacted dependency concept has an `okf_ref`, load that bundle and repeat locally.
4. **Read the rules.** Pull [layering](/architecture/layering.md) and [coding standards](/references/conventions/coding-standards.md).
5. **Generate the change** consistent with the conventions and existing component contracts.
6. **Attest.** Run [build & test](/architecture/build-and-test.md) and refuse to propose a change whose attestation fails.

See [feature enhancement](/playbooks/feature-enhancement.md) and [bug fix](/playbooks/bug-fix.md) for the two concrete flows.

# Traversal

The code generator follows this graph traversal to turn a JIRA ticket into a change:

## Entry

Match ticket nouns ("printer registration", "claim code", "email address") against concept `title`, `description`, and `tags`. The usual entry points are:

* **API endpoints** in `/api/*` — e.g., [POST /Printers](/api/post-printers.md) for printer registration tickets.
* **Use cases** in `/usecases/*` — e.g., [UC-001 — Get](/usecases/uc-001-get.md) for scan job upload flows.
* **Components** in `/components/*` — when the ticket names a specific class or service.

## Expansion

From each entry concept, follow the links to assemble the impacted subgraph:

1. **Endpoint → Handler component** — The API concept's `handler` field points to the controller (e.g., [PrintersResource](/components/controllers/PrintersResource.md)).
2. **Handler → Dependencies** — Read the component's `Depends on` section to find injected services (e.g., `PrinterManager`, `SimpleCacheClient`).
3. **Services → Domain entities** — Services manipulate entities; follow references to `/dependencies/internal/entities.md` or domain model concepts.
4. **Cross into dependencies** — When a component depends on an internal library (e.g., `/dependencies/internal/printer.md`), read that concept; if it carries an `okf_ref`, load the referenced bundle and continue the traversal there.

## Rules

Before proposing code, read:

* [Coding standards](/references/conventions/coding-standards.md) — house style (XML wiring, thin controllers, service-layer transactions, DTO reuse).
* [Service context](/service.md) — the root concept's "Business context" section (when enriched) explains the service's role in the ecosystem.
* [Layering](/architecture/layering.md) — respect the architectural boundaries.

## Gate

After generating a change, **attest** it:

1. Run [build & test](/architecture/build-and-test.md) — the sanctioned Maven invocation.
2. If the attestation fails (non-zero exit, test failures), **do not propose the change**. Revise and re-attest.
3. Only changes with passing attestation may be shown to the user.

## Sync

After a change is accepted:

* Update or create the affected API concept (in `/api/`) if the change adds/modifies an endpoint.
* Update or create the affected use-case concept (in `/usecases/`) if the change alters a user-facing flow.
* Update the ecosystem concept (in `/ecosystem/`) if the change adds a new dependency or alters an integration point.

This keeps the OKF bundle in sync with the code, so the next ticket starts from accurate knowledge.

# Worked example

**Ticket:** "Add support for printer firmware version validation during registration."

### Step-by-step traversal

1. **Entry:** Match "printer registration" → [POST /Printers](/api/post-printers.md).
2. **Handler:** The endpoint's `handler` is `SpringFinder.represent`, but the enriched concept would point to [PrintersResource](/components/controllers/PrintersResource.md). Read that component.
3. **Dependencies:** [PrintersResource](/components/controllers/PrintersResource.md) depends on `PrinterManager`, `ICollectionServiceClient`, and `SimpleCacheClient`. The ticket implies validation logic, so focus on `PrinterManager` (the service that handles printer entities).
4. **Domain:** `PrinterManager` manipulates `Printer` entities. The ticket mentions "firmware version", which maps to the `firmwareVersion` field already present in `PrinterIdentification` (see the `setPrinterFirmwareVersion` method in [PrintersResource](/components/controllers/PrintersResource.md)).
5. **Rules:** Read [coding standards](/references/conventions/coding-standards.md) — validation logic belongs in the service layer, not the controller. Add a validation method to `PrinterManager` (or a dedicated validator service) that checks firmware version constraints.
6. **Generate:** Add a `validateFirmwareVersion(String version)` method to `PrinterManager`, call it from `PrintersResource.acceptRepresentation` before persisting the printer, and throw a `RegistrationDataInvalidException` if the version is unsupported.
7. **Attest:** Run [build & test](/architecture/build-and-test.md) — `mvn -B -q -DskipTests=false test`. If tests pass, the change is valid.
8. **Sync:** Update [POST /Printers](/api/post-printers.md) to document the new validation behavior, and update [UC-001](/usecases/uc-001-get.md) (or the relevant use case) to reflect the validation step.

This traversal touched 3 concepts ([POST /Printers](/api/post-printers.md), [PrintersResource](/components/controllers/PrintersResource.md), [PrinterUserDetailsService](/components/services/PrinterUserDetailsService.md)) and produced a change consistent with the existing architecture.
