---
type: Playbook
title: JIRA ticket → code
description: How the multi-agent code generator consumes this bundle to fulfil a ticket.
tags: [playbook, codegen]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2026-09-13T12:41:34Z }
sources:
  - { id: service, resource: /service.md, title: offramp service root }
  - { id: post-printers, resource: /api/post-printers.md, title: POST /Printers endpoint }
  - { id: printers-resource, resource: /components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: printer-user-details, resource: /components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
  - { id: build-test, resource: /architecture/build-and-test.md, title: Build & test attestation }
  - { id: coding-standards, resource: /references/conventions/coding-standards.md, title: Coding standards }
---

This bundle is the knowledge source for a code-generation pipeline. Given a JIRA ticket (feature or bug), the pipeline traverses the OKF graph rather than re-reading raw source.


# Procedure

1. **Locate entry concepts.** Match ticket text against concept `title`/`description`/`tags`. Endpoints, use cases and components are the usual entry points.
2. **Assemble the impacted subgraph.** From each entry concept follow links: an endpoint → its handler component → the components it *Depends on* → the domain entities they touch → the internal libraries and services involved.
3. **Cross bundles when needed.** If an impacted dependency concept has an `okf_ref`, load that bundle and repeat locally.
4. **Read the rules.** Pull [layering](/architecture/layering.md) and [coding standards](/references/conventions/coding-standards.md).
5. **Generate the change** consistent with the conventions and existing component contracts.
6. **Attest.** Run [build & test](/architecture/build-and-test.md) and refuse to propose a change whose attestation fails.

See [feature enhancement](/playbooks/feature-enhancement.md) and [bug fix](/playbooks/bug-fix.md) for the two concrete flows.

## Traversal

The code generator follows this graph-traversal route to turn a JIRA ticket into a change:

### Entry

Map the ticket's nouns (resource names, operations, domain terms) to entry concepts:

* **API endpoints** in [api/](/api/index.md) — match HTTP method + path or resource name from the ticket description.
* **Use cases** in [usecases/](/usecases/index.md) — match the user story or acceptance criteria.
* **Components** in [components/](/components/index.md) — when the ticket names a specific class or service.

Tags (`endpoint`, `usecase`, `controller`, `service`) accelerate the match.

### Expansion

From each entry concept, expand the impacted subgraph:

1. **Endpoint → handler component** — follow the `handler` field in the API concept (e.g., [POST /Printers](/api/post-printers.md) → [PrintersResource](/components/controllers/PrintersResource.md)).
2. **Handler → dependencies** — read the component's `Depends on` section to discover services, managers, and clients it calls (e.g., PrintersResource depends on `PrinterManager`, `ICollectionServiceClient`, `SimpleCacheClient`).
3. **Services → domain entities** — follow method signatures and field types to the domain model (schemas, DTOs, entities in `domain/` or inline in component concepts).
4. **Cross into dependencies** — when a dependency concept carries an `okf_ref` to another bundle, load that bundle and continue the traversal there.

### Rules

Before proposing code, read the governing concepts:

* [Coding standards](/references/conventions/coding-standards.md) — house style (wiring, layering, transaction boundaries, DTO reuse).
* [Service context](/service.md) — the root concept's *Business context* section (when enriched) explains the service's purpose and constraints.
* [Layering](/architecture/layering.md) — the architectural boundaries controllers, services, repositories must respect.

### Gate

After generating the change, attest it:

* Run [build & test](/architecture/build-and-test.md) — the sanctioned Maven invocation (`mvn -B -q -DskipTests=false test`).
* The attester compares the receipt (exit code, executed goal, surefire summary) against the sanctioned computation.
* **Refuse to propose a change whose attestation fails.** A failing build or test means the change is incomplete or breaks existing contracts.

### Sync

After a successful change, update the affected concepts so the bundle stays current:

* If you added or modified an endpoint, update or create the corresponding [api/](/api/index.md) concept.
* If you added or changed a use case, update or create the corresponding [usecases/](/usecases/index.md) concept.
* If you touched the ecosystem (added a dependency, changed a service boundary), update [ecosystem](/ecosystem/ecosystem.md).

This keeps the OKF bundle as the single source of truth for the next ticket.

## Worked example

**Ticket:** *"Add validation to printer registration: reject printers with serial numbers on the blocked list."*

### 1. Entry

Search for "printer registration" in concept titles/descriptions. Match:

* [POST /Printers](/api/post-printers.md) — the registration endpoint.
* [PrintersResource](/components/controllers/PrintersResource.md) — the handler for POST /Printers.

### 2. Expansion

From [PrintersResource](/components/controllers/PrintersResource.md), read:

* **Depends on:** `PrinterManager`, `ICollectionServiceClient`, `SimpleCacheClient`, `StatisticsCollector`.
* **Methods:** `acceptRepresentation`, `validateSerialNumber`, `createPrinterIdentification`.

The ticket mentions "blocked list," so we need a new validation step. Inspect `validateSerialNumber` — it already validates format; we'll extend it or add a new method `checkBlockedList`.

Follow the dependency to `PrinterManager` (a service in [dependencies/internal](/dependencies/internal/index.md) or inferred from the `Depends on` list). If `PrinterManager` has a method to query blocked printers, reuse it; otherwise, add one.

### 3. Rules

Read [coding standards](/references/conventions/coding-standards.md):

* Controllers stay thin; business logic lives in services.
* Reuse existing DTOs/entities before adding new ones.

So the blocked-list check belongs in `PrinterManager` (the service), not in `PrintersResource` (the controller). The controller calls `printerManager.isBlocked(serialNumber)` and throws `BlockedPrinterException` if true.

### 4. Generate

Produce the change:

* In `PrinterManager`: add `boolean isBlocked(String serialNumber)` that queries the blocked-list (from cache or DB).
* In `PrintersResource.acceptRepresentation`: after `validateSerialNumber`, call `if (printerManager.isBlocked(serialNumber)) throw new BlockedPrinterException(...)`.
* Add a test in `PrintersResourceTest` that mocks `printerManager.isBlocked(...)` returning true and asserts the exception is thrown.

### 5. Gate

Run [build & test](/architecture/build-and-test.md):

    mvn -B -q -DskipTests=false test

The attester checks:

* Exit code 0.
* Executed goal: `test`.
* Surefire summary: all tests pass.

If the build fails or a test breaks, revise the change until attestation succeeds.

### 6. Sync

Update:

* [POST /Printers](/api/post-printers.md) — add a note in the description: "Rejects printers on the blocked list with 403."
* [PrintersResource](/components/controllers/PrintersResource.md) — add `isBlocked` to the *Depends on* list if it's a new method, or note the new exception in the *Methods* table.

The bundle now reflects the change, ready for the next ticket.
