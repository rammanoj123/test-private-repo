---
type: Playbook
title: Feature enhancement flow
description: Traversal + generation steps for a feature-enhancement ticket.
tags: [playbook, codegen, feature]
status: stable
generated: { by: gpt-4o/playbooks, at: 2025-01-13T10:30:00Z }
sources:
  - { id: service, resource: okf_bundle/service.md, title: offramp service }
  - { id: post-printers, resource: okf_bundle/api/post-printers.md, title: POST /Printers }
  - { id: printers-resource, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource }
  - { id: coding-standards, resource: okf_bundle/references/conventions/coding-standards.md, title: Coding standards }
---

# When the ticket adds or changes behaviour

1. Identify the closest existing use case / endpoint; if none, the feature is net-new — pick the controller/service the ticket implies.
2. Prefer extending existing components over adding new ones; reuse domain entities and DTOs already in `domain/`.
3. Respect transaction boundaries from the service layer.
4. Add/adjust an API concept and a use-case concept for the new behaviour as part of the change so the bundle stays in sync.
5. Attest via [build & test](/architecture/build-and-test.md).

# Traversal

When a ticket adds or changes behavior, follow this route:

## Entry

Identify the closest existing use case or endpoint:

* If the ticket mentions an existing endpoint (e.g., "add a field to printer registration"), start at that API concept (e.g., [POST /Printers](/api/post-printers.md)).
* If the ticket describes a new capability (e.g., "support bulk printer deregistration"), find the controller or service the ticket implies (e.g., [PrintersResource](/components/controllers/PrintersResource.md) for printer-related operations).
* If no existing concept fits, the feature is **net-new** — pick the layer (controller, service, or repository) where the feature belongs based on [layering](/architecture/layering.md).

## Expansion

From the entry concept:

1. **Endpoint → Handler component** — Follow the `handler` link to the controller.
2. **Handler → Services** — Read the controller's `Depends on` section to find the services it uses.
3. **Services → Domain entities** — Services manipulate entities; prefer **reusing** existing entities in `/dependencies/internal/entities.md` or domain model concepts over creating new ones.
4. **Cross into dependencies** — If the feature requires functionality from an internal library (e.g., `/dependencies/internal/printer.md`), read that concept.

## Rules

Before proposing code:

* Read [coding standards](/references/conventions/coding-standards.md) — controllers stay thin, business logic lives in services, persistence only through repositories, transactions declared on service methods.
* **Prefer extension over addition** — reuse existing components and DTOs; only add new classes when the feature cannot fit into existing ones.
* **Respect transaction boundaries** — service methods are transactional; controllers are not.

## Gate

After generating the change:

1. Run [build & test](/architecture/build-and-test.md) — the sanctioned Maven invocation.
2. If the attestation fails, **do not propose the change**. Revise and re-attest.

## Sync

As part of the change, **update the bundle** so it stays in sync:

* **Add or adjust an API concept** (in `/api/`) for the new or modified endpoint.
* **Add or adjust a use-case concept** (in `/usecases/`) for the new behavior.
* If the feature adds a new dependency, update `/ecosystem/ecosystem.md`.

This ensures the next ticket starts from accurate knowledge.

# Worked example

**Ticket:** "Add an optional `reuseExistingIdentity` flag to printer registration that skips identity validation."

### Step-by-step traversal

1. **Entry:** Match "printer registration" → [POST /Printers](/api/post-printers.md).
2. **Handler:** The endpoint's handler is [PrintersResource](/components/controllers/PrintersResource.md). Read that component.
3. **Dependencies:** [PrintersResource](/components/controllers/PrintersResource.md) depends on `PrinterManager` (the service that handles printer entities). The ticket implies a change to registration logic, so focus on `PrinterManager`.
4. **Reuse existing structures:** The component already has a `REUSE_EXISTING_IDENTITY_HEADER` constant and logic in `acceptRepresentation` that checks headers. The feature fits into the existing flow — no new classes needed.
5. **Rules:** Read [coding standards](/references/conventions/coding-standards.md) — business logic belongs in the service layer. Add a parameter to `PrinterManager.registerPrinter(...)` to accept the flag, and modify the validation logic to skip identity checks when the flag is true.
6. **Generate:** 
   - Modify [PrintersResource](/components/controllers/PrintersResource.md) to read the `reuseExistingIdentity` header.
   - Pass the flag to `PrinterManager.registerPrinter(...)`.
   - Update `PrinterManager` to conditionally skip `isPrinterIdentityKnown(...)` when the flag is set.
7. **Attest:** Run [build & test](/architecture/build-and-test.md) — `mvn -B -q -DskipTests=false test`. If tests pass, the change is valid.
8. **Sync:** Update [POST /Printers](/api/post-printers.md) to document the new `reuseExistingIdentity` header, and update the relevant use case to reflect the optional validation step.

This traversal touched 2 concepts ([POST /Printers](/api/post-printers.md), [PrintersResource](/components/controllers/PrintersResource.md)) and extended existing logic without adding new classes.
