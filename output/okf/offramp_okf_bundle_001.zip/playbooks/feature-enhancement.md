---
type: Playbook
title: Feature enhancement flow
description: Traversal + generation steps for a feature-enhancement ticket.
tags: [playbook, codegen, feature]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2026-09-13T12:41:34Z }
sources:
  - { id: service, resource: /service.md, title: offramp service root }
  - { id: post-printers, resource: /api/post-printers.md, title: POST /Printers endpoint }
  - { id: printers-resource, resource: /components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: build-test, resource: /architecture/build-and-test.md, title: Build & test attestation }
  - { id: coding-standards, resource: /references/conventions/coding-standards.md, title: Coding standards }
---

# When the ticket adds or changes behaviour

1. Identify the closest existing use case / endpoint; if none, the feature is net-new — pick the controller/service the ticket implies.
2. Prefer extending existing components over adding new ones; reuse domain entities and DTOs already in `domain/`.
3. Respect transaction boundaries from the service layer.
4. Add/adjust an API concept and a use-case concept for the new behaviour as part of the change so the bundle stays in sync.
5. Attest via [build & test](/architecture/build-and-test.md).

## Traversal

When a ticket adds or changes behaviour, follow this route:

### Entry

Identify the closest existing concept:

* **Existing endpoint or use case** — if the ticket extends an existing API operation (e.g., "Add a query parameter to GET /Printers"), start at [api/](/api/index.md) or [usecases/](/usecases/index.md).
* **New endpoint** — if the ticket describes a net-new operation (e.g., "Add POST /Printers/{id}/block"), the feature is new. Pick the controller the ticket implies (e.g., [PrintersResource](/components/controllers/PrintersResource.md) or a new `PrinterBlockResource`).

### Expansion

From the entry concept, expand to the components and domain entities involved:

1. **Controller → service** — follow the `Depends on` section to the service layer (e.g., [PrintersResource](/components/controllers/PrintersResource.md) depends on `PrinterManager`).
2. **Service → domain entities** — inspect method signatures and field types to discover the DTOs, entities, and schemas the feature touches (e.g., `Printer`, `PrinterConfiguration`, `PrinterIdentification`).
3. **Reuse over creation** — prefer extending existing components and reusing domain entities already in `domain/` or inline in component concepts. Adding a new component or entity is a last resort.

### Rules

Before proposing the change, read:

* [Coding standards](/references/conventions/coding-standards.md) — respect transaction boundaries (declared on service methods), keep controllers thin, and reuse existing DTOs/entities.
* [Layering](/architecture/layering.md) — ensure the change respects architectural boundaries (controllers call services, services call repositories, no skipping layers).
* [Service context](/service.md) — the root concept's *Business context* (when enriched) explains constraints and invariants the feature must honour.

### Gate

After generating the change, attest it:

* Run [build & test](/architecture/build-and-test.md) — the sanctioned Maven invocation (`mvn -B -q -DskipTests=false test`).
* The attester checks exit code, executed goal, and surefire summary.
* **Refuse to propose a change whose attestation fails.**

### Sync

Update the bundle to reflect the new behaviour:

* **Add or adjust an API concept** — if you added an endpoint, create a new concept in [api/](/api/index.md) with `type: API Endpoint`, `http_method`, `http_path`, `handler`, and a description.
* **Add or adjust a use-case concept** — if the feature introduces a new user story, create a concept in [usecases/](/usecases/index.md) with `type: Use Case`, `usecase_id`, and the steps.
* **Update component concepts** — if you added methods or dependencies, update the component's `Methods` table and `Depends on` section.

This keeps the bundle in sync with the codebase.

## Worked example

**Ticket:** *"Add a new endpoint GET /Printers/{id}/status that returns the printer's current state (online, offline, error) and last-seen timestamp."*

### 1. Entry

The ticket describes a new endpoint. The resource is `/Printers/{id}/status`, so the natural handler is [PrintersResource](/components/controllers/PrintersResource.md) (or a new `PrinterResource` if one exists for single-printer operations). Check [api/](/api/index.md) — no existing `GET /Printers/{id}/status`, so this is net-new.

### 2. Expansion

From [PrintersResource](/components/controllers/PrintersResource.md), read:

* **Depends on:** `PrinterManager`, `ICollectionServiceClient`, `SimpleCacheClient`, `StatisticsCollector`.

The ticket asks for "current state" and "last-seen timestamp." These are likely fields on the `Printer` entity or a related DTO. Inspect `PrinterManager` — it probably has a method like `getPrinterById(String id)` that returns a `Printer`. If `Printer` already has `state` and `lastSeen` fields, reuse them. If not, add them to the `Printer` entity (or create a new DTO `PrinterStatus` if the fields don't belong on the core entity).

### 3. Rules

Read [coding standards](/references/conventions/coding-standards.md):

* Controllers stay thin; business logic lives in services.
* Reuse existing DTOs/entities before adding new ones.

So the controller method `getStatus` calls `printerManager.getPrinterById(id)`, extracts `state` and `lastSeen`, and returns them. If `Printer` doesn't have these fields, check if they exist in a related entity (e.g., `PrinterStateReport`) and reuse that.

### 4. Generate

Produce the change:

* In `PrintersResource`: add a method `getStatus(String id)` annotated with `@Get` (or the Restlet equivalent). It calls `printerManager.getPrinterById(id)`, constructs a response with `state` and `lastSeen`, and returns it.
* If `Printer` lacks these fields, add them (or reuse an existing DTO like `StateReport` — check [components/misc/StateReport.md](/components/misc/StateReport.md)).
* Add a test in `PrintersResourceTest` that mocks `printerManager.getPrinterById(...)` and asserts the response contains the expected fields.

### 5. Gate

Run [build & test](/architecture/build-and-test.md):

    mvn -B -q -DskipTests=false test

The attester checks exit code 0, executed goal `test`, and all tests pass. If the build fails, revise until attestation succeeds.

### 6. Sync

Update the bundle:

* **Create [api/get-printers-printerid-status.md](/api/get-printers-printerid-status.md):**
  ```yaml
  ---
  type: API Endpoint
  title: GET /Printers/{id}/status
  description: Returns the printer's current state and last-seen timestamp.
  resource: /Printers/{id}/status
  tags: [api, endpoint, get, status]
  status: stable
  handler: PrintersResource
  handler_method: getStatus
  http_method: GET
  http_path: /Printers/{id}/status
  ---
  ```
* **Update [PrintersResource](/components/controllers/PrintersResource.md):** add `getStatus` to the *Methods* table.
* **Create a use-case concept** (optional, if the feature is user-facing): [usecases/uc-016-get.md](/usecases/uc-016-get.md) describing the "Check printer status" story.

The bundle now documents the new feature, ready for the next ticket.
