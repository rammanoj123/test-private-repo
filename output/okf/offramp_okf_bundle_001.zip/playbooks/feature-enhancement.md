---
type: Playbook
title: Feature enhancement flow
description: Traversal + generation steps for a feature-enhancement ticket.
tags: [playbook, codegen, feature]
status: stable
generated: { by: gpt-4o-2024-05-13/playbooks, at: 2025-01-15T00:00:00Z }
sources:
  - { id: service.md, resource: okf_bundle/service.md, title: offramp service }
  - { id: post-printers.md, resource: okf_bundle/api/post-printers.md, title: POST Printers endpoint }
  - { id: PrintersResource.md, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: coding-standards.md, resource: okf_bundle/references/conventions/coding-standards.md, title: Coding standards }
  - { id: build-and-test.md, resource: okf_bundle/architecture/build-and-test.md, title: Build and test }
---

# When the ticket adds or changes behaviour

1. Identify the closest existing use case / endpoint; if none, the feature is net-new — pick the controller/service the ticket implies.
2. Prefer extending existing components over adding new ones; reuse domain entities and DTOs already in `domain/`.
3. Respect transaction boundaries from the service layer.
4. Add/adjust an API concept and a use-case concept for the new behaviour as part of the change so the bundle stays in sync.
5. Attest via [build & test](/architecture/build-and-test.md).

## Traversal

For a feature-enhancement ticket, follow this route through the bundle:

### Entry

Identify the closest existing concept:

- If the ticket describes a new endpoint or modifies an existing one, start at [api/](/api/index.md)
- If it extends a use case, start at [usecases/](/usecases/index.md)
- If no close match exists, the feature is net-new — infer the controller/service from the ticket's domain (e.g., "printer" → [PrintersResource](/components/controllers/PrintersResource.md), "email" → EmailAddressResource)

### Expansion

From the entry concept:

1. **Endpoint → Handler**: Follow `handler` to the controller component
2. **Handler → Services**: Read `Depends on` to find injected services
3. **Services → Domain**: Identify domain entities and DTOs used in method signatures
4. **Reuse before adding**: Check [domain/](/domain/index.md) for existing entities; prefer extending them over creating new ones
5. **Dependencies**: If the feature requires external libraries, check [dependencies/](/dependencies/index.md) and [ecosystem](/ecosystem/ecosystem.md)

### Rules

Before generating:

- Read [Coding standards](/references/conventions/coding-standards.md): "Reuse existing DTOs/entities in domain/ before adding new ones", "Transactions declared on service methods"
- Read [Layering](/architecture/layering.md): respect controller/service/repository boundaries
- Read the **Business context** section of each touched component to understand domain invariants

### Gate

After generating the change:

1. Run [build & test](/architecture/build-and-test.md): `mvn -B -q -DskipTests=false test`
2. Attest: exit code 0, goal `test`, 0 failures, 0 errors
3. **Refuse to propose** if attestation fails

### Sync

After a successful change:

- **Add or update** the [api/](/api/index.md) concept for the new/modified endpoint
- **Add or update** the [usecases/](/usecases/index.md) concept describing the new behavior
- Update `Depends on` sections if new dependencies were introduced
- Update [ecosystem](/ecosystem/ecosystem.md) if external libraries were added

This keeps the bundle synchronized with the evolved codebase.

## Worked example

**Ticket**: "Add support for printer firmware version validation during registration — reject printers with firmware older than a configurable minimum version"

### 1. Entry

Search for "printer registration" and "firmware":

- Found: [POST /Printers](/api/post-printers.md) (tags: `registration`, `printer`)
- Found: [PrintersResource](/components/controllers/PrintersResource.md) (description: "Handles POST requests to register new printers")
- Existing method: `setPrinterFirmwareVersion(printerIdentification, printer)` in [PrintersResource Algorithm](/components/controllers/PrintersResource.md#algorithm)

Entry point: [PrintersResource](/components/controllers/PrintersResource.md)

### 2. Expansion

Follow the graph:

- [PrintersResource](/components/controllers/PrintersResource.md) → `Depends on`:
  - OfframpVersionFactory → [OfframpVersionFactory](/components/config/OfframpVersionFactory.md) (handles version-specific logic)
  - OffRampAPIConfig (configuration source)
- Domain entities:
  - PrinterIdentification (contains firmware version from request)
  - Printer (entity being registered)
- Existing validation methods: `validateSerialNumber`, `validateXMLSchema`, `validateRegistrationMetadata`

**Decision**: Add a new validation method `validateFirmwareVersion` following the existing pattern.

### 3. Rules

Read:

- [Coding standards](/references/conventions/coding-standards.md): "Controllers stay thin; business logic lives in services", "Reuse existing DTOs/entities"
- [PrintersResource Business rules](/components/controllers/PrintersResource.md#business-rules): existing validation rules return 400 BAD_REQUEST for invalid data
- [PrintersResource Algorithm](/components/controllers/PrintersResource.md#algorithm): validation methods are called in sequence during `acceptRepresentation`

**Design**:

- Add `MINIMUM_FIRMWARE_VERSION` to OffRampAPIConfig
- Add `validateFirmwareVersion(PrinterIdentification)` method to PrintersResource
- Call it after `validateSerialNumber` in the `acceptRepresentation` flow
- Throw `RegistrationDataInvalidException` if firmware is too old
- Reuse existing exception handling in `actOnRegRequestFailure`

### 4. Generate

Add to `OffRampAPIConfig.java`:

```java
public static final String MINIMUM_FIRMWARE_VERSION = "2.0.0";
```

Add to `PrintersResource.java`:

```java
private void validateFirmwareVersion(PrinterIdentification printerIdentification) 
        throws RegistrationDataInvalidException {
    String firmwareVersion = printerIdentification.getFirmwareVersion();
    if (firmwareVersion == null || firmwareVersion.isEmpty()) {
        throw new RegistrationDataInvalidException("Firmware version is required");
    }
    
    String minVersion = getOfframpAPIConfigInstance().MINIMUM_FIRMWARE_VERSION;
    if (compareVersions(firmwareVersion, minVersion) < 0) {
        throw new RegistrationDataInvalidException(
            "Firmware version " + firmwareVersion + " is below minimum required " + minVersion);
    }
}

private int compareVersions(String v1, String v2) {
    String[] parts1 = v1.split("\\.");
    String[] parts2 = v2.split("\\.");
    int length = Math.max(parts1.length, parts2.length);
    for (int i = 0; i < length; i++) {
        int p1 = i < parts1.length ? Integer.parseInt(parts1[i]) : 0;
        int p2 = i < parts2.length ? Integer.parseInt(parts2[i]) : 0;
        if (p1 != p2) return Integer.compare(p1, p2);
    }
    return 0;
}
```

Update `acceptRepresentation` method (after line calling `validateSerialNumber`):

```java
validateFirmwareVersion(printerIdentification);
```

Add unit test `PrintersResourceTest.java`:

```java
@Test
public void testValidateFirmwareVersion_BelowMinimum_ThrowsException() {
    // Arrange
    PrinterIdentification id = new PrinterIdentification();
    id.setFirmwareVersion("1.5.0");
    
    // Act & Assert
    assertThrows(RegistrationDataInvalidException.class, 
        () -> printersResource.validateFirmwareVersion(id));
}
```

### 5. Gate

Run attestation:

```bash
mvn -B -q -DskipTests=false test
```

Check receipt:
- `exit_code`: 0 ✓
- `executed_goal`: test ✓
- `surefire_summary`: Tests run: 145, Failures: 0, Errors: 0, Skipped: 0 ✓

**Attestation PASS** → proceed to propose the change.

### 6. Sync

Update [PrintersResource](/components/controllers/PrintersResource.md):

- Add to `Methods` table: `validateFirmwareVersion`, `compareVersions`
- Add to `Business rules`: "If firmware version is below configured minimum, reject registration with 400 BAD_REQUEST."
- Update `Algorithm` section: insert step "Validate firmware version via validateFirmwareVersion(printerIdentification)" after step 11

Update [POST /Printers](/api/post-printers.md):

- Add to `Errors` table: "400 Bad Request | Firmware version below minimum required"

No new use case needed (existing registration use case covers this), but if one existed, update its `Steps` section to mention firmware validation.
