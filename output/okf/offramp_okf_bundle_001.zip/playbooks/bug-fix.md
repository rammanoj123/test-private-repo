---
type: Playbook
title: Bug fix flow
description: Traversal + generation steps for a bug-fix ticket.
tags: [playbook, codegen, bug]
status: stable
generated: { by: gpt-4o/playbooks, at: 2025-01-13T10:30:00Z }
sources:
  - { id: service, resource: okf_bundle/service.md, title: offramp service }
  - { id: uc-001, resource: okf_bundle/usecases/uc-001-get.md, title: UC-001 — Get }
  - { id: printers-resource, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource }
  - { id: printer-user-details, resource: okf_bundle/components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
---

# When the ticket reports a defect

1. Map the symptom to a use case or endpoint; walk its `Steps` to the component/method most likely responsible.
2. Inspect that component's `Depends on` and `Cross-cutting` sections for the smallest correct change.
3. Keep the change minimal and local; do not alter unrelated contracts.
4. Add or strengthen a test that reproduces the defect.
5. Attest via [build & test](/architecture/build-and-test.md).

# Traversal

When a ticket reports a defect, follow this route to locate and fix it:

## Entry

Map the symptom to a use case or endpoint:

* If the ticket describes a failing API call (e.g., "POST /Printers returns 500 for valid input"), start at that API concept (e.g., [POST /Printers](/api/post-printers.md)).
* If the ticket describes a user-facing flow (e.g., "scan job upload fails at step 3"), start at the relevant use case (e.g., [UC-001 — Get](/usecases/uc-001-get.md)).
* If the ticket names a specific class or method (e.g., "NPE in PrintersResource.acceptRepresentation"), start at that component (e.g., [PrintersResource](/components/controllers/PrintersResource.md)).

## Expansion

From the entry concept, walk the `Steps` (for use cases) or `Depends on` (for components) to the method most likely responsible:

1. **Use case → Entry point** — The use case's `Entry point` field names the handler method.
2. **Endpoint → Handler component** — The API concept's `handler` field points to the controller.
3. **Handler → Dependencies** — Read the component's `Depends on` section to find the services it calls.
4. **Inspect cross-cutting concerns** — Check the component's `Cross-cutting` section (when enriched) for logging, caching, or transaction issues.

## Rules

Before proposing a fix:

* **Keep the change minimal and local** — do not alter unrelated contracts or refactor code outside the defect's scope.
* **Add or strengthen a test** that reproduces the defect — the fix should make that test pass.
* Read [coding standards](/references/conventions/coding-standards.md) to ensure the fix follows house style.

## Gate

After generating the fix:

1. Run [build & test](/architecture/build-and-test.md) — the sanctioned Maven invocation.
2. If the attestation fails, **do not propose the fix**. Revise and re-attest.
3. The new or updated test that reproduces the defect must pass.

## Sync

If the fix changes observable behavior (e.g., error messages, response codes), update the affected API or use-case concept to reflect the corrected behavior.

# Worked example

**Ticket:** "POST /Printers fails with NullPointerException when `firmwareVersion` is missing from the request."

### Step-by-step traversal

1. **Entry:** Match "POST /Printers" → [POST /Printers](/api/post-printers.md).
2. **Handler:** The endpoint's handler is [PrintersResource](/components/controllers/PrintersResource.md). Read that component.
3. **Locate the defect:** The ticket mentions `firmwareVersion`, which maps to the `setPrinterFirmwareVersion` method in [PrintersResource](/components/controllers/PrintersResource.md). Inspect that method — it likely dereferences `printerIdentification.getFirmwareVersion()` without a null check.
4. **Dependencies:** The method calls `printer.setPrinterVersion(...)`, which expects a non-null `PrinterVersion`. The defect is in [PrintersResource](/components/controllers/PrintersResource.md), not in a dependency.
5. **Minimal fix:** Add a null check in `setPrinterFirmwareVersion`:
   ```java
   if (printerIdentification.getFirmwareVersion() != null) {
       // existing logic
   }
   ```
6. **Add a test:** In `PrintersResourceTest`, add a test case that sends a registration request with `firmwareVersion` omitted, and assert that the response is 200 (or the appropriate success code) instead of 500.
7. **Attest:** Run [build & test](/architecture/build-and-test.md) — `mvn -B -q -DskipTests=false test`. The new test should pass, and no existing tests should break.
8. **Sync:** Update [POST /Printers](/api/post-printers.md) to document that `firmwareVersion` is optional (if it wasn't already documented).

This traversal touched 2 concepts ([POST /Printers](/api/post-printers.md), [PrintersResource](/components/controllers/PrintersResource.md)) and produced a minimal, local fix with a test that reproduces the defect.
