---
type: Playbook
title: Bug fix flow
description: Traversal + generation steps for a bug-fix ticket.
tags: [playbook, codegen, bug]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2026-09-13T12:41:34Z }
sources:
  - { id: service, resource: /service.md, title: offramp service root }
  - { id: post-printers, resource: /api/post-printers.md, title: POST /Printers endpoint }
  - { id: printers-resource, resource: /components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: printer-user-details, resource: /components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
  - { id: build-test, resource: /architecture/build-and-test.md, title: Build & test attestation }
  - { id: coding-standards, resource: /references/conventions/coding-standards.md, title: Coding standards }
---

# When the ticket reports a defect

1. Map the symptom to a use case or endpoint; walk its `Steps` to the component/method most likely responsible.
2. Inspect that component's `Depends on` and `Cross-cutting` sections for the smallest correct change.
3. Keep the change minimal and local; do not alter unrelated contracts.
4. Add or strengthen a test that reproduces the defect.
5. Attest via [build & test](/architecture/build-and-test.md).

## Traversal

When a ticket reports a defect, follow this route to locate and fix it:

### Entry

Map the symptom to an entry concept:

* **Use case or endpoint** — if the ticket describes a failing operation (e.g., "POST /Printers returns 500 when serial number is null"), start at [api/](/api/index.md) or [usecases/](/usecases/index.md).
* **Component** — if the ticket names a specific class or method (e.g., "PrintersResource.validateSerialNumber throws NPE"), start at [components/](/components/index.md).

### Expansion

From the entry concept, walk the call chain to the component most likely responsible:

1. **Endpoint → handler component** — follow the `handler` field in the API concept (e.g., [POST /Printers](/api/post-printers.md) → [PrintersResource](/components/controllers/PrintersResource.md)).
2. **Handler → method** — read the component's `Methods` table to find the method the ticket describes (e.g., `acceptRepresentation`, `validateSerialNumber`).
3. **Method → dependencies** — inspect the `Depends on` section and the method's logic to discover which service, manager, or client is involved in the failure (e.g., `PrinterManager`, `SimpleCacheClient`).
4. **Service → domain entities** — if the bug involves data validation or transformation, follow the method signatures to the DTOs and entities (e.g., `PrinterIdentification`, `Printer`).

### Rules

Before proposing the fix, read:

* [Coding standards](/references/conventions/coding-standards.md) — ensure the fix respects house style (error handling, null-handling, validation patterns).
* [Service context](/service.md) — the root concept's *Business context* (when enriched) may explain invariants the fix must preserve.
* [Cross-cutting concerns](/architecture/cross-cutting.md) — if the bug involves logging, caching, or security, check the cross-cutting section for patterns to follow.

### Constraints

* **Keep the change minimal and local** — fix only the defect; do not refactor unrelated code or alter contracts other components depend on.
* **Do not alter unrelated contracts** — if the fix requires changing a method signature, ensure all callers are updated (or add a new method and deprecate the old one).

### Gate

After generating the fix:

1. **Add or strengthen a test** — write a test that reproduces the defect (e.g., `testAcceptRepresentation_NullSerialNumber_ThrowsException`). The test should fail before the fix and pass after.
2. **Attest** — run [build & test](/architecture/build-and-test.md) (`mvn -B -q -DskipTests=false test`). The attester checks exit code, executed goal, and surefire summary.
3. **Refuse to propose a fix whose attestation fails.**

### Sync

After a successful fix, update the affected concepts if the fix changes behaviour:

* If the fix changes an endpoint's error responses, update the [api/](/api/index.md) concept (e.g., add "Returns 400 if serial number is null").
* If the fix adds a new validation method, update the component's `Methods` table.

Minor fixes (e.g., null checks, off-by-one errors) typically don't require concept updates unless they change the observable contract.

## Worked example

**Ticket:** *"POST /Printers returns 500 when the `serialNumber` field in the request XML is missing. Should return 400 Bad Request instead."*

### 1. Entry

The ticket describes a failing endpoint: [POST /Printers](/api/post-printers.md). Start there.

### 2. Expansion

From [POST /Printers](/api/post-printers.md), read:

* **Handler:** `SpringFinder.represent` (this is a placeholder; the real handler is [PrintersResource](/components/controllers/PrintersResource.md)).

From [PrintersResource](/components/controllers/PrintersResource.md), read:

* **Methods:** `acceptRepresentation` — the entry point for POST.
* **Depends on:** `PrinterManager`, `ICollectionServiceClient`, `SimpleCacheClient`, `StatisticsCollector`.

Inspect `acceptRepresentation` (or the source if available). It calls `createPrinterIdentification(xml)` to parse the request, then `validateSerialNumber(printerIdentification)`. The 500 suggests an uncaught exception — likely a `NullPointerException` when `serialNumber` is null.

### 3. Rules

Read [coding standards](/references/conventions/coding-standards.md):

* Validation patterns: check required fields early and throw a descriptive exception (e.g., `RegistrationDataInvalidException`).

The fix: in `validateSerialNumber`, add a null check before accessing `serialNumber`. If null, throw `RegistrationDataInvalidException("Serial number is required")`. The framework (or a filter) should map this to 400.

### 4. Generate

Produce the fix:

* In `PrintersResource.validateSerialNumber(PrinterIdentification printerIdentification)`:
  ```java
  if (printerIdentification.getSerialNumber() == null || printerIdentification.getSerialNumber().isEmpty()) {
      throw new RegistrationDataInvalidException("Serial number is required");
  }
  ```
* Add a test in `PrintersResourceTest`:
  ```java
  @Test(expectedExceptions = RegistrationDataInvalidException.class)
  public void testValidateSerialNumber_Null_ThrowsException() {
      PrinterIdentification id = new PrinterIdentification();
      id.setSerialNumber(null);
      resource.validateSerialNumber(id);
  }
  ```

### 5. Gate

Run [build & test](/architecture/build-and-test.md):

    mvn -B -q -DskipTests=false test

The attester checks:

* Exit code 0.
* Executed goal: `test`.
* Surefire summary: all tests pass (including the new test).

If the build fails, revise the fix until attestation succeeds.

### 6. Sync

Update [POST /Printers](/api/post-printers.md):

* Add to the description: "Returns 400 Bad Request if `serialNumber` is missing or empty."

Update [PrintersResource](/components/controllers/PrintersResource.md):

* No change needed — `validateSerialNumber` already exists in the *Methods* table; the fix is internal.

The bundle now reflects the corrected behaviour, ready for the next ticket.
