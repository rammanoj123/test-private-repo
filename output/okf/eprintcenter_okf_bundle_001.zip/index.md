---
okf_version: "0.2"
---

# eprintcenter

# Concepts

* [eprintcenter](service.md) - Spring service hp/eprintcenter; entry point for the OKF bundle.

# Subdirectories

* [api/](api/) - API surface
* [architecture/](architecture/) - Architecture
* [components/](components/) - Spring components
* [config/](config/) - Configuration
* [dependencies/](dependencies/) - Dependencies & ecosystem
* [domain/](domain/) - Domain model
* [ecosystem/](ecosystem/) - Ecosystem registry
* [playbooks/](playbooks/) - Playbooks
* [references/](references/) - References
* [usecases/](usecases/) - Use cases
