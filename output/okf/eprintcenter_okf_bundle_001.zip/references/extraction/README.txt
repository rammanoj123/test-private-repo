Structural extraction (verbatim)

Deterministic scanner output, embedded so this OKF bundle is the single, self-contained artifact. Enrichment reads structural detail here and algorithms from the application source. These are not OKF concepts and are not enriched.
