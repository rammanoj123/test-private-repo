# Conventions

# Concepts

* [Coding standards](coding-standards.md) - House style the code generator must follow.
