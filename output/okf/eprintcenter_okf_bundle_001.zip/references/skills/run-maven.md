---
type: Reference
title: Run Maven
---

# Run Maven

Executor for the build & test attested computation.

1. `cd` to the module root (or repo root when `module` is unset).
2. Run `mvn -B -q -DskipTests=false test` (append `-pl <module>` when `module` is provided).
3. Return a receipt: `{ exit_code, executed_goal, surefire_summary }`.
