---
type: Playbook
title: Feature enhancement flow
description: Traversal + generation steps for a feature-enhancement ticket.
tags: [playbook, codegen, feature]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

# When the ticket adds or changes behaviour

1. Identify the closest existing use case / endpoint; if none, the feature is net-new — pick the controller/service the ticket implies.
2. Prefer extending existing components over adding new ones; reuse domain entities and DTOs already in `domain/`.
3. Respect transaction boundaries from the service layer.
4. Add/adjust an API concept and a use-case concept for the new behaviour as part of the change so the bundle stays in sync.
5. Attest via [build & test](/architecture/build-and-test.md).
