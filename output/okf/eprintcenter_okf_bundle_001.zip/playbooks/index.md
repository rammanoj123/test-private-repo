# Playbooks

# Concepts

* [Bug fix flow](bug-fix.md) - Traversal + generation steps for a bug-fix ticket.
* [Feature enhancement flow](feature-enhancement.md) - Traversal + generation steps for a feature-enhancement ticket.
* [JIRA ticket → code](jira-to-code.md) - How the multi-agent code generator consumes this bundle to fulfil a ticket.
