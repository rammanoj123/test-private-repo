---
type: Playbook
title: Bug fix flow
description: Traversal + generation steps for a bug-fix ticket.
tags: [playbook, codegen, bug]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

# When the ticket reports a defect

1. Map the symptom to a use case or endpoint; walk its `Steps` to the component/method most likely responsible.
2. Inspect that component's `Depends on` and `Cross-cutting` sections for the smallest correct change.
3. Keep the change minimal and local; do not alter unrelated contracts.
4. Add or strengthen a test that reproduces the defect.
5. Attest via [build & test](/architecture/build-and-test.md).
