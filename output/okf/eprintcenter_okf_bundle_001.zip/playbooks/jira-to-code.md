---
type: Playbook
title: JIRA ticket → code
description: How the multi-agent code generator consumes this bundle to fulfil a ticket.
tags: [playbook, codegen]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

This bundle is the knowledge source for a code-generation pipeline. Given a JIRA ticket (feature or bug), the pipeline traverses the OKF graph rather than re-reading raw source.

# Procedure

1. **Locate entry concepts.** Match ticket text against concept `title`/`description`/`tags`. Endpoints, use cases and components are the usual entry points.
2. **Assemble the impacted subgraph.** From each entry concept follow links: an endpoint → its handler component → the components it *Depends on* → the domain entities they touch → the internal libraries and services involved.
3. **Cross bundles when needed.** If an impacted dependency concept has an `okf_ref`, load that bundle and repeat locally.
4. **Read the rules.** Pull [layering](/architecture/layering.md) and [coding standards](/references/conventions/coding-standards.md).
5. **Generate the change** consistent with the conventions and existing component contracts.
6. **Attest.** Run [build & test](/architecture/build-and-test.md) and refuse to propose a change whose attestation fails.

See [feature enhancement](/playbooks/feature-enhancement.md) and [bug fix](/playbooks/bug-fix.md) for the two concrete flows.
