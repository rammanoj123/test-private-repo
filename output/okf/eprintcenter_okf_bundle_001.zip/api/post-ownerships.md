---
type: API Endpoint
title: POST /ownerships
description: POST /ownerships → SpringFinder.represent (description pending enrichment).
resource: /ownerships
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
