---
type: API Endpoint
title: POST /ownerships
description: Create a new ownership record.
resource: /ownerships
tags: [api, endpoint, post, ownership, create]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
