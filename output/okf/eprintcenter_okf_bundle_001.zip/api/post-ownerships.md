---
type: API Endpoint
title: Create Ownership
description: Creates a new ownership record in the system.
resource: /ownerships
tags: [api, endpoint, post, ownership, create, record]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
