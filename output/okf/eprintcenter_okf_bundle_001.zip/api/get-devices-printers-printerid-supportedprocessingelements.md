---
type: API Endpoint
title: Get Printer Supported Processing Elements
description: Retrieves supported processing elements and capabilities available for a printer device.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, get, printer, capabilities, processing]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
