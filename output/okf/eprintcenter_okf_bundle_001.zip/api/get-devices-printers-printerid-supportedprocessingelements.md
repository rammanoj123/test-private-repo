---
type: API Endpoint
title: Get Supported Processing Elements
description: Retrieves supported processing elements for a specified printer device.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, get, printer, processing, capabilities]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
