---
type: API Endpoint
title: Delete Printer Whitelist
description: Deletes the entire whitelist for a specific printer.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, delete, whitelist, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
