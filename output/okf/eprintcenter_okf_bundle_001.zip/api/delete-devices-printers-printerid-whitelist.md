---
type: API Endpoint
title: Delete Printer Whitelist
description: Removes the entire whitelist configuration for a specified printer device.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, delete, printer, whitelist, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
