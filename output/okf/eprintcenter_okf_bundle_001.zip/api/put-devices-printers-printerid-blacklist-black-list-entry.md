---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
description: PUT /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
