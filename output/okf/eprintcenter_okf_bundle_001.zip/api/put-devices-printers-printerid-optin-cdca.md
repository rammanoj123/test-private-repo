---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/optin/cDCA
description: Update cDCA opt-in status for a specific printer.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, put, optin, cdca]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
