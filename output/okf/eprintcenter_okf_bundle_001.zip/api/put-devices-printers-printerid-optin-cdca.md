---
type: API Endpoint
title: Update CDCA Opt-In
description: Updates CDCA opt-in status for a specified printer device.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, put, printer, optin, cdca]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
