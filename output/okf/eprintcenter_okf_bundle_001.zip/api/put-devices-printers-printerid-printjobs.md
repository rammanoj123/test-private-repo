---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/printjobs/
description: PUT /devices/printers/{PrinterID}/printjobs/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
