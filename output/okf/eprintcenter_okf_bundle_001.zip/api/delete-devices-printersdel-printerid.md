---
type: API Endpoint
title: DELETE /devices/printersDel/{PrinterID}/
description: DELETE /devices/printersDel/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
