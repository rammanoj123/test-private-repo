---
type: API Endpoint
title: Delete Printer (Alternate)
description: Deletes a printer using the printersDel endpoint path.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, delete, printer, alternate]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printersDel/{PrinterID}/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
