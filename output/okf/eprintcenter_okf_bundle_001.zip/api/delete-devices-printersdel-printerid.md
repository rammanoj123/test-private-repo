---
type: API Endpoint
title: Delete Printer (Alternate)
description: Deletes a printer using the printersDel endpoint.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, delete, printer, alternate]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printersDel/{PrinterID}/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
