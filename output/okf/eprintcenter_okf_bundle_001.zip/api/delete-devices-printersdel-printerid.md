---
type: API Endpoint
title: Delete Printer (printersDel)
description: Removes a printer device from the system using the printersDel endpoint.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, delete, printer, device, removal]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printersDel/{PrinterID}/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
