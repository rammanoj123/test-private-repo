---
type: API Endpoint
title: Delete Blacklist Entry
description: Deletes a specific blacklist entry for a printer.
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, delete, blacklist, entry]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
