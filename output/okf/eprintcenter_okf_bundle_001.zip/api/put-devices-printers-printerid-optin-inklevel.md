---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/optin/inklevel/
description: PUT /devices/printers/{PrinterID}/optin/inklevel/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
