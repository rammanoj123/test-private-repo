---
type: API Endpoint
title: Update Ink Level Opt-In
description: Updates ink level monitoring opt-in status for a specified printer device.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, put, printer, optin, inklevel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
