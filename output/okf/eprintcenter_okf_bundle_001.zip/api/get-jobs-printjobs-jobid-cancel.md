---
type: API Endpoint
title: GET /jobs/printjobs/{JobID}/cancel/
description: GET /jobs/printjobs/{JobID}/cancel/ → SpringFinder.represent (description pending enrichment).
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
