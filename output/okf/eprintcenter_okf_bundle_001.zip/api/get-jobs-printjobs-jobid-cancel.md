---
type: API Endpoint
title: Get Print Job Cancellation Status
description: Retrieves cancellation status and details for a specific print job.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, get, printjob, cancel, status]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
