---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/status/
description: DELETE /devices/printers/{PrinterID}/status/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/status/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
