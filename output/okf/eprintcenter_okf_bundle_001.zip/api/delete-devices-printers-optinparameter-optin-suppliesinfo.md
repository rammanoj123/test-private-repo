---
type: API Endpoint
title: Delete Supplies Info Opt-in
description: Deletes printer supplies info opt-in configuration identified by opt-in parameter.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, delete, optin, supplies]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
