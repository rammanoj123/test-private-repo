---
type: API Endpoint
title: Delete Supplies Info Opt-in
description: Deletes supplies info opt-in configuration for a printer identified by parameter.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, delete, optin, supplies, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
