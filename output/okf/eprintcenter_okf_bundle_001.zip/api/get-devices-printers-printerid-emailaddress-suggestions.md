---
type: API Endpoint
title: Get Email Address Suggestions
description: Retrieves suggested email addresses for a specified printer device.
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, get, printer, email, suggestions]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
