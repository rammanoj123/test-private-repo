---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/emailaddress/suggestions/
description: Retrieve suggested email addresses for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, get, email, suggestions]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
