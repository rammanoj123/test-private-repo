---
type: API Endpoint
title: PUT /devices/printersDel/{PrinterID}/
description: PUT /devices/printersDel/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
