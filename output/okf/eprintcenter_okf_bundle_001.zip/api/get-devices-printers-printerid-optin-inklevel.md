---
type: API Endpoint
title: Get Ink Level Opt-In Status
description: Retrieves ink level monitoring opt-in configuration status for a printer device.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, get, optin, inklevel, monitoring]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
