---
type: API Endpoint
title: Get Ink Level Opt-In
description: Retrieves ink level monitoring opt-in status for a specified printer device.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, get, printer, optin, inklevel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
