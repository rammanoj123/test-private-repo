---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/inklevel/
description: Retrieve ink level opt-in status for a specific printer.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, get, optin, inklevel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
