---
type: API Endpoint
title: Create Printer Ownership
description: Creates a new printer ownership association.
resource: /devices/printers/ownerships
tags: [api, endpoint, post, printers, ownership, create]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /devices/printers/ownerships
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
