---
type: API Endpoint
title: POST /devices/printers/ownerships
description: POST /devices/printers/ownerships → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/ownerships
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /devices/printers/ownerships
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
