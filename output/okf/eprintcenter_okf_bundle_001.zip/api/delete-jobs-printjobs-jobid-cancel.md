---
type: API Endpoint
title: Delete Job Cancellation
description: Deletes a print job cancellation request.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, delete, job, cancel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
