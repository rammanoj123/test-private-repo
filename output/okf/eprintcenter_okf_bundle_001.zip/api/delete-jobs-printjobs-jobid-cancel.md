---
type: API Endpoint
title: Cancel Print Job (DELETE)
description: Cancels a print job by job ID using DELETE method.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, delete, printjob, cancel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
