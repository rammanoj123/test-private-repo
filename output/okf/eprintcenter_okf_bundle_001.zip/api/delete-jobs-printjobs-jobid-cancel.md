---
type: API Endpoint
title: Cancel Print Job
description: Cancels a specific print job identified by JobID.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, delete, printjob, cancel, jobs]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
