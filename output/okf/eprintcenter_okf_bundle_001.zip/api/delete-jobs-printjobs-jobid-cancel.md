---
type: API Endpoint
title: DELETE /jobs/printjobs/{JobID}/cancel/
description: DELETE /jobs/printjobs/{JobID}/cancel/ → SpringFinder.represent (description pending enrichment).
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
