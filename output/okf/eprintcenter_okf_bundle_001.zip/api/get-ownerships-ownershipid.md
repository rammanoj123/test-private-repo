---
type: API Endpoint
title: Get Ownership Details
description: Retrieves detailed information for a specific ownership record by ownership ID.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, get, ownership, details, record]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships/{OwnershipID}/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
