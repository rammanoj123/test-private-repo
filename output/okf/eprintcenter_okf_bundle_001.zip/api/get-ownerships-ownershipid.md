---
type: API Endpoint
title: GET /ownerships/{OwnershipID}/
description: GET /ownerships/{OwnershipID}/ → SpringFinder.represent (description pending enrichment).
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
