---
type: API Endpoint
title: Get API Version
description: Retrieves the API version information.
resource: /version/
tags: [api, endpoint, get, version, info]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /version/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/version/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
