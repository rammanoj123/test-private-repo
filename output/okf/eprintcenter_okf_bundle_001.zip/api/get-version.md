---
type: API Endpoint
title: GET /version/
description: Retrieve API version information.
resource: /version/
tags: [api, endpoint, get, version, metadata]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /version/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/version/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
