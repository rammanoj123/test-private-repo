---
type: API Endpoint
title: GET /version/
description: GET /version/ → SpringFinder.represent (description pending enrichment).
resource: /version/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /version/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/version/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
