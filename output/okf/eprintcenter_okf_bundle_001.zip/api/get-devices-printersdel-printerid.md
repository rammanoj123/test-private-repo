---
type: API Endpoint
title: Get Deleted Printer
description: Retrieves information about a deleted printer device.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, get, printer, deleted, device]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printersDel/{PrinterID}/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
