---
type: API Endpoint
title: Get Deleted Printer
description: Retrieves deleted printer information for a printer marked for deletion.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, get, printer, deleted, archive]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printersDel/{PrinterID}/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
