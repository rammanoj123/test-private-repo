---
type: API Endpoint
title: GET /devices/printersDel/{PrinterID}/
description: GET /devices/printersDel/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
