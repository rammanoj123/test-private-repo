---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/consumablesubscription/
description: Retrieve consumable subscription details for a specific printer.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, get, subscription, consumables]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
