---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/status/
description: PUT /devices/printers/{PrinterID}/status/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/status/
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
