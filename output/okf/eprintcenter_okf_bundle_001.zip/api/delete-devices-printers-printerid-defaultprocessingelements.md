---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/defaultprocessingelements/
description: DELETE /devices/printers/{PrinterID}/defaultprocessingelements/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
