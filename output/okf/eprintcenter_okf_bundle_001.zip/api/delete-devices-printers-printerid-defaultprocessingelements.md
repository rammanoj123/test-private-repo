---
type: API Endpoint
title: Delete Default Processing Elements
description: Deletes default processing elements configuration for a specific printer.
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, delete, defaults, processing, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
