---
type: API Endpoint
title: GET /v2/devices/printers/{PrinterID}/optin/{optinType}
description: GET /v2/devices/printers/{PrinterID}/optin/{optinType} → SpringFinder.represent (description pending enrichment).
resource: /v2/devices/printers/{PrinterID}/optin/{optinType}
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v2/devices/printers/{PrinterID}/optin/{optinType}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v2/devices/printers/{PrinterID}/optin/{optinType}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
