---
type: API Endpoint
title: Get Printer Ownerships V1
description: Retrieves printer ownership records using version 1 API endpoint format.
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, get, ownership, v1, printers]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v1/devices/printers/ownerships
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v1/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
