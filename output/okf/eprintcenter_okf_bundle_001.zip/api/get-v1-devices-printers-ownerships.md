---
type: API Endpoint
title: Get Printer Ownerships (v1)
description: Retrieves printer ownership information using v1 API endpoint.
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, get, printers, ownerships, v1]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v1/devices/printers/ownerships
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v1/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
