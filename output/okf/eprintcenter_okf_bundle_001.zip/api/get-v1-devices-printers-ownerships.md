---
type: API Endpoint
title: GET /v1/devices/printers/ownerships
description: GET /v1/devices/printers/ownerships → SpringFinder.represent (description pending enrichment).
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v1/devices/printers/ownerships
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v1/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
