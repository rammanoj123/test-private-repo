---
type: API Endpoint
title: Delete Email Address Suggestions
description: Deletes email address suggestions data for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, delete, email, suggestions]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
