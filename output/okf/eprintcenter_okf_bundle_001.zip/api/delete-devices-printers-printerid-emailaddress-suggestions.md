---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/emailaddress/suggestions/
description: DELETE /devices/printers/{PrinterID}/emailaddress/suggestions/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
