---
type: API Endpoint
title: Delete Email Address Suggestions
description: Deletes email address suggestions data for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/suggestions/
tags: [api, endpoint, delete, email, suggestions, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/suggestions/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/suggestions/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
