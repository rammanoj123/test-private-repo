---
type: API Endpoint
title: Get Printers
description: Retrieves a list of printer devices from the system.
resource: /devices/printers
tags: [api, endpoint, get, printers, list, devices]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
