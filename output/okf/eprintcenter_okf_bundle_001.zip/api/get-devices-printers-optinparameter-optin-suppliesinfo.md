---
type: API Endpoint
title: Get Supplies Info Opt-In
description: Retrieves supplies information opt-in status for a printer identified by optinParameter.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, get, printer, optin, supplies]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
