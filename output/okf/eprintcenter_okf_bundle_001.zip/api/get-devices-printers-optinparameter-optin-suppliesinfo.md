---
type: API Endpoint
title: GET /devices/printers/{optinParameter}/optin/suppliesinfo/
description: GET /devices/printers/{optinParameter}/optin/suppliesinfo/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
