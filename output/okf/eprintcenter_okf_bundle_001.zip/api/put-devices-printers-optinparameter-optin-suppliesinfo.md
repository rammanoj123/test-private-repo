---
type: API Endpoint
title: Update Supplies Info Opt-In
description: Updates supplies information opt-in configuration for a printer.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, put, printer, optin, supplies]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
