---
type: API Endpoint
title: Submit Ownership Status
description: Submits ownership status information for processing.
resource: /ownerships/status
tags: [api, endpoint, post, ownership, status, submit]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships/status
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
