---
type: API Endpoint
title: POST /ownerships/status
description: Update ownership status information.
resource: /ownerships/status
tags: [api, endpoint, post, ownership, status]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships/status
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
