---
type: API Endpoint
title: POST /ownerships/status
description: POST /ownerships/status → SpringFinder.represent (description pending enrichment).
resource: /ownerships/status
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships/status
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
