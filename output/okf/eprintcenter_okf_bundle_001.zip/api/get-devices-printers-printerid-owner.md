---
type: API Endpoint
title: Get Printer Owner
description: Retrieves owner information for a specified printer device.
resource: /devices/printers/{PrinterID}/owner/
tags: [api, endpoint, get, printer, owner, device]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/owner/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/owner/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
