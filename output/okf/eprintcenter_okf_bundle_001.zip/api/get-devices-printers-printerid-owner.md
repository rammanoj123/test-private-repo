---
type: API Endpoint
title: Get Printer Owner
description: Retrieves ownership information for a printer including the owner's user details and registration data.
resource: /devices/printers/{PrinterID}/owner/
tags: [api, endpoint, get, owner, printer, ownership]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/owner/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/owner/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
