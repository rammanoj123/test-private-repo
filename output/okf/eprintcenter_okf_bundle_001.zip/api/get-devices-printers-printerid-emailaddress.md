---
type: API Endpoint
title: Get Printer Email Address
description: Retrieves the email address assigned to a printer for receiving print jobs via email.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, get, email, printer, address]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
