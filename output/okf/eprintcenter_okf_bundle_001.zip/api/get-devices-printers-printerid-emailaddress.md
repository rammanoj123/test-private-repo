---
type: API Endpoint
title: Get Printer Email Address
description: Retrieves the email address associated with a specified printer device.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, get, printer, email, address]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
