---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
description: GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
