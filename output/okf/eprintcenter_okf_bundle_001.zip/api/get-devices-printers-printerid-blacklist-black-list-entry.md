---
type: API Endpoint
title: Get Blacklist Entry
description: Retrieves a specific blacklist entry for a printer device.
resource: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
tags: [api, endpoint, get, printer, blacklist, entry]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
