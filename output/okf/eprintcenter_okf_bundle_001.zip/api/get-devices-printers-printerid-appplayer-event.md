---
type: API Endpoint
title: Get App Player Event
description: Retrieves app player event information for a specified printer device.
resource: /devices/printers/{PrinterID}/appplayer/event/
tags: [api, endpoint, get, printer, appplayer, event]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/appplayer/event/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/appplayer/event/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
