---
type: API Endpoint
title: Get App Player Event
description: Retrieves app player event configuration and status for a printer device.
resource: /devices/printers/{PrinterID}/appplayer/event/
tags: [api, endpoint, get, appplayer, event, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/appplayer/event/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/appplayer/event/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
