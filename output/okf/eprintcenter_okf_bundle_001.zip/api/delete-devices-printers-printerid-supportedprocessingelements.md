---
type: API Endpoint
title: Delete Supported Processing Elements
description: Deletes supported processing elements for a specific printer.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, delete, supported, processing]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
