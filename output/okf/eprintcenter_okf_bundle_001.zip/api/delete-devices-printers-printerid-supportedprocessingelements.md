---
type: API Endpoint
title: Delete Supported Processing Elements
description: Removes the supported processing elements configuration for a specified printer.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, delete, printer, processing, capabilities]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
