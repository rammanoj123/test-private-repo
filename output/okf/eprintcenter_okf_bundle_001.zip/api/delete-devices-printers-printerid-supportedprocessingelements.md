---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/supportedprocessingelements/
description: DELETE /devices/printers/{PrinterID}/supportedprocessingelements/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
