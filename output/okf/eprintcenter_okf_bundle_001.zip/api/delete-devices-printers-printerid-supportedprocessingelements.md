---
type: API Endpoint
title: Delete Supported Processing Elements
description: Deletes supported processing elements configuration for a specific printer.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, delete, processing, capabilities]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
