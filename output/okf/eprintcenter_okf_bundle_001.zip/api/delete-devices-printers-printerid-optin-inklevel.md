---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/optin/inklevel/
description: DELETE /devices/printers/{PrinterID}/optin/inklevel/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
