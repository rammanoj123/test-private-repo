---
type: API Endpoint
title: Delete Ink Level Opt-in
description: Deletes ink level opt-in configuration for a specific printer.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, delete, optin, inklevel]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
