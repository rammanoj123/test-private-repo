---
type: API Endpoint
title: Delete Printer Blacklist
description: Deletes the entire blacklist for a specific printer.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, delete, blacklist, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
