---
type: API Endpoint
title: Get CDCA Opt-In Status
description: Retrieves CDCA opt-in configuration status for Connected Device Configuration and Analytics features.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, get, optin, cdca, analytics]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
