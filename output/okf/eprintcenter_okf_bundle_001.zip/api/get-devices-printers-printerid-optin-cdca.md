---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/cDCA
description: GET /devices/printers/{PrinterID}/optin/cDCA → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
