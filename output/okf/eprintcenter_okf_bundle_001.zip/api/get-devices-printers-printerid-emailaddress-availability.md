---
type: API Endpoint
title: Check Email Address Availability
description: Checks availability of an email address for a specified printer device.
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, get, printer, email, availability]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
