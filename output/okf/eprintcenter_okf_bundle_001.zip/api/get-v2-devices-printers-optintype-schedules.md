---
type: API Endpoint
title: Get Opt-In Schedules V2
description: Retrieves opt-in schedules for a specific opt-in type using version 2 API endpoint.
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, get, optin, schedules, v2]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
