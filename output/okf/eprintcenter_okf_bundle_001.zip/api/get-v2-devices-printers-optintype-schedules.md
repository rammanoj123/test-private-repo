---
type: API Endpoint
title: GET /v2/devices/printers/{optinType}/schedules
description: GET /v2/devices/printers/{optinType}/schedules → SpringFinder.represent (description pending enrichment).
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
