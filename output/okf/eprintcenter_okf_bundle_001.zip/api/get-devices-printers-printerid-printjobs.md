---
type: API Endpoint
title: Get Printer Print Jobs
description: Retrieves the list of print jobs queued or processed for a specific printer device.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, get, printjobs, printer, queue]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
