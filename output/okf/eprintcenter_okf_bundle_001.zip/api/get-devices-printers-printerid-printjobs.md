---
type: API Endpoint
title: Get Printer Print Jobs
description: Retrieves all print jobs associated with a specified printer device.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, get, printer, printjobs, jobs]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
