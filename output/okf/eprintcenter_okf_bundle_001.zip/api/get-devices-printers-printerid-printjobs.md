---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/printjobs/
description: Retrieve print jobs associated with a specific printer.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, get, printjobs, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
