---
type: API Endpoint
title: Delete Printer Opt-In by Type
description: Removes a specific opt-in configuration for a printer by opt-in type.
resource: /v2/devices/printers/{PrinterID}/optin/{optinType}
tags: [api, endpoint, delete, printer, optin, v2]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /v2/devices/printers/{PrinterID}/optin/{optinType}
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/v2/devices/printers/{PrinterID}/optin/{optinType}` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
