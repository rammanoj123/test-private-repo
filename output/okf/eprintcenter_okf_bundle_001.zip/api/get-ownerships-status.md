---
type: API Endpoint
title: Get Ownership Status
description: Retrieves ownership status information for validation and verification purposes.
resource: /ownerships/status
tags: [api, endpoint, get, ownership, status, validation]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships/status
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
