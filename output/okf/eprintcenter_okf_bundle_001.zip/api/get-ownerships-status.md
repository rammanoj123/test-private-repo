---
type: API Endpoint
title: Get Ownership Status
description: Retrieves ownership status information from the system.
resource: /ownerships/status
tags: [api, endpoint, get, ownership, status, query]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships/status
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
