---
type: API Endpoint
title: GET /ownerships/status
description: GET /ownerships/status → SpringFinder.represent (description pending enrichment).
resource: /ownerships/status
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships/status
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
