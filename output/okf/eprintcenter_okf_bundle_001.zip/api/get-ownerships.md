---
type: API Endpoint
title: Get Ownerships
description: Retrieves a list of all printer ownership records in the system.
resource: /ownerships
tags: [api, endpoint, get, ownership, list, printers]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
