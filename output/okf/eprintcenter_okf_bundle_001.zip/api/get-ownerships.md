---
type: API Endpoint
title: GET /ownerships
description: Retrieve a list of ownership records.
resource: /ownerships
tags: [api, endpoint, get, ownership, list]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /ownerships
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
