---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/
description: DELETE /devices/printers/{PrinterID}/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
