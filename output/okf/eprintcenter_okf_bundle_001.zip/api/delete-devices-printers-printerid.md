---
type: API Endpoint
title: Delete Printer
description: Deletes a printer resource by printer ID.
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, delete, printer, device, resource]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
