---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/status/
description: GET /devices/printers/{PrinterID}/status/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/status/
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
