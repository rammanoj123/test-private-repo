---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/status/
description: Retrieve status information for a specific printer.
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, get, status, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/status/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
