---
type: API Endpoint
title: Get Printer Status
description: Retrieves current operational status of a printer including state, errors, and availability information.
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, get, status, printer, state]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/status/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
