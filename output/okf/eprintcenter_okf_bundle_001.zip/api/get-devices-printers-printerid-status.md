---
type: API Endpoint
title: Get Printer Status
description: Retrieves current status information for a specified printer device.
resource: /devices/printers/{PrinterID}/status/
tags: [api, endpoint, get, printer, status, device]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/status/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/status/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
