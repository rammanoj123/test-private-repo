---
type: API Endpoint
title: Get Printer Opt-In
description: Retrieves opt-in configuration and status for a specified printer device.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, get, printer, optin, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
