---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/
description: Retrieve all opt-in settings for a specific printer.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, get, optin, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
