---
type: API Endpoint
title: Delete Email Address Availability
description: Deletes email address availability check for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, delete, email, availability]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
