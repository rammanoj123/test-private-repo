---
type: API Endpoint
title: Delete Email Address Availability
description: Deletes email address availability check data for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, delete, email, availability]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
