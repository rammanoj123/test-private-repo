---
type: API Endpoint
title: Get Printer Whitelist
description: Retrieves the whitelist entries for a printer showing allowed email addresses or domains.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, get, whitelist, printer, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
