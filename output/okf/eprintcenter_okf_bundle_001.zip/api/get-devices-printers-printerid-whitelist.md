---
type: API Endpoint
title: Get Printer Whitelist
description: Retrieves the whitelist configuration for a specified printer device.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, get, printer, whitelist, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
