---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/whitelist/
description: Retrieve the whitelist configuration for a specific printer.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, get, whitelist, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
