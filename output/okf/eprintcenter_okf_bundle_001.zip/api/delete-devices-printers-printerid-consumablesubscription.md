---
type: API Endpoint
title: Delete Consumable Subscription
description: Deletes consumable subscription configuration for a specific printer.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, delete, subscription, consumables]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
