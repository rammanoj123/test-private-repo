---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/consumablesubscription/
description: DELETE /devices/printers/{PrinterID}/consumablesubscription/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
