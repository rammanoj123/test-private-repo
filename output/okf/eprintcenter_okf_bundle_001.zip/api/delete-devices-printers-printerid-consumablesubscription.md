---
type: API Endpoint
title: Delete Consumable Subscription
description: Deletes consumable subscription configuration for a specific printer.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, delete, subscription, consumable, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
