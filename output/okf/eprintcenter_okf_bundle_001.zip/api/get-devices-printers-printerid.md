---
type: API Endpoint
title: Get Printer Details
description: Retrieves detailed information about a specific printer device.
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, get, printer, device, details]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
