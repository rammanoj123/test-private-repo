---
type: API Endpoint
title: Delete Printer Owner
description: Removes the owner association from a specified printer device.
resource: /devices/printers/{PrinterID}/owner/
tags: [api, endpoint, delete, printer, owner, device]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/owner/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/owner/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
