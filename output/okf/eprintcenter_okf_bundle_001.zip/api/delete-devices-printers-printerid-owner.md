---
type: API Endpoint
title: Delete Printer Owner
description: Deletes owner information for a specific printer.
resource: /devices/printers/{PrinterID}/owner/
tags: [api, endpoint, delete, owner, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/owner/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/owner/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
