---
type: API Endpoint
title: Delete App Player Event
description: Deletes app player event data for a specific printer.
resource: /devices/printers/{PrinterID}/appplayer/event/
tags: [api, endpoint, delete, appplayer, event, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/appplayer/event/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/appplayer/event/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
