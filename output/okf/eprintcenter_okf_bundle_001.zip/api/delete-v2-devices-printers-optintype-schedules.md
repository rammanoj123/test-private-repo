---
type: API Endpoint
title: Delete Opt-In Schedules
description: Removes opt-in schedules for a specified opt-in type.
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, delete, optin, schedules, v2]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
