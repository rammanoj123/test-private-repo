---
type: API Endpoint
title: DELETE /v2/devices/printers/{optinType}/schedules
description: DELETE /v2/devices/printers/{optinType}/schedules → SpringFinder.represent (description pending enrichment).
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
