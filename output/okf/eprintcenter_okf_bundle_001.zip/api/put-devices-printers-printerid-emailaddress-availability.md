---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/emailaddress/availability/
description: PUT /devices/printers/{PrinterID}/emailaddress/availability/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
