---
type: API Endpoint
title: Update Email Address Availability
description: Updates email address availability status for a specified printer device.
resource: /devices/printers/{PrinterID}/emailaddress/availability/
tags: [api, endpoint, put, printer, email, availability]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/availability/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/availability/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
