---
type: API Endpoint
title: Update Printer Opt-In
description: Updates opt-in configuration and status for a specified printer device.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, put, printer, optin, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
