---
type: API Endpoint
title: Get Printer Ownerships
description: Retrieves ownership information for printer devices.
resource: /devices/printers/ownerships
tags: [api, endpoint, get, printers, ownerships, devices]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/ownerships
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
