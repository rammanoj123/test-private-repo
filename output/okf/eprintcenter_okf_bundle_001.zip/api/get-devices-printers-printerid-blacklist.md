---
type: API Endpoint
title: Get Printer Blacklist
description: Retrieves the blacklist entries for a printer showing blocked email addresses or domains.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, get, blacklist, printer, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
