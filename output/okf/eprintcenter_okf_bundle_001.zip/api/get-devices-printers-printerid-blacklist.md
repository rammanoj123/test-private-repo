---
type: API Endpoint
title: Get Printer Blacklist
description: Retrieves the blacklist configuration for a specified printer device.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, get, printer, blacklist, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
