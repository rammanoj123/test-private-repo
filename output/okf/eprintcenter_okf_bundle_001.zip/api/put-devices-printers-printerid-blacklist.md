---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/blacklist/
description: Update blacklist configuration for a specific printer.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, put, blacklist, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
