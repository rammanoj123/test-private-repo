---
type: API Endpoint
title: Update Printer Blacklist
description: Updates the blacklist configuration for a specified printer device.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, put, printer, blacklist, security]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
