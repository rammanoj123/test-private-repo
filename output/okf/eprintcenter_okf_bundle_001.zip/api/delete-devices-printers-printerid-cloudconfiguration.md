---
type: API Endpoint
title: Delete Cloud Configuration
description: Deletes cloud configuration for a specific printer.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, delete, cloud, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
