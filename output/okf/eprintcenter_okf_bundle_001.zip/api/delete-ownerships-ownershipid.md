---
type: API Endpoint
title: Delete Ownership
description: Removes an ownership association identified by OwnershipID from the system.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, delete, ownership, association, device]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /ownerships/{OwnershipID}/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
