---
type: API Endpoint
title: Delete Ownership
description: Deletes a printer ownership record by ownership ID.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, delete, ownership]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /ownerships/{OwnershipID}/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
