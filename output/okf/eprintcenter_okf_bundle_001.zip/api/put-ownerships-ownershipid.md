---
type: API Endpoint
title: PUT /ownerships/{OwnershipID}/
description: Update a specific ownership record by ownership identifier.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, put, ownership, update]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
