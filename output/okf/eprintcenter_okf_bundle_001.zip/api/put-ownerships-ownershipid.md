---
type: API Endpoint
title: PUT /ownerships/{OwnershipID}/
description: PUT /ownerships/{OwnershipID}/ → SpringFinder.represent (description pending enrichment).
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
