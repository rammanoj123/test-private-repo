---
type: API Endpoint
title: Delete Whitelist Entry
description: Deletes a specific whitelist entry for a printer.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, delete, whitelist, entry]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
