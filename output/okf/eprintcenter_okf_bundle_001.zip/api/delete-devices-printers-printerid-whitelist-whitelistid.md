---
type: API Endpoint
title: Delete Whitelist Entry
description: Deletes a specific whitelist entry from a printer's whitelist.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, delete, whitelist, entry]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
