---
type: API Endpoint
title: Delete Whitelist Entry
description: Removes a specific whitelist entry identified by WhiteListID from a printer.
resource: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
tags: [api, endpoint, delete, printer, whitelist, entry]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/{WhiteListID}/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/{WhiteListID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
