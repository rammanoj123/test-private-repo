---
type: API Endpoint
title: Delete Printer Whitelist
description: Deletes printer whitelist configuration.
resource: /devices/printers/{PrinterID}/printerwhitelist/
tags: [api, endpoint, delete, whitelist, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/printerwhitelist/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/printerwhitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
