---
type: API Endpoint
title: Delete Printer Print Jobs
description: Deletes print jobs for a specific printer.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, delete, printjobs, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
