---
type: API Endpoint
title: Delete Print Jobs
description: Deletes print jobs for a specific printer.
resource: /devices/printers/{PrinterID}/printjobs/
tags: [api, endpoint, delete, printjobs, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/printjobs/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/printjobs/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
