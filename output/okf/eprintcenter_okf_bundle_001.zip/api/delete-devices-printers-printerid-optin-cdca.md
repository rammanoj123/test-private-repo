---
type: API Endpoint
title: Delete CDCA Opt-in
description: Deletes CDCA opt-in configuration for a specific printer.
resource: /devices/printers/{PrinterID}/optin/cDCA
tags: [api, endpoint, delete, optin, cdca]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/cDCA
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/cDCA` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
