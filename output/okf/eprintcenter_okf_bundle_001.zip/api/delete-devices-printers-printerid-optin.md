---
type: API Endpoint
title: Delete Opt-in Configuration
description: Deletes opt-in configuration for a specific printer.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, delete, optin, configuration, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
