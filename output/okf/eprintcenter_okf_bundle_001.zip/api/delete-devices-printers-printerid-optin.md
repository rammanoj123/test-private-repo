---
type: API Endpoint
title: Delete Opt-in Configuration
description: Deletes opt-in configuration for a specific printer.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, delete, optin, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
