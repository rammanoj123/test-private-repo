---
type: API Endpoint
title: Update Default Processing Elements
description: Updates default processing elements configuration for a specified printer.
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, put, printer, processing, defaults]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
