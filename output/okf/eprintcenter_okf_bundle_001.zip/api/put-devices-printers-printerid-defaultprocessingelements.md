---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/defaultprocessingelements/
description: PUT /devices/printers/{PrinterID}/defaultprocessingelements/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
