---
type: API Endpoint
title: Update Consumable Subscription
description: Updates consumable subscription information for a specified printer device.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, put, printer, subscription, consumables]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
