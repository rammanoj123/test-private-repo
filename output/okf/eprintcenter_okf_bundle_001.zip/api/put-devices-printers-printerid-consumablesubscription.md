---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/consumablesubscription/
description: Update consumable subscription details for a specific printer.
resource: /devices/printers/{PrinterID}/consumablesubscription/
tags: [api, endpoint, put, subscription, consumables]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/consumablesubscription/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/consumablesubscription/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
