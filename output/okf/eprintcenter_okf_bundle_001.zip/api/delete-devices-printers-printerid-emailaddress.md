---
type: API Endpoint
title: Delete Printer Email Address
description: Deletes email address for a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, delete, email, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
