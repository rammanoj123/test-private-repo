---
type: API Endpoint
title: Delete Printer Email Address
description: Deletes the email address associated with a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, delete, email, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
