---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/cloudconfiguration/
description: Update cloud configuration settings for a specific printer.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, put, cloud, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
