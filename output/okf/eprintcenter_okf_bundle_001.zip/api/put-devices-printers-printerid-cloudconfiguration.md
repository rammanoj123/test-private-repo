---
type: API Endpoint
title: Update Cloud Configuration
description: Updates cloud configuration settings for a specified printer device.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, put, printer, cloud, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
