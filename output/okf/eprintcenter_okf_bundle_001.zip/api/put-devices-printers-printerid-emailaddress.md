---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/emailaddress/
description: PUT /devices/printers/{PrinterID}/emailaddress/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
