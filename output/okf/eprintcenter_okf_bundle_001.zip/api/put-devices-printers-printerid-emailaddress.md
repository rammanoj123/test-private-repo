---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/emailaddress/
description: Update the email address assigned to a specific printer.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, put, email, printer]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
