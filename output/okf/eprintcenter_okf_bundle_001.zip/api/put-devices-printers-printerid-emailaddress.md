---
type: API Endpoint
title: Update Printer Email Address
description: Updates the email address associated with a specified printer device.
resource: /devices/printers/{PrinterID}/emailaddress/
tags: [api, endpoint, put, printer, email, address]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/emailaddress/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/emailaddress/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
