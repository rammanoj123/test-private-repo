---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/cloudconfiguration/
description: GET /devices/printers/{PrinterID}/cloudconfiguration/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
