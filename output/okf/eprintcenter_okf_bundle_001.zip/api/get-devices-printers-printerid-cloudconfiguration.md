---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/cloudconfiguration/
description: Retrieve cloud configuration settings for a specific printer.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, get, cloud, configuration]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
