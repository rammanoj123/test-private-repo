---
type: API Endpoint
title: Submit API Version
description: Submits API version information to the system.
resource: /version/
tags: [api, endpoint, post, version, submit]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /version/
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/version/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
