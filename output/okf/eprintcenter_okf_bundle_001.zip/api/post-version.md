---
type: API Endpoint
title: POST /version/
description: POST /version/ → SpringFinder.represent (description pending enrichment).
resource: /version/
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /version/
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/version/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
