---
type: API Endpoint
title: POST /devices/printers
description: POST /devices/printers → SpringFinder.represent (description pending enrichment).
resource: /devices/printers
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /devices/printers
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/devices/printers` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
