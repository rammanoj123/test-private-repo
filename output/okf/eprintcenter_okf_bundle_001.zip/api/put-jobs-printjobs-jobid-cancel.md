---
type: API Endpoint
title: PUT /jobs/printjobs/{JobID}/cancel/
description: PUT /jobs/printjobs/{JobID}/cancel/ → SpringFinder.represent (description pending enrichment).
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
