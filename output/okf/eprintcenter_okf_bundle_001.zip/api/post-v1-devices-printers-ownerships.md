---
type: API Endpoint
title: Create Printer Ownership (v1)
description: Creates a new printer ownership using v1 API endpoint.
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, post, printers, ownership, v1]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /v1/devices/printers/ownerships
generated: { by: claude-3.7-sonnet, at: 2026-09-20T06:15:00Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/v1/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
