# Ecosystem registry

# Concepts

* [Ecosystem & dependency registry](ecosystem.md) - Federation registry: this service plus every library and service it depends on.
