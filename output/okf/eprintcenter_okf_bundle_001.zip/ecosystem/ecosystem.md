---
type: System
title: Ecosystem & dependency registry
description: "Federation registry: this service plus every library and service it depends on."
tags: [ecosystem, registry, dependencies]
status: draft
okf_bundle_id: hp/eprintcenter
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

The registry of every bundle this service knows about. It is the spine of the federation: each internal library and dependent service is a concept here, and as each one is itself documented in OKF, its `okf_ref` is filled in and consumers can traverse the whole graph across bundles.

# Bundles

| Coordinate / name | Kind | Bundle id | Concept | Own bundle documented? |
| --- | --- | --- | --- | --- |
| **this** | Service | hp/eprintcenter | [service.md](/service.md) | yes |
| com.hp.cloudprint:printer:${printer.version} | Internal Library | hp/printer | [printer](/dependencies/internal/printer.md) | no |
| com.hp.cloudprint:devicecapabilities:25.1.5 | Internal Library | hp/devicecapabilities | [devicecapabilities](/dependencies/internal/devicecapabilities.md) | no |
| com.hp.cloudprint:metrics:25.1.4 | Internal Library | hp/metrics | [metrics](/dependencies/internal/metrics.md) | no |
| org.restlet:org.restlet:1.1.6 | Dependency | — | [org-restlet-org-restlet](/dependencies/external/org-restlet-org-restlet.md) | n/a |
| com.noelios.restlet:com.noelios.restlet:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet](/dependencies/external/com-noelios-restlet-com-noelios-restlet.md) | n/a |
| com.noelios.restlet:com.noelios.restlet.ext.servlet:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet-ext-servlet](/dependencies/external/com-noelios-restlet-com-noelios-restlet-ext-servlet.md) | n/a |
| org.aspectj:aspectjweaver:1.9.20.1 | Dependency | — | [org-aspectj-aspectjweaver](/dependencies/external/org-aspectj-aspectjweaver.md) | n/a |
| org.springframework:spring-aspects:${spring.version} | Dependency | — | [org-springframework-spring-aspects](/dependencies/external/org-springframework-spring-aspects.md) | n/a |
| com.hp.cloudprint:util:25.1.4 | Internal Library | hp/util | [util](/dependencies/internal/util.md) | no |
| com.hp.cloudprint:pjpservices:25.1.5 | Internal Library | hp/pjpservices | [pjpservices](/dependencies/internal/pjpservices.md) | no |
| com.hp.cloudprint:pumavalidator:25.3.4.2 | Internal Library | hp/pumavalidator | [pumavalidator](/dependencies/internal/pumavalidator.md) | no |
| com.hp.cloudprint:pumavalidatelib:25.3.4.2 | Internal Library | hp/pumavalidatelib | [pumavalidatelib](/dependencies/internal/pumavalidatelib.md) | no |
| com.hp.cloudprint:eprintUserDirectory:25.1.4 | Internal Library | hp/eprintuserdirectory | [eprintuserdirectory](/dependencies/internal/eprintuserdirectory.md) | no |
| com.hp.cloudprint:sjpservices:25.1.5 | Internal Library | hp/sjpservices | [sjpservices](/dependencies/internal/sjpservices.md) | no |
| commons-cli:commons-cli:1.6.0 | Dependency | — | [commons-cli-commons-cli](/dependencies/external/commons-cli-commons-cli.md) | n/a |
| cglib:cglib-nodep:3.3.0 | Dependency | — | [cglib-cglib-nodep](/dependencies/external/cglib-cglib-nodep.md) | n/a |
| cglib:cglib:3.3.0 | Dependency | — | [cglib-cglib](/dependencies/external/cglib-cglib.md) | n/a |
| com.hp.cloudprint:pjpcommon:25.1.5 | Internal Library | hp/pjpcommon | [pjpcommon](/dependencies/internal/pjpcommon.md) | no |
| org.testng:testng:${testng.version} | Dependency | — | [org-testng-testng](/dependencies/external/org-testng-testng.md) | n/a |
| org.powermock:powermock-module-testng:${powermock.version} | Dependency | — | [org-powermock-powermock-module-testng](/dependencies/external/org-powermock-powermock-module-testng.md) | n/a |
| org.powermock:powermock-api-mockito:${powermock.version} | Dependency | — | [org-powermock-powermock-api-mockito](/dependencies/external/org-powermock-powermock-api-mockito.md) | n/a |
| org.mockito:mockito-core:5.8.0 | Dependency | — | [org-mockito-mockito-core](/dependencies/external/org-mockito-mockito-core.md) | n/a |
| org.springframework:spring-test:${spring.version} | Dependency | — | [org-springframework-spring-test](/dependencies/external/org-springframework-spring-test.md) | n/a |
| com.hp.cloudprint:rest-common:25.1.4 | Internal Library | hp/rest-common | [rest-common](/dependencies/internal/rest-common.md) | no |
| com.hp.cloudprint:pumaclient:25.1.5 | Internal Library | hp/pumaclient | [pumaclient](/dependencies/internal/pumaclient.md) | no |
| com.hp.cloudprint:papiclients:25.1.5 | Internal Library | hp/papiclients | [papiclients](/dependencies/internal/papiclients.md) | no |
| com.hp.ipg.iws.wp:printerlist-schema:${ukas-wp-version} | Internal Library | hp/printerlist-schema | [printerlist-schema](/dependencies/internal/printerlist-schema.md) | no |
| com.hp.iws.wpp:wp-common-web:${wp-common-version} | Internal Library | hp/wp-common-web | [wp-common-web](/dependencies/internal/wp-common-web.md) | no |
| com.hp.iws.wpp:wp-common:${wp-common-version} | Internal Library | hp/wp-common | [wp-common](/dependencies/internal/wp-common.md) | no |
| com.hp.iws.wpp:wpp-base-schema:${wpp-version} | Internal Library | hp/wpp-base-schema | [wpp-base-schema](/dependencies/internal/wpp-base-schema.md) | no |
| org.springframework.security:spring-security-core:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-core](/dependencies/external/org-springframework-security-spring-security-core.md) | n/a |
| org.springframework.security:spring-security-acl:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-acl](/dependencies/external/org-springframework-security-spring-security-acl.md) | n/a |
| com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6 | Dependency | — | [com-noelios-restlet-com-noelios-restlet-ext-spring](/dependencies/external/com-noelios-restlet-com-noelios-restlet-ext-spring.md) | n/a |
| org.restlet:org.restlet.ext.spring:1.1.6 | Dependency | — | [org-restlet-org-restlet-ext-spring](/dependencies/external/org-restlet-org-restlet-ext-spring.md) | n/a |
| net.sf.ehcache:ehcache:1.3.0 | Dependency | — | [net-sf-ehcache-ehcache](/dependencies/external/net-sf-ehcache-ehcache.md) | n/a |
| com.hp.cloudprint:security:25.1.4 | Internal Library | hp/security | [security](/dependencies/internal/security.md) | no |
| com.sun.jersey:jersey-client:1.10 | Dependency | — | [com-sun-jersey-jersey-client](/dependencies/external/com-sun-jersey-jersey-client.md) | n/a |
| com.sun.jersey.contribs:jersey-multipart:1.10 | Dependency | — | [com-sun-jersey-contribs-jersey-multipart](/dependencies/external/com-sun-jersey-contribs-jersey-multipart.md) | n/a |
| com.sun.jersey:jersey-core:1.10 | Dependency | — | [com-sun-jersey-jersey-core](/dependencies/external/com-sun-jersey-jersey-core.md) | n/a |
| com.hp.cloudprint:eprintcenter-schema:25.1.4 | Internal Library | hp/eprintcenter-schema | [eprintcenter-schema](/dependencies/internal/eprintcenter-schema.md) | no |
| com.hp.cloudprint:httpclient-util:25.1.4 | Internal Library | hp/httpclient-util | [httpclient-util](/dependencies/internal/httpclient-util.md) | no |
| com.nimbusds:nimbus-jose-jwt:9.25.1 | Dependency | — | [com-nimbusds-nimbus-jose-jwt](/dependencies/external/com-nimbusds-nimbus-jose-jwt.md) | n/a |
| com.hp.cloudprint:ePrintLogger:25.1.4 | Internal Library | hp/eprintlogger | [eprintlogger](/dependencies/internal/eprintlogger.md) | no |
| org.springframework:spring-core:${spring.version} | Dependency | — | [org-springframework-spring-core](/dependencies/external/org-springframework-spring-core.md) | n/a |
| org.springframework:spring-beans:${spring.version} | Dependency | — | [org-springframework-spring-beans](/dependencies/external/org-springframework-spring-beans.md) | n/a |
| org.springframework:spring-context:${spring.version} | Dependency | — | [org-springframework-spring-context](/dependencies/external/org-springframework-spring-context.md) | n/a |
| org.springframework:spring-aop:${spring.version} | Dependency | — | [org-springframework-spring-aop](/dependencies/external/org-springframework-spring-aop.md) | n/a |
| org.springframework:spring-aspects:${spring.version} | Dependency | — | [org-springframework-spring-aspects-2](/dependencies/external/org-springframework-spring-aspects-2.md) | n/a |
| org.springframework:spring-context-support:${spring.version} | Dependency | — | [org-springframework-spring-context-support](/dependencies/external/org-springframework-spring-context-support.md) | n/a |
| org.springframework:spring-web:${spring.version} | Dependency | — | [org-springframework-spring-web](/dependencies/external/org-springframework-spring-web.md) | n/a |
| org.springframework:spring-webmvc:${spring.version} | Dependency | — | [org-springframework-spring-webmvc](/dependencies/external/org-springframework-spring-webmvc.md) | n/a |
| org.springframework:spring-test:${spring.version} | Dependency | — | [org-springframework-spring-test-2](/dependencies/external/org-springframework-spring-test-2.md) | n/a |
| org.springframework:spring-expression:${spring.version} | Dependency | — | [org-springframework-spring-expression](/dependencies/external/org-springframework-spring-expression.md) | n/a |
| org.springframework:spring-orm:${spring.version} | Dependency | — | [org-springframework-spring-orm](/dependencies/external/org-springframework-spring-orm.md) | n/a |
| org.springframework:spring-tx:${spring.version} | Dependency | — | [org-springframework-spring-tx](/dependencies/external/org-springframework-spring-tx.md) | n/a |
| org.springframework:spring-jdbc:${spring.version} | Dependency | — | [org-springframework-spring-jdbc](/dependencies/external/org-springframework-spring-jdbc.md) | n/a |
| org.springframework.security:spring-security-config:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-config](/dependencies/external/org-springframework-security-spring-security-config.md) | n/a |
| org.springframework.security:spring-security-web:${springframework.security.version} | Dependency | — | [org-springframework-security-spring-security-web](/dependencies/external/org-springframework-security-spring-security-web.md) | n/a |
| org.springframework.security.oauth:spring-security-oauth:${spring-security-oauth.version} | Dependency | — | [org-springframework-security-oauth-spring-security-oauth](/dependencies/external/org-springframework-security-oauth-spring-security-oauth.md) | n/a |
| org.glassfish.jaxb:jaxb-runtime:4.0.4 | Dependency | — | [org-glassfish-jaxb-jaxb-runtime](/dependencies/external/org-glassfish-jaxb-jaxb-runtime.md) | n/a |
| com.hp.cloudprint:jefapi:25.1.4 | Internal Library | hp/jefapi | [jefapi](/dependencies/internal/jefapi.md) | no |
| com.hp.cloudprint:pjpworksteps:25.1.5 | Internal Library | hp/pjpworksteps | [pjpworksteps](/dependencies/internal/pjpworksteps.md) | no |
| com.hp.cloudprint:pjpworkstepsutil:25.1.5 | Internal Library | hp/pjpworkstepsutil | [pjpworkstepsutil](/dependencies/internal/pjpworkstepsutil.md) | no |
| com.hp.cloudprint:storage-client:25.1.4 | Internal Library | hp/storage-client | [storage-client](/dependencies/internal/storage-client.md) | no |
| com.hp.cloudprint:validateclient:25.4.4 | Internal Library | hp/validateclient | [validateclient](/dependencies/internal/validateclient.md) | no |
| com.hp.cloudprint:eventLogger:25.1.4 | Internal Library | hp/eventlogger | [eventlogger](/dependencies/internal/eventlogger.md) | no |
| com.hp.cloudprint:cjputil:25.1.4 | Internal Library | hp/cjputil | [cjputil](/dependencies/internal/cjputil.md) | no |
| com.hp.cloudprint:eprintDirectory:25.1.4 | Internal Library | hp/eprintdirectory | [eprintdirectory](/dependencies/internal/eprintdirectory.md) | no |
| com.hp.cloudprint:eventingcommon:25.1.4 | Internal Library | hp/eventingcommon | [eventingcommon](/dependencies/internal/eventingcommon.md) | no |
| com.fasterxml.jackson.core:jackson-annotations:2.15.2 | Dependency | — | [com-fasterxml-jackson-core-jackson-annotations](/dependencies/external/com-fasterxml-jackson-core-jackson-annotations.md) | n/a |
| org.apache.commons:commons-configuration2:2.9.0 | Dependency | — | [org-apache-commons-commons-configuration2](/dependencies/external/org-apache-commons-commons-configuration2.md) | n/a |
| com.fasterxml.jackson.core:jackson-core:2.15.2 | Dependency | — | [com-fasterxml-jackson-core-jackson-core](/dependencies/external/com-fasterxml-jackson-core-jackson-core.md) | n/a |
| org.apache.commons:commons-lang3:3.14.0 | Dependency | — | [org-apache-commons-commons-lang3](/dependencies/external/org-apache-commons-commons-lang3.md) | n/a |
| org.codehaus.jackson:jackson-mapper-asl:1.9.13 | Dependency | — | [org-codehaus-jackson-jackson-mapper-asl](/dependencies/external/org-codehaus-jackson-jackson-mapper-asl.md) | n/a |
| com.hp.cloudprint:notification-common:25.2.3 | Internal Library | hp/notification-common | [notification-common](/dependencies/internal/notification-common.md) | no |
| commons-codec:commons-codec:1.17.2 | Dependency | — | [commons-codec-commons-codec](/dependencies/external/commons-codec-commons-codec.md) | n/a |
| org.aspectj:aspectjrt:1.9.20.1 | Dependency | — | [org-aspectj-aspectjrt](/dependencies/external/org-aspectj-aspectjrt.md) | n/a |
| org.apache.httpcomponents:httpcore:4.4.13 | Dependency | — | [org-apache-httpcomponents-httpcore](/dependencies/external/org-apache-httpcomponents-httpcore.md) | n/a |
| com.fasterxml.jackson.core:jackson-databind:2.15.2 | Dependency | — | [com-fasterxml-jackson-core-jackson-databind](/dependencies/external/com-fasterxml-jackson-core-jackson-databind.md) | n/a |
| com.hp.cloudprint:notification-client:25.2.3 | Internal Library | hp/notification-client | [notification-client](/dependencies/internal/notification-client.md) | no |
| com.hp.swp:papi-base-schema:13.17.3 | Internal Library | hp/papi-base-schema | [papi-base-schema](/dependencies/internal/papi-base-schema.md) | no |
| com.hp.cloudprint:channelinterfaces:25.1.4 | Internal Library | hp/channelinterfaces | [channelinterfaces](/dependencies/internal/channelinterfaces.md) | no |
| commons-io:commons-io:2.18.0 | Dependency | — | [commons-io-commons-io](/dependencies/external/commons-io-commons-io.md) | n/a |
| org.codehaus.jackson:jackson-core-asl:1.9.2 | Dependency | — | [org-codehaus-jackson-jackson-core-asl](/dependencies/external/org-codehaus-jackson-jackson-core-asl.md) | n/a |
| com.mchange:c3p0:0.9.5.5 | Dependency | — | [com-mchange-c3p0](/dependencies/external/com-mchange-c3p0.md) | n/a |
| org.slf4j:slf4j-api:${slf4j.version} | Dependency | — | [org-slf4j-slf4j-api](/dependencies/external/org-slf4j-slf4j-api.md) | n/a |
| com.hp.cloudprint:entities:25.3.5 | Internal Library | hp/entities | [entities](/dependencies/internal/entities.md) | no |
| mysql:mysql-connector-java:8.0.11 | Dependency | — | [mysql-mysql-connector-java](/dependencies/external/mysql-mysql-connector-java.md) | n/a |
| com.hp.cloudprint:snoobe-client:25.1.4 | Internal Library | hp/snoobe-client | [snoobe-client](/dependencies/internal/snoobe-client.md) | no |
| com.hp.wpp:wpp-json-logging-adaptor:1.0.13 | Internal Library | hp/wpp-json-logging-adaptor | [wpp-json-logging-adaptor](/dependencies/internal/wpp-json-logging-adaptor.md) | no |
| com.hp.wpp:wpp-logger:2.2.14 | Internal Library | hp/wpp-logger | [wpp-logger](/dependencies/internal/wpp-logger.md) | no |
| ch.qos.logback:logback-classic:1.5.18 | Dependency | — | [ch-qos-logback-logback-classic](/dependencies/external/ch-qos-logback-logback-classic.md) | n/a |
| ch.qos.logback:logback-core:1.5.18 | Dependency | — | [ch-qos-logback-logback-core](/dependencies/external/ch-qos-logback-logback-core.md) | n/a |

# How this stays extensible

* A new dependency appears in `codebase_context.json` → the generator adds a concept under `dependencies/` and a row here automatically.
* When that dependency publishes its own OKF bundle, the ecosystem cartographer agent sets the concept's `okf_ref` to its location and flips the last column to `yes`.
* Nothing in a consumer breaks when a row is unresolved: broken/absent cross-bundle refs are tolerated by the OKF spec (§11).
