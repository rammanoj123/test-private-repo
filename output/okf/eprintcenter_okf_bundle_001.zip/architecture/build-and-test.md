---
type: Attested Computation
title: Build & test
description: The blessed Maven build/test the codegen pipeline attests against.
tags: [build, test, ci]
status: draft
runtime: maven
parameters:
  - { name: module, type: string, required: false }
executor:
  resource: /references/skills/run-maven.md
  receipt: [exit_code, executed_goal, surefire_summary]
attester: { resource: /references/attesters/maven_build.py }
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

Sanctioned build + unit-test invocation for this service. The code generator MUST run this after producing a change and MUST NOT display a change whose attestation fails.

# Computation

    mvn -B -q -DskipTests=false test

Binds only the declared parameters; the runner supplies `-pl <module>` when `module` is set. The attester compares the executed goal and the surefire summary in the receipt against this sanctioned invocation.
