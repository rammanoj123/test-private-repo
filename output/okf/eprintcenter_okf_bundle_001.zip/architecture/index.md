# Architecture

# Concepts

* [Build & test](build-and-test.md) - The blessed Maven build/test the codegen pipeline attests against.
* [Architecture & layering](layering.md) - XML-configured Spring layering and the conventions code generation must respect.
