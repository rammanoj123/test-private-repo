---
type: Reference
title: Architecture & layering
description: XML-configured Spring layering and the conventions code generation must respect.
tags: [architecture, conventions]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

Wiring style: **XML-configured** (135 legacy XML beans present).

# Layers

Components are organized by responsibility. Requests flow inward (controller → service → repository) and never the reverse.

| Layer | Directory | Role |
| --- | --- | --- |
| Controller | components/controllers/ | HTTP entry points; no business logic |
| Service | components/services/ | business rules, transactions |
| Repository | components/repositories/ | persistence access |
| Domain | domain/ | entities, DTOs, value objects |
| Config | components/config/ | wiring, beans, cross-cutting |

# Conventions

* Transaction boundaries live on service methods (see per-component `Cross-cutting` sections).
* Persistence goes through repositories only.
* New endpoints must link to a use case and reuse existing DTOs where possible.

See [coding standards](/references/conventions/coding-standards.md) for the full house style the code generator must follow.
