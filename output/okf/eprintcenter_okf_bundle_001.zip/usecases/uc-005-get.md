---
type: Use Case
title: UC-005 — Get
description: Retrieve suggested email addresses for a printer.
tags: [usecase, email, suggestions, printer]
status: draft
usecase_id: UC-005
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-005 |
| Trigger | GET /devices/printers/{PrinterID}/emailaddress/suggestions/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
