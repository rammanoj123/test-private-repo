---
type: Use Case
title: UC-008 — Get
description: Retrieve list of ownership records.
tags: [usecase, ownership, list, api]
status: draft
usecase_id: UC-008
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-008 |
| Trigger | GET /ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
