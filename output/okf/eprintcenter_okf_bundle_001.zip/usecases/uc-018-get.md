---
type: Use Case
title: UC-018 — Get
description: GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-018
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Field | Value |
| --- | --- |
| Id | UC-018 |
| Trigger | GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
