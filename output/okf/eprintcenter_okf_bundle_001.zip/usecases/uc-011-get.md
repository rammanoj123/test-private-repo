---
type: Use Case
title: UC-011 — Get
description: Retrieve specific ownership record by identifier.
tags: [usecase, ownership, details, api]
status: draft
usecase_id: UC-011
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-011 |
| Trigger | GET /ownerships/{OwnershipID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
