---
type: Use Case
title: UC-004 — Get
description: GET /devices/printers/{PrinterID}/emailaddress/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-004
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Field | Value |
| --- | --- |
| Id | UC-004 |
| Trigger | GET /devices/printers/{PrinterID}/emailaddress/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
