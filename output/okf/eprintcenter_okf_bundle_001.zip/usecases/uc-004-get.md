---
type: Use Case
title: UC-004 — Get
description: Retrieve email address assigned to a printer.
tags: [usecase, email, printer, api]
status: draft
usecase_id: UC-004
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-004 |
| Trigger | GET /devices/printers/{PrinterID}/emailaddress/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
