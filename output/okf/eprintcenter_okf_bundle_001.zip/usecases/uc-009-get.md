---
type: Use Case
title: UC-009 — Get
description: GET /devices/printers/ownerships (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-009
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Field | Value |
| --- | --- |
| Id | UC-009 |
| Trigger | GET /devices/printers/ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
