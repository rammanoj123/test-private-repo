---
type: Use Case
title: UC-009 — Get
description: Retrieve printer ownership records.
tags: [usecase, ownership, printer, api]
status: draft
usecase_id: UC-009
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-009 |
| Trigger | GET /devices/printers/ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
