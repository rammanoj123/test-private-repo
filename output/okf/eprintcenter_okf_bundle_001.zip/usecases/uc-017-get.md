---
type: Use Case
title: UC-017 — Get
description: GET /devices/printers/{PrinterID}/defaultprocessingelements/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-017
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

| Field | Value |
| --- | --- |
| Id | UC-017 |
| Trigger | GET /devices/printers/{PrinterID}/defaultprocessingelements/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
