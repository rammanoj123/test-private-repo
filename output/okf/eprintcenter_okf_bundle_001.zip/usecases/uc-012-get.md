---
type: Use Case
title: UC-012 — Get
description: Retrieve detailed printer information by identifier.
tags: [usecase, printer, details, api]
status: draft
usecase_id: UC-012
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-012 |
| Trigger | GET /devices/printers/{PrinterID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
