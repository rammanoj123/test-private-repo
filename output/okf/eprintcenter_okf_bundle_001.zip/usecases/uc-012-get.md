---
type: Use Case
title: UC-012 — Get
description: GET /devices/printers/{PrinterID}/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-012
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Field | Value |
| --- | --- |
| Id | UC-012 |
| Trigger | GET /devices/printers/{PrinterID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
