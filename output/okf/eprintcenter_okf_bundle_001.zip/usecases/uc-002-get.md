---
type: Use Case
title: UC-002 — Get
description: Retrieve print job cancellation details by job identifier.
tags: [usecase, printjob, cancel, api]
status: draft
usecase_id: UC-002
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-002 |
| Trigger | GET /jobs/printjobs/{JobID}/cancel/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
