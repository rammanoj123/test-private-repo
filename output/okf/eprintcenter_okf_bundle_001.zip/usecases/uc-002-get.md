---
type: Use Case
title: UC-002 — Get
description: GET /jobs/printjobs/{JobID}/cancel/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-002
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Field | Value |
| --- | --- |
| Id | UC-002 |
| Trigger | GET /jobs/printjobs/{JobID}/cancel/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
