---
type: Use Case
title: UC-010 — Get
description: GET /v1/devices/printers/ownerships (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-010
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Field | Value |
| --- | --- |
| Id | UC-010 |
| Trigger | GET /v1/devices/printers/ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
