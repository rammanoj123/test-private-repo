---
type: Use Case
title: UC-010 — Get
description: Retrieve printer ownership records via versioned API.
tags: [usecase, ownership, printer, versioned]
status: draft
usecase_id: UC-010
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-010 |
| Trigger | GET /v1/devices/printers/ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
