---
type: Use Case
title: UC-028 — Get
description: GET /devices/printers/{PrinterID}/blacklist/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-028
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Field | Value |
| --- | --- |
| Id | UC-028 |
| Trigger | GET /devices/printers/{PrinterID}/blacklist/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
