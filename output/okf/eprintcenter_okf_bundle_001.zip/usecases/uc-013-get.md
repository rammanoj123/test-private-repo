---
type: Use Case
title: UC-013 — Get
description: GET /devices/printersDel/{PrinterID}/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-013
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Field | Value |
| --- | --- |
| Id | UC-013 |
| Trigger | GET /devices/printersDel/{PrinterID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
