# Use cases

# Concepts

* [UC-001 — Get](uc-001-get.md) - GET /version/ (pending enrichment).
* [UC-002 — Get](uc-002-get.md) - GET /jobs/printjobs/{JobID}/cancel/ (pending enrichment).
* [UC-003 — Get](uc-003-get.md) - GET /devices/printers/{PrinterID}/cloudconfiguration/ (pending enrichment).
* [UC-004 — Get](uc-004-get.md) - GET /devices/printers/{PrinterID}/emailaddress/ (pending enrichment).
* [UC-005 — Get](uc-005-get.md) - GET /devices/printers/{PrinterID}/emailaddress/suggestions/ (pending enrichment).
* [UC-006 — Get](uc-006-get.md) - GET /devices/printers/{PrinterID}/emailaddress/availability/ (pending enrichment).
* [UC-007 — Get](uc-007-get.md) - GET /ownerships/status (pending enrichment).
* [UC-008 — Get](uc-008-get.md) - GET /ownerships (pending enrichment).
* [UC-009 — Get](uc-009-get.md) - GET /devices/printers/ownerships (pending enrichment).
* [UC-010 — Get](uc-010-get.md) - GET /v1/devices/printers/ownerships (pending enrichment).
* [UC-011 — Get](uc-011-get.md) - GET /ownerships/{OwnershipID}/ (pending enrichment).
* [UC-012 — Get](uc-012-get.md) - GET /devices/printers/{PrinterID}/ (pending enrichment).
* [UC-013 — Get](uc-013-get.md) - GET /devices/printersDel/{PrinterID}/ (pending enrichment).
* [UC-014 — Get](uc-014-get.md) - GET /devices/printers (pending enrichment).
* [UC-015 — Get](uc-015-get.md) - GET /devices/printers/{PrinterID}/status/ (pending enrichment).
* [UC-016 — Get](uc-016-get.md) - GET /devices/printers/{PrinterID}/whitelist/ (pending enrichment).
* [UC-017 — Get](uc-017-get.md) - GET /devices/printers/{PrinterID}/defaultprocessingelements/ (pending enrichment).
* [UC-018 — Get](uc-018-get.md) - GET /devices/printers/{PrinterID}/whitelist/{WhiteListID}/ (pending enrichment).
* [UC-019 — Get](uc-019-get.md) - GET /devices/printers/{PrinterID}/printjobs/ (pending enrichment).
* [UC-020 — Get](uc-020-get.md) - GET /devices/printers/{PrinterID}/supportedprocessingelements/ (pending enrichment).
* [UC-021 — Get](uc-021-get.md) - GET /devices/printers/{PrinterID}/appplayer/event/ (pending enrichment).
* [UC-022 — Get](uc-022-get.md) - GET /devices/printers/{PrinterID}/owner/ (pending enrichment).
* [UC-023 — Get](uc-023-get.md) - GET /devices/printers/{PrinterID}/optin/ (pending enrichment).
* [UC-024 — Get](uc-024-get.md) - GET /devices/printers/{PrinterID}/consumablesubscription/ (pending enrichment).
* [UC-025 — Get](uc-025-get.md) - GET /devices/printers/{PrinterID}/optin/inklevel/ (pending enrichment).
* [UC-026 — Get](uc-026-get.md) - GET /devices/printers/{PrinterID}/optin/cDCA (pending enrichment).
* [UC-027 — Get](uc-027-get.md) - GET /devices/printers/{optinParameter}/optin/suppliesinfo/ (pending enrichment).
* [UC-028 — Get](uc-028-get.md) - GET /devices/printers/{PrinterID}/blacklist/ (pending enrichment).
* [UC-029 — Get](uc-029-get.md) - GET /devices/printers/{PrinterID}/printerwhitelist/ (pending enrichment).
* [UC-030 — Get](uc-030-get.md) - GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} (pending enrichment).
* [UC-031 — Get](uc-031-get.md) - GET /v2/devices/printers/{PrinterID}/optin/{optinType} (pending enrichment).
* [UC-032 — Get](uc-032-get.md) - GET /v2/devices/printers/{optinType}/schedules (pending enrichment).
* [UC-033 — Start Https Test](uc-033-start-https-test.md) - main(String[] args) in HttpsTest (pending enrichment).
