---
type: Use Case
title: UC-020 — Get
description: GET /devices/printers/{PrinterID}/supportedprocessingelements/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-020
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Field | Value |
| --- | --- |
| Id | UC-020 |
| Trigger | GET /devices/printers/{PrinterID}/supportedprocessingelements/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
