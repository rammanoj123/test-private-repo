---
type: Use Case
title: UC-006 — Get
description: Check email address availability for a printer.
tags: [usecase, email, availability, printer]
status: draft
usecase_id: UC-006
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-006 |
| Trigger | GET /devices/printers/{PrinterID}/emailaddress/availability/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
