---
type: Use Case
title: UC-027 — Get
description: GET /devices/printers/{optinParameter}/optin/suppliesinfo/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-027
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

| Field | Value |
| --- | --- |
| Id | UC-027 |
| Trigger | GET /devices/printers/{optinParameter}/optin/suppliesinfo/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
