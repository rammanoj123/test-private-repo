---
type: Use Case
title: UC-022 — Get
description: GET /devices/printers/{PrinterID}/owner/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-022
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

| Field | Value |
| --- | --- |
| Id | UC-022 |
| Trigger | GET /devices/printers/{PrinterID}/owner/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
