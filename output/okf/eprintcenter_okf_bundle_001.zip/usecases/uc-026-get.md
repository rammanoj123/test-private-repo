---
type: Use Case
title: UC-026 — Get
description: GET /devices/printers/{PrinterID}/optin/cDCA (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-026
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

| Field | Value |
| --- | --- |
| Id | UC-026 |
| Trigger | GET /devices/printers/{PrinterID}/optin/cDCA |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
