---
type: Use Case
title: UC-007 — Get
description: Retrieve ownership status information.
tags: [usecase, ownership, status, api]
status: draft
usecase_id: UC-007
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-007 |
| Trigger | GET /ownerships/status |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
