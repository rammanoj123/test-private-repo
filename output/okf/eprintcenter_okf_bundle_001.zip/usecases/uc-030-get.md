---
type: Use Case
title: UC-030 — Get
description: GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-030
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Field | Value |
| --- | --- |
| Id | UC-030 |
| Trigger | GET /devices/printers/{PrinterID}/blacklist/{BLACK_LIST_ENTRY} |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
