---
type: Use Case
title: UC-019 — Get
description: GET /devices/printers/{PrinterID}/printjobs/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-019
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Field | Value |
| --- | --- |
| Id | UC-019 |
| Trigger | GET /devices/printers/{PrinterID}/printjobs/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
