---
type: Use Case
title: UC-001 — Get
description: Retrieve API version information.
tags: [usecase, version, api, metadata]
status: draft
usecase_id: UC-001
generated: { by: okf_generator/1.0, at: 2026-09-20 06:48:05+00:00 }
---

| Field | Value |
| --- | --- |
| Id | UC-001 |
| Trigger | GET /version/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
