---
type: Component
title: OAuth Signature Method Factory
description: Generates and validates HMAC-SHA1 signatures for OAuth authentication using consumer and token secrets.
tags: [component, config, oauth, security, authentication]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\CoreOAuthSignatureMethodFactory_DraftHammer.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.CoreOAuthSignatureMethodFactory_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| key | String |  |
| secretKeySpec | SecretKeySpec |  |
| mac | Mac |  |
| rawHmac | byte[] |  |
| generatedSignature | String |  |
| isValid | boolean | @Override |
| consumerSecret | String |  |
| finalTokenSecret | String |  |
| plainTextSignatureMethod | PlainTextSignatureMethod |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| generateHmacSha1Signature | String | String baseString, String consumerSecret, String tokenSecret |  |
| validateHmacSha1Signature | boolean | String baseString, String consumerSecret, String tokenSecret, String providedSignature |  |
| getSignatureMethod | OAuthSignatureMethod | String methodName, SignatureSecret signatureSecret, final String tokenSecret |  |
