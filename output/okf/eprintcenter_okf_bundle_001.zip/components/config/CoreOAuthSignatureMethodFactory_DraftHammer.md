---
type: Component
title: CoreOAuthSignatureMethodFactory_DraftHammer
description: Config `CoreOAuthSignatureMethodFactory_DraftHammer`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\CoreOAuthSignatureMethodFactory_DraftHammer.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.security.CoreOAuthSignatureMethodFactory_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| key | String |  |
| secretKeySpec | SecretKeySpec |  |
| mac | Mac |  |
| rawHmac | byte[] |  |
| generatedSignature | String |  |
| isValid | boolean | @Override |
| consumerSecret | String |  |
| finalTokenSecret | String |  |
| plainTextSignatureMethod | PlainTextSignatureMethod |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| generateHmacSha1Signature | String | String baseString, String consumerSecret, String tokenSecret |  |
| validateHmacSha1Signature | boolean | String baseString, String consumerSecret, String tokenSecret, String providedSignature |  |
| getSignatureMethod | OAuthSignatureMethod | String methodName, SignatureSecret signatureSecret, final String tokenSecret |  |
