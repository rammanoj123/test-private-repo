---
type: Component
title: ePrint Center API Configuration
description: Provides centralized configuration management for ePrint Center API settings including service URLs, feature flags, and thresholds.
tags: [component, config, api, settings, singleton]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EPrintCenterAPIConfig.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| objectInstance | EPrintCenterAPIConfig |  |
| wpConfigurationService | WpConfigurationService | @Resource |
| SERVICE_NAME | String | @Resource |
| maxCount | String |  |
| clientsList | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EPrintCenterAPIConfig |  |  |  |
| getInstance | EPrintCenterAPIConfig |  |  |
| init | void |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getBooleanValue | boolean | String key |  |
| getStringValue | String | String key |  |
| getIntValue | int | String key |  |
| getMaxCountForUserPrintHistory | int |  |  |
| getDocumentSunsetNumberOfDays | int |  |  |
| enableMigrationDateCheck | boolean |  |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getRetryAfterInSecs | String |  |  |
| getKeys | Iterator | String prefix |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |
| getInstantInkOverrideValue | int |  |  |
| isCalypsoEmailAddressReplicationEnabled | boolean |  |  |
| isCalypsoEmailAddressValidationEnabled | boolean |  |  |
| getCalypsoUrl | String |  |  |
| getCalypsoRetryCount | int |  |  |
| getCalypsoAuthToken | String |  |  |
| getFeaTTL | Long |  |  |
| getDomain | String |  |  |
| getStratusPublishUrl | String |  |  |

# Depends on

* `WpConfigurationService`
* `String`
