---
type: Component
title: MCS Opt-in Configuration
description: Defines MCS opt-in configuration schema with optin group, model number, and serial number fields.
tags: [component, config, mcs, optin, schema]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\schemas\mcs\McsOptinConfig.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.schemas.mcs.McsOptinConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| optinGroup | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| modelNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| serialNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinGroup | String |  |  |
| setOptinGroup | void | String value |  |
| getModelNumber | String |  |  |
| setModelNumber | void | String value |  |
| getSerialNumber | String |  |  |
| setSerialNumber | void | String value |  |
