---
type: Component
title: McsOptinConfig
description: Config `McsOptinConfig`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\schemas\mcs\McsOptinConfig.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.schemas.mcs.McsOptinConfig`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| optinGroup | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| modelNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| serialNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinGroup | String |  |  |
| setOptinGroup | void | String value |  |
| getModelNumber | String |  |  |
| setModelNumber | void | String value |  |
| getSerialNumber | String |  |  |
| setSerialNumber | void | String value |  |
