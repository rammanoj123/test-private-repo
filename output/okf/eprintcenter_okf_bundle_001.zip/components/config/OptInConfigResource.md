---
type: Component
title: Opt-In Configuration Resource
description: Manages printer opt-in configuration for data collection groups, supporting GET and PUT operations for MCS and CRM settings.
tags: [component, config, optin, rest, printer]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptInConfigResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| IS_MCS_ENABLED | String |  |
| IS_CRM_ENABLED | String |  |
| INVALID_REQUEST_DATA | String |  |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| dataCollectionGroupType | DataCollectionGroupType | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| optinConfig | OptinConfig |  |
| optInXML | String |  |
| rep | Representation |  |
| startTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| optInConfig | OptinConfig | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| getActivePrinterByPrinterIDStartTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| dataCollectionGroupType | DataCollectionGroupType |  |
| numberOfSelectedOptions | int |  |
| updateOptInConfigStartTime | long |  |
| updatePrinterCloudConfigForMCSStartTime | long |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OptInConfigResource |  |  |  |
| handleGet | void |  |  |
| handlePut | void |  |  |
| isCRMEnabled | boolean |  |  |
| isMCSEnabled | boolean |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
