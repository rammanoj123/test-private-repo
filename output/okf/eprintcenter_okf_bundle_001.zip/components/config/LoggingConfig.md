---
type: Component
title: LoggingConfig
description: Config `LoggingConfig`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\config\LoggingConfig.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.config.LoggingConfig`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
