---
type: Component
title: Consumable Subscription Config Resource
description: Manages consumable subscription configuration for printers including MCS and CRM enablement settings.
tags: [component, config, subscription, mcs, crm, printer]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\ConsumableSubscriptionConfigResource.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| IS_MCS_ENABLED | String |  |
| IS_CRM_ENABLED | String |  |
| INVALID_REQUEST_DATA | String |  |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| notificationServiceClientHelper | NotificationServiceClientHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#GET") |
| startTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| consumableSubscriptionConfig | ConsumableSubscriptionConfig | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| printer | Printer |  |
| getActivePrinterByPrinterIDStartTime | long |  |
| consumableSubscriptionPayload | ConsumableSubscriptionPayload |  |
| link | Link |  |
| linkInXML | String |  |
| index | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ConsumableSubscriptionConfigResource |  |  |  |
| handleGet | void |  |  |
| handlePut | void |  |  |
| getPrinterConfigInstance | PrinterConfig |  |  |
| sleep | void | long timeSpan, String id |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| trimDomainFromEmailAddress | String | String emailAdddress |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* `NotificationServiceClientHelper`
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
