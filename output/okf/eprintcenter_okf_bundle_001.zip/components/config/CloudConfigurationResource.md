---
type: Component
title: CloudConfigurationResource
description: Config `CloudConfigurationResource`. (Description pending enrichment.)
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CloudConfigurationResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| securityDirectory | SecurityDirectory | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| printerCloudConfigurationOld | PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printerCloudConfig | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printer | Printer |  |
| uid | String |  |
| ownersAdditionalEmailAddresses | List |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| data | String |  |
| printerCloudConfigResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| objFactory | ObjectFactory |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerCloudConfig | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerCloudConfiguration | PrinterCloudConfiguration | @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printer | com.hp.cloudprint.entities.Printer |  |
| cloudConfigLink | Link |  |
| data | String |  |
| objFactory | ObjectFactory |  |
| responseHeaders | Form |  |
| uid | String |  |
| tokenDO | TokenDO |  |
| whitelist | List |  |
| userId | String |  |
| userIdentities | UserIdentities |  |
| userId | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handlePut | void |  |  |
| handleGet | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| extractUIDFromPUC | String |  |  |
| createWhitelist | List | List<OwnerAdditionalEmailAddress> ownerAdditionalEmailAddresses |  |
| updateUserEmailInWhitelistOrBlacklistOfPrinter | void | Printer printer |  |
| getUserIdFromHeader | String |  |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `SecurityDirectory`
* `UserEmailAddressHelper`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
