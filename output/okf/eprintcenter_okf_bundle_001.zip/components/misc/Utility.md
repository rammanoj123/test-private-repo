---
type: Component
title: Utility
description: Provides utility methods for schema validation, XML calendar creation, cache headers, and token extraction.
tags: [component, unknown, utility, helper, schema, xml]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Utility.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| version | String |  |
| obj | Object |  |
| sf | SchemaFactory |  |
| schemaName | String |  |
| schemaName | String |  |
| schemaFile | File |  |
| dbf | DocumentBuilderFactory |  |
| db | DocumentBuilder |  |
| doc | Document |  |
| xmlGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| tokenDO | TokenDO |  |
| tokenDO | TokenDO |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getApiVersion | String |  |  |
| addCacheHeaderToResponse | Response | Response resp |  |
| createXMLGregorianCalendar | XMLGregorianCalendar | Date creationTime |  |
| extractUIDFromPUC | String | Map<String, Object> parameters |  |
| isServicePuc | boolean | Request request |  |
