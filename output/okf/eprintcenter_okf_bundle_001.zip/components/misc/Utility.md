---
type: Component
title: Utility
description: Provides XML schema validation, API versioning, cache header management, and token extraction utilities.
tags: [component, unknown, utility, schema, cache]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Utility.java
generated: { by: okf_generator/1.0, at: 2026-09-14 08:35:07+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| version | String |  |
| obj | Object |  |
| sf | SchemaFactory |  |
| schemaName | String |  |
| schemaName | String |  |
| schemaFile | File |  |
| dbf | DocumentBuilderFactory |  |
| db | DocumentBuilder |  |
| doc | Document |  |
| xmlGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| tokenDO | TokenDO |  |
| tokenDO | TokenDO |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getApiVersion | String |  |  |
| addCacheHeaderToResponse | Response | Response resp |  |
| createXMLGregorianCalendar | XMLGregorianCalendar | Date creationTime |  |
| extractUIDFromPUC | String | Map<String, Object> parameters |  |
| isServicePuc | boolean | Request request |  |
