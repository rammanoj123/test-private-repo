---
type: Component
title: Utility
description: Provides utility methods for schema validation, XML calendar creation, and token extraction.
tags: [component, unknown, utility, helper, xml]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Utility.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.Utility`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| version | String |  |
| obj | Object |  |
| sf | SchemaFactory |  |
| schemaName | String |  |
| schemaName | String |  |
| schemaFile | File |  |
| dbf | DocumentBuilderFactory |  |
| db | DocumentBuilder |  |
| doc | Document |  |
| xmlGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| tokenDO | TokenDO |  |
| tokenDO | TokenDO |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getApiVersion | String |  |  |
| addCacheHeaderToResponse | Response | Response resp |  |
| createXMLGregorianCalendar | XMLGregorianCalendar | Date creationTime |  |
| extractUIDFromPUC | String | Map<String, Object> parameters |  |
| isServicePuc | boolean | Request request |  |
