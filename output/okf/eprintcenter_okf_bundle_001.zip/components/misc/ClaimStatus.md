---
type: Component
title: Claim Status
description: Represents printer claim status enumeration.
tags: [component, unknown, enum, status, printer, claim]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`
