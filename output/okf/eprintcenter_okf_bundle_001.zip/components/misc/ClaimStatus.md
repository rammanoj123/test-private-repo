---
type: Component
title: Claim Status
description: Enumerates printer claim status values.
tags: [component, unknown, enum, claim, status]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`
