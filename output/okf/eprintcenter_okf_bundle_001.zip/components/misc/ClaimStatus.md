---
type: Component
title: Claim Status
description: Enumerates printer claim status values.
tags: [component, unknown, enum, claim, status]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`
