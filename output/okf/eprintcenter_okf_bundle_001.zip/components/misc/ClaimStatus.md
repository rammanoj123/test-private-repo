---
type: Component
title: Claim Status
description: Represents printer claim status enumeration.
tags: [component, unknown, enum, claim, status]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`
