---
type: Component
title: Stratus HTTP Client
description: Executes HTTP operations (GET, POST, PUT, PATCH, DELETE) with retry logic and performance logging for Stratus service integration.
tags: [component, unknown, http, client, stratus, retry]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusHttpClient.java
generated: { by: okf_generator/1.0, at: 2026-09-14 08:35:07+00:00 }
---

`com.hp.cloudprint.http.clients.StratusHttpClient`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| httpClient | CloseableHttpClient |  |
| appConfig | HttpClientConfig |  |
| socketTimeout | int | @PostConstruct |
| config | RequestConfig | @PostConstruct |
| httpClientBuilder | HttpClientBuilder | @PostConstruct |
| hostnameVerifier | HostnameVerifier |  |
| sslConnectionSocketFactory | SSLConnectionSocketFactory |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInMilliseconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| getRequest | HttpGet |  |
| RETRY_THRESHOLD | int |  |
| getRequest | HttpGet |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| postRequest | HttpPost |  |
| RETRY_THRESHOLD | int |  |
| postRequest | HttpPost |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| putRequest | HttpPut |  |
| RETRY_THRESHOLD | int |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| putRequest | HttpPut |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| patchRequest | HttpPatch |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| deleteRequest | HttpDelete |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| entryTimeInMilliseconds | long |  |
| putRequest | HttpPut |  |
| patchRequest | HttpPatch |  |
| deleteRequest | HttpDelete |  |
| putRequest | HttpPut |  |
| responseCode | int |  |
| respBody | byte[] |  |
| httpResponseUtil | HttpResponseUtil |  |
| responseStream | InputStream |  |
| responseCode | int |  |
| respBody | byte[] |  |
| responseStream | InputStream |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| StratusHttpClient |  |  |  |
| getAppConfig | HttpClientConfig |  |  |
| setAppConfig | void | HttpClientConfig appConfig |  |
| init | void |  |  |
| getHttpClient | CloseableHttpClient |  |  |
| doGet | HttpResponse | String url, Map<String, String> headers |  |
| addLoggerForHttpCalls | void | long entryTimeInMilliseconds, long exitTimeInMilliseconds, HttpResponse response, long diffTimeInSec, String url, String methodType |  |
| createGetRequest | HttpGet | String url, Map<String, String> headers |  |
| doPost | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| createPostRequest | HttpPost | String url, Map<String, String> headers, HttpEntity entity |  |
| doPut | HttpResponse | String url, Map<String, String> headers, byte[] content |  |
| doPatch | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| doDelete | HttpResponse | String url, Map<String, String> headers |  |
| createPutRequest | HttpPut | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createPatchRequest | HttpPatch | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createDeleteRequest | HttpDelete | String url, Map<String, String> headers |  |
| createResponse | HttpResponseUtil | HttpResponse resp |  |
| setHeaders | void | Map<String, String> headers, HttpUriRequest request |  |
