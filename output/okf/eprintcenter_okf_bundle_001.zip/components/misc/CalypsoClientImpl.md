---
type: Component
title: CalypsoClientImpl
description: Unknown `CalypsoClientImpl`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClientImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.http.clients.CalypsoClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| logger | Logger |  |
| EMAILADDRESS_URL | String |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| httpclient | HttpClientUtil | @Resource |
| pumaClientWrapper | PUMAClientWrapper | @Resource |
| emailAddressUrl | String | @Override |
| emailAddressUrl | String | @Override |
| jsonbody | String | @Override |
| entity | HttpEntity | @Override |
| emailAddressUrl | String | @Override |
| emailAddressUrl | String | @Override |
| httpResponseUtil | HttpResponseUtil | @Override |
| isMarkedForExpiry | Boolean | @Override |
| respBody | String | @Override |
| retryCount | int |  |
| response | HttpResponse |  |
| httpResponseUtil | HttpResponseUtil |  |
| status | int |  |
| markedForDelete | Boolean |  |
| mapper | ObjectMapper |  |
| node | JsonNode |  |
| cloudNode | JsonNode |  |
| body | String |  |
| headersMap | Map |  |
| authToken | String |  |
| authTokenPuma | String |  |
| index | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
| executeHttpCall | HttpResponseUtil | String emailAddressUrl, HTTPMethods method, HttpEntity entity |  |
| getMarkedForExpiry | Boolean | String responseBody |  |
| prepareErrorMessage | String | HTTPMethods method, String url, String status |  |
| prepareJsonBody | String | long expiryInMills |  |
| prepareHeaders | Map |  |  |
| trimDomainFromEmailAddress | String | String emailAdddress |  |
| getHttpclient | HttpClientUtil |  |  |
| setHttpclient | void | HttpClientUtil httpclient |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `HttpClientUtil`
* `PUMAClientWrapper`
