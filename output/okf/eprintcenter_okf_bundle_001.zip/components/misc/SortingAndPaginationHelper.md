---
type: Component
title: Sorting and Pagination Helper
description: Sorts and paginates print history document lists based on criteria, start index, and count parameters.
tags: [component, unknown, helper, sorting, pagination, printhistory]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| comparator | UserHistoryComparator |  |
| paginatedDocList | List |  |
| paginationStart | int |  |
| normalizedCount | int |  |
| paginationEnd | int |  |
| maxCountPerPage | int |  |
| normalizedCount | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |
