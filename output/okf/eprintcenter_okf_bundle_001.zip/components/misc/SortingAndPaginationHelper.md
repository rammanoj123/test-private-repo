---
type: Component
title: Sorting and Pagination Helper
description: Provides sorting and pagination utilities for print history results.
tags: [component, unknown, helper, sorting, pagination, history, utility]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| comparator | UserHistoryComparator |  |
| paginatedDocList | List |  |
| paginationStart | int |  |
| normalizedCount | int |  |
| paginationEnd | int |  |
| maxCountPerPage | int |  |
| normalizedCount | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |
