---
type: Component
title: Stratus Event Info (ePrint Center)
description: Holds Stratus event information for ePrint Center including event type, resource identifiers, and attributes.
tags: [component, unknown, event, stratus, eprintcenter]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\StratusEventInfo.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.StratusEventInfo`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| event | String |  |
| fqResourceName | String |  |
| resourceId | String |  |
| tenantResourceId | String |  |
| scopes | List |  |
| eventAttributeValueMap | Map |  |
| customData | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEvent | String |  |  |
| setEvent | void | String event |  |
| getFqResourceName | String |  |  |
| setFqResourceName | void | String fqResourceName |  |
| getResourceId | String |  |  |
| setResourceId | void | String resourceId |  |
| getTenantResourceId | String |  |  |
| setTenantResourceId | void | String tenantResourceId |  |
| getScopes | List |  |  |
| getEventAttributeValueMap | Map |  |  |
| setEventAttributeValueMap | void | Map<String, EventAttribute> eventAttributeValueMap |  |
| setScopes | void | List<String> scopes |  |
| getCustomData | String |  |  |
| setCustomData | void | String customData |  |
