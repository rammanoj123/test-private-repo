---
type: Component
title: Stratus Event Info
description: Encapsulates event metadata for publishing device ownership events to Stratus event streaming service.
tags: [component, unknown, event, stratus, metadata]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\StratusEventInfo.java
generated: { by: okf_generator/1.0, at: 2026-09-14 08:35:07+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.StratusEventInfo`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| event | String |  |
| fqResourceName | String |  |
| resourceId | String |  |
| tenantResourceId | String |  |
| scopes | List |  |
| eventAttributeValueMap | Map |  |
| customData | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEvent | String |  |  |
| setEvent | void | String event |  |
| getFqResourceName | String |  |  |
| setFqResourceName | void | String fqResourceName |  |
| getResourceId | String |  |  |
| setResourceId | void | String resourceId |  |
| getTenantResourceId | String |  |  |
| setTenantResourceId | void | String tenantResourceId |  |
| getScopes | List |  |  |
| getEventAttributeValueMap | Map |  |  |
| setEventAttributeValueMap | void | Map<String, EventAttribute> eventAttributeValueMap |  |
| setScopes | void | List<String> scopes |  |
| getCustomData | String |  |  |
| setCustomData | void | String customData |  |
