---
type: Component
title: Outbound Email Helper
description: Sends outbound email notifications for additional email address validation.
tags: [component, unknown, helper, email, notification, validation, eos]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\OutEmailHelper.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| EMAIL_LIST_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| EMAIL_LIST_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| logger | EPrintLogger |  |
| FROM_EMAIL_ID | String |  |
| eosClient | EOSClient | @hpeprint.com |
| templateData | Map | @hpeprint.com |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEosClient | EOSClient |  |  |
| setEosClient | void | EOSClient eosClient |  |
| sendAdditionalEmailAddressValidationMail | void | String userId, String emailId, String url, String firstName |  |
