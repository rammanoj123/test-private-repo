---
type: Component
title: OutEmailHelper
description: Unknown `OutEmailHelper`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\OutEmailHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| EMAIL_LIST_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| EMAIL_LIST_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| logger | EPrintLogger |  |
| FROM_EMAIL_ID | String |  |
| eosClient | EOSClient | @hpeprint.com |
| templateData | Map | @hpeprint.com |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEosClient | EOSClient |  |  |
| setEosClient | void | EOSClient eosClient |  |
| sendAdditionalEmailAddressValidationMail | void | String userId, String emailId, String url, String firstName |  |
