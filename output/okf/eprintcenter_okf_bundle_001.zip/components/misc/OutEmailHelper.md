---
type: Component
title: Outbound Email Helper
description: Sends additional email address validation emails via outbound email service.
tags: [component, unknown, helper, email, validation]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\OutEmailHelper.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| EMAIL_LIST_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| EMAIL_LIST_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| logger | EPrintLogger |  |
| FROM_EMAIL_ID | String |  |
| eosClient | EOSClient | @hpeprint.com |
| templateData | Map | @hpeprint.com |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEosClient | EOSClient |  |  |
| setEosClient | void | EOSClient eosClient |  |
| sendAdditionalEmailAddressValidationMail | void | String userId, String emailId, String url, String firstName |  |
