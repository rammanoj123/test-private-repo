---
type: Component
title: URI Helper
description: Generates URI paths for API resources including printers, ownerships, and print jobs.
tags: [component, unknown, helper, uri, url, builder]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\URIHelper.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.URIHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| OPTIN_TYPE | String |  |
| SCHEDULE | String |  |
| UriSeperator | String |  |
| PRINTER_ID | String |  |
| OWNERSHIP_ID | String |  |
| JOBID | String |  |
| DOCUMENTID | String |  |
| PAGE_QUERYSTRING | String |  |
| RESULTS_PER_PAGE | String |  |
| WHITELIST_ID | String |  |
| EmailId | String |  |
| OWNER_ID | String |  |
| GET_FAVORITES | String |  |
| GET_MORE_PRINTER_DETAILS | String |  |
| ParameterLeftDelimiter | String |  |
| ParameterRightDelimiter | String |  |
| OwnershipsUri | String |  |
| PrintJobStatusUri | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintJobURI | String | String jobId |  |
| getCancelURI | String | String jobId |  |
| getPrintJobsURI | String |  |  |
| getPrintJobStatusURI | String | String jobId |  |
| getEmailAddressURIOnRamp | String | String printerId |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getPrintersURIOnRamp | String |  |  |
| getPrinterURIOnRamp | String | String printerId |  |
| getCloudConfigURI | String | String printerId |  |
| getWhiteListURI | String | String printerId |  |
| getWhiteListEntryURI | String | String printerId, String WhiteListID |  |
| getPrinterPrintJobsURI | String | String printerId |  |
| getPrinterSupportedProcesssingElementsURI | String | String printerId |  |
| getPrinterStatusURI | String | String printerId |  |
| getPrinterDefaultProcessingElementsURI | String | String printerId |  |
| getBlackListURI | String | String printerId, String blackListID |  |
| getOwnerAdditionalEmailAddressLink | String | String ownerAdditionalEmailAddressID |  |
