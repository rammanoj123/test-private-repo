---
type: Component
title: Event Attribute (ePrint Center)
description: Represents event attribute data with type and value for ePrint Center eventing.
tags: [component, unknown, event, attribute, data, eprintcenter]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EventAttribute.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.EventAttribute`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |
