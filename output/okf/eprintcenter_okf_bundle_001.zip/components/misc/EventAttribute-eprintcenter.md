---
type: Component
title: Event Attribute (ePrint Center)
description: Holds event attribute data with type and string value for ePrint Center eventing.
tags: [component, unknown, event, attribute, eprintcenter]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EventAttribute.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.EventAttribute`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |
