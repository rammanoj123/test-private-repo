---
type: Component
title: Blacklist Entry Handler
description: Handles blacklist entry operations for printers via GET and DELETE.
tags: [component, unknown, handler, blacklist, printer]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListHandler.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | IPrinterManager |  |
| blackListID | String printerID, | @Override |
| blackListID | String printerID, | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleDelete | void | CPGMessage message |  |
| handleGet | void | CPGMessage message |  |
