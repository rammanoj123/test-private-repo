---
type: Component
title: Blacklist Handler
description: Handles GET and DELETE operations for individual printer blacklist entries via message processing.
tags: [component, unknown, handler, blacklist, message, printer]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListHandler.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | IPrinterManager |  |
| blackListID | String printerID, | @Override |
| blackListID | String printerID, | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleDelete | void | CPGMessage message |  |
| handleGet | void | CPGMessage message |  |
