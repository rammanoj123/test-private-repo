---
type: Component
title: Stratus Client Implementation
description: Publishes ownership claim and unclaim events to Stratus eventing platform.
tags: [component, unknown, client, stratus, eventing, ownership]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClientImpl.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.http.clients.StratusClientImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| pumaClientWrapper | PUMAClientWrapper | @Resource |
| stratusHttpClient | StratusHttpClient | @Resource |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| FQ_RESOURCE_NAME | String |  |
| EVENT_ADDED | String |  |
| SCOPE | String |  |
| DEVICE_ID | String |  |
| USER_ID | String |  |
| ACCOUNT_ID | String |  |
| STRATUS_ID | String |  |
| OWNERSHIP_ID | String |  |
| EVENT_DELETED | String |  |
| OCTOKEN_EXPECTED_ISSUER_URL | String |  |
| httpHeaders | HashMap |  |
| stratusURL | String | @Override |
| token | String | @Override |
| claimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| statusCode | int |  |
| token | String |  |
| event | StratusEventInfo |  |
| authzToken | Token |  |
| scope | List |  |
| eventAttMap | Map |  |
| expected_issuer | String |  |
| issuer | String |  |
| accountId | String |  |
| split_accountId | String[] |  |
| tenant_id | Optional |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |
| eventAttributeValueMap | Map |  |
| eventAttribute | EventAttribute |  |
| tokens | String[] |  |
| split_string | String[] |  |
| base64EncodedHeader | String |  |
| base64EncodedBody | String |  |
| base64EncodedSignature | String |  |
| base64Url | Base64 |  |
| header | String |  |
| body | String |  |
| mapper | ObjectMapper |  |
| tp | Token |  |
| stratusURL | String |  |
| token | String |  |
| unClaimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| event | StratusEventInfo |  |
| authzToken | Token |  |
| eventAttMap | Map |  |
| scope | List |  |
| expected_issuer | String |  |
| issuer | String |  |
| accountId | String |  |
| split_accountId | String[] |  |
| tenant_id | Optional |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |
| stratusURL | String |  |
| token | String |  |
| unClaimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| event | StratusEventInfo |  |
| eventAttMap | Map |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPumaClientWrapper | PUMAClientWrapper |  |  |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| getStratusHttpClient | StratusHttpClient |  |  |
| setStratusHttpClient | void | StratusHttpClient stratusHttpClient |  |
| publishAddOwnershipToStratus | void | Ownership ownership, String tokenid |  |
| getAuthAccessToken | String | String userID |  |
| getPayloadForClaim | String | Ownership ownership, String tokenid |  |
| getEventAttributeValueMap | Map | Map<String, String> eventMap |  |
| getTenantIdFromToken | Token | String token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  tokenid |  |
| getPayloadForUnClaim | String | Ownership ownership, String tokenid |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |
| getPayloadForDeviceClaimByPuc | String | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `PUMAClientWrapper`
* [StratusHttpClient](/components/misc/StratusHttpClient.md)
