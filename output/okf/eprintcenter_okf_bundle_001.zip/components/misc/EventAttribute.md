---
type: Component
title: Event Attribute
description: Represents an event attribute with data type and string value fields.
tags: [component, unknown, event, attribute, data]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\EventAttribute.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.EventAttribute`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |
