---
type: Component
title: Event Attribute
description: Holds event attribute data with type and string value for eventing systems.
tags: [component, unknown, event, attribute, data]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\EventAttribute.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.EventAttribute`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |
