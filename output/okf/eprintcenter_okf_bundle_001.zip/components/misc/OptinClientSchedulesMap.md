---
type: Component
title: Opt-in Client Schedules Map
description: Maps opt-in types to their supported client schedules for CDCA and ACR configurations.
tags: [component, unknown, optin, schedule, map, configuration]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |
| cDCAScheduleMapCDCA | Map |  |
| cDCAScheduleMapACR | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |
