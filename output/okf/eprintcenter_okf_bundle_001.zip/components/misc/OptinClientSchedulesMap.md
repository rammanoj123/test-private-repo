---
type: Component
title: Opt-in Client Schedules Map
description: Maps opt-in types to their supported client schedules for CDCA and ACR.
tags: [component, unknown, optin, schedule, mapping, config]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |
| cDCAScheduleMapCDCA | Map |  |
| cDCAScheduleMapACR | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |
