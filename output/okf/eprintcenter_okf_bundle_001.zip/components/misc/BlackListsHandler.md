---
type: Component
title: BlackListsHandler
description: Unknown `BlackListsHandler`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListsHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| printerID | String | @Override |
| printerID | String | @Override |
| blackList | BlackList | @Override |
| printerOwner | Ownership | @Override |
| primaryEmailAddress | String | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |
