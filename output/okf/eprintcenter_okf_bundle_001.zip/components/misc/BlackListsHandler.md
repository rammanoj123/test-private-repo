---
type: Component
title: Blacklist Collection Handler
description: Handles GET and POST operations for printer blacklist collections.
tags: [component, unknown, handler, blacklist, printer, collection, dm]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListsHandler.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| printerID | String | @Override |
| printerID | String | @Override |
| blackList | BlackList | @Override |
| printerOwner | Ownership | @Override |
| primaryEmailAddress | String | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |
