---
type: Component
title: Owner Access Processor
description: Validates printer owner access permissions before processing requests.
tags: [component, unknown, processor, security, access, ownership, validation]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\processors\OwnerAccessProcessor.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager |  |
| securityDirectory | SecurityDirectory |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| logger | EPrintLogger |  |
| printerId | String | @Override |
| printerOwner | Ownership | @Override |
| accessToken | AccessTokenEntity | @Override |
| pumaToken | TokenDO | @Override |
| userID | String |  |
| issuer | String |  |
| allUserIdentities | UserIdentities |  |
| userIdentitiesAsList | List |  |
| userID | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| preProcess | void | CPGMessage message, Request request |  |
| isAccessAllowed | boolean | String ownerUserId, List<String> allUserIdentities |  |
| getUIDFromTokens | String | AccessTokenEntity accessToken, TokenDO pumaToken |  |
