---
type: Component
title: Custom HTTP Status
description: Defines custom HTTP status codes including invalid registration status.
tags: [component, unknown, http, status, custom]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |
