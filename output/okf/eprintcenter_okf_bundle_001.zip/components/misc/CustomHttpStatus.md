---
type: Component
title: CustomHttpStatus
description: Unknown `CustomHttpStatus`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |
