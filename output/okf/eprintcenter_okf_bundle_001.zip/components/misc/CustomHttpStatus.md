---
type: Component
title: Custom HTTP Status
description: Defines custom HTTP status codes for invalid registration scenarios.
tags: [component, unknown, http, status, custom]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |
