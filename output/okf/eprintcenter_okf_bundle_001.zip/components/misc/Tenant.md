---
type: Component
title: Tenant
description: Represents tenant information with roles, fully-qualified ID, and tenant ID for multi-tenancy support.
tags: [component, unknown, model, tenant, multitenancy]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Tenant.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.Tenant`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| roles | List |  |
| tenant_fqid | String |  |
| tenant_id | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRoles | List |  |  |
| setRoles | void | List<String> roles |  |
| getTenant_fqid | String |  |  |
| setTenant_fqid | void | String tenant_fqid |  |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |
