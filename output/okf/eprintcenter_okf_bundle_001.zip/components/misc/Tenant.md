---
type: Component
title: Tenant
description: Unknown `Tenant`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Tenant.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.Tenant`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| roles | List |  |
| tenant_fqid | String |  |
| tenant_id | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRoles | List |  |  |
| setRoles | void | List<String> roles |  |
| getTenant_fqid | String |  |  |
| setTenant_fqid | void | String tenant_fqid |  |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |
