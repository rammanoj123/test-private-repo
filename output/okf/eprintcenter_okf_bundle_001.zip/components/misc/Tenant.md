---
type: Component
title: Tenant
description: Represents tenant information with roles and tenant identifiers for multi-tenancy support.
tags: [component, unknown, tenant, data, multitenancy]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Tenant.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.Tenant`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| roles | List |  |
| tenant_fqid | String |  |
| tenant_id | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRoles | List |  |  |
| setRoles | void | List<String> roles |  |
| getTenant_fqid | String |  |  |
| setTenant_fqid | void | String tenant_fqid |  |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |
