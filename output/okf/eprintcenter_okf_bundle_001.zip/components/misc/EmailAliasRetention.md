---
type: Component
title: Email Alias Retention
description: Enumerates email alias retention options for printer ownership deletion.
tags: [component, unknown, enum, email, retention, alias, ownership]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EmailAliasRetention.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.EmailAliasRetention`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAliasRetention | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EmailAliasRetention |  | String retentionChoice |  |
| getEnum | EmailAliasRetention | String value |  |
