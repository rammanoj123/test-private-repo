---
type: Component
title: Whitelist Handler
description: Handles GET and POST operations for printer whitelist collections.
tags: [component, unknown, handler, whitelist, printer, collection]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\WhitelistHandler.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerID | String | @Override |
| userId | String | @Override |
| printerID | String | @Override |
| whiteList | WhiteList | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |
