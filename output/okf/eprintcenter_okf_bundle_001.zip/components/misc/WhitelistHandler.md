---
type: Component
title: Whitelist Handler
description: Handles whitelist collection operations for printers via GET and POST.
tags: [component, unknown, handler, whitelist, collection]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\WhitelistHandler.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerID | String | @Override |
| userId | String | @Override |
| printerID | String | @Override |
| whiteList | WhiteList | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |
