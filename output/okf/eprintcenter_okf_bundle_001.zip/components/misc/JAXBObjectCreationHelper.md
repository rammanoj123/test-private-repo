---
type: Component
title: JAXB Object Creation Helper
description: Creates JAXB objects for printer descriptions, print history, and cloud configuration responses.
tags: [component, unknown, helper, jaxb, xml, mapper]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\JAXBObjectCreationHelper.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| storageEndPoint | String | @Resource |
| printHistory | PrintHistory | @Resource |
| printHistoryDocument | Document |  |
| isCurrentUserTheDocumentOwner | boolean |  |
| isDocumentPending | boolean |  |
| isDocumentRejectedOrAborted | boolean |  |
| wasTnCAccepted | boolean |  |
| isHavingAccessToDocument | boolean |  |
| sunsetPeriodInDays | int |  |
| cal | Calendar |  |
| isPossibleToDeleteDocument | boolean |  |
| newLink | Link |  |
| ownerAdditionalEmailAddressEntries | List |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| formatter | DateFormat |  |
| gregorianCalendar | GregorianCalendar |  |
| printerIdMappedWithPrinterInfo | Map |  |
| infoAboutPrinterFromPLS | PrinterInfo |  |
| imagesForResponse | Images |  |
| imagesFromPLS | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images |  |
| imageForResponse | com.hp.cloudprint.api.eprintcenter.schemas.Image |  |
| printerIdMappedWithPrinterInfo | Map |  |
| infoAboutPrinterFromPLS | PrinterInfo |  |
| imagesForResponse | Images |  |
| imagesFromPLS | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images |  |
| imageForResponse | com.hp.cloudprint.api.eprintcenter.schemas.Image |  |
| SD_APP_DEVICE_CLASS | String |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerVersion | PrinterVersion |  |
| modelKey | String |  |
| revisionFoundFromAppconfig | String |  |
| firmwareVersion | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerCloudConfigResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| state | DocumentState |  |
| stateReason | String |  |
| comments | DocumentComments |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserPrintHistory | PrintHistory | List<com.hp.cloudprint.entities.Document>  documentsBasedOnCriteria, UserHistorySearchCriteria historySearchCriteria, long total, UserIdentities userIdentities, boolean userEmailVerified |  |
| createDocumentForResponse | Document | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities, boolean userEmailVerified |  |
| isDocumentRejectedOrAbortedBecauseOfInputContent | boolean | Document printHistoryDocument |  |
| wasTermsAndConditionsAcceptedWhenJobWasProcessed | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| getStorageEndPoint | String |  |  |
| formNewLinkElement | Link | String name, String href |  |
| isDocumentInPendingState | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| isCurrentUserTheDocumentOwner | boolean | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities |  |
| verifyOriginator | boolean | List<String> allEmailIds, String originatingUserId |  |
| getXMLEncodedDate | XMLGregorianCalendar | Date date |  |
| mapPLSPrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo printerInfo |  |
| mapPLSCompletePrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo completePrinterInfo |  |
| overrideInkCapability | void | PrinterDescription printerDesc |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | String supportedAppPlayerVersions |  |
| getImageListSize | Object | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images imagesFromPLS |  |
| generatePrinterCloudConfigurationJAXBObject | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | PrinterCloudConfiguration printerCloudConfiguration |  |
| configureInkSubscription | void | PrinterDescription printerDesc, byte consumableSubscription |  |
| setDocumentStateAndStateReason | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| setDocumentStateAndStateReasonForError | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| populateOptinSubscriptionDetails | OptinConfig | DataCollectionGroupType dataCollectionGroupType, OptinConfig optinConfig |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |

# Depends on

* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `String`
* `PrintHistory`
* `List`
* `UserHistorySearchCriteria`
* `long`
* `UserIdentities`
* `boolean`
* `Document`
