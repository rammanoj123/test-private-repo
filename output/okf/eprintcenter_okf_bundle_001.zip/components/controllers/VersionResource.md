---
type: Component
title: VersionResource
description: Controller `VersionResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\VersionResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.VersionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| logUID | String | @Override, @Auditable(name = "/version/#GET") |
| rep | Representation | @Override, @Auditable(name = "/version/#GET") |
| version | Version | @Override, @Auditable(name = "/version/#GET") |
| strVersion | String | @Override, @Auditable(name = "/version/#GET") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |
