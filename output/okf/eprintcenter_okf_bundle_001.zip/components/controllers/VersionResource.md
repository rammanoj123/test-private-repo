---
type: Component
title: Version Resource
description: Handles GET requests to retrieve the API version information.
tags: [component, controller, rest, version, metadata]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\VersionResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.VersionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| logUID | String | @Override, @Auditable(name = "/version/#GET") |
| rep | Representation | @Override, @Auditable(name = "/version/#GET") |
| version | Version | @Override, @Auditable(name = "/version/#GET") |
| strVersion | String | @Override, @Auditable(name = "/version/#GET") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |
