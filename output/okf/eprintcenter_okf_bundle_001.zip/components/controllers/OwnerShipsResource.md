---
type: Component
title: Ownerships Resource
description: Manages ownership collections via GET, POST, and PUT operations, listing and creating printer-user associations.
tags: [component, controller, rest, ownership, collection]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnerShipsResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @javax.annotation.Resource |
| productListingServiceHelper | ProductListingServiceHelper | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| FIRMWARE_NOT_FOUND | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships#POST") |
| ownerShip | OwnerShip | @Override, @Auditable(name = "/ownerships#POST") |
| isFavorite | boolean | @Override, @Auditable(name = "/ownerships#POST") |
| printer | Printer |  |
| devOwnership | Ownership |  |
| expiryInSecs | long |  |
| allEmailIdsForUser | List |  |
| userIdentities | UserIdentities |  |
| stratusEventing | boolean |  |
| awful | HttpServletRequest |  |
| token | String |  |
| logUID | String | @Override, @Auditable(name = "/ownerships#PUT") |
| ownerShipXMLInput | OwnerShip | @Override, @Auditable(name = "/ownerships#PUT") |
| isFavorite | boolean | @Override, @Auditable(name = "/ownerships#PUT") |
| printer | Printer |  |
| ownershipEntity | Ownership |  |
| startTime | long | @Override, @Auditable(name = "/ownerships#GET") |
| shouldLogPerfMetrics | boolean | @Override, @Auditable(name = "/ownerships#GET") |
| logUID | String | @Override, @Auditable(name = "/ownerships#GET") |
| form | Form | @Override, @Auditable(name = "/ownerships#GET") |
| issuer | String | @Override, @Auditable(name = "/ownerships#GET") |
| userId | String |  |
| getMorePrinterDetails | String |  |
| getFavoritesAlso | boolean |  |
| getFavorites | String |  |
| ownershipsEntity | List |  |
| ownerUserIdentities | UserIdentities |  |
| pamCallStartTime | long |  |
| getOwnershipsStartTime | long |  |
| ownerShipsSchema | OwnerShips |  |
| ownerShips | List |  |
| printerDescription | PrinterDescription |  |
| ownerShipSchema | OwnerShip |  |
| owner | Owner |  |
| ownershipLink | Link |  |
| getPrinterDescStartTime | long |  |
| rep | Representation |  |
| ownerShipsString | String |  |
| claimDate | XMLGregorianCalendar |  |
| dateFromOwnership | Date |  |
| printerDescription | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| printerGeoLocationType | PrinterGeoLocationType |  |
| printerLocationType | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| modelNumber | String |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| printVersionSchema | PrinterVersion |  |
| gregorianCalendar | GregorianCalendar |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printer | Printer |  |
| xmlObject | Object |  |
| applicationTrace | StringBuffer |  |
| trace | StackTraceElement[] |  |
| ownerShip | OwnerShip |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnerShipsResource |  |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| acceptRepresentation | void | Representation entity |  |
| storeRepresentation | void | Representation entity |  |
| handleGet | void |  |  |
| getOwnershipClaimDate | XMLGregorianCalendar | Ownership ownership |  |
| getPrinterDescription | PrinterDescription | Printer printer, String getMorePrinterDetails |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| getInstantInkSubscriptionCongigValue | int |  |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDescription, String modelNumber |  |
| verifyPrinterStatus | Printer | String strEmailladdress, boolean isFavorite |  |
| unMarshalAndValidateOwnershipsInput | OwnerShip | Representation entity |  |
| setShardCode | void | String printerId |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| getDeviceCapabilitiesManager | DeviceCapabilitiesManager |  |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |
| getOwnershipUserService | OwnershipUserService |  |  |

# Depends on

* `IPrinterManager`
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `PrinterCloudConfigurationManager`
* `DeviceCapabilitiesManager`
* `UserEmailAddressHelper`
* [StratusClient](/components/services/StratusClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `String`
* `Form`
