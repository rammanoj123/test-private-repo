---
type: Component
title: Ownership Status Resource
description: Accepts POST requests to check ownership status for printers based on provided criteria.
tags: [component, controller, rest, ownership, status]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnershipStatusResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ownershipStatusService | OwnershipStatusService | @Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/status#POST") |
| rootUrl | String |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| response | Representation |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnershipStatusResource |  |  |  |
| setOwnershipStatusService | void | OwnershipStatusService ownershipStatusService |  |
| acceptRepresentation | void | Representation entity |  |
| unMarshalAndValidateInputForOwnershipStatus | OwnershipStatusRequest | Representation entity |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| returnResponse | void | OwnershipStatusResponse res |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |

# Depends on

* [OwnershipStatusService](/components/services/OwnershipStatusService.md)
