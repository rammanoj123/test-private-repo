---
type: Component
title: Ownership Status Resource
description: Checks ownership status for printers via POST request with JSON request and response handling.
tags: [component, controller, resource, ownership, status]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnershipStatusResource.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ownershipStatusService | OwnershipStatusService | @Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/status#POST") |
| rootUrl | String |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| response | Representation |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnershipStatusResource |  |  |  |
| setOwnershipStatusService | void | OwnershipStatusService ownershipStatusService |  |
| acceptRepresentation | void | Representation entity |  |
| unMarshalAndValidateInputForOwnershipStatus | OwnershipStatusRequest | Representation entity |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| returnResponse | void | OwnershipStatusResponse res |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |

# Depends on

* [OwnershipStatusService](/components/services/OwnershipStatusService.md)
