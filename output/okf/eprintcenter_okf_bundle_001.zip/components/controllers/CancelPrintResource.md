---
type: Component
title: Cancel Print Resource
description: Handles PUT requests to cancel a print job by job ID.
tags: [component, controller, rest, printjob, cancel]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CancelPrintResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |
| jobId | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| doWork | void | String jobId |  |

# Depends on

* `PrintService`
