---
type: Component
title: Cancel Print Resource
description: Cancels a print job by job ID via PUT request.
tags: [component, controller, resource, print, job]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CancelPrintResource.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |
| jobId | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| doWork | void | String jobId |  |

# Depends on

* `PrintService`
