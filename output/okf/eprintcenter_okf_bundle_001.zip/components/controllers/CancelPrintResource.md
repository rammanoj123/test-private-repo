---
type: Component
title: Cancel Print Resource
description: Cancels a print job by job ID via PUT endpoint.
tags: [component, controller, rest, print, cancel]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CancelPrintResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |
| jobId | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| doWork | void | String jobId |  |

# Depends on

* `PrintService`
