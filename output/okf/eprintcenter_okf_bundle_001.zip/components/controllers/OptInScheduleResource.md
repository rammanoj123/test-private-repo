---
type: Component
title: Opt-In Schedule Resource
description: Handles GET requests to retrieve opt-in schedules for supported opt-in types.
tags: [component, controller, rest, optin, schedule]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptInScheduleResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| optinClientSchedulesMap | OptinClientSchedulesMap |  |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{optinType}/schedules#GET") |
| optinSchedules | OptinSchedules | @Override, @Auditable(name = "/v2/devices/printers/{optinType}/schedules#GET") |
| optinType | String |  |
| schedulesMap | EnumMap |  |
| supportedOptinTypes | Set |  |
| optinTypeSupported | boolean |  |
| response | Response |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| rep | Representation |  |
| optinSchedules | OptinSchedules |  |
| schedules | List |  |
| schedule | Schedule |  |
| optInType | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | com.hp.cloudprint.api.eprintcenter.schemas.json.Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinClientSchedulesMap | OptinClientSchedulesMap |  |  |
| setOptinClientSchedulesMap | void | OptinClientSchedulesMap optinClientSchedulesMap |  |
| OptInScheduleResource |  |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| getOptinSchedules | OptinSchedules | Map<String, String> clientScheduleMap |  |
| getOptInType | String |  |  |
| getErrorResponse | Representation | String errorCode, String errorDescription, Status status |  |
