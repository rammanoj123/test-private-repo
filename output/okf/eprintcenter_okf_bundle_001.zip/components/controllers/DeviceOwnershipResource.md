---
type: Component
title: DeviceOwnershipResource
description: Controller `DeviceOwnershipResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\DeviceOwnershipResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/ownerships#POST") |
| printer | Printer | @Auditable(name = "/devices/printers/ownerships#POST") |
| ownerShip | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |
| devOwnership | Ownership |  |
| response | Representation |  |
| devOwnership | Ownership |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownership | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceOwnershipResource |  |  |  |
| acceptRepresentation | void | Representation entity |  |
| getResponse | void | Ownership devOwnership |  |
| getOwnership | Ownership | Printer printer, com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownerShip |  |
| fetchPrinterDetails | Printer | String printerId |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| unMarshalAndValidateOwnershipsInput | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership | Representation entity |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |

# Depends on

* `IPrinterManager`
* [OwnershipUserService](/components/services/OwnershipUserService.md)
