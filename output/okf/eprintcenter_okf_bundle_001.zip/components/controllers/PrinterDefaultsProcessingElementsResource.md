---
type: Component
title: Printer Defaults Processing Elements Resource
description: Manages default processing elements for printers with GET and PUT operations.
tags: [component, controller, rest, printer, defaults, processing]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterDefaultsProcessingElementsResource.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#GET") |
| printer | Printer |  |
| printerDefaultsProcessingElements | PrinterDefaultsProcessingElements |  |
| objFactory | ObjectFactory |  |
| strDefaultProcessingEleXML | String |  |
| rep | Representation |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#PUT") |
| printer | Printer |  |
| defaultsProcessingElementsSchema | PrinterDefaultsProcessingElements |  |
| objFactory | ObjectFactory |  |
| strDefaultProcessingEleXML | String |  |
| rep | Representation |  |
| lstPrinterDefaultProcessingElements | List |  |
| defaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |
| familyDefaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |
| printerDefaultProcessingElements | PrinterDefaultProcessingElements |  |
| printerDefaultsProcessingElements | PrinterDefaultsProcessingElements |  |
| defaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |
| handlePut | void |  |  |
| updatePrinterDefaultsProcessingElements | void | Printer printer, PrinterDefaultsProcessingElements defaultsProcessingElementsSchema |  |
| getPrinterDefaultsProcessingElements | PrinterDefaultsProcessingElements | Printer printer |  |

# Depends on

* `IPrinterManager`
* `DeviceCapabilitiesManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
