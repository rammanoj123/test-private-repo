---
type: Component
title: Abstract Resource
description: Provides base HTTP method support checking for REST resource controllers.
tags: [component, controller, rest, base, http]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\AbstractResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.AbstractResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |
