---
type: Component
title: AbstractResource
description: Controller `AbstractResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\AbstractResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.AbstractResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |
