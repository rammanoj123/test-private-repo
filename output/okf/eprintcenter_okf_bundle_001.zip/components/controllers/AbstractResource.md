---
type: Component
title: Abstract Resource
description: Provides base functionality for REST resources to control allowed HTTP methods.
tags: [component, controller, rest, base, http]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\AbstractResource.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.AbstractResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |
