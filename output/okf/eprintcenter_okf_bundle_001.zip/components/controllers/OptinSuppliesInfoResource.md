---
type: Component
title: Supplies Info Opt-In Resource
description: Manages supplies info opt-in configuration for printers identified by email, claim code, or printer ID.
tags: [component, controller, resource, optin, supplies]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptinSuppliesInfoResource.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| OPTIN_PARAMETER | String |  |
| printer | Printer |  |
| parameter | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| errorXml | String | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| error | Error | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| printer | Printer |  |
| printer | Printer |  |
| printer | Printer |  |
| claimCodeWithDomain | String |  |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| response | Response |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| OptinSuppliesInfoResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| getErrorXML | String | ErrorCode errorCode |  |
| getParameter | String |  |  |
| getPrinter | Printer |  |  |
| getPrinterFromEmail | Printer | String printerEmail |  |
| getPrinterFromClaimCode | Printer | String claimCode |  |
| getPrinterFromPrinterId | Printer | String printerID |  |
| handleRequestMethod | void | Printer printer, RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| putPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| deletePrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| getPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| putPrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
