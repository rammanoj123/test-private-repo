---
type: Component
title: Ownership Resource
description: Handles GET and DELETE operations for a single ownership record including detailed printer information and Stratus eventing.
tags: [component, controller, rest, ownership, printer]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnerShipResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @Resource |
| productListingServiceHelper | ProductListingServiceHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| userHeader | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| form | Form | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownerShipId | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownershipEntity | Ownership | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| getMorePrinterDetails | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownerShipSchema | OwnerShip |  |
| printerDescription | PrinterDescription |  |
| owner | Owner |  |
| printer | Printer |  |
| ownerShipString | String |  |
| rep | Representation |  |
| claimDate | XMLGregorianCalendar |  |
| dateFromOwnership | Date |  |
| logUID | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| ownerShipId | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| queryParams | Form | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| emailAliasRetention | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| aliasRetentionEnum | EmailAliasRetention | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| ownership | Ownership |  |
| stratusEventingEnabled | boolean |  |
| awful | HttpServletRequest |  |
| token | String |  |
| printerDescription | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| printerGeoLocationType | PrinterGeoLocationType |  |
| printerLocationType | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| modelNumber | String |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| printVersionSchema | PrinterVersion |  |
| gregorianCalendar | GregorianCalendar |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnerShipResource |  |  |  |
| represent | Representation | Variant variant |  |
| getOwnerShipClaimDate | XMLGregorianCalendar | Ownership ownershipEntity |  |
| removeRepresentations | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |
| getOwnershipUserService | OwnershipUserService |  |  |
| setShardCode | void | String printerId |  |
| getDeviceCapabilitiesManager | DeviceCapabilitiesManager |  |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| getPrinterDescription | PrinterDescription | Printer printer, String  getMorePrinterDetails |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDescription, String modelNumber |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| getInstantInkSubscriptionCongigValue | int |  |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |

# Depends on

* `IPrinterManager`
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* `DeviceCapabilitiesManager`
* [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `PrinterCloudConfigurationManager`
* [StratusClient](/components/services/StratusClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `String`
* `Form`
