---
type: Component
title: Print Jobs Resource
description: Retrieves paginated print job history for a printer via GET endpoint.
tags: [component, controller, rest, printjob, history]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrintJobsResource.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| errorMessage | String |  |
| form | Form |  |
| resultsPerPageStr | String |  |
| restultsPerPage | Integer |  |
| criteria | SearchJobCriteria |  |
| pageNumberStr | String |  |
| pageNumber | Integer |  |
| presults | PagedResult |  |
| jobs | Collection |  |
| dyF | DatatypeFactory |  |
| gregorianCalendar | GregorianCalendar |  |
| printJobs | PrintJobs |  |
| jobReferences | List |  |
| jobReference | JobReference |  |
| jobLnk | Link |  |
| printJobsRepresentation | String |  |
| reasons | JobStateReasonsType |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrintService | PrintService |  |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| setCorrespondingJobStateAndStateReasonInJobReference | void | JobReference jobReference, final Job job |  |

# Depends on

* `IPrinterManager`
* `PrintService`
* `Form`
