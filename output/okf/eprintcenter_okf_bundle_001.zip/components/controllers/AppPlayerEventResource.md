---
type: Component
title: App Player Event Resource
description: Accepts and processes app player event data posted for a specific printer.
tags: [component, controller, resource, event, printer]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AppPlayerEventResource.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| entityStr | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/appplayer/event/#POST") |
| xmlObject | Object |  |
| appPlayerEvent | AppPlayerEvent |  |
| printerID | String |  |
| printer | Printer |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| acceptRepresentation | void | Representation entity |  |

# Depends on

* `PrinterManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
