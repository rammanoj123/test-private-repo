---
type: Component
title: PrinterOwnerResource
description: Controller `PrinterOwnerResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterOwnerResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerEntity | Ownership | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwner | Owner |  |
| xmlRepresentation | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrinterManager | IPrinterManager |  |  |
| handleGet | void |  |  |
