---
type: Component
title: Printer Owner Resource
description: Retrieves printer owner information by printer ID via GET requests.
tags: [component, controller, rest, printer, owner, ownership]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterOwnerResource.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerEntity | Ownership | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwner | Owner |  |
| xmlRepresentation | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrinterManager | IPrinterManager |  |  |
| handleGet | void |  |  |
