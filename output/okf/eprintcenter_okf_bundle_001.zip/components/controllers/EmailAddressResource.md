---
type: Component
title: EmailAddressResource
description: Controller `EmailAddressResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\EmailAddressResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| emailAddressManager | EmailAddressManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| strPrinterEmailAddress | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| xmlObject | Object | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printer | Printer |  |
| markedForExpiry | boolean |  |
| isEmailAddressLockedForDeviceOwner | boolean |  |
| sendbackObjects | Map[] |  |
| emailAddress | String |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| logUID | String | @Override |
| printerID | String | @Override |
| printerEmailAddress | PrinterEmailAddress | @Override |
| strPrinterEmailAddressXML | String | @Override |
| rep | Representation | @Override |
| printer | Printer | @Override |
| emailAddress | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| deleteEmailAddressFromCalypso | void | String printerEmailAddress |  |
| handlePost | void |  |  |
| handleGet | void |  |  |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEmailAddressManager | EmailAddressManager |  |  |
| setEmailAddressManager | void | EmailAddressManager emailAddressManager |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |

# Depends on

* `IPrinterManager`
* `EmailAddressManager`
* [CalypsoClient](/components/services/CalypsoClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
