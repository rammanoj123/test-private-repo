---
type: Component
title: Email Address Availability Resource
description: Checks availability of printer email address aliases via POST endpoint.
tags: [component, controller, rest, email, validation]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| desiredEmailAddressAlias | String |  |
| isAliasAvailable | boolean |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
