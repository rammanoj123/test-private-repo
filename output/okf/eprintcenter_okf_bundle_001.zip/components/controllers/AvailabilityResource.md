---
type: Component
title: Availability Resource
description: Checks email address alias availability for a printer via POST endpoint.
tags: [component, controller, rest, email, availability]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| desiredEmailAddressAlias | String |  |
| isAliasAvailable | boolean |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
