---
type: Component
title: Device Ownership Stratus Resource
description: Creates device ownership records with Stratus eventing support via POST endpoint.
tags: [component, controller, rest, ownership, stratus]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\DeviceOwnershipStratusResource.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| stratusClient | StratusClient | @Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| stratusEventingEnabled | boolean | @Override, @Auditable(name = "/v1/devices/printers/ownerships#POST") |
| logUID | String | @Override, @Auditable(name = "/v1/devices/printers/ownerships#POST") |
| printer | Printer |  |
| ownerShip | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |
| devOwnership | Ownership |  |
| awful | HttpServletRequest |  |
| token | String |  |
| response | Representation |  |
| devOwnership | Ownership |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownership | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceOwnershipStratusResource |  |  |  |
| acceptRepresentation | void | Representation entity |  |
| getResponse | void | Ownership devOwnership |  |
| getOwnership | Ownership | Printer printer, com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownerShip |  |
| fetchPrinterDetails | Printer | String printerId |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| unMarshalAndValidateOwnershipsInput | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership | Representation entity |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |

# Depends on

* `IPrinterManager`
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* [StratusClient](/components/services/StratusClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
