---
type: Component
title: PrinterStatusResource
description: Controller `PrinterStatusResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterStatusResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| NON_BLOCKING | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| startTime | long | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| nonBlockingFlag | boolean | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| queryParams | Form | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| printerID | String |  |
| printer | Printer |  |
| tokenDO | TokenDO |  |
| userId | String |  |
| getActivePrinterByPrinterIDStartTime | long |  |
| printerStatusToReturn | PrinterStatus |  |
| printerStatus | com.hp.cloudprint.devices.printer.data.PrinterStatus |  |
| printerConnectionState | ConnectionStateEnum |  |
| getPrinterConnectionStateStartTime | long |  |
| connectionState | ConnectionState |  |
| getPrinterStatusStartTime | long |  |
| responseHeaders | Form |  |
| getQueuedJobsCountStartTime | long |  |
| queuedJobsCount | int |  |
| reasons | PrinterStateReasons |  |
| printerStateReason | PrinterStateReasons.PrinterStateReason |  |
| locId | String |  |
| calendar | GregorianCalendar |  |
| xmlGregorianCalendar | XMLGregorianCalendar |  |
| ownership | Ownership |  |
| rep | Representation |  |
| objectFactory | ObjectFactory |  |
| resp | Response |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| verifyPrinterOwner | boolean | String printerID, String userId |  |
| sendData | void | PrinterStatus printStatus |  |

# Depends on

* `IPrinterManager`
* `PrintService`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
