---
type: Component
title: Solution Opt-In Resource
description: Manages solution-specific opt-in settings with schedule support via PUT, DELETE, and GET operations.
tags: [component, controller, rest, optin, solution]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SolutionOptInResource.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| DEFAULT_SCHEDULE | String |  |
| IS_CDCA_SCHEDULE_MIGRATION_ENABLED | String |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| optinClientSchedulesMap | OptinClientSchedulesMap | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#PUT") |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#DELETE") |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| printer | Printer | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| printerID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| optInType | String | @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| schedule | String |  |
| schedules | OptinSchedules |  |
| clientSchedulesMap | EnumMap |  |
| supportedOptinTypes | Set |  |
| optinTypeSupported | boolean |  |
| supportedClientSchedules | Map |  |
| response | Response |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| rep | Representation |  |
| form | Form |  |
| schedule | String |  |
| optInType | String |  |
| printerID | String |  |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| optinSchedules | OptinSchedules |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| schedule | Schedule |  |
| supportedOptinTypes | Set |  |
| schedules | List |  |
| previousOptinType | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | com.hp.cloudprint.api.eprintcenter.schemas.json.Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinClientSchedulesMap | OptinClientSchedulesMap |  |  |
| setOptinClientSchedulesMap | void | OptinClientSchedulesMap optinClientSchedulesMap |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| SolutionOptInResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| validateOptInTypeAndSchedule | void | String optInType, String schedule |  |
| setSuccessResponseStatus | void | RequestType requestType, OptinSchedules schedules |  |
| getSchedule | String |  |  |
| getOptInType | String |  |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| putPrinterCloudConfiguration | void | Printer printer, String optinType, String schedule |  |
| deletePrinterCloudConfiguration | void | Printer printer, String optinType |  |
| getPrinterCloudConfiguration | OptinSchedules | Printer printer, String optinType |  |
| isUpdateRequired | boolean | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| putPrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| deletePrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String printerId |  |
| getErrorResponse | Representation | String errorCode, String errorDescription, Status status |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* [OptinClientSchedulesMap](/components/misc/OptinClientSchedulesMap.md)
* `Form`
