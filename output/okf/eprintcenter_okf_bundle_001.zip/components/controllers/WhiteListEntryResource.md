---
type: Component
title: Whitelist Entry Resource
description: Manages individual whitelist entries with GET, PUT, and DELETE operations for printers.
tags: [component, controller, rest, whitelist, entry, printer]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\WhiteListEntryResource.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| printerID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whiteListID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whitelistentry | JAXBElement | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whitelistEntity | com.hp.cloudprint.entities.WhiteList | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| printer | com.hp.cloudprint.entities.Printer |  |
| requestWhiteListentity | com.hp.cloudprint.entities.WhiteList |  |
| e | WhiteListEntryType |  |
| responseWhiteListentity | com.hp.cloudprint.entities.WhiteList |  |
| whiteListEntryType | WhiteListEntryType |  |
| objectfactory | com.hp.cloudprint.api.eprintcenter.schemas.ObjectFactory |  |
| element | JAXBElement |  |
| data | String |  |
| sw | StringWriter |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| whiteListID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| whiteListEntity | com.hp.cloudprint.entities.WhiteList |  |
| objectfactory | ObjectFactory |  |
| whiteListEntryType | WhiteListEntryType |  |
| element | JAXBElement |  |
| data | String |  |
| sw | StringWriter |  |
| responseHeaders | Form |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| whiteListID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printerOwner | Ownership |  |
| primaryEmailAddress | String |  |
| existingWhiteListEntity | WhiteList |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| handleGet | void |  |  |
| handleDelete | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |

# Depends on

* `IPrinterManager`
* `UserEmailAddressHelper`
