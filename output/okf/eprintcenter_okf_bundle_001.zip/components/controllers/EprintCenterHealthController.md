---
type: Component
title: EprintCenterHealthController
description: Controller `EprintCenterHealthController`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\EprintCenterHealthController.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| LOG | EPrintLogger |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| GEN2_CALYPSO_HEALTH_CHECK | String |  |
| ULS_HEALTH_CHECK | String |  |
| EPC_PLATFORM | String |  |
| DISABLE_PAM_LOOKUP_FOR_USER_IDENTITIES | String |  |
| ULS_ABOUT_URL | String |  |
| ULS_PROXY_ENABLED | String |  |
| ULS_PROXY_HOST | String |  |
| ULS_PROXY_PORT | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| jdbcUrl | String |  |
| hostName | String |  |
| uri | URI |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| shardDS | ComboPooledDataSource |  |
| hostName | String |  |
| shardUpCountMinThreshold | int |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| tigaseDS | ComboPooledDataSource |  |
| hostName | String |  |
| xmppRoutingDataSource | XmppRoutingDataSource |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| xmppDirectory | XMPPDirectory |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| xmppServerGroup | XmppServerGroup |  |
| channelIP | String |  |
| plsServiceURL | String |  |
| authzserviceurl | String |  |
| pamServiceURL | String |  |
| ulsServiceURL | String |  |
| pumaServiceURL | String |  |
| pdsAboutUrl | String |  |
| pdsServiceURL | String |  |
| outBoundEmailServiceURL | String |  |
| applicationContext | ApplicationContext |  |
| eprintUserDirectoryDataSource | ComboPooledDataSource |  |
| jdbcUrl | String |  |
| hostName | String |  |
| GEN2_CALYPSO_URL | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| cpgDBHealthCheck | void |  |  |
| getEprintDirDS | ComboPooledDataSource |  |  |
| getDetails | String | ComboPooledDataSource comboPooledDataSource |  |
| getHostName | String | String url |  |
| shardDBHealthCheck | void |  |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| tigaseDBHealthCheck | void |  |  |
| getTigaseDBDataSource | DataSource | String shardCode |  |
| getTigaseDbGroupType | GroupType |  |  |
| getThresholdForTigaseDbHealth | int |  |  |
| channelHealthCheck | void |  |  |
| plsHealthCheck | void |  |  |
| idmHealthCheck | void |  |  |
| authzHealthCheck | void |  |  |
| pamHealthCheck | void |  |  |
| ulsHealthCheck | void |  |  |
| pumaHealthCheck | void |  |  |
| pdsHealthCheck | void |  |  |
| outBoundEmailHealthCheck | void |  |  |
| eprintUserDirectoryHealthCheck | void |  |  |
| gen2CalypsoHealthCheck | void |  |  |
| constructAboutContextPathFromServiceContext | String | String serviceContextPath |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |
