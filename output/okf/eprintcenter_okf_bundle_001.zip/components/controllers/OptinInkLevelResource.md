---
type: Component
title: Ink Level Opt-In Resource
description: Manages ink level opt-in settings for printers via PUT, DELETE, and GET operations.
tags: [component, controller, rest, optin, ink]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptinInkLevelResource.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#DELETE") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#GET") |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| response | Response |  |
| printerID | String |  |
| printer | Printer |  |
| errorXml | String |  |
| error | Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| OptinInkLevelResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| getErrorXML | String | ErrorCode errorCode |  |
| putPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| deletePrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| getPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| putPrinterCloudConfigurationInkLevelOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationInkLevelOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
