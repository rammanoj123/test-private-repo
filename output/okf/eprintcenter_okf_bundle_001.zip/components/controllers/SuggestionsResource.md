---
type: Component
title: Email Suggestions Resource
description: Generates printer email address suggestions based on user hints via POST endpoint.
tags: [component, controller, rest, email, suggestions]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SuggestionsResource.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| MIN_SUGGESTIONS | int |  |
| emailAddressManager | EmailAddressManager | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| hints | EmailAddressGenerationHints |  |
| firstName | String |  |
| lastName | String |  |
| screenName | String |  |
| desiredAlias | String |  |
| userEmailAddress | String |  |
| suggestionsListForAliases | List |  |
| suggestedEmailAddress | EmailAddressSuggestions |  |
| emailAddressList | EmailAddressList |  |
| printerEmailAddress | PrinterEmailAddress |  |
| dataToBeReturned | String |  |
| responseHeaders | Form |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SuggestionsResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
