---
type: Component
title: Shard Persistence Filter
description: Determines and sets database shard context based on printer or owner identifiers from request URLs.
tags: [component, security, filter, shard, persistence]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ShardPersistenceFilter.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ShardPersistenceFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| urlProcessorUtility | URLProcessorUtility | @Resource |
| printerManager | PrinterManager | @Resource |
| request | HttpServletRequest | @Resource |
| response | HttpServletResponse | @Resource |
| requestURL | String | @Resource |
| shardCode | String | @Resource |
| printerID | String |  |
| ownerID | String |  |
| shardCode | String |  |
| lisOfShardsForTheGivenUser | List |  |
| ownerList | List |  |
| printer | Printer |  |
| uri | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain |  |
| getShardCode | String | HttpServletRequest request, HttpServletResponse response, String requestURL |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| getActivePrinter | Printer | String printerID |  |
| buildRequestUrl | String | String servletPath, String requestURI, String contextPath, String pathInfo, String queryString |  |
| setUrlProcessorUtility | void | URLProcessorUtility urlProcessorUtility |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| init | void | FilterConfig filterConfig |  |
| destroy | void |  |  |

# Depends on

* `URLProcessorUtility`
* `PrinterManager`
* `HttpServletRequest`
* `HttpServletResponse`
* `String`
* `ServletRequest`
* `ServletResponse`
* `FilterChain`
