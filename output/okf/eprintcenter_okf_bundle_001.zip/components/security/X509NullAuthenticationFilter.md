---
type: Component
title: X.509 Null Authentication Filter
description: Handles X.509 certificate authentication with null certificate fallback.
tags: [component, security, filter, x509, certificate, authentication]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\X509NullAuthenticationFilter.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.X509NullAuthenticationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| req | HttpServletRequest | @Override |
| res | HttpServletResponse | @Override |
| certs | X509Certificate[] | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
