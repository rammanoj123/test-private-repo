---
type: Component
title: X509NullAuthenticationFilter
description: Security `X509NullAuthenticationFilter`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\X509NullAuthenticationFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.security.X509NullAuthenticationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| req | HttpServletRequest | @Override |
| res | HttpServletResponse | @Override |
| certs | X509Certificate[] | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
