# Security components

# Concepts

* [BasicAuthenticationFilter](BasicAuthenticationFilter.md) - Security `BasicAuthenticationFilter`. (Description pending enrichment.)
* [ProtectedResourceProcessingFilter_DraftHammer](ProtectedResourceProcessingFilter_DraftHammer.md) - Security `ProtectedResourceProcessingFilter_DraftHammer`. (Description pending enrichment.)
* [ShardPersistenceFilter](ShardPersistenceFilter.md) - Security `ShardPersistenceFilter`. (Description pending enrichment.)
* [X509NullAuthenticationFilter](X509NullAuthenticationFilter.md) - Security `X509NullAuthenticationFilter`. (Description pending enrichment.)
