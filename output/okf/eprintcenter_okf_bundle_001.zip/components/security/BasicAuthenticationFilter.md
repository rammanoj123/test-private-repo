---
type: Component
title: Basic Authentication Filter
description: Authenticates requests using HTTP Basic authentication with client credentials validation.
tags: [component, security, filter, authentication, basic]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\BasicAuthenticationFilter.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| authorizationHeader | String |  |
| headerValueType | String |  |
| securityDirectory | SecurityDirectory |  |
| wpConfigurationService | WpConfigurationService |  |
| request | HttpServletRequest | @Override |
| response | HttpServletResponse | @Override |
| headerValue | String | @Override |
| base64Token | byte[] |  |
| decodedBasicToken | String |  |
| token | Token |  |
| characterEncoding | String |  |
| isTokenValid | boolean |  |
| clientAuthDetails | ClientAuthDetails |  |
| isWellFormedToken | boolean |  |
| clientAuthDetails | ClientAuthDetails |  |
| clientID | String |  |
| clientSecret | String |  |
| decodedTokens | String[] |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| BasicAuthenticationFilter |  |  |  |
| doFilter | void | ServletRequest req, ServletResponse res, FilterChain chain |  |
| getCharacterEncoding | String | HttpServletRequest request |  |
| isBasicValidationAllowed | boolean |  |  |
| validateToken | boolean | Token token |  |
| getToken | Token | String decodedBasicToken |  |
| isWellFormedToken | boolean | Token token |  |
| getClientAuthDetails | ClientAuthDetails | Token token |  |
| setUnAuthResponse | void | HttpServletResponse response |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getClientID | String |  |  |
| setClientID | void | String clientID |  |
| getClientSecret | String |  |  |
| setClientSecret | void | String clientSecret |  |

# Depends on

* `HttpServletRequest`
* `HttpServletResponse`
