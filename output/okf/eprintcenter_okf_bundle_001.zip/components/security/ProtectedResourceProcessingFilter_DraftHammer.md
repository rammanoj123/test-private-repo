---
type: Component
title: ProtectedResourceProcessingFilter_DraftHammer
description: Security `ProtectedResourceProcessingFilter_DraftHammer`. (Description pending enrichment.)
tags: [component, security]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceProcessingFilter_DraftHammer.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceProcessingFilter_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| signatureMethod | String | @Override |
| signature | String | @Override |
| token | String |  |
| clientId | String | @Override |
| authentication | ConsumerAuthentication | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateOAuthParams | void | ConsumerDetails consumerDetails, Map<String, String> oauthParams |  |
| onValidSignature | void | HttpServletRequest request, HttpServletResponse response, FilterChain chain |  |
| fail | void | HttpServletRequest request, HttpServletResponse response, AuthenticationException failure |  |
