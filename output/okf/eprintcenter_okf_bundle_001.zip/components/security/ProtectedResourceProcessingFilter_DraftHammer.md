---
type: Component
title: Protected Resource Processing Filter
description: Processes OAuth-protected resource requests with signature validation and consumer authentication.
tags: [component, security, filter, oauth, authentication]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceProcessingFilter_DraftHammer.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceProcessingFilter_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| signatureMethod | String | @Override |
| signature | String | @Override |
| token | String |  |
| clientId | String | @Override |
| authentication | ConsumerAuthentication | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateOAuthParams | void | ConsumerDetails consumerDetails, Map<String, String> oauthParams |  |
| onValidSignature | void | HttpServletRequest request, HttpServletResponse response, FilterChain chain |  |
| fail | void | HttpServletRequest request, HttpServletResponse response, AuthenticationException failure |  |
