---
type: Component
title: Protected Resource Processing Filter (Draft Hammer)
description: Processes OAuth-protected resource requests with signature validation using Draft Hammer specification.
tags: [component, security, filter, oauth, signature]
status: draft
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceProcessingFilter_DraftHammer.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceProcessingFilter_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| signatureMethod | String | @Override |
| signature | String | @Override |
| token | String |  |
| clientId | String | @Override |
| authentication | ConsumerAuthentication | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateOAuthParams | void | ConsumerDetails consumerDetails, Map<String, String> oauthParams |  |
| onValidSignature | void | HttpServletRequest request, HttpServletResponse response, FilterChain chain |  |
| fail | void | HttpServletRequest request, HttpServletResponse response, AuthenticationException failure |  |
