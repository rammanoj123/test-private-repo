---
type: Component
title: Client Conflict Exception
description: Signals HTTP 409 Conflict errors from client operations.
tags: [component, exception, http, conflict, client]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientConflictException.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.http.clients.ClientConflictException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientConflictException |  | Throwable throwable |  |
