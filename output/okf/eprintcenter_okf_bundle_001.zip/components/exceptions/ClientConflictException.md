---
type: Component
title: Client Conflict Exception
description: Signals HTTP 409 Conflict errors in client operations.
tags: [component, exception, http, conflict, error]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientConflictException.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.http.clients.ClientConflictException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientConflictException |  | Throwable throwable |  |
