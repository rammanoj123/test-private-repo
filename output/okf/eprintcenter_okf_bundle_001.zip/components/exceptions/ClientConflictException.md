---
type: Component
title: ClientConflictException
description: Exception `ClientConflictException`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientConflictException.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.http.clients.ClientConflictException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientConflictException |  | Throwable throwable |  |
