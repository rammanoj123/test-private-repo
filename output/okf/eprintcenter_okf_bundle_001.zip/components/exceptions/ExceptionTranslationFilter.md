---
type: Component
title: Exception Translation Filter
description: Translates authentication and authorization exceptions into appropriate HTTP responses.
tags: [component, exception, filter, security, http]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ExceptionTranslationFilter.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| res | HttpServletResponse | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
