---
type: Component
title: Exception Translation Filter
description: Translates security exceptions into appropriate HTTP responses in the filter chain.
tags: [component, exception, filter, security, http]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ExceptionTranslationFilter.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| res | HttpServletResponse | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
