---
type: Component
title: Exception Translation Filter
description: Intercepts and translates security exceptions during request filtering.
tags: [component, exception, security, filter, translation]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ExceptionTranslationFilter.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| res | HttpServletResponse | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
