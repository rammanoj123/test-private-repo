---
type: Component
title: ExceptionTranslationFilter
description: Exception `ExceptionTranslationFilter`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ExceptionTranslationFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| res | HttpServletResponse | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
