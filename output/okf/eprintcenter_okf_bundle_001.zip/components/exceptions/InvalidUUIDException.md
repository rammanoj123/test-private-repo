---
type: Component
title: Invalid UUID Exception
description: Signals invalid UUID format errors in data management operations.
tags: [component, exception, uuid, validation, error]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |
