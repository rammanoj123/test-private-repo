---
type: Component
title: Invalid UUID Exception
description: Signals invalid UUID format errors with the problematic UUID value.
tags: [component, exception, uuid, validation, error]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |
