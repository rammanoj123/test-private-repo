---
type: Component
title: Invalid UUID Exception
description: Signals invalid UUID format errors.
tags: [component, exception, validation, uuid]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: gpt-4o-2024-11-20, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |
