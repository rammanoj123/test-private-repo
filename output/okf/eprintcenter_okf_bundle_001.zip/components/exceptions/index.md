# Exceptions

# Concepts

* [ClientConflictException](ClientConflictException.md) - Exception `ClientConflictException`. (Description pending enrichment.)
* [ClientErrorException](ClientErrorException.md) - Exception `ClientErrorException`. (Description pending enrichment.)
* [ExceptionTranslationFilter](ExceptionTranslationFilter.md) - Exception `ExceptionTranslationFilter`. (Description pending enrichment.)
* [InvalidUUIDException](InvalidUUIDException.md) - Exception `InvalidUUIDException`. (Description pending enrichment.)
