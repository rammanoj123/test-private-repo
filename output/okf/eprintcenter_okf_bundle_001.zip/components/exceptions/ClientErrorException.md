---
type: Component
title: ClientErrorException
description: Exception `ClientErrorException`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientErrorException.java
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

`com.hp.cloudprint.http.clients.ClientErrorException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientErrorException |  | Throwable throwable |  |
