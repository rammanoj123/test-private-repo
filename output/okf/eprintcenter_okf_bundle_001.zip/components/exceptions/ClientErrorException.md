---
type: Component
title: Client Error Exception
description: Represents general HTTP client errors from external service calls.
tags: [component, exception, http, client, error]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientErrorException.java
generated: { by: gpt-4o, at: 2025-01-15T10:30:00Z }
---

`com.hp.cloudprint.http.clients.ClientErrorException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientErrorException |  | Throwable throwable |  |
