---
type: Component
title: Client Error Exception
description: Signals general client-side HTTP errors in operations.
tags: [component, exception, http, client, error]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientErrorException.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.http.clients.ClientErrorException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientErrorException |  | Throwable throwable |  |
