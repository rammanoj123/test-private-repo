---
type: Component
title: Client Error Exception
description: Signals general client-side HTTP errors in operations.
tags: [component, exception, http, error, client]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientErrorException.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.http.clients.ClientErrorException`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientErrorException |  | Throwable throwable |  |
