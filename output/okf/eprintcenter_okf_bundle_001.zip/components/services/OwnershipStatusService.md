---
type: Component
title: OwnershipStatusService
description: Service `OwnershipStatusService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipStatusService.java
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipStatusService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
