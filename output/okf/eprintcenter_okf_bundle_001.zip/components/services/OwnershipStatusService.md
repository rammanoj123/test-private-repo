---
type: Component
title: Ownership Status Service
description: Defines interface for retrieving printer ownership status by device identifiers and user.
tags: [component, service, interface, ownership, status]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipStatusService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipStatusService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
