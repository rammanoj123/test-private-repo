---
type: Component
title: WP Configuration Service Provider
description: Provides singleton access to WpConfigurationService instance loaded from Spring application context.
tags: [component, service, provider, configuration, singleton]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\WpConfigurationServiceProvider.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
