---
type: Component
title: WP Configuration Service Provider
description: Provides singleton access to WpConfigurationService for application configuration management.
tags: [component, service, provider, configuration, singleton]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\WpConfigurationServiceProvider.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
