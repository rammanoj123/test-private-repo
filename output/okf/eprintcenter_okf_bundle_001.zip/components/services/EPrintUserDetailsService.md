---
type: Component
title: EPrintUserDetailsService
description: Service `EPrintUserDetailsService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\EPrintUserDetailsService.java
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

`com.hp.cloudprint.api.eprintcenter.security.EPrintUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| securityManager | SecurityManager |  |
| eprintUser | EPrintUser | @Override |
| grantedAuthoritiesList | List | @Override |
| user | User |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadUserByUsername | UserDetails | String userName |  |
