---
type: Component
title: ePrint User Details Service
description: Loads user details for Spring Security authentication by username.
tags: [component, service, security, user, authentication, spring]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\EPrintUserDetailsService.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.EPrintUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| securityManager | SecurityManager |  |
| eprintUser | EPrintUser | @Override |
| grantedAuthoritiesList | List | @Override |
| user | User |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadUserByUsername | UserDetails | String userName |  |
