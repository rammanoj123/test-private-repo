---
type: Component
title: ePrint User Details Service
description: Loads user details by username from security manager for Spring Security authentication.
tags: [component, service, security, userdetails, authentication]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\EPrintUserDetailsService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.EPrintUserDetailsService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| securityManager | SecurityManager |  |
| eprintUser | EPrintUser | @Override |
| grantedAuthoritiesList | List | @Override |
| user | User |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadUserByUsername | UserDetails | String userName |  |
