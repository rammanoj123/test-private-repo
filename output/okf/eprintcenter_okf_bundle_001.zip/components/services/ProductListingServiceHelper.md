---
type: Component
title: Product Listing Service Helper
description: Retrieves and filters printer information from Product Listing Service including firmware versions and device capabilities.
tags: [component, service, helper, pls, printer-info, firmware]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\ProductListingServiceHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| plsClient | PLSClient | @Resource |
| printerInfoResponse | PrinterInfoList | @Resource |
| printerIdWithInfo | Map | @Resource |
| printerInfoResponse | PrinterInfoList |  |
| completePrinterInfoList | PrinterInfoList |  |
| printerInfoAsList | List |  |
| printerInfoBasedOnModelAndFirmwareVersion | PrinterInfo |  |
| printerInfoAsList | List |  |
| appPlayerEntries | List |  |
| matchingPlayerEntry | AppPlayerEntry |  |
| appPlayerEntries | List |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPlsClient | void | PLSClient plsClient |  |
| getPrinterInfoFromPLS | Map | String userId, List<String> modelNumbers |  |
| getPrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber |  |
| getCompletePrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber, String firmwareVersion |  |
| getPrinterInfoAsList | List | String modelNumber, PrinterInfoList completePrinterInfoList |  |
| filterPrinterInfoBasedOnFirmwareVersion | PrinterInfo | List<PrinterInfo> printerInfoAsList, String firmwareVersion |  |
| reCreatePrinterInfo | PrinterInfo | AppPlayerEntry matchingPlayerEntry, List<PrinterInfo> printerInfoAsList |  |
| convertToAppPlayerEntries | List | List<PrinterInfo> printerInfoAsList |  |

# Depends on

* `PLSClient`
* `PrinterInfoList`
* `Map`
* `String`
* `List`
