---
type: Component
title: Consumer Detail Service Provider
description: Loads OAuth consumer details by consumer key for authentication and authorization.
tags: [component, service, oauth, consumer, security]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ConsumerDetailServiceProvider.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| securityManager | SecurityManager |  |
| consumerDetails | ConsumerDetailsEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadConsumerByConsumerKey | ConsumerDetails | String consumerKey |  |
