---
type: Component
title: Consumer Detail Service Provider
description: Loads OAuth consumer details by consumer key from the security manager for authentication.
tags: [component, service, oauth, consumer, security]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ConsumerDetailServiceProvider.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| securityManager | SecurityManager |  |
| consumerDetails | ConsumerDetailsEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadConsumerByConsumerKey | ConsumerDetails | String consumerKey |  |
