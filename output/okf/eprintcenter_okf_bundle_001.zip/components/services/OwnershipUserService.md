---
type: Component
title: Ownership User Service Interface
description: Defines interface for managing printer ownership operations including add, delete, and retrieval.
tags: [component, service, interface, ownership, user]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipUserService.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
