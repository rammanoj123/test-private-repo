---
type: Component
title: Ownership User Service
description: Defines operations for managing printer ownership relationships including add, delete, and retrieval of ownership records.
tags: [component, service, ownership, printer, interface]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipUserService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
