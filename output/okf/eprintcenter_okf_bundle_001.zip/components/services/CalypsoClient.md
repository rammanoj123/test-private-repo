---
type: Component
title: Calypso Client Interface
description: Defines interface for Calypso email address management operations.
tags: [component, service, interface, calypso, email, client]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClient.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.http.clients.CalypsoClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
