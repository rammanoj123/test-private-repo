---
type: Component
title: Calypso Client
description: Defines interface for Calypso email address operations including add, patch, delete, and expiry checking.
tags: [component, service, interface, calypso, email]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.http.clients.CalypsoClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
