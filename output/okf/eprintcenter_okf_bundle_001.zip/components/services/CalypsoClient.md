---
type: Component
title: Calypso Client Interface
description: Defines interface for managing printer email addresses in Calypso service including add, patch, delete, and expiry operations.
tags: [component, service, interface, calypso, email]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClient.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.http.clients.CalypsoClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
