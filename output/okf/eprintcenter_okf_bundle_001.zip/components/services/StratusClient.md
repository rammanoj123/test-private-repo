---
type: Component
title: StratusClient
description: Service `StratusClient`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClient.java
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

`com.hp.cloudprint.http.clients.StratusClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishAddOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownership |  |
