---
type: Component
title: Stratus Client
description: Defines interface for publishing ownership add and delete events to Stratus eventing service.
tags: [component, service, interface, stratus, eventing]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-21T12:00:00Z }
---

`com.hp.cloudprint.http.clients.StratusClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishAddOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownership |  |
