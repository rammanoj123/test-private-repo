---
type: Component
title: Stratus Client
description: Publishes ownership lifecycle events to Stratus service for add and delete operations on printer ownerships.
tags: [component, service, client, stratus, events, ownership, integration]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2026-09-20T04:23:40Z }
---

`com.hp.cloudprint.http.clients.StratusClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishAddOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownership |  |
