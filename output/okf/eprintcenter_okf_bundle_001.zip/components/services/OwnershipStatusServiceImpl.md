---
type: Component
title: Ownership Status Service Implementation
description: Retrieves printer ownership status by device identifiers and constructs ownership response with claim status.
tags: [component, service, ownership, status, implementation]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipStatusServiceImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-14 08:35:07+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| version | String |  |
| self | String |  |
| printerManager | IPrinterManager | @Resource |
| deviceData | DeviceData | @Override |
| printerEntity | Printer | @Override |
| ownershipEntity | Ownership |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| links | List |  |
| ownershipLink | Link |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
| getOwnershipStatusResponse | OwnershipStatusResponse | Ownership ownershipEntity, ClaimStatus claimStatus, String rootUrl |  |

# Depends on

* `IPrinterManager`
