---
type: Component
title: Ownership Status Service Implementation
description: Retrieves printer ownership status by device identifiers, returning claim status and ownership links.
tags: [component, service, implementation, ownership, status]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipStatusServiceImpl.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| version | String |  |
| self | String |  |
| printerManager | IPrinterManager | @Resource |
| deviceData | DeviceData | @Override |
| printerEntity | Printer | @Override |
| ownershipEntity | Ownership |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| links | List |  |
| ownershipLink | Link |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
| getOwnershipStatusResponse | OwnershipStatusResponse | Ownership ownershipEntity, ClaimStatus claimStatus, String rootUrl |  |

# Depends on

* `IPrinterManager`
