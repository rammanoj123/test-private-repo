---
type: Component
title: Ownership Status Service Implementation
description: Retrieves printer ownership status by model, serial, UUID, or user ID.
tags: [component, service, implementation, ownership, status, printer]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipStatusServiceImpl.java
generated: { by: gpt-4o, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| version | String |  |
| self | String |  |
| printerManager | IPrinterManager | @Resource |
| deviceData | DeviceData | @Override |
| printerEntity | Printer | @Override |
| ownershipEntity | Ownership |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| links | List |  |
| ownershipLink | Link |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
| getOwnershipStatusResponse | OwnershipStatusResponse | Ownership ownershipEntity, ClaimStatus claimStatus, String rootUrl |  |

# Depends on

* `IPrinterManager`
