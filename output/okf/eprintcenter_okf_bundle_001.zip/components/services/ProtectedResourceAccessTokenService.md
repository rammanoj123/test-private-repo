---
type: Component
title: Protected Resource Access Token Service
description: Manages OAuth access token lifecycle including creation, validation, expiration checking, and removal.
tags: [component, service, oauth, token, security]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceAccessTokenService.java
generated: { by: okf_generator/1.0, at: 2026-09-14 08:35:07+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| securityManager | SecurityManager |  |
| tokenToVerify | AccessTokenEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | AccessTokenEntity | String token |  |
| removeToken | void | String token | @Transactional |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication |  |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token |  |
| isExpired | boolean | AccessTokenEntity tokenToVerify |  |

# Cross-cutting

* Transactional: `removeToken`
