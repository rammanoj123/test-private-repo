---
type: Component
title: Protected Resource Access Token Service
description: Manages OAuth access tokens including creation, validation, expiry checking, and removal.
tags: [component, service, oauth, token, security]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceAccessTokenService.java
generated: { by: gpt-4o, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| securityManager | SecurityManager |  |
| tokenToVerify | AccessTokenEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | AccessTokenEntity | String token |  |
| removeToken | void | String token | @Transactional |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication |  |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token |  |
| isExpired | boolean | AccessTokenEntity tokenToVerify |  |

# Cross-cutting

* Transactional: `removeToken`
