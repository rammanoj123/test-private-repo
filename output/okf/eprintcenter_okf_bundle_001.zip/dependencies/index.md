# Dependencies & ecosystem

# Subdirectories

* [external/](external/) - Third-party dependencies
* [internal/](internal/) - Internal / custom libraries
