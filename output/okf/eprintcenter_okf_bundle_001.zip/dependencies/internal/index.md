# Internal / custom libraries

# Concepts

* [channelinterfaces](channelinterfaces.md) - Custom/org library `com.hp.cloudprint:channelinterfaces:25.1.4` (pending enrichment).
* [cjputil](cjputil.md) - Custom/org library `com.hp.cloudprint:cjputil:25.1.4` (pending enrichment).
* [devicecapabilities](devicecapabilities.md) - Custom/org library `com.hp.cloudprint:devicecapabilities:25.1.5` (pending enrichment).
* [entities](entities.md) - Custom/org library `com.hp.cloudprint:entities:25.3.5` (pending enrichment).
* [eprintcenter-schema](eprintcenter-schema.md) - Custom/org library `com.hp.cloudprint:eprintcenter-schema:25.1.4` (pending enrichment).
* [eprintDirectory](eprintdirectory.md) - Custom/org library `com.hp.cloudprint:eprintDirectory:25.1.4` (pending enrichment).
* [ePrintLogger](eprintlogger.md) - Custom/org library `com.hp.cloudprint:ePrintLogger:25.1.4` (pending enrichment).
* [eprintUserDirectory](eprintuserdirectory.md) - Custom/org library `com.hp.cloudprint:eprintUserDirectory:25.1.4` (pending enrichment).
* [eventingcommon](eventingcommon.md) - Custom/org library `com.hp.cloudprint:eventingcommon:25.1.4` (pending enrichment).
* [eventLogger](eventlogger.md) - Custom/org library `com.hp.cloudprint:eventLogger:25.1.4` (pending enrichment).
* [httpclient-util](httpclient-util.md) - Custom/org library `com.hp.cloudprint:httpclient-util:25.1.4` (pending enrichment).
* [jefapi](jefapi.md) - Custom/org library `com.hp.cloudprint:jefapi:25.1.4` (pending enrichment).
* [metrics](metrics.md) - Custom/org library `com.hp.cloudprint:metrics:25.1.4` (pending enrichment).
* [notification-client](notification-client.md) - Custom/org library `com.hp.cloudprint:notification-client:25.2.3` (pending enrichment).
* [notification-common](notification-common.md) - Custom/org library `com.hp.cloudprint:notification-common:25.2.3` (pending enrichment).
* [papi-base-schema](papi-base-schema.md) - Custom/org library `com.hp.swp:papi-base-schema:13.17.3` (pending enrichment).
* [papiclients](papiclients.md) - Custom/org library `com.hp.cloudprint:papiclients:25.1.5` (pending enrichment).
* [pjpcommon](pjpcommon.md) - Custom/org library `com.hp.cloudprint:pjpcommon:25.1.5` (pending enrichment).
* [pjpservices](pjpservices.md) - Custom/org library `com.hp.cloudprint:pjpservices:25.1.5` (pending enrichment).
* [pjpworksteps](pjpworksteps.md) - Custom/org library `com.hp.cloudprint:pjpworksteps:25.1.5` (pending enrichment).
* [pjpworkstepsutil](pjpworkstepsutil.md) - Custom/org library `com.hp.cloudprint:pjpworkstepsutil:25.1.5` (pending enrichment).
* [printer](printer.md) - Custom/org library `com.hp.cloudprint:printer:${printer.version}` (pending enrichment).
* [printerlist-schema](printerlist-schema.md) - Custom/org library `com.hp.ipg.iws.wp:printerlist-schema:${ukas-wp-version}` (pending enrichment).
* [pumaclient](pumaclient.md) - Custom/org library `com.hp.cloudprint:pumaclient:25.1.5` (pending enrichment).
* [pumavalidatelib](pumavalidatelib.md) - Custom/org library `com.hp.cloudprint:pumavalidatelib:25.3.4.2` (pending enrichment).
* [pumavalidator](pumavalidator.md) - Custom/org library `com.hp.cloudprint:pumavalidator:25.3.4.2` (pending enrichment).
* [rest-common](rest-common.md) - Custom/org library `com.hp.cloudprint:rest-common:25.1.4` (pending enrichment).
* [security](security.md) - Custom/org library `com.hp.cloudprint:security:25.1.4` (pending enrichment).
* [sjpservices](sjpservices.md) - Custom/org library `com.hp.cloudprint:sjpservices:25.1.5` (pending enrichment).
* [snoobe-client](snoobe-client.md) - Custom/org library `com.hp.cloudprint:snoobe-client:25.1.4` (pending enrichment).
* [storage-client](storage-client.md) - Custom/org library `com.hp.cloudprint:storage-client:25.1.4` (pending enrichment).
* [util](util.md) - Custom/org library `com.hp.cloudprint:util:25.1.4` (pending enrichment).
* [validateclient](validateclient.md) - Custom/org library `com.hp.cloudprint:validateclient:25.4.4` (pending enrichment).
* [wp-common](wp-common.md) - Custom/org library `com.hp.iws.wpp:wp-common:${wp-common-version}` (pending enrichment).
* [wp-common-web](wp-common-web.md) - Custom/org library `com.hp.iws.wpp:wp-common-web:${wp-common-version}` (pending enrichment).
* [wpp-base-schema](wpp-base-schema.md) - Custom/org library `com.hp.iws.wpp:wpp-base-schema:${wpp-version}` (pending enrichment).
* [wpp-json-logging-adaptor](wpp-json-logging-adaptor.md) - Custom/org library `com.hp.wpp:wpp-json-logging-adaptor:1.0.13` (pending enrichment).
* [wpp-logger](wpp-logger.md) - Custom/org library `com.hp.wpp:wpp-logger:2.2.14` (pending enrichment).
