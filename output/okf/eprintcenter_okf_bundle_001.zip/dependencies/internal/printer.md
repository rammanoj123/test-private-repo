---
type: Internal Library
title: printer
description: Custom/org library `com.hp.cloudprint:printer:${printer.version}` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: printer
depends_on_bundle: hp/printer
group_id: com.hp.cloudprint
scope: compile
version: ${printer.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

Maven coordinate: `com.hp.cloudprint:printer:${printer.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/printer`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
