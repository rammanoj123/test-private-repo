---
type: Internal Library
title: entities
description: Custom/org library `com.hp.cloudprint:entities:25.3.5` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: entities
depends_on_bundle: hp/entities
group_id: com.hp.cloudprint
scope: compile
version: 25.3.5
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

Maven coordinate: `com.hp.cloudprint:entities:25.3.5`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/entities`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
