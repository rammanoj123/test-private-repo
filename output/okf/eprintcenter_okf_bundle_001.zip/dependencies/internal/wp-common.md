---
type: Internal Library
title: wp-common
description: Custom/org library `com.hp.iws.wpp:wp-common:${wp-common-version}` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: wp-common
depends_on_bundle: hp/wp-common
group_id: com.hp.iws.wpp
scope: compile
version: ${wp-common-version}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

Maven coordinate: `com.hp.iws.wpp:wp-common:${wp-common-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wp-common`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
