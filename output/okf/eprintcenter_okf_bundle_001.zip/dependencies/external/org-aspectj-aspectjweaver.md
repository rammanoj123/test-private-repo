---
type: Dependency
title: org.aspectj:aspectjweaver
description: Third-party dependency `org.aspectj:aspectjweaver:1.9.20.1` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.aspectj/aspectjweaver
tags: [dependency, external]
status: draft
artifact_id: aspectjweaver
group_id: org.aspectj
scope: runtime
version: 1.9.20.1
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

Maven coordinate: `org.aspectj:aspectjweaver:1.9.20.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
