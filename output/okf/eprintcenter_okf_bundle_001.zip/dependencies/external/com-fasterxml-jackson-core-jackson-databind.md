---
type: Dependency
title: com.fasterxml.jackson.core:jackson-databind
description: Third-party dependency `com.fasterxml.jackson.core:jackson-databind:2.15.2` (pending enrichment).
resource: https://central.sonatype.com/artifact/com.fasterxml.jackson.core/jackson-databind
tags: [dependency, external]
status: draft
artifact_id: jackson-databind
group_id: com.fasterxml.jackson.core
scope: compile
version: 2.15.2
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

Maven coordinate: `com.fasterxml.jackson.core:jackson-databind:2.15.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
