---
type: Dependency
title: com.noelios.restlet:com.noelios.restlet.ext.spring
description: Third-party dependency `com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6` (pending enrichment).
resource: https://central.sonatype.com/artifact/com.noelios.restlet/com.noelios.restlet.ext.spring
tags: [dependency, external]
status: draft
artifact_id: com.noelios.restlet.ext.spring
group_id: com.noelios.restlet
scope: compile
version: 1.1.6
generated: { by: okf_generator/1.0, at: 2026-09-20T05:50:55Z }
---

Maven coordinate: `com.noelios.restlet:com.noelios.restlet.ext.spring:1.1.6`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
