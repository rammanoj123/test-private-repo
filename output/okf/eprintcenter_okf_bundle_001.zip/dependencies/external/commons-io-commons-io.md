---
type: Dependency
title: commons-io:commons-io
description: Third-party dependency `commons-io:commons-io:2.18.0` (pending enrichment).
resource: https://central.sonatype.com/artifact/commons-io/commons-io
tags: [dependency, external]
status: draft
artifact_id: commons-io
group_id: commons-io
scope: compile
version: 2.18.0
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

Maven coordinate: `commons-io:commons-io:2.18.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
