---
type: Dependency
title: org.springframework.security:spring-security-web
description: Third-party dependency `org.springframework.security:spring-security-web:${springframework.security.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-web
tags: [dependency, external]
status: draft
artifact_id: spring-security-web
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

Maven coordinate: `org.springframework.security:spring-security-web:${springframework.security.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
