---
type: Dependency
title: net.sf.ehcache:ehcache
description: Third-party dependency `net.sf.ehcache:ehcache:1.3.0` (pending enrichment).
resource: https://central.sonatype.com/artifact/net.sf.ehcache/ehcache
tags: [dependency, external]
status: draft
artifact_id: ehcache
group_id: net.sf.ehcache
scope: compile
version: 1.3.0
generated: { by: okf_generator/1.0, at: 2026-09-20T05:50:55Z }
---

Maven coordinate: `net.sf.ehcache:ehcache:1.3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
