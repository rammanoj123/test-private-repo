---
type: Dependency
title: org.springframework.security:spring-security-core
description: Third-party dependency `org.springframework.security:spring-security-core:${springframework.security.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.springframework.security/spring-security-core
tags: [dependency, external]
status: draft
artifact_id: spring-security-core
group_id: org.springframework.security
scope: compile
version: ${springframework.security.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

Maven coordinate: `org.springframework.security:spring-security-core:${springframework.security.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
