---
type: Dependency
title: com.nimbusds:nimbus-jose-jwt
description: Third-party dependency `com.nimbusds:nimbus-jose-jwt:9.25.1` (pending enrichment).
resource: https://central.sonatype.com/artifact/com.nimbusds/nimbus-jose-jwt
tags: [dependency, external]
status: draft
artifact_id: nimbus-jose-jwt
group_id: com.nimbusds
scope: compile
version: 9.25.1
generated: { by: okf_generator/1.0, at: 2026-09-20T04:23:40Z }
---

Maven coordinate: `com.nimbusds:nimbus-jose-jwt:9.25.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
