---
type: Dependency
title: org.aspectj:aspectjrt
description: Third-party dependency `org.aspectj:aspectjrt:1.9.20.1` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.aspectj/aspectjrt
tags: [dependency, external]
status: draft
artifact_id: aspectjrt
group_id: org.aspectj
scope: compile
version: 1.9.20.1
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

Maven coordinate: `org.aspectj:aspectjrt:1.9.20.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
