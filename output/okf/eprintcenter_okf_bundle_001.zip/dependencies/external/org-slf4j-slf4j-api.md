---
type: Dependency
title: org.slf4j:slf4j-api
description: Third-party dependency `org.slf4j:slf4j-api:${slf4j.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.slf4j/slf4j-api
tags: [dependency, external]
status: draft
artifact_id: slf4j-api
group_id: org.slf4j
scope: compile
version: ${slf4j.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

Maven coordinate: `org.slf4j:slf4j-api:${slf4j.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
