---
type: Dependency
title: org.springframework:spring-tx
description: Third-party dependency `org.springframework:spring-tx:${spring.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.springframework/spring-tx
tags: [dependency, external]
status: draft
artifact_id: spring-tx
group_id: org.springframework
scope: compile
version: ${spring.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

Maven coordinate: `org.springframework:spring-tx:${spring.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
