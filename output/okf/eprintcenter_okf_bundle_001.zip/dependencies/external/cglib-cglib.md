---
type: Dependency
title: cglib:cglib
description: Third-party dependency `cglib:cglib:3.3.0` (pending enrichment).
resource: https://central.sonatype.com/artifact/cglib/cglib
tags: [dependency, external]
status: draft
artifact_id: cglib
group_id: cglib
scope: provided
version: 3.3.0
generated: { by: okf_generator/1.0, at: 2026-09-20T12:38:53Z }
---

Maven coordinate: `cglib:cglib:3.3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
