---
type: Dependency
title: org.powermock:powermock-api-mockito
description: Third-party dependency `org.powermock:powermock-api-mockito:${powermock.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.powermock/powermock-api-mockito
tags: [dependency, external]
status: draft
artifact_id: powermock-api-mockito
group_id: org.powermock
scope: test
version: ${powermock.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T06:48:05Z }
---

Maven coordinate: `org.powermock:powermock-api-mockito:${powermock.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
