---
type: Dependency
title: commons-codec:commons-codec
description: Third-party dependency `commons-codec:commons-codec:1.17.2` (pending enrichment).
resource: https://central.sonatype.com/artifact/commons-codec/commons-codec
tags: [dependency, external]
status: draft
artifact_id: commons-codec
group_id: commons-codec
scope: compile
version: 1.17.2
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

Maven coordinate: `commons-codec:commons-codec:1.17.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
