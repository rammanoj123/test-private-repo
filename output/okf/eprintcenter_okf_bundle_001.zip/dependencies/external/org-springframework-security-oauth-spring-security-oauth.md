---
type: Dependency
title: org.springframework.security.oauth:spring-security-oauth
description: Third-party dependency `org.springframework.security.oauth:spring-security-oauth:${spring-security-oauth.version}` (pending enrichment).
resource: https://central.sonatype.com/artifact/org.springframework.security.oauth/spring-security-oauth
tags: [dependency, external]
status: draft
artifact_id: spring-security-oauth
group_id: org.springframework.security.oauth
scope: compile
version: ${spring-security-oauth.version}
generated: { by: okf_generator/1.0, at: 2026-09-20T04:02:32Z }
---

Maven coordinate: `org.springframework.security.oauth:spring-security-oauth:${spring-security-oauth.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
