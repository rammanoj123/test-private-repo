# Domain model

# Concepts

* [EntityConverter](EntityConverter.md) - `EntityConverter`. (Description pending enrichment.)
