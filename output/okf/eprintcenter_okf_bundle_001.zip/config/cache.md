---
type: Configuration
title: Cache
description: Cache configuration (pending enrichment).
tags: [config, cache]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-14T08:35:07Z }
---

| Key | Value |
| --- | --- |
| type | None |
| redis_host | None |
