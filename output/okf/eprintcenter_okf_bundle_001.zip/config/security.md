---
type: Configuration
title: Security
description: Security configuration (pending enrichment).
tags: [config, security]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-20T10:26:54Z }
---

| Key | Value |
| --- | --- |
| jwt_present | False |
| oauth2_providers | [] |
| ldap_url | None |
