---
type: Configuration
title: Security
description: Security configuration (pending enrichment).
tags: [config, security]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-18T16:39:07Z }
---

| Key | Value |
| --- | --- |
| jwt_present | False |
| oauth2_providers | [] |
| ldap_url | None |
