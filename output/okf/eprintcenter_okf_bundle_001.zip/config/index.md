# Configuration

# Concepts

* [Cache](cache.md) - Cache configuration (pending enrichment).
* [Application context](context.md) - Profiles and legacy XML wiring.
* [Security](security.md) - Security configuration (pending enrichment).
