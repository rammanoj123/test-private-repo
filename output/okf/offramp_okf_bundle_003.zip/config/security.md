---
type: Configuration
title: Security Configuration
description: Defines authentication, authorization, and ACL enforcement for printer-based access control.
tags: [config, security, authentication, authorization, acl]
status: stable
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
sources:
  - { id: security-md, resource: /config/security.md, title: Security configuration concept }
  - { id: applicationContext-security-xml, resource: /offramp/src/main/resources/applicationContext-security.xml, title: Security context }
---

| Key | Value |
| --- | --- |
| jwt_present | False |
| oauth2_providers | [] |
| ldap_url | None |

# Purpose

**What it controls**: This configuration defines authentication, authorization, and access control for the offramp service. It uses Spring Security with custom extensions for printer-based authentication and ACL enforcement.

**Authentication flows**: The system supports three distinct authentication flows, each with its own filter chain and authentication manager:

1. **Registration flow** (`/printers` POST): Authenticates new printers during registration using a claim code or temporary token. Uses [RegistrationAuthenticationProvider](/components/security/RegistrationAuthenticationProvider.md) and [RegistrationUserDetailsService](/components/services/RegistrationUserDetailsService.md). Entry point: [RegistrationAuthenticationEntryPoint](/components/misc/RegistrationAuthenticationEntryPoint.md).

2. **Validation flow** (`/validateprinter`): Validates printer credentials without granting full access. Used for health checks and credential verification. Uses a separate authentication manager (`offrampAuthenticationValidationManager`).

3. **Standard flow** (all other endpoints): Authenticates registered printers for normal operations (fetching jobs, uploading state reports, etc.). Uses [PrinterUserDetailsService](/components/services/PrinterUserDetailsService.md) for standard operations and [DeregPrinterUserDetailsService](/components/services/DeregPrinterUserDetailsService.md) for deregistration.

**Authorization**: After authentication, access decisions are made by ACL voters:
- [PrinterFilterAclEntryVoter](/components/security/PrinterFilterAclEntryVoter.md): Checks READ, UPDATE, DELETE permissions on printer resources. Ensures a printer can only access its own data.
- [SessionSecretFilterAclEntryVoter](/components/security/SessionSecretFilterAclEntryVoter.md): Controls access to session secrets used for secure printer-cloud communication.
- [TempTokenAuthorizationFilterAclEntryVoter](/components/security/TempTokenAuthorizationFilterAclEntryVoter.md): Validates temporary tokens for OAuth-like authorization flows.

All voters must approve (unanimous decision) for access to be granted.

**ACL persistence**: ACLs are stored in the database and managed by `jdbcMutableAclService` (a custom implementation with multi-tenant fixes). The `NullAclCache` bean disables ACL caching, prioritizing consistency over performance.

**Password encoding**: Printer passwords are hashed using [LegacySha256PasswordEncoder](/components/misc/LegacySha256PasswordEncoder.md), a custom SHA-256 encoder for backward compatibility with legacy printers. New implementations should migrate to bcrypt or PBKDF2, but the legacy encoder must remain for existing printers.

**OAuth support**: The system includes OAuth 1.0a provider support for user authorization flows (e.g., authorizing a printer to access a user's cloud storage). Managed by [UserAuthorizationTokenServices](/components/services/UserAuthorizationTokenServices.md) and [CustomUserAuthorizationProcessingFilter](/components/security/CustomUserAuthorizationProcessingFilter.md).

**Environment caveats**:
- **Development**: Security may be relaxed (e.g., disabled HTTPS enforcement, permissive CORS). Check `config.properties` for `security.enabled` and `security.strict` flags.
- **Production**: All endpoints require HTTPS. ACL checks are strictly enforced. Missing or invalid credentials result in 401 Unauthorized. ACL violations result in 403 Forbidden.
- **Testing**: Test context uses mock authentication providers and in-memory ACLs. Security filters may be disabled for unit tests that focus on business logic.

**Generator rules**:
1. **Preserve authentication flows**: Do not merge or remove the three authentication managers. Each flow has distinct requirements and failure modes.
2. **Respect ACL voters**: When adding new endpoints, ensure they are covered by the appropriate ACL voter. If a new permission type is needed, create a new voter and register it with `offrampAccessDecisionManager`.
3. **Do not bypass security**: Never add endpoints that skip the security filter chain. All endpoints must authenticate and authorize requests.
4. **Test all flows**: When modifying security configuration, test registration, validation, and standard flows independently. A change that breaks one flow may not affect the others.
5. **Password encoding**: Do not change the password encoder without a migration plan. Existing printers cannot authenticate if the encoder changes.
6. **OAuth tokens**: OAuth token operations are transactional (see [cross-cutting](/architecture/cross-cutting.md)). Do not remove transaction boundaries from token service methods.
