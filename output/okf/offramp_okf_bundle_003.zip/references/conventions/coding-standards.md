---
type: Reference
title: Coding standards
description: House style the code generator must follow.
tags: [conventions, codegen]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-14T06:38:26Z }
---

House style inferred from the codebase. The code generator must keep generated code consistent with these.

# Rules

* Wiring: XML bean definitions.
* Controllers stay thin; business logic lives in services.
* Persistence only through repositories.
* Transactions declared on service methods.
* Reuse existing DTOs/entities in `domain/` before adding new ones.
* Match existing package layout and naming.

_Enrichment agent: add project-specific rules (error handling, logging marker conventions, null-handling, validation patterns) observed in the codebase._
