---
type: Playbook
title: Bug fix flow
description: Traversal + generation steps for a bug-fix ticket.
tags: [playbook, codegen, bug]
status: stable
generated: { by: gpt-4o-2024-05-13/playbooks, at: 2025-01-15T12:00:00Z }
sources:
  - { id: service.md, resource: okf_bundle/service.md, title: offramp service }
  - { id: post-printers.md, resource: okf_bundle/api/post-printers.md, title: POST Printers endpoint }
  - { id: PrintersResource.md, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: PrinterUserDetailsService.md, resource: okf_bundle/components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
  - { id: coding-standards.md, resource: okf_bundle/references/conventions/coding-standards.md, title: Coding standards }
  - { id: build-and-test.md, resource: okf_bundle/architecture/build-and-test.md, title: Build and test }
---

# When the ticket reports a defect

1. Map the symptom to a use case or endpoint; walk its `Steps` to the component/method most likely responsible.
2. Inspect that component's `Depends on` and `Cross-cutting` sections for the smallest correct change.
3. Keep the change minimal and local; do not alter unrelated contracts.
4. Add or strengthen a test that reproduces the defect.
5. Attest via [build & test](/architecture/build-and-test.md).


# Traversal

For a bug-fix ticket, follow this route through the bundle:

### Entry

Map the symptom to a concept:

- If the bug manifests at an endpoint (e.g., "POST /Printers returns 500 instead of 400"), start at [api/](/api/index.md)
- If the bug is in a specific use case (e.g., "Printer registration fails for valid serial numbers"), start at [usecases/](/usecases/index.md)
- If the ticket names a component (e.g., "PrinterUserDetailsService throws NPE"), start at [components/](/components/index.md)

### Expansion

From the entry concept:

1. **Endpoint → Handler**: Follow `handler` to the controller component (e.g., [POST /Printers](/api/post-printers.md) → [PrintersResource](/components/controllers/PrintersResource.md))
2. **Use case → Steps**: Read the `Steps` section to identify which component/method is responsible for the failing step
3. **Component → Algorithm**: Read the `Algorithm` section to find the method most likely containing the bug
4. **Component → Depends on**: Check injected dependencies — the bug might be in a service the component calls (e.g., [PrinterUserDetailsService](/components/services/PrinterUserDetailsService.md))
5. **Component → Business rules**: Verify the fix doesn't violate existing business rules
6. **Cross-cutting**: Check [Cross-cutting](/architecture/cross-cutting.md) for logging, caching, or transaction issues

### Rules

Before fixing:

- Read [Coding standards](/references/conventions/coding-standards.md): "Keep changes minimal and local"
- Read the **Business context** and **Business rules** sections of the affected component to understand invariants
- **Do not alter unrelated contracts** — if the bug is in error handling, don't refactor the happy path

### Gate

After fixing:

1. **Add or strengthen a test** that reproduces the defect (e.g., `testValidateSerialNumber_NullInput_ThrowsException`)
2. Run [build & test](/architecture/build-and-test.md): `mvn -B -q -DskipTests=false test`
3. Attest: exit code 0, goal `test`, 0 failures, 0 errors
4. **Refuse to propose** if attestation fails

### Sync

After a successful fix:

- Update the affected component's `Algorithm` section if the logic changed
- Update `Business rules` if the fix clarifies or corrects a rule
- If the bug was in an endpoint's error response, update the [api/](/api/index.md) concept's `Errors` table
- **Do not** update use cases or add new concepts unless the fix changes observable behavior

Keep the change minimal and the bundle synchronized.

# Worked example

**Ticket**: "POST /Printers returns 500 Internal Server Error when PrinterIdentification.serialNumber is null, should return 400 Bad Request"

### 1. Entry

Search for the symptom:

- Found: [POST /Printers](/api/post-printers.md) (endpoint)
- Found: [PrintersResource](/components/controllers/PrintersResource.md) (handler)

Entry point: [POST /Printers](/api/post-printers.md)

### 2. Expansion

Follow the graph:

- [POST /Printers](/api/post-printers.md) → handler: `SpringFinder.represent` (maps to [PrintersResource](/components/controllers/PrintersResource.md))
- [PrintersResource](/components/controllers/PrintersResource.md) → `Algorithm` section:
  - Step 11: "Validate serial number via validateSerialNumber(printerIdentification)"
  - Step 22: "In finally block, call actOnRegRequestFailure to log failure and set appropriate HTTP status"
- [PrintersResource](/components/controllers/PrintersResource.md) → `Methods` table:
  - `validateSerialNumber(PrinterIdentification)` — checks if serial number is in restricted list
  - `actOnRegRequestFailure(Exception, ...)` — maps exceptions to HTTP status codes

**Hypothesis**: `validateSerialNumber` doesn't handle null serial numbers, causing a NullPointerException that gets mapped to 500 by `actOnRegRequestFailure`.

### 3. Rules

Read:

- [Coding standards](/references/conventions/coding-standards.md): "Keep changes minimal and local"
- [PrintersResource Business rules](/components/controllers/PrintersResource.md): "If registration data is invalid or missing required attributes, return 400 BAD_REQUEST."
- [PrintersResource Algorithm](/components/controllers/PrintersResource.md): `validateSerialNumber` is called before `checkRequiredAttributes`, so null checks should happen in validation

**Decision**: Add null check to `validateSerialNumber` and throw `RegistrationDataInvalidException` (which `actOnRegRequestFailure` maps to 400).

### 4. Fix

Update `PrintersResource.validateSerialNumber`:

```java
private void validateSerialNumber(PrinterIdentification printerIdentification) 
        throws RegistrationDataInvalidException {
    String curSerialNumber = printerIdentification.getSerialNumber();
    
    // Add null check
    if (curSerialNumber == null || curSerialNumber.trim().isEmpty()) {
        throw new RegistrationDataInvalidException("Serial number is required");
    }
    
    String invalidSerialNumberList = 
        getOfframpAPIConfigInstance().RESTRICTED_SERIAL_NUMBERS_LIST;
    
    if (!invalidSerialNumberList.isEmpty()) {
        String[] restrictedSerials = invalidSerialNumberList.split(",");
        for (String restricted : restrictedSerials) {
            if (curSerialNumber.trim().equalsIgnoreCase(restricted.trim())) {
                throw new RegistrationDataInvalidException(
                    REGISTRATION_DATA_INVALID_MESSAGE);
            }
        }
    }
}
```

Add test to `PrintersResourceTest.java`:

```java
@Test
public void testValidateSerialNumber_NullSerialNumber_ThrowsException() {
    // Arrange
    PrinterIdentification id = new PrinterIdentification();
    id.setSerialNumber(null);
    
    // Act & Assert
    RegistrationDataInvalidException ex = assertThrows(
        RegistrationDataInvalidException.class,
        () -> printersResource.validateSerialNumber(id)
    );
    assertEquals("Serial number is required", ex.getMessage());
}

@Test
public void testValidateSerialNumber_EmptySerialNumber_ThrowsException() {
    // Arrange
    PrinterIdentification id = new PrinterIdentification();
    id.setSerialNumber("   ");
    
    // Act & Assert
    assertThrows(RegistrationDataInvalidException.class,
        () -> printersResource.validateSerialNumber(id));
}
```

### 5. Gate

Run attestation:

```bash
mvn -B -q -DskipTests=false test
```

Check receipt:
- `exit_code`: 0 ✓
- `executed_goal`: test ✓
- `surefire_summary`: Tests run: 144, Failures: 0, Errors: 0, Skipped: 0 ✓

**Attestation PASS** → proceed to propose the change.

### 6. Sync

Update [PrintersResource](/components/controllers/PrintersResource.md):

- Update `Algorithm` section, step 11: "Validate serial number via validateSerialNumber(printerIdentification) — throws RegistrationDataInvalidException if null, empty, or in restricted list"
- Update `Business rules`: "If serial number is null or empty, reject registration with 400 BAD_REQUEST."

Update [POST /Printers](/api/post-printers.md):

- Confirm `Errors` table already lists: "400 Bad Request | Invalid or missing registration data" (covers this case)

No use case update needed — the observable behavior (400 for invalid data) was always intended; the bug was in the implementation.
