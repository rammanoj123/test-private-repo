---
type: Playbook
title: JIRA ticket → code
description: How the multi-agent code generator consumes this bundle to fulfil a ticket.
tags: [playbook, codegen]
status: stable
generated: { by: gpt-4o-2024-05-13/playbooks, at: 2025-01-15T12:00:00Z }
sources:
  - { id: service.md, resource: okf_bundle/service.md, title: offramp service }
  - { id: post-printers.md, resource: okf_bundle/api/post-printers.md, title: POST Printers endpoint }
  - { id: PrintersResource.md, resource: okf_bundle/components/controllers/PrintersResource.md, title: PrintersResource controller }
  - { id: PrinterUserDetailsService.md, resource: okf_bundle/components/services/PrinterUserDetailsService.md, title: PrinterUserDetailsService }
  - { id: printer.md, resource: okf_bundle/dependencies/internal/printer.md, title: printer library }
  - { id: coding-standards.md, resource: okf_bundle/references/conventions/coding-standards.md, title: Coding standards }
  - { id: build-and-test.md, resource: okf_bundle/architecture/build-and-test.md, title: Build and test }
---

This bundle is the knowledge source for a code-generation pipeline. Given a JIRA ticket (feature or bug), the pipeline traverses the OKF graph rather than re-reading raw source.



# Procedure

1. **Locate entry concepts.** Match ticket text against concept `title`/`description`/`tags`. Endpoints, use cases and components are the usual entry points.
2. **Assemble the impacted subgraph.** From each entry concept follow links: an endpoint → its handler component → the components it *Depends on* → the domain entities they touch → the internal libraries and services involved.
3. **Cross bundles when needed.** If an impacted dependency concept has an `okf_ref`, load that bundle and repeat locally.
4. **Read the rules.** Pull [layering](/architecture/layering.md) and [coding standards](/references/conventions/coding-standards.md).
5. **Generate the change** consistent with the conventions and existing component contracts.
6. **Attest.** Run [build & test](/architecture/build-and-test.md) and refuse to propose a change whose attestation fails.

See [feature enhancement](/playbooks/feature-enhancement.md) and [bug fix](/playbooks/bug-fix.md) for the two concrete flows.


# Traversal

The code generator follows this graph walk to turn a JIRA ticket into a change:

### Entry

Map the ticket's nouns ("printer registration", "email address", "claim code") to concepts by matching against `title`, `description`, and `tags`:

- **API endpoints** in [api/](/api/index.md) — e.g., [POST /Printers](/api/post-printers.md) for printer registration tickets
- **Use cases** in [usecases/](/usecases/index.md) — e.g., UC-003: Register printer
- **Components** in [components/](/components/index.md) — when the ticket names a specific service or controller

### Expansion

From each entry concept, traverse outward:

1. **Endpoint → Handler**: Follow the `handler` field to the controller component (e.g., [POST /Printers](/api/post-printers.md) → [PrintersResource](/components/controllers/PrintersResource.md))
2. **Handler → Dependencies**: Read the controller's `Depends on` section to find injected services (e.g., PrinterManager, ICollectionServiceClient, SimpleCacheClient)
3. **Services → Domain**: Follow service method signatures to domain entities and DTOs (e.g., Printer, PrinterIdentification, PrinterConfiguration)
4. **Domain → Libraries**: Check which internal libraries supply domain types (e.g., [printer](/dependencies/internal/printer.md) library for Printer entity)
5. **Cross-bundle**: If a dependency concept has an `okf_ref`, load that external bundle and continue the traversal there

### Rules

Before generating code, read:

- [Coding standards](/references/conventions/coding-standards.md) — house style (XML wiring, thin controllers, service-layer transactions, DTO reuse)
- [Layering](/architecture/layering.md) — architectural constraints
- **Business context** section of each touched component — domain rules and invariants

### Gate

After generating the change:

1. Run [build & test](/architecture/build-and-test.md): `mvn -B -q -DskipTests=false test`
2. Attest the result: exit code 0, executed goal `test`, Surefire summary shows 0 failures and 0 errors
3. **Refuse to propose** any change whose attestation fails

### Sync

After a successful change, update the affected OKF concepts:

- If a new endpoint was added, create or update the corresponding [api/](/api/index.md) concept
- If a use case changed, update the [usecases/](/usecases/index.md) concept
- If dependencies shifted, update the `Depends on` sections and [ecosystem](/ecosystem/ecosystem.md) links

This keeps the bundle synchronized with the code.

# Worked example

**Ticket**: "Add validation to reject printers with restricted serial numbers during registration"

### 1. Entry

Search for "printer registration" in concept titles and tags:

- Found: [POST /Printers](/api/post-printers.md) (tags: `registration`, `printer`)
- Found: [PrintersResource](/components/controllers/PrintersResource.md) (description: "Handles POST requests to register new printers")

Entry point: [POST /Printers](/api/post-printers.md)

### 2. Expansion

Follow the graph:

- [POST /Printers](/api/post-printers.md) → handler: `SpringFinder.represent` (maps to [PrintersResource](/components/controllers/PrintersResource.md))
- [PrintersResource](/components/controllers/PrintersResource.md) → `Depends on`:
  - PrinterManager (from [printer](/dependencies/internal/printer.md) library)
  - ICollectionServiceClient
  - SimpleCacheClient
  - OfframpVersionFactory → [OfframpVersionFactory](/components/config/OfframpVersionFactory.md)
  - OfframpHelper
- [PrintersResource](/components/controllers/PrintersResource.md) → `Algorithm` section shows `validateSerialNumber(printerIdentification)` method already exists
- Domain entities: PrinterIdentification, Printer (from [printer](/dependencies/internal/printer.md) library)

### 3. Rules

Read:

- [Coding standards](/references/conventions/coding-standards.md): "Controllers stay thin; business logic lives in services"
- [PrintersResource Business rules](/components/controllers/PrintersResource.md): "If serial number is in restricted list, reject registration with 400 BAD_REQUEST"
- Existing `validateSerialNumber` method: checks `OffRampAPIConfig.RESTRICTED_SERIAL_NUMBERS_LIST` and throws `RegistrationDataInvalidException` if match found

**Decision**: The validation already exists. The ticket likely requests extending the restricted list or fixing a bug in the validation logic. Check `OffRampAPIConfig` for the list source.

### 4. Generate

If the restricted list is hardcoded, refactor to load from configuration. If it's a bug (e.g., case-sensitivity), fix the comparison in `validateSerialNumber`.

Example change (bug fix for case-insensitive comparison):

```java
// In PrintersResource.validateSerialNumber
if (curSerialNumber != null && !invalidSerialNumberList.isEmpty()) {
    String[] restrictedSerials = invalidSerialNumberList.split(",");
    for (String restricted : restrictedSerials) {
        if (curSerialNumber.trim().equalsIgnoreCase(restricted.trim())) {
            throw new RegistrationDataInvalidException(REGISTRATION_DATA_INVALID_MESSAGE);
        }
    }
}
```

### 5. Gate

Run attestation:

```bash
mvn -B -q -DskipTests=false test
```

Check receipt:
- `exit_code`: 0 ✓
- `executed_goal`: test ✓
- `surefire_summary`: Tests run: 142, Failures: 0, Errors: 0, Skipped: 0 ✓

**Attestation PASS** → proceed to propose the change.

### 6. Sync

Update [PrintersResource](/components/controllers/PrintersResource.md):

- Add to `Business rules`: "Serial number comparison is case-insensitive and whitespace-trimmed."
- Update `Algorithm` section for `validateSerialNumber` to reflect the case-insensitive logic

No new endpoints or use cases were added, so no other concepts need updating.
