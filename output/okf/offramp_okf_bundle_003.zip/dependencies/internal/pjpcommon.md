---
type: Internal Library
title: Print Job Processing Common Library
description: Provides common utilities and models for print job processing workflows.
tags: [dependency, internal, library, printjob, common]
status: draft
artifact_id: pjpcommon
depends_on_bundle: hp/pjpcommon
group_id: com.hp.cloudprint
scope: compile
version: 25.1.10
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:pjpcommon:25.1.10`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/pjpcommon`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
