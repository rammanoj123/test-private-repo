---
type: Internal Library
title: Print Job Processing Services Library
description: Provides service layer for print job processing including rendering and delivery.
tags: [dependency, internal, library, printjob, services]
status: draft
artifact_id: pjpservices
depends_on_bundle: hp/pjpservices
group_id: com.hp.cloudprint
scope: compile
version: 25.1.10
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:pjpservices:25.1.10`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/pjpservices`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
