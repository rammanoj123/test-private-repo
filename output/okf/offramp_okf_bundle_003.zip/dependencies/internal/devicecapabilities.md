---
type: Internal Library
title: Device Capabilities Library
description: Provides device capability models and parsers for printer feature detection and configuration.
tags: [dependency, internal, library, device, capabilities]
status: draft
artifact_id: devicecapabilities
depends_on_bundle: hp/devicecapabilities
group_id: com.hp.cloudprint
scope: compile
version: 25.1.7
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:devicecapabilities:25.1.7`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/devicecapabilities`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
