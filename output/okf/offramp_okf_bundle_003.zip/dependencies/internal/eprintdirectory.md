---
type: Internal Library
title: ePrint Directory Library
description: Provides directory services for ePrint email address management and printer lookup.
tags: [dependency, internal, library, eprint, directory]
status: draft
artifact_id: eprintDirectory
depends_on_bundle: hp/eprintdirectory
group_id: com.hp.cloudprint
scope: compile
version: 25.1.6
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:eprintDirectory:25.1.6`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/eprintdirectory`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
