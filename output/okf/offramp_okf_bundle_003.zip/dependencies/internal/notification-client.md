---
type: Internal Library
title: Notification Client Library
description: Provides client for sending push notifications to printers and users via notification service.
tags: [dependency, internal, library, notification, client]
status: draft
artifact_id: notification-client
depends_on_bundle: hp/notification-client
group_id: com.hp.cloudprint
scope: compile
version: 25.2.4
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:notification-client:25.2.4`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/notification-client`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
