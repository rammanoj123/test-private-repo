---
type: Internal Library
title: Entity Models Library
description: Provides JPA entity models for database persistence of printers, jobs, and users.
tags: [dependency, internal, library, entity, persistence]
status: draft
artifact_id: entities
depends_on_bundle: hp/entities
group_id: com.hp.cloudprint
scope: compile
version: 25.4.1
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:entities:25.4.1`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/entities`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
