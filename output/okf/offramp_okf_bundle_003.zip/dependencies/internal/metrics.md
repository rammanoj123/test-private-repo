---
type: Internal Library
title: Metrics Library
description: Provides metrics collection and reporting for service performance monitoring and alerting.
tags: [dependency, internal, library, metrics, monitoring]
status: draft
artifact_id: metrics
depends_on_bundle: hp/metrics
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:metrics:25.1.4`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/metrics`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
