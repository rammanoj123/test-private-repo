---
type: Internal Library
title: Job Execution Framework API
description: Provides Job Execution Framework API for job lifecycle management and execution.
tags: [dependency, internal, library, job, framework]
status: draft
artifact_id: jefapi
depends_on_bundle: hp/jefapi
group_id: com.hp.cloudprint
scope: compile
version: 25.1.13
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:jefapi:25.1.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/jefapi`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
