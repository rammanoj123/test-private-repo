---
type: Internal Library
title: Simple Cache Client Library
description: Provides Memcached client wrapper for distributed caching in Web Print Platform services.
tags: [dependency, internal, library, cache, memcached]
status: draft
artifact_id: wp-simplecache-client
depends_on_bundle: hp/wp-simplecache-client
group_id: com.hp.iws.wpp
scope: compile
version: ${simplecache-client-version}
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.iws.wpp:wp-simplecache-client:${simplecache-client-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wp-simplecache-client`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
