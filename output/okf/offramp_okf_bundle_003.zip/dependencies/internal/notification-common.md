---
type: Internal Library
title: Notification Common Library
description: Provides common notification models and utilities shared across notification services.
tags: [dependency, internal, library, notification, common]
status: draft
artifact_id: notification-common
depends_on_bundle: hp/notification-common
group_id: com.hp.cloudprint
scope: compile
version: 25.2.3
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:notification-common:25.2.3`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/notification-common`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
