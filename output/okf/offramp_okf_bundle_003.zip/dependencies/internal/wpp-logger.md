---
type: Internal Library
title: Web Print Platform Logger Library
description: Provides logging framework and utilities for Web Print Platform service diagnostics.
tags: [dependency, internal, library, logging, wpp]
status: draft
artifact_id: wpp-logger
depends_on_bundle: hp/wpp-logger
group_id: com.hp.wpp
scope: compile
version: 2.2.14
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.wpp:wpp-logger:2.2.14`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wpp-logger`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
