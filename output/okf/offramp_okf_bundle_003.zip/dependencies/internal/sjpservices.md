---
type: Internal Library
title: Scan Job Processing Services Library
description: Provides service layer for scan job processing including document handling and workflow.
tags: [dependency, internal, library, scanjob, services]
status: draft
artifact_id: sjpservices
depends_on_bundle: hp/sjpservices
group_id: com.hp.cloudprint
scope: compile
version: 25.1.10
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:sjpservices:25.1.10`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/sjpservices`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
