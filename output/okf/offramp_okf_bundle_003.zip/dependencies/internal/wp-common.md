---
type: Internal Library
title: Web Print Platform Common Library
description: Provides common utilities and models shared across Web Print Platform services.
tags: [dependency, internal, library, wpp, common]
status: draft
artifact_id: wp-common
depends_on_bundle: hp/wp-common
group_id: com.hp.iws.wpp
scope: compile
version: ${wpp-version}
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.iws.wpp:wp-common:${wpp-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wp-common`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
