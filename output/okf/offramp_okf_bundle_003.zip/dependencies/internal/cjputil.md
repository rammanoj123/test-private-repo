---
type: Internal Library
title: Cloud Job Processing Utilities
description: Provides utility functions and helpers for cloud job processing operations.
tags: [dependency, internal, library, utility, job]
status: draft
artifact_id: cjputil
depends_on_bundle: hp/cjputil
group_id: com.hp.cloudprint
scope: compile
version: 25.1.4
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

Maven coordinate: `com.hp.cloudprint:cjputil:25.1.4`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/cjputil`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
