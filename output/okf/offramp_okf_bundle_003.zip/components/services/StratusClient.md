---
type: Component
title: Stratus Client
description: Defines interface for publishing printer ownership deletion events to Stratus eventing service.
tags: [component, service, interface, stratus, eventing]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\StratusClient.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: StratusClient.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/StratusClient.java, title: StratusClient.java }
---

`com.hp.cloudprint.api.offramp.StratusClient`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishDeleteOwnershipToStratus | void | String ownershipId, String  printerid |  |

# Business context

Service interface defining the contract for publishing printer ownership deletion events to the Stratus eventing service. Implemented by components that handle deregistration workflows and need to notify downstream systems of ownership changes.

# Algorithm

**publishDeleteOwnershipToStratus**
1. Accept `ownershipId` and `printerId` parameters
2. Publish ownership deletion event to Stratus eventing service
3. Throw `StratusClientException` for general errors
4. Throw `NotificationRetriableException` for transient failures that can be retried
5. Throw `NotificationNotRetriableException` for permanent failures

# Business rules

• The method throws three distinct exception types to enable callers to distinguish between retriable and non-retriable failures.
• Implementations must handle ownership deletion event publishing with appropriate error handling.
• The interface supports asynchronous event-driven architectures for printer deregistration.

# Participates in

• Printer deregistration workflows
• Ownership deletion event publishing
