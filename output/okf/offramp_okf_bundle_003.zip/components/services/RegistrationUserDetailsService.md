---
type: Component
title: Registration User Details Service
description: Loads registration credentials from cache or database, validates domain keys, and tracks failed attempts.
tags: [component, service, security, registration, user-details]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: registration-user-details-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/RegistrationUserDetailsService.java }
---

`com.hp.cloudprint.api.offramp.security.RegistrationUserDetailsService`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| SIMPLECACHE_WEIGHT_INCREMENT | int |  |
| LOGGER | Logger |  |
| SEPARATOR | String |  |
| TEST_DOMAIN | String |  |
| cachedTestDomainMasterKey | String |  |
| cachedKeyRefreshConfigValue | int |  |
| lock | Lock |  |
| KEY_SEPERATOR | String |  |
| securityManager | SecurityManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| arrParams | String[] | @Override |
| modelNumber | String | @Override |
| registrationDomain | String | @Override |
| id | String | @Override |
| memcacheKey | String |  |
| blockThreshold | int |  |
| key | String |  |
| regAttemptsObj | Object |  |
| regAttempts | Integer |  |
| domain | PrinterRegistrationDomain |  |
| key | String |  |
| keyRefreshConfigValue | int |  |
| key | String |  |
| validationResult | boolean |  |
| digest | MessageDigest |  |
| hash | byte[] |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| RegistrationUserDetailsService |  |  |  |
| loadUserByUsername | UserDetails | String userName |  |
| readFromCache | void | String memcacheKey, String modelNumber, String id, int blockThreshold |  |
| getUserKeyFromDB | String | String userName, String modelNumber, String registrationDomain |  |
| getTestDomainUserKey | String | String userName, String modelNumber |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getTestDomainKeyRefreshConfig | int |  |  |
| getCachedTestDomainMasterKey | String |  |  |
| getCachedKeyRefreshConfigValue | int |  |  |
| isDomainKeyHashCheckEnabled | boolean |  |  |
| getSHA256Hash | String | String key |  |


# Depends on

- [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) - retrieves blockThreshold, keyRefreshConfig, domainKeyHashCheckEnabled
- SecurityManager - retrieves PrinterRegistrationDomain, validates model numbers
- SimpleCacheClient - tracks registration attempts for blocking logic
- RegistrationAttemptsHolder - thread-local storage for attempt tracking
- PrinterRegistrationDomain entity - holds domain master keys
- Spring Security Core - UserDetailsService, User, UsernameNotFoundException, SimpleGrantedAuthority
- Spring MessageSource - internationalized error messages
- Java security - MessageDigest for SHA-256 hashing
- ReentrantLock - thread-safe test domain key refresh

# Algorithm

**loadUserByUsername(String userName)**: Main authentication method for printer registration. Parses username format "ModelNumber+RegistrationDomain+ID" (ID is serialNumber for v1.7, registrationID for v2.0+). Validates all three components are non-null and non-empty, throwing UsernameNotFoundException if invalid. Constructs memcache key from modelNumber and ID. If blockThreshold > 0, calls readFromCache() to check/track registration attempts. Retrieves domain key: if registrationDomain is "test_domain", calls getTestDomainUserKey(); otherwise calls getUserKeyFromDB(). If domain key hash check enabled, appends '$' + SHA256 hash of key. Returns User object with username, key (possibly with hash), all account flags true, and "ROLE_PRINTER" authority.

**readFromCache(String memcacheKey, String modelNumber, String id, int blockThreshold)**: Retrieves registration attempt count from cache. Defaults to 1 if not found. Increments count by 1. Stores key and count in RegistrationAttemptsHolder thread-local. If count exceeds blockThreshold, throws BlockedPrinterException. Logs and ignores cache access exceptions.

**getUserKeyFromDB(String userName, String modelNumber, String registrationDomain)**: Retrieves PrinterRegistrationDomain entity via securityManager. Throws DataRetrievalFailureException on exceptions. Throws UsernameNotFoundException if domain not found. Returns domain's masterKey.

**getTestDomainUserKey(String userName, String modelNumber)**: Implements double-checked locking with refresh logic for test domain key caching. On first access, fetches key from DB and caches it. Checks if keyRefreshConfig changed; if so, uses tryLock() to refresh cache (non-blocking). Validates modelNumber via securityManager.validateModelNumber(). Returns cached test domain master key.

**getSHA256Hash(String key)**: Computes SHA-256 hash of key bytes (UTF-8), returns Base64-encoded string. Throws RuntimeException if SHA-256 algorithm unavailable.

# Business context

RegistrationUserDetailsService implements Spring Security's UserDetailsService for printer registration authentication. It validates printer credentials against domain master keys stored in the database, supports test domain with cached keys, tracks registration attempts via cache to prevent abuse, and optionally appends SHA-256 hashes for additional validation. The service enforces printer blocking based on failed registration attempt thresholds.

# Business rules

- Username format: "ModelNumber+RegistrationDomain+ID" (3 parts separated by '+')
- ID field is serialNumber for offramp v1.7 and below, registrationID for v2.0+
- All three username components must be non-null and non-empty
- Memcache key format: "ModelNumber_ID"
- Registration attempt tracking only enabled if blockThreshold > 0
- Registration attempts increment by 1 on each call
- Printer blocked if attempts exceed blockThreshold (throws BlockedPrinterException)
- Cache access failures logged but do not block registration
- Special domain "test_domain" uses cached master key with refresh logic
- Test domain key cached on first access with double-checked locking
- Test domain key refreshed when REGISTRATION_TESTDOMAIN_KEY_REFRESH_CONFIG changes
- Test domain requires model number validation via securityManager
- Non-test domains fetch master key from PrinterRegistrationDomain table
- Domain key hash check appends '$' + Base64(SHA256(key)) if enabled
- All authenticated printers granted "ROLE_PRINTER" authority
- All User account flags set to true

# Participates in

- Spring Security authentication for printer registration flows
- Printer registration credential validation
- Registration attempt tracking and printer blocking
- Test domain authentication with cached credentials
- Domain master key retrieval and validation
- SHA-256 hash-based additional authentication
- Role-based access control with ROLE_PRINTER authority
