---
type: Component
title: Printer User Details Service
description: Loads printer user details from database for authentication during normal operations.
tags: [component, service, security, user-details, authentication]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\PrinterUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: printer-user-details-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/PrinterUserDetailsService.java }
---

`com.hp.cloudprint.api.offramp.security.PrinterUserDetailsService`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| LOGGER | Logger |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |

# Algorithm

**loadUserByUsername(String userName)**: Implements Spring Security's UserDetailsService for printer authentication during normal operations. Logs the printer lookup. Calls printerManager.getActivePrinterByPrinterID(userName) to retrieve printer. If DeviceNotFoundExcpeption thrown, throws UsernameNotFoundException with i18n message. On other exceptions, logs error and throws DataRetrievalFailureException. If printer is null, throws UsernameNotFoundException. Extracts printerID and printerKey from printer entity. Constructs Spring Security User object with username=printerID, password=printerKey, all account flags=true, and granted authority="ROLE_PRINTER". Returns User object.

# Business context

PrinterUserDetailsService implements Spring Security's UserDetailsService to load printer credentials for authentication during normal printer operations (post-registration). It retrieves active printer records from the database and constructs Spring Security User objects with printer credentials. Unlike DeregPrinterUserDetailsService, this service does not include cache cleanup logic for blocked printers.

# Business rules

- Username parameter is the printer ID
- Only active printers can be loaded (via getActivePrinterByPrinterID)
- Printer not found throws UsernameNotFoundException immediately (no cache cleanup)
- All User account flags set to true (enabled, accountNonExpired, credentialsNonExpired, accountNonLocked)
- All authenticated printers granted "ROLE_PRINTER" authority
- Database retrieval failures throw DataRetrievalFailureException
- Error messages retrieved from Spring Security's message source for i18n support

# Depends on

- [PrinterManager](/components/services/PrinterManager.md) - retrieves active printer entities
- Spring Security Core - UserDetailsService, UserDetails, User, UsernameNotFoundException, SimpleGrantedAuthority
- Spring Security MessageSource - internationalized error messages
- Printer entity - source of printer ID and key
- SLF4J Logger - structured logging with LogConstants

# Participates in

- Spring Security authentication for normal printer operations
- Printer credential loading and validation
- Role-based access control with ROLE_PRINTER authority
- Database-backed authentication for printer operations
- Post-registration printer authentication flows
