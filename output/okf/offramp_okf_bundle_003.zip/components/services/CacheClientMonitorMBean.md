---
type: Component
title: Cache Client Monitor MBean
description: Exposes JMX operation to reconfigure cache server connections at runtime.
tags: [component, service, jmx, cache, monitoring]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\oam\CacheClientMonitorMBean.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: cache-monitor-mbean-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/oam/CacheClientMonitorMBean.java }
---

`com.hp.cloudprint.api.offramp.oam.CacheClientMonitorMBean`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| reconfigureCacheServers | int |  |  |

# Algorithm

**reconfigureCacheServers()**: JMX operation that triggers reconfiguration of cache server connections. Fetches updated list of cache servers from configuration source. Reconfigures the cache client to use the new server list. Returns the count of active memcached servers after reconfiguration. May throw MBeanException if reconfiguration fails.

# Business context

CacheClientMonitorMBean is a JMX management interface that exposes runtime operations for cache infrastructure management. It allows administrators to dynamically reconfigure cache server connections without restarting the application. This is critical for operational scenarios like cache server maintenance, failover, or scaling where the cache topology changes.

# Business rules

- Operation can be invoked via JMX console or programmatic JMX client
- Fetches cache server configuration from external configuration source (not hardcoded)
- Returns integer count of active memcached servers post-reconfiguration
- May throw MBeanException on configuration errors or connection failures
- Enables zero-downtime cache infrastructure changes

# Depends on

- JMX framework - javax.management.MBeanException
- Cache client implementation (not directly referenced in interface)
- Configuration service for cache server list retrieval

# Participates in

- JMX-based operational management and monitoring
- Cache infrastructure reconfiguration workflows
- Runtime cache server topology updates
- Memcached cluster management
