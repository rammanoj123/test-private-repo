---
type: Component
title: Deregistration Printer User Details Service
description: Loads printer user details for deregistration, checking blocked status via cache before database lookup.
tags: [component, service, security, user-details, deregistration]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\DeregPrinterUserDetailsService.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: dereg-printer-user-details-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/DeregPrinterUserDetailsService.java }
---

`com.hp.cloudprint.api.offramp.security.DeregPrinterUserDetailsService`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager |  |
| simpleCacheClient | SimpleCacheClient |  |
| LOGGER | Logger |  |
| VIP_PRINTER | String |  |
| messages | MessageSourceAccessor |  |
| printer | Printer | @Override |
| username | String |  |
| password | String |  |
| user | User |  |
| BLOCKED_ATTEMPTS_COUNTER_ID_STR | String |  |
| simpleCacheKey | String |  |
| simpleCacheKeyObj | Object |  |
| extendedCacheKey | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| loadUserByUsername | UserDetails | String userName |  |
| deleteFromCache | void | String printerID |  |
| getPrinterManager | PrinterManager |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getSimpleCacheClient | SimpleCacheClient |  |  |
| setSimpleCacheClient | void | SimpleCacheClient simpleCacheClient |  |
| getMessages | MessageSourceAccessor |  |  |
| setMessages | void | MessageSourceAccessor messages |  |

# Algorithm

**loadUserByUsername(String userName)**: Implements Spring Security's UserDetailsService for printer deregistration authentication. Logs the printer lookup. Calls printerManager.getActivePrinterByPrinterID(userName) to retrieve printer. If DeviceNotFoundExcpeption thrown, calls deleteFromCache(userName) and throws UsernameNotFoundException. On other exceptions, logs error and throws DataRetrievalFailureException. If printer is null, throws UsernameNotFoundException. Extracts printerID and printerKey from printer entity. Constructs Spring Security User object with username=printerID, password=printerKey, all account flags=true, and granted authority="ROLE_PRINTER". Returns User object.

**deleteFromCache(String printerID)**: Attempts to clean up cache entries for blocked printers. Retrieves cache key from simpleCacheClient using "VIP_PRINTER_" + printerID. If cache key found and non-empty, constructs extended cache key by appending "_BLOCKED_ATTEMPTS_COUNT". Deletes both cache keys from simpleCacheClient. Logs deletion with cache keys. Catches and logs exceptions without propagating.

# Business context

DeregPrinterUserDetailsService implements Spring Security's UserDetailsService to load printer credentials for deregistration operations. It retrieves active printer records from the database and constructs Spring Security User objects with printer credentials. The service includes cache cleanup logic to remove blocked printer entries when a printer is not found, supporting the printer blocking/unblocking mechanism.

# Business rules

- Username parameter is the printer ID
- Only active printers can be loaded (via getActivePrinterByPrinterID)
- Printer not found triggers cache cleanup before throwing UsernameNotFoundException
- All User account flags set to true (enabled, accountNonExpired, credentialsNonExpired, accountNonLocked)
- All authenticated printers granted "ROLE_PRINTER" authority
- Cache cleanup targets two keys: VIP_PRINTER_{printerID} and the stored key + "_BLOCKED_ATTEMPTS_COUNT"
- Cache cleanup failures are logged but do not prevent authentication flow
- Database retrieval failures throw DataRetrievalFailureException
- Error messages retrieved from Spring Security's message source for i18n support

# Depends on

- [PrinterManager](/components/services/PrinterManager.md) - retrieves active printer entities
- SimpleCacheClient - cache operations for blocked printer tracking
- Spring Security Core - UserDetailsService, UserDetails, User, UsernameNotFoundException, SimpleGrantedAuthority
- Spring Security MessageSource - internationalized error messages
- Printer entity - source of printer ID and key
- SLF4J Logger - structured logging with LogConstants

# Participates in

- Spring Security authentication for printer deregistration flows
- Printer credential loading and validation
- Blocked printer cache management and cleanup
- Role-based access control with ROLE_PRINTER authority
- Database-backed authentication for printer operations
