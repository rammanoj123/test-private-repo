---
type: Component
title: User Authorization Token Services
description: Manages OAuth request tokens, authorization, and access token creation for user authorization flows.
tags: [component, service, oauth, token, authorization]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\UserAuthorizationTokenServices.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: UserAuthorizationTokenServices.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/UserAuthorizationTokenServices.java, title: UserAuthorizationTokenServices.java }
---

`com.hp.cloudprint.api.offramp.security.UserAuthorizationTokenServices`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| authoritiesToVerify | List |  |
| securityManager | SecurityManager |  |
| token | RequestTokenEntity | @Override, @Transactional |
| tokenToVerify | RequestTokenEntity | @Override, @Transactional |
| grantedAuthority | String | @Override, @Transactional |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | RequestTokenEntity | String token |  |
| removeToken | void | String token |  |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication | @Transactional |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token | @Transactional |
| isExpired | boolean | RequestTokenEntity tokenToVerify | @Transactional |
| setAuthoritiesToVerify | void | List<String> authoritiesToVerify | @Transactional |
| getAuthoritiesToVerify | List |  | @Transactional |


# Cross-cutting

* Transactional: `authorizeRequestToken`, `getToken`, `isExpired`, `setAuthoritiesToVerify`, `getAuthoritiesToVerify`

# Business context

Implements OAuth 1.0 provider token services for user authorization flows. Manages request token lifecycle including authorization, validation, and expiration. Enforces authority-based access control by verifying consumer authorities against a whitelist. The transactional boundary ensures token state consistency during authorization and validation.

# Algorithm

**authorizeRequestToken** (@Transactional)
1. Read token from storage via `securityManager.getRequestToken(requestToken)`
2. If token is null, throw `InvalidOAuthTokenException`
3. Check if token is expired via `isExpired(token)`
4. If expired, remove token via `removeToken(requestToken)` and throw `ExpiredOAuthTokenException`
5. Set authenticated user on token via `token.setUser(authentication.getName())`
6. Reset creation time to current GMT time (resets expiration window)
7. Set verification code on token via `token.setVerificationCode(verifier)`
8. Update token in storage via `securityManager.updateRequestToken(token)`

**getToken** (@Transactional)
1. Read token from storage via `readToken(token)`
2. Validate token and consumer authorities exist; if not, throw `InvalidOAuthTokenException`
3. Extract first granted authority from consumer
4. Check if authority is in `authoritiesToVerify` list; if not, throw `InvalidOAuthTokenException`
5. Check if token is expired via `isExpired(tokenToVerify)`
6. If expired, remove token via `removeToken(token)` and throw `ExpiredOAuthTokenException`
7. Return the validated token

**isExpired**
1. Calculate expiration timestamp: `tokenToVerify.getCreationTime() + (tokenToVerify.getConsumer().getRequestTokenExpirationValue() * 1000)`
2. Compare against current GMT time in milliseconds
3. Return true if current time exceeds expiration timestamp

**readToken**
1. Delegate to `securityManager.getRequestToken(token)`

**removeToken**
1. Delegate to `securityManager.deleteRequestToken(token)`

**createAccessToken**
1. Throw `NotImplementedException` (not implemented)

**createUnauthorizedRequestToken**
1. Throw `NotImplementedException` (not implemented)

# Business rules

• If a request token is null or missing consumer authorities, it is invalid.
• If a token's consumer authority is not in the `authoritiesToVerify` list, the token is invalid.
• Tokens expire based on the consumer's `requestTokenExpirationValue` (in seconds) added to the token's creation time.
• Expired tokens are automatically removed from storage when detected.
• Authorizing a request token resets its creation time, effectively extending its expiration window.
• Access token creation and unauthorized request token creation are not implemented (throw `NotImplementedException`).
• All token operations use GMT timezone for time calculations.

# Depends on

• [SecurityManager](code:SecurityManager) - injected via setter, provides CRUD operations for request tokens
• `RequestTokenEntity` - entity representing OAuth request tokens
• `OAuthProviderTokenServices` - Spring Security OAuth interface implemented by this service
• `Authentication` - Spring Security authentication object
• `Calendar` - Java time utilities for GMT-based expiration checks
