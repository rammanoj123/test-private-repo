---
type: Component
title: Temp Token Authorization Filter ACL Entry Voter
description: Votes on temporary token access by validating request token and checking ACL permissions.
tags: [component, security, acl, voter, token]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\TempTokenAuthorizationFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: temp-token-acl-voter-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/TempTokenAuthorizationFilterAclEntryVoter.java }
---

`com.hp.cloudprint.api.offramp.security.TempTokenAuthorizationFilterAclEntryVoter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Log |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| sidParameterName | String |  |
| securityManager | SecurityManager |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| requestTokenStr | String |  |
| reqToken | RequestTokenEntity |  |
| tempToken | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| TempTokenAuthorizationFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getProcessDomainObjectClass2 | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getProcessDomainObjectClass | Class |  |  |

# Algorithm

**vote(Authentication authentication, Object object, Collection<ConfigAttribute> config)**: Main authorization decision method. Iterates through config attributes, skipping unsupported ones. Calls getDomainObjectInstance() to extract temp token ObjectIdentity. Returns ACCESS_DENIED if domain object is null or request token string is empty. Retrieves RequestTokenEntity via securityManager.getRequestToken(). Returns ACCESS_DENIED if request token entity is null. Returns ACCESS_ABSTAIN if no config attribute matches. Note: The implementation appears incomplete - it does not perform ACL checks despite having aclService and requirePermission fields.

**getDomainObjectInstance(Object secureObject)**: Extracts temporary token from FilterInvocation request. Checks request parameter first, then header for sidParameterName (default "temp_token"). If found, creates ObjectIdentityImpl with String.class and token value. Returns null if not FilterInvocation or token not found.

**supports(ConfigAttribute attribute)**: Returns true if attribute matches processConfigAttribute.

**supports(Class<?> clazz)**: Returns true if clazz is FilterInvocation or subclass.

**setProcessDomainObjectClass(String processDomainObjectClass)**: Converts string class name to Class object via reflection, throwing IllegalArgumentException if class not found.

**getProcessDomainObjectClass()**: Returns String.class as default domain object class.

# Business context

TempTokenAuthorizationFilterAclEntryVoter implements Spring Security's AccessDecisionVoter to validate temporary token-authenticated requests. It extracts temporary tokens from requests and verifies their existence via SecurityManager. The voter appears to be partially implemented - it has ACL infrastructure (aclService, requirePermission) but does not perform ACL permission checks, only validating token existence.

# Business rules

- Temporary token extracted from request parameter or header named "temp_token" (configurable via sidParameterName)
- Request parameter takes precedence over header for token extraction
- Voter only processes requests matching the configured processConfigAttribute
- Temp token must not be null or empty; missing/empty tokens result in ACCESS_DENIED
- RequestTokenEntity must exist in the system; missing entities result in ACCESS_DENIED
- Voter abstains if no matching config attribute found
- Process domain object class defaults to String.class
- Note: ACL permission checks are not implemented despite infrastructure being present

# Depends on

- Spring Security ACL framework - AclService, Permission, ObjectIdentity, ObjectIdentityRetrievalStrategy (configured but not used)
- Spring Security Core - Authentication, AccessDecisionVoter, ConfigAttribute
- Spring Security Web - FilterInvocation
- SecurityManager - retrieves RequestTokenEntity
- RequestTokenEntity - temporary token entity from eprintdirectory
- Apache Commons Logging - Log, LogFactory

# Participates in

- Spring Security access decision voting for temporary token-authenticated endpoints
- Temporary token validation flows
- OAuth or temporary authorization scenarios
- Request-based authentication for limited-time access grants
