---
type: Component
title: Session Secret Filter ACL Entry Voter
description: Votes on session secret access by validating session token and checking printer ACL permissions.
tags: [component, security, acl, voter, session]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\SessionSecretFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: session-secret-acl-voter-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/SessionSecretFilterAclEntryVoter.java }
---

`com.hp.cloudprint.api.offramp.security.SessionSecretFilterAclEntryVoter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| requirePermission | Permission[] |  |
| aclService | AclService |  |
| securityManager | SecurityManager |  |
| sidParameterName | String |  |
| processConfigAttribute | String |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| iter | Iterator | @Override |
| attr | ConfigAttribute | @Override |
| domainObject | Object | @Override |
| sessionTokenStr | String |  |
| shardCode | String |  |
| sessionToken | SessionToken |  |
| printerIdentity | ObjectIdentity |  |
| userSid | List |  |
| printerAcl | Acl |  |
| sessionToken | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SessionSecretFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> config |  |
| getAclService | AclService |  |  |
| setAclService | void | AclService aclService |  |
| getSecurityManager | SecurityManager |  |  |
| setSecurityManager | void | SecurityManager securityManager |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| getProcessDomainObjectClass | Class |  |  |
| setProcessDomainObjectClass | void | String processDomainObjectClass |  |
| supports | boolean | ConfigAttribute attribute |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getSidParameterName | String |  |  |
| setSidParameterName | void | String sidParameterName |  |
| getDomainObjectURIFilter | String |  |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |

# Algorithm

**vote(Authentication authentication, Object object, Collection<ConfigAttribute> config)**: Main authorization decision method. Iterates through config attributes, skipping unsupported ones. Calls getDomainObjectInstance() to extract session token ObjectIdentity. Returns ACCESS_DENIED if domain object is null or session token string is empty. Extracts shard code from session token and sets shard context. Retrieves SessionToken entity via securityManager, returning ACCESS_DENIED on exceptions or if token/printer is null, ACCESS_ABSTAIN if printer not found. Creates ObjectIdentity for the printer and PrincipalSid from authentication. Reads printer ACL via aclService, returning ACCESS_DENIED if ACL not found. Checks if required permissions are granted; returns ACCESS_GRANTED if yes, ACCESS_DENIED if no. Returns ACCESS_ABSTAIN if no config attribute matches.

**getDomainObjectInstance(Object secureObject)**: Extracts session token from FilterInvocation request. Checks request parameter first, then header for sidParameterName (default "sessiontoken"). If found, creates ObjectIdentityImpl with String.class and token value. Returns null if not FilterInvocation or token not found.

**supports(ConfigAttribute attribute)**: Returns true if attribute matches processConfigAttribute.

**supports(Class<?> clazz)**: Returns true if clazz is FilterInvocation or subclass.

**setProcessDomainObjectClass(String processDomainObjectClass)**: Converts string class name to Class object via reflection, throwing IllegalArgumentException if class not found.

# Business context

SessionSecretFilterAclEntryVoter implements Spring Security's AccessDecisionVoter to enforce ACL-based authorization for session token-authenticated requests. It validates session tokens, retrieves the associated printer, and checks ACL permissions on the printer resource. The voter supports shard-aware data access by extracting and setting the appropriate shard context from the session token identifier.

# Business rules

- Session token extracted from request parameter or header named "sessiontoken" (configurable via sidParameterName)
- Request parameter takes precedence over header for token extraction
- Voter only processes requests matching the configured processConfigAttribute
- Session token must not be null or empty; missing/empty tokens result in ACCESS_DENIED
- Session token ID format includes shard code; shard context set before database lookup
- SessionToken entity must exist and have an associated printer; missing entities result in ACCESS_DENIED or ACCESS_ABSTAIN
- ACL must exist for the printer; missing ACLs result in ACCESS_DENIED
- All required permissions must be granted for ACCESS_GRANTED vote
- Exceptions during session token retrieval result in ACCESS_DENIED with error logging
- Voter abstains if no matching config attribute found
- Uses PrincipalSid based on authenticated principal for ACL checks
- Process domain object class defaults to String.class

# Depends on

- Spring Security ACL framework - AclService, ObjectIdentity, Sid, Permission, Acl, ObjectIdentityRetrievalStrategy
- Spring Security Core - Authentication, AccessDecisionVoter, ConfigAttribute
- Spring Security Web - FilterInvocation
- SecurityManager - retrieves SessionToken entities
- SessionToken entity - holds printer association
- EprintShardHolder, ShardUtil - shard-aware data access
- SLF4J Logger - structured logging with LogConstants

# Participates in

- Spring Security access decision voting for session token-authenticated endpoints
- ACL-based authorization enforcement for printer operations via session tokens
- Shard-aware request routing in distributed printer data architecture
- Session-based authentication flows for printer and user interactions
- Multi-tenant printer access control with per-printer ACLs
