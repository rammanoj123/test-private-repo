---
type: Component
title: Custom User Authorization Processing Filter
description: Initializes custom user authorization processing filter with success handler for OAuth flows.
tags: [component, security, oauth, filter, authorization]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\CustomUserAuthorizationProcessingFilter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: custom-user-auth-filter-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/CustomUserAuthorizationProcessingFilter.java }
---

`com.hp.cloudprint.api.offramp.security.CustomUserAuthorizationProcessingFilter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| userAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserAuthorizationSuccessfulAuthenticationHandler | UserAuthorizationSuccessfulAuthenticationHandler |  |  |
| setUserAuthorizationSuccessfulAuthenticationHandler | void | UserAuthorizationSuccessfulAuthenticationHandler userAuthorizationSuccessfulAuthenticationHandler |  |
| init | void |  |  |

# Business context

CustomUserAuthorizationProcessingFilter extends Spring Security OAuth's UserAuthorizationProcessingFilter to customize the OAuth authorization flow. It allows injection of a custom success handler that executes after successful user authorization. The filter is initialized via Spring's @PostConstruct lifecycle hook to wire the custom handler into the parent filter's authentication success handling chain.

# Algorithm

**init()**: Annotated with @PostConstruct, this method is automatically invoked by Spring after dependency injection completes. It calls the parent class's `setAuthenticationSuccessHandler()` method, passing the injected `userAuthorizationSuccessfulAuthenticationHandler`. This wires the custom success handler into the OAuth authorization processing pipeline.

**getUserAuthorizationSuccessfulAuthenticationHandler()**: Returns the injected custom success handler.

**setUserAuthorizationSuccessfulAuthenticationHandler(UserAuthorizationSuccessfulAuthenticationHandler handler)**: Setter for Spring dependency injection of the custom success handler.

The filter inherits all request processing logic from UserAuthorizationProcessingFilter, only customizing the success handler behavior.

# Business rules

- Custom success handler must be injected via Spring configuration before @PostConstruct initialization
- The init() method is private, invoked only by Spring container during bean initialization
- Success handler customization occurs once during application startup
- Filter extends OAuth provider filter, participating in OAuth authorization flows
- No validation of the injected handler (can be null if not configured)

# Depends on

- `org.springframework.security.oauth.provider.filter.UserAuthorizationProcessingFilter` - parent OAuth filter class
- `org.springframework.security.oauth.provider.filter.UserAuthorizationSuccessfulAuthenticationHandler` - custom success handler interface
- Spring Framework - @PostConstruct lifecycle management and dependency injection

# Participates in

- OAuth authorization flows for user consent and token issuance
- Spring Security filter chain for authenticated requests
- Custom authentication success handling (redirect, logging, session management)
- User authorization processing in OAuth provider role
