---
type: Component
title: Printer Filter ACL Entry Voter
description: Votes on printer resource access by extracting printer ID from request and checking ACL permissions.
tags: [component, security, acl, voter, authorization]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\PrinterFilterAclEntryVoter.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: printer-filter-acl-voter-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/PrinterFilterAclEntryVoter.java }
---

`com.hp.cloudprint.api.offramp.security.PrinterFilterAclEntryVoter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| aclService | AclService |  |
| processConfigAttribute | String |  |
| requirePermission | List |  |
| objectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |
| processDomainObjectClass | Class |  |
| domainObjectURIFilter | String |  |
| urlMatcher | AntPathRequestMatcher |  |
| sidExtractionFilter | String |  |
| printerManager | PrinterManager |  |
| objectIdentity | ObjectIdentity |  |
| printerId | String |  |
| requestUrl | String |  |
| pattern | Pattern |  |
| matcher | Matcher |  |
| parts | String[] |  |
| domainObject | Object | @Override |
| objectIdentity | ObjectIdentity | @Override |
| sids | List | @Override |
| acl | Acl |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| PrinterFilterAclEntryVoter |  | AclService aclService, String processConfigAttribute, Permission[] requirePermission |  |
| setDomainObjectURIFilter | void | String domainObjectURIFilter |  |
| getDomainObjectURIFilter | String |  |  |
| setSidExtractionFilter | void | String sidExtractionFilter |  |
| getSidExtractionFilter | String |  |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| getPrinterManager | PrinterManager |  |  |
| getDomainObjectInstance | Object | Object secureObject |  |
| extractPrinterIdFromRequest | String | FilterInvocation filterInvocation |  |
| vote | int | Authentication authentication, Object object, Collection<ConfigAttribute> attributes |  |
| supports | boolean | ConfigAttribute attribute |  |
| setObjectIdentityRetrievalStrategy | void | ObjectIdentityRetrievalStrategy objectIdentityRetrievalStrategy |  |
| getObjectIdentityRetrievalStrategy | ObjectIdentityRetrievalStrategy |  |  |
| setProcessDomainObjectClass | void | Class<?> processDomainObjectClass |  |
| getProcessDomainObjectClass | Class |  |  |

# Business context

PrinterFilterAclEntryVoter implements Spring Security's AccessDecisionVoter to enforce ACL-based authorization for printer resource access. It extracts printer IDs from HTTP request URLs, retrieves ACL entries for the printer, and votes on access decisions based on required permissions. The voter integrates with Spring Security ACL infrastructure and supports shard-aware routing by setting the appropriate shard context based on printer ID.

# Algorithm

**vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes)**: Main authorization decision method. Iterates through config attributes, skipping unsupported ones. Calls `getDomainObjectInstance()` to extract printer ObjectIdentity from the request. Creates a PrincipalSid from the authenticated user. Reads the ACL for the printer and checks if required permissions are granted. Returns ACCESS_GRANTED if permissions match, ACCESS_DENIED if not, or ACCESS_ABSTAIN if no matching config attribute or domain object found. Throws AccessDeniedException if ACL not found.

**getDomainObjectInstance(Object secureObject)**: Extracts printer ID from FilterInvocation request and creates ObjectIdentity. Calls `extractPrinterIdFromRequest()` to parse the printer ID. Uses objectIdentityRetrievalStrategy if configured, otherwise creates ObjectIdentityImpl directly. Sets shard context via `printerManager.setShardByPrinterId()`. Returns ObjectIdentity or null if extraction fails. Wraps exceptions in AccessDeniedException.

**extractPrinterIdFromRequest(FilterInvocation filterInvocation)**: Parses printer ID from request URL. First attempts regex extraction using sidExtractionFilter pattern if configured. Falls back to simple "/printers/" path parsing, extracting the segment immediately following "printers". Returns null if printer ID cannot be extracted. Throws AccessDeniedException for invalid regex patterns.

**supports(ConfigAttribute attribute)**: Returns true if attribute matches processConfigAttribute.

**supports(Class<?> clazz)**: Returns true if clazz is FilterInvocation or subclass.

# Business rules

- Voter only processes requests matching the configured processConfigAttribute
- Printer ID extraction supports both regex pattern (sidExtractionFilter) and fallback path parsing
- Fallback extraction looks for "/printers/" in URL and takes the next path segment
- ACL must exist for the printer; missing ACLs result in AccessDeniedException
- All required permissions must be granted for ACCESS_GRANTED vote
- Shard context is set based on extracted printer ID for distributed data access
- Invalid regex patterns in sidExtractionFilter cause AccessDeniedException
- domainObjectURIFilter cannot be null or empty (validated in setter)
- Voter abstains if printer ID cannot be extracted or config attribute doesn't match
- Uses PrincipalSid based on authenticated user's name for ACL lookups

# Depends on

- Spring Security ACL framework - AclService, ObjectIdentity, Sid, Permission, Acl
- Spring Security Core - Authentication, AccessDecisionVoter, ConfigAttribute, AccessDeniedException
- Spring Security Web - FilterInvocation, AntPathRequestMatcher
- [PrinterManager](/components/services/PrinterManager.md) - sets shard context based on printer ID
- Java regex - Pattern, Matcher for URL parsing

# Participates in

- Spring Security access decision voting for printer resource endpoints
- ACL-based authorization enforcement for printer operations
- Shard-aware request routing in distributed printer data architecture
- URL-based resource identification and access control
- Multi-tenant printer access control with per-printer ACLs
