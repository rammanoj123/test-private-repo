---
type: Component
title: Registration Authentication Provider
description: Authenticates printer registration requests by validating credentials against stored domain keys.
tags: [component, security, authentication, registration, provider]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\RegistrationAuthenticationProvider.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: registration-auth-provider-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/RegistrationAuthenticationProvider.java }
---

`com.hp.cloudprint.api.offramp.security.RegistrationAuthenticationProvider`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| KEY_SEPERATOR_REGEX | String |  |
| LOG | EPrintLogger |  |
| presentedPassword | String | @Override |
| userPasswords | String[] | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| additionalAuthenticationChecks | void | UserDetails userDetails, UsernamePasswordAuthenticationToken authentication |  |

# Algorithm

**additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication)**: Overrides DaoAuthenticationProvider's additional authentication checks to support multiple domain keys per printer. First validates that credentials are present, throwing BadCredentialsException if null. Extracts presented password from authentication token. Splits the stored password string by '$' delimiter to get array of valid domain keys. Iterates through each stored password, using the configured PasswordEncoder to match the presented password against each stored key. Returns immediately on first successful match. Throws BadCredentialsException if no stored password matches the presented credentials.

# Business context

RegistrationAuthenticationProvider extends Spring Security's DaoAuthenticationProvider to implement custom authentication logic for printer registration. It supports printers with multiple valid domain keys (separated by '$' delimiter) and authenticates successfully if the presented credentials match any of the stored keys. This allows printers to authenticate with any of their registered domain keys during the registration process.

# Business rules

- Credentials must not be null; null credentials result in BadCredentialsException
- Stored passwords contain one or more domain keys separated by '$' delimiter (KEY_SEPERATOR_REGEX = "\\$")
- Authentication succeeds if the presented password matches ANY stored domain key
- Password matching uses the configured PasswordEncoder (supports hashing/encoding)
- Authentication fails with BadCredentialsException if no stored key matches
- Error messages retrieved from Spring Security's message source for i18n support
- Inherits all other authentication behavior from DaoAuthenticationProvider (user loading, account status checks, etc.)

# Depends on

- Spring Security Core - DaoAuthenticationProvider, UsernamePasswordAuthenticationToken, UserDetails, AuthenticationException, BadCredentialsException
- Spring Security PasswordEncoder - for secure password comparison
- Spring MessageSource - for internationalized error messages
- EPrintLogger - for logging (imported but not actively used in this method)

# Participates in

- Spring Security authentication provider chain
- Printer registration authentication flows
- Multi-domain-key authentication scenarios
- Password-based authentication with encoding/hashing support
