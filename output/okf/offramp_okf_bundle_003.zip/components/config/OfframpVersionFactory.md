---
type: Component
title: Offramp Version Factory
description: Returns version-specific offramp implementation based on v2 compatibility flag.
tags: [component, config, factory, versioning, singleton]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\OfframpVersionFactory.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OfframpVersionFactory.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/OfframpVersionFactory.java, title: OfframpVersionFactory.java }
---

`com.hp.cloudprint.api.offramp.OfframpVersionFactory`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INSTANCE | OfframpVersionFactory |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OfframpVersionFactory |  |  |  |
| getInstance | OfframpVersionFactory |  |  |
| getOfframpVersionImpl | OfframpVersion | boolean v2Compatible |  |

# Business context

Factory providing version-specific offramp implementations based on API compatibility flag. Returns either v2-compatible or base version implementation to handle protocol differences. Singleton pattern ensures single factory instance.

# Algorithm

1. **Constructor (private)** - Prevents external instantiation; singleton pattern.
2. **getInstance** - Returns singleton INSTANCE.
3. **getOfframpVersionImpl(v2Compatible)**:
   1. If v2Compatible is true, return new OfframpVersion2().
   2. Otherwise, return new OfframpVersionBase().

# Business rules

• If v2Compatible flag is true, return OfframpVersion2 implementation.
• If v2Compatible flag is false, return OfframpVersionBase implementation.
• New instances are created on each call; no caching of version implementations.
