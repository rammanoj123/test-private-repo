---
type: Component
title: Cloud Configuration
description: Holds cloud printing configuration settings including SIPs, mobile apps, email, protection mode, and subscription flags.
tags: [component, config, cloud, printer-settings, xml-schema]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\CloudConfiguration.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: CloudConfiguration.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/CloudConfiguration.java, title: CloudConfiguration.java }
---

`com.hp.cloudprint.api.offramp.schemas.CloudConfiguration`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| allowsSips | Boolean | @XmlElement(namespace = "http: |
| allowsMobileApps | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http: |
| allowsEmail | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http: |
| protectionMode | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http: |
| claimStatus | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http: |
| allowsUsageDataCollection | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http: |
| consumableSubscription | Boolean | @XmlElement(namespace = "http:     protected Boolean allowsSips; 	@XmlElement(namespace = "http:     protected Boolean allowsMobileApps; 	@XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http:     protected Boolean allowsUsageDataCollection; 	@XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected Boolean allowsEmail; 	@XmlElement(namespace = "http:     protected Boolean protectionMode; 	@XmlElement(namespace = "http:     protected Boolean claimStatus; 	@XmlElement(namespace = "http:     protected Boolean allowsUsageDataCollection; 	@XmlElement(namespace = "http:     protected Boolean consumableSubscription;     @XmlAttribute(required = true)     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| isAllowsSips | Boolean |  |  |
| setAllowsSips | void | Boolean value |  |
| isAllowsMobileApps | Boolean |  |  |
| setAllowsMobileApps | void | Boolean value |  |
| isAllowsEmail | Boolean |  |  |
| setAllowsEmail | void | Boolean value |  |
| isProtectionMode | Boolean |  |  |
| setProtectionMode | void | Boolean value |  |
| isClaimStatus | Boolean |  |  |
| setClaimStatus | void | Boolean value |  |
| isAllowsUsageDataCollection | Boolean |  |  |
| setAllowsUsageDataCollection | void | Boolean value |  |
| getConsumableSubscription | Boolean |  |  |
| setConsumableSubscription | void | Boolean value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |

# Business context

JAXB-generated data transfer object representing cloud printing configuration settings for a printer. Holds feature flags controlling which cloud services are enabled (SIPs, mobile apps, email), security settings (protection mode, claim status), usage data collection consent, and consumable subscription status. Bound to XML schema namespace for serialization/deserialization in API responses.

# Algorithm

All methods are standard JavaBean getters and setters:
1. **isAllowsSips/setAllowsSips** - Get/set whether printer allows SIP-based printing.
2. **isAllowsMobileApps/setAllowsMobileApps** - Get/set whether printer allows mobile app printing.
3. **isAllowsEmail/setAllowsEmail** - Get/set whether printer allows email-to-print.
4. **isProtectionMode/setProtectionMode** - Get/set whether protection mode is enabled.
5. **isClaimStatus/setClaimStatus** - Get/set whether printer is claimed.
6. **isAllowsUsageDataCollection/setAllowsUsageDataCollection** - Get/set usage data collection consent.
7. **getConsumableSubscription/setConsumableSubscription** - Get/set consumable subscription enrollment.
8. **getVersion/setVersion** - Get/set schema version attribute (required).

# Business rules

• If version attribute is not set, XML validation will fail (required=true).
• All Boolean fields are optional (minOccurs=0) and may be null.
• XML elements must use namespace http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11.
