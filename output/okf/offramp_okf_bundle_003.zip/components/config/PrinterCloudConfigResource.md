---
type: Component
title: Printer Cloud Config Resource
description: Handles GET and PUT requests for printer cloud configuration including usage data collection and feature flags.
tags: [component, config, resource, printer, restlet]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterCloudConfigResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterCloudConfigResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/PrinterCloudConfigResource.java, title: PrinterCloudConfigResource.java }
---

`com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#GET") |
| version | String |  |
| cloudConfig | com.hp.cloudprint.entities.PrinterCloudConfiguration |  |
| cloudConfiguration | CloudConfiguration |  |
| requiredAccountsClaimStatuFeatureEnabled | boolean |  |
| ownership | Ownership |  |
| rep | Representation |  |
| headerValues | Form |  |
| customHeaderValues | Map |  |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#PUT") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration#PUT") |
| cloudConfig | CloudConfiguration |  |
| inputStream | InputStream |  |
| data | String |  |
| cloudConfig1 | PrinterCloudConfiguration |  |
| udcFlag | Integer |  |
| writer | Writer |  |
| buffer | char[] |  |
| reader | Reader |  |
| n | int |  |
| isLFPPrinter | boolean |  |
| printerModelListForLFP | String |  |
| modelList | String[] |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| isPrinterFromDesignJetFamily | boolean | String modelNumber |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| getAPIVersionFromRequestHeader | String |  |  |
| itSupportsClaimStatus | boolean | String version |  |
| itSupportsConsumableSubscription | boolean | String version |  |
| handlePut | void |  |  |
| getSchema | Schema |  |  |
| convertStreamToString | String | InputStream is |  |
| getUDCvalue | int | boolean isAllowsUsageDataCollection, String printerModel |  |
| isUDCFlagEnabled | boolean |  |  |
| isPrinterModelsInLFP | boolean | String printerModel |  |


# Depends on

• `PrinterManager` (fetch printer, check ownership)
• `PrinterCloudConfigurationManager` (get/update cloud config)
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) (configuration properties)
• [OfframpHelper](/components/misc/OfframpHelper.md) (version checks, header parsing)

# Business context

RESTful resource managing printer cloud configuration including feature flags (email, mobile apps, SIPs), protection mode, usage data collection (UDC), consumable subscription, and claim status. Supports GET to retrieve current config and PUT to update settings. Applies version-specific logic and regional rules (e.g., Italy UDC disablement). Validates XML input against schema when enabled.

# Algorithm

1. **handleGet** (audited as /Printers/{PrinterID}/CloudConfiguration#GET):
   1. Extract printerID from request attributes; set MDC device ID.
   2. Validate printerID is not null/empty; return 404 if invalid.
   3. Fetch active printer via printerManager.getActivePrinterByPrinterID(printerID); return 404 on DeviceNotFoundExcpeption, 500 on other exceptions.
   4. Validate printer is not null; return 404 if null.
   5. Get API version from request header via getAPIVersionFromRequestHeader().
   6. Fetch cloud config via printerCloudConfigurationManager.getPrinterCloudConfig(printer.getInternalPrinterID()).
   7. Populate CloudConfiguration DTO from entity fields (email, mobile, SIPs, version, protection mode).
   8. If version is v2-compatible, set allowsUsageDataCollection (true if not DISABLED_UDC).
   9. If version supports consumable subscription, set consumableSubscription (true if value == 1).
   10. If version supports claim status, check REQUIRED_ACCOUNTS_CLAIM_STATUS_FEATURE_ENABLED flag or DesignJet family; fetch ownership and set claimStatus accordingly (default true if feature disabled, false if OwnershipNotFoundException).
   11. Marshal CloudConfiguration to XML and return 200 with entity.
   12. On any exception, log and return 500.
2. **handlePut** (audited as /Printers/{PrinterID}/CloudConfiguration#PUT):
   1. Extract printerID from request; set MDC device ID.
   2. Validate printerID; return 400 if invalid.
   3. Fetch active printer; return 404 on DeviceNotFoundExcpeption, 500 on other exceptions.
   4. Validate printer is not null; return 404 if null.
   5. If XSD_VALIDATION enabled, read input stream, convert to string for logging, validate and unmarshal against schema; else unmarshal without validation.
   6. If cloudConfig is not null, fetch existing config, compute UDC flag via getUDCvalue().
   7. Apply Italy UDC disablement rule: if UDC flag is 1 or 2 and country is 'italy' and opt-in configs are all disabled, set UDC to DISABLED_UDC.
   8. Call printerCloudConfigurationManager.updatePrinterCloudConfiguration() with all fields.
   9. Return 200 on success.
   10. Return 404 on PrinterCloudConfigurationNotFoundException, 400 on JAXBException/SAXException/IOException, 500 on other exceptions.
3. **getUDCvalue(isAllowsUsageDataCollection, printerModel)** - If true, return LFP_ENABLED_UDC if UDC flag enabled and model in LFP list, else ENABLED_UDC; if false, return DISABLED_UDC.
4. **isPrinterModelsInLFP(printerModel)** - Split LFP_PRINTER_MODEL_LIST by comma and check if printerModel matches any entry (case-insensitive).
5. **isPrinterFromDesignJetFamily(modelNumber)** - Check if modelNumber is contained in DESIGNJET_PRINTER_MODEL_LIST config.
6. **itSupportsClaimStatus(version)** - Delegate to OfframpHelper.isValidOfframpAPIVersion(CLAIM_STATUS_NA_FOR_VERSIONS, version).
7. **itSupportsConsumableSubscription(version)** - Delegate to OfframpHelper.isValidOfframpAPIVersion(CONSUMABLE_SUBSCRIPTION_NA_FOR_VERSIONS, version).
8. **convertStreamToString(is)** - Read InputStream via BufferedReader into StringWriter using 1024-char buffer; close stream in finally block.

# Business rules

• If printerID is invalid or printer not found, return 404.
• If API version is v2-compatible, include allowsUsageDataCollection in response.
• If API version supports consumable subscription, include consumableSubscription in response.
• If API version supports claim status, fetch actual ownership unless REQUIRED_ACCOUNTS_CLAIM_STATUS_FEATURE_ENABLED is false (then default to true); DesignJet printers always fetch actual ownership.
• On PUT, if country is 'italy' and UDC flag is 1 or 2 but all opt-in configs are disabled, force UDC to DISABLED_UDC.
• If LFP printer and UDC enabled, use LFP_ENABLED_UDC value; else use ENABLED_UDC.
• If XSD_VALIDATION is enabled, validate input XML against schema; return 400 on validation failure.
