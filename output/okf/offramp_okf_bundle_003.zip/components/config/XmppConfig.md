---
type: Component
title: XMPP Config
description: Holds XMPP server connection details including hostname, ports, Jabber IDs, backoff limits, and whitespace intervals.
tags: [component, config, xmpp, messaging, xml-schema]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\XmppConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: XmppConfig.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/XmppConfig.java, title: XmppConfig.java }
---

`com.hp.cloudprint.api.offramp.schemas.XmppConfig`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| xmppVersion | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| serverHostname | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| jabberIDs | XmppConfig.JabberIDs | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http: |
| tcpPorts | XmppConfig.TcpPorts | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String xmppVersion;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String serverHostname;     @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http:     protected XmppConfig.TcpPorts tcpPorts;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| maxXMPPBackoffLimit | BigInteger | @XmlElement(namespace = "http:     protected XmppConfig.JabberIDs jabberIDs;     @XmlElement(namespace = "http:     protected XmppConfig.TcpPorts tcpPorts;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String version;     @XmlElement(name = "maxXMPPBackoffLimit", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger") |
| whitespaceInterval | BigInteger | @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String version;     @XmlElement(name = "maxXMPPBackoffLimit", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger")     protected BigInteger maxXMPPBackoffLimit;     @XmlElement(name = "whitespaceInterval", namespace = "http:     @XmlSchemaType(name = "nonNegativeInteger") |
| serverDomainName | String | @XmlElement(namespace = "http: |
| serverNodeName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| printerNodeName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String serverNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| ledmResourceName | String | @XmlElement(namespace = "http:         protected String serverDomainName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String serverNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class)         protected String printerNodeName;         @XmlElement(namespace = "http:         @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| tcpPort | List | @XmlElement(namespace = "http: |
| priority | BigInteger | @XmlElement(namespace = "http:             @XmlSchemaType(name = "positiveInteger") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getXmppVersion | String |  |  |
| setXmppVersion | void | String value |  |
| getServerHostname | String |  |  |
| setServerHostname | void | String value |  |
| getJabberIDs | XmppConfig.JabberIDs |  |  |
| setJabberIDs | void | XmppConfig.JabberIDs value |  |
| getTcpPorts | XmppConfig.TcpPorts |  |  |
| setTcpPorts | void | XmppConfig.TcpPorts value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getMaxXMPPBackoffLimit | BigInteger |  |  |
| setMaxXMPPBackoffLimit | void | BigInteger value |  |
| getWhitespaceInterval | BigInteger |  |  |
| setWhitespaceInterval | void | BigInteger value |  |
| getServerDomainName | String |  |  |
| setServerDomainName | void | String value |  |
| getServerNodeName | String |  |  |
| setServerNodeName | void | String value |  |
| getPrinterNodeName | String |  |  |
| setPrinterNodeName | void | String value |  |
| getLedmResourceName | String |  |  |
| setLedmResourceName | void | String value |  |
| getTcpPort | List |  |  |


# Depends on

* `String`

# Business context

JAXB-generated data transfer object representing XMPP connection configuration for printer cloud messaging. Contains server hostname, Jabber IDs for server and printer nodes, prioritized TCP port list, backoff limits, and keepalive intervals. Returned during printer registration to configure XMPP client.

# Algorithm

All methods are standard JavaBean getters and setters:
1. **getXmppVersion/setXmppVersion** - Get/set XMPP protocol version (token).
2. **getServerHostname/setServerHostname** - Get/set XMPP server hostname (max 64 chars).
3. **getJabberIDs/setJabberIDs** - Get/set Jabber ID configuration (nested JabberIDs object).
4. **getTcpPorts/setTcpPorts** - Get/set TCP port list (nested TcpPorts object).
5. **getVersion/setVersion** - Get/set schema version attribute (required).
6. **getMaxXMPPBackoffLimit/setMaxXMPPBackoffLimit** - Get/set max backoff limit in seconds (non-negative integer, optional).
7. **getWhitespaceInterval/setWhitespaceInterval** - Get/set whitespace keepalive interval in seconds (non-negative integer, optional).

Nested classes:
- **JabberIDs**: serverDomainName (max 64 chars), serverNodeName (max 32 chars), printerNodeName (max 32 chars), ledmResourceName (max 8 chars).
- **TcpPorts**: List of TcpPort entries.
- **TcpPort**: priority (positive integer), value (positive integer).

# Business rules

• xmppVersion, serverHostname, jabberIDs, and tcpPorts are required.
• version attribute is required.
• maxXMPPBackoffLimit and whitespaceInterval are optional (nonNegativeInteger).
• serverHostname max length is 64 characters.
• JabberIDs: serverDomainName max 64 chars, serverNodeName/printerNodeName max 32 chars, ledmResourceName max 8 chars.
• TcpPorts contains unbounded list of TcpPort entries; each has priority and value (both positive integers).
• getTcpPort() returns live list; modifications affect JAXB object directly.
• XML namespace is http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11.
