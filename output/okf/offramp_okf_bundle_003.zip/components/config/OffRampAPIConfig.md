---
type: Component
title: OffRamp API Config
description: Provides centralized access to offramp API configuration properties including XMPP, security, and feature flags.
tags: [component, config, api, singleton, properties]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\OffRampAPIConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: OffRampAPIConfig.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/OffRampAPIConfig.java, title: OffRampAPIConfig.java }
---

`com.hp.cloudprint.api.offramp.OffRampAPIConfig`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| instance | OffRampAPIConfig |  |
| ORG_RESTLET_HTTP_HEADERS | String |  |
| OFF_RAMP_VERSION | String |  |
| CLOUD_PRINT_JABBER_ID | String |  |
| XMPP_VERSION | String |  |
| LEDM_RESOURCE_NAME | String |  |
| JABBER_ID_APPEND | String |  |
| MAX_XMPP_BACK_OFF_LIMIT_IN_SECONDS | String |  |
| WHITESPACE_INTERVAL_IN_SECONDS | String |  |
| BKOFF_WSPACEINTRVL_NA_FOR_VERSIONS | String |  |
| CLAIM_STATUS_NA_FOR_VERSIONS | String |  |
| REQUIRED_ACCOUNTS_CLAIM_STATUS_FEATURE_ENABLED | String |  |
| SECURITY_CHECK_REQUIRED | String |  |
| DESIGNJET_PRINTER_MODEL_LIST | String |  |
| RESTRICTED_SERIAL_NUMBERS_LIST | String |  |
| CONSUMABLE_SUBSCRIPTION_NA_FOR_VERSIONS | String |  |
| XSD_VALIDATION | String |  |
| XSD_OFFRAMP_API_SPEC | String |  |
| XSD_OFFRAMP_API_V2_SPEC | String |  |
| SUPPORTS_SERIAL_NUMBER_ENCRYPTION | String |  |
| REGISTRATION_TESTDOMAIN_KEY_REFRESH_CONFIG | String |  |
| REGISTRATION_SHUTDOWNHOOK_DELAY_IN_SECS | String |  |
| IS_DOMAIN_KEY_HASH_CHECK_ENABLED | String |  |
| LFP_PRINTER_MODEL_LIST | String |  |
| IS_UDC_FOR_LFP_ENABLED | String |  |
| BLOCK_PRINTER_THESHOLD | String |  |
| SIMPLECACHE_SERVER_INSTANCES | String |  |
| PBUT_DISABLE_COUNTRY | String |  |
| STRATUS_EVENTING_ENABLED | String |  |
| wpConfigurationService | WpConfigurationService |  |
| serviceName | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OffRampAPIConfig |  |  |  |
| getInstance | OffRampAPIConfig |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setServiceName | void | String serviceName |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getLongValue | long | String key |  |
| getStringValue | String | String key |  |
| getBooleanValue | boolean | String key |  |
| getIntValue | int | String key |  |
| getListValue | List | String key |  |
| getDoubleValue | double | String key |  |
| getFloatValue | float | String key |  |
| isPullNode | boolean |  |  |
| getShutDownHookDelay | int |  |  |
| isDomainKeyHashCheckEnabled | boolean |  |  |
| getBlockPrinterThreshold | int |  |  |

# Business context

Singleton configuration facade providing centralized access to offramp API runtime properties. Wraps WpConfigurationService to retrieve typed configuration values for XMPP settings, security flags, feature toggles, printer model lists, and operational thresholds. Initialized by Spring and accessed via getInstance() throughout the application.

# Algorithm

1. **Constructor (deprecated)** - Sets static instance reference; intended only for Spring initialization.
2. **getInstance** - Returns singleton instance (synchronized).
3. **setWpConfigurationService** - Spring injection setter for WpConfigurationService dependency.
4. **setServiceName** - Sets the service name used as namespace for config lookups.
5. **getLongValue(key)** - Delegates to wpConfigurationService.getLong(serviceName, key).
6. **getStringValue(key)** - Delegates to wpConfigurationService.getString(serviceName, key).
7. **getBooleanValue(key)** - Delegates to wpConfigurationService.getBoolean(serviceName, key).
8. **getIntValue(key)** - Delegates to wpConfigurationService.getInt(serviceName, key).
9. **getListValue(key)** - Delegates to wpConfigurationService.getList(serviceName, key).
10. **getDoubleValue(key)** - Delegates to wpConfigurationService.getDouble(serviceName, key).
11. **getFloatValue(key)** - Delegates to wpConfigurationService.getFloat(serviceName, key).
12. **isPullNode** - Returns boolean for PrinterConfig.SUPPORTS_CONTENT_PULL, defaulting to false.
13. **getShutDownHookDelay** - Returns int for REGISTRATION_SHUTDOWNHOOK_DELAY_IN_SECS, defaulting to 180 seconds.
14. **isDomainKeyHashCheckEnabled** - Returns boolean for IS_DOMAIN_KEY_HASH_CHECK_ENABLED, defaulting to false.
15. **getBlockPrinterThreshold** - Returns int for BLOCK_PRINTER_THESHOLD, defaulting to 5.

# Business rules

• Singleton pattern enforced via private static instance and getInstance().
• All configuration keys are defined as public static final constants.
• Typed getter methods provide defaults for critical operational parameters (shutdown delay=180s, block threshold=5, domain key check=false, pull node=false).
• PBUT_DISABLE_COUNTRY is hardcoded to 'italy' for UDC flag disablement.

# Depends on

• `WpConfigurationService` (configuration service interface)
