---
type: Component
title: Printer Cloud Config Resource V2
description: Handles GET requests for v2 printer cloud configuration with version-specific response formatting.
tags: [component, config, resource, printer, v2]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\PrinterCloudConfigResourceV2.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterCloudConfigResourceV2.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/PrinterCloudConfigResourceV2.java, title: PrinterCloudConfigResourceV2.java }
---

`com.hp.cloudprint.api.offramp.resources.PrinterCloudConfigResourceV2`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| printer | Printer | @Override, @Auditable(name = "/Printers/{PrinterID}/CloudConfiguration/V2#GET") |
| cloudConfig | PrinterCloudConfiguration |  |
| cloudConfiguration | CloudConfiguration |  |
| rep | Representation |  |
| headerValues | Form |  |
| customHeaderValues | Map |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getAPIVersionFromRequestHeader | String |  |  |


# Depends on

• `PrinterManager` (fetch printer, check claim status)
• `PrinterCloudConfigurationManager` (get cloud config)
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) (configuration properties)
• [OfframpHelper](/components/misc/OfframpHelper.md) (header parsing)

# Business context

V2-specific RESTful resource for retrieving printer cloud configuration. Always includes usage data collection, consumable subscription, and actual claim status in response. Read-only endpoint (GET only) with simplified version-agnostic logic compared to v1 resource.

# Algorithm

1. **handleGet** (audited as /Printers/{PrinterID}/CloudConfiguration/V2#GET):
   1. Extract printerID from request attributes; set MDC device ID.
   2. Validate printerID is not null/empty; return 404 if invalid.
   3. Fetch active printer via printerManager.getActivePrinterByPrinterID(printerID); return 404 on DeviceNotFoundExcpeption, 500 on other exceptions.
   4. Validate printer is not null; return 404 if null.
   5. Fetch cloud config via printerCloudConfigurationManager.getPrinterCloudConfig(printer.getInternalPrinterID()).
   6. Populate CloudConfiguration DTO: email, mobile, SIPs, version (from request header), protection mode.
   7. Set allowsUsageDataCollection (true if not DISABLED_UDC).
   8. Set consumableSubscription (true if value == 1).
   9. Fetch actual claim status via printerManager.isPrinterClaimed(printer) and set claimStatus.
   10. Marshal CloudConfiguration to XML and return 200 with entity.
   11. On any exception, log and return 500.
2. **getAPIVersionFromRequestHeader** - Extract custom HP header from request, parse it via OfframpHelper, and return API_VERSION value.

# Business rules

• If printerID is invalid or printer not found, return 404.
• Always include allowsUsageDataCollection (true if UDC value != DISABLED_UDC).
• Always include consumableSubscription (true if value == 1).
• Always fetch actual claim status from printer ownership (no feature flag check).
• Version attribute is set from request header, not from config.
