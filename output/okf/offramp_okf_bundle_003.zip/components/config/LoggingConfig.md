---
type: Component
title: Logging Config
description: Initializes logging configuration for the offramp application.
tags: [component, config, logging, initialization]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\config\LoggingConfig.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: LoggingConfig.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/config/LoggingConfig.java, title: LoggingConfig.java }
---

`com.hp.cloudprint.api.offramp.config.LoggingConfig`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |

# Business context

Spring-managed configuration component that initializes structured JSON logging for the offramp application. Enables Datadog-compatible log output for centralized log aggregation and monitoring. Executes once at application startup.

# Algorithm

1. **init** (annotated @PostConstruct):
   1. Call LogOutputModeController.setMode(LogOutputMode.JSON).
   2. This switches the logging framework from plain text to structured JSON format.

# Business rules

• Logging mode is set to JSON on application startup before any business logic executes.
• All subsequent logs will be output in JSON format compatible with Datadog.
