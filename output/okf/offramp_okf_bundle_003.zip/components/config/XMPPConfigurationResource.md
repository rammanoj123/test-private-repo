---
type: Component
title: XMPP Configuration Resource
description: Handles GET requests to retrieve XMPP configuration for a printer from the directory.
tags: [component, config, resource, xmpp, restlet]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\XMPPConfigurationResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: XMPPConfigurationResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/XMPPConfigurationResource.java, title: XMPPConfigurationResource.java }
---

`com.hp.cloudprint.api.offramp.resources.XMPPConfigurationResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ORG_RESTLET_HTTP_HEADERS | String |  |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| LOGGER | Logger |  |
| eprintDirectory | EprintDirectory | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| headerValues | Form | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| htHeaderValues | HashMap | @Override, @Auditable(name = "/Printers/{PrinterID}/XMPPConfiguration#GET") |
| deviceData | DeviceData |  |
| xmppConfig | XmppConfig |  |
| rep | Representation |  |
| xmppConfig | XmppConfig |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setEprintDirectory | void | EprintDirectory eprintDirectory |  |
| allowDelete | boolean |  |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| handleGet | void |  |  |
| getXMPPConfiguration | XmppConfig | String printerID, HashMap<String, String> htHeaderValues, DeviceData deviceData |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |


# Depends on

• `EprintDirectory` (lookup device by ID)
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) (configuration properties)
• [OfframpHelper](/components/misc/OfframpHelper.md) (header parsing, XMPP config builder)

# Business context

RESTful resource providing XMPP configuration for printer cloud messaging. Looks up printer in directory, retrieves shard-specific XMPP server details, and constructs Jabber ID for printer. Returns XML configuration for establishing XMPP connection.

# Algorithm

1. **handleGet** (audited as /Printers/{PrinterID}/XMPPConfiguration#GET):
   1. Extract printerID from request attributes; set MDC device ID.
   2. Validate printerID is not null/empty; return 400 if invalid.
   3. Extract custom HP header from request via OfframpHelper.getCustomHPHeader(headerValues).
   4. Parse header values via OfframpHelper.getValuesFromCustomHPHeader(); return 400 on exception with error message.
   5. Lookup device in directory via eprintDirectory.lookUpDeviceById(printerID); return 404 on DeviceNotFoundExcpeption, 500 on other exceptions.
   6. Call getXMPPConfiguration(printerID, htHeaderValues, deviceData) to build XmppConfig.
   7. Marshal XmppConfig to XML; return 500 on JAXBException.
   8. Set response entity and return 200.
2. **getXMPPConfiguration(printerID, htHeaderValues, deviceData)**:
   1. Build Jabber ID from printerID + DELIMITER + JABBER_ID_APPEND config value.
   2. Call OfframpHelper.getXMPPConfiguration() with version "1.0", Jabber IDs, TCP ports, load balancer hostname from deviceData.getShard().getXmppServerGroup().getLbHostName(), and API version from header.
   3. Return populated XmppConfig.

# Business rules

• If printerID is invalid, return 400.
• If custom HP header is invalid or missing required values, return 400.
• If printer not found in directory, return 404.
• Jabber ID is constructed as printerID + delimiter + JABBER_ID_APPEND config value.
• XMPP server hostname is retrieved from printer's shard configuration.
