---
type: Component
title: Object Factory
description: Creates JAXB schema objects for printer configuration, XMPP, state reports, and cloud settings.
tags: [component, config, jaxb, factory, xml]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\ObjectFactory.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: ObjectFactory.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/ObjectFactory.java, title: ObjectFactory.java }
---

`com.hp.cloudprint.api.offramp.schemas.ObjectFactory`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| _InstructionType_QNAME | QName |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ObjectFactory |  |  |  |
| createPrinterConfiguration | PrinterConfiguration |  |  |
| createStateReportState | StateReport.State |  |  |
| createXmppConfigTcpPorts | XmppConfig.TcpPorts |  |  |
| createXmppConfigTcpPortsTcpPort | XmppConfig.TcpPorts.TcpPort |  |  |
| createXmppConfigJabberIDs | XmppConfig.JabberIDs |  |  |
| createStateReportStateError | StateReport.State.Error |  |  |
| createSessionSecret | SessionSecret |  |  |
| createXmppConfig | XmppConfig |  |  |
| createPrinterEmailAddress | PrinterEmailAddress |  |  |
| createStateReport | StateReport |  |  |
| createPrinterIdentification | PrinterIdentification |  |  |
| createCloudConfiguration | CloudConfiguration |  |  |
| createPrinterClaimInfo | PrinterClaimInfo |  |  |
| createInstructionType | JAXBElement | String value |  |

# Business context

JAXB-generated factory for creating instances of schema-derived classes in the com.hp.cloudprint.api.offramp.schemas package. Provides factory methods for all XML-bound domain objects used in printer registration and configuration APIs. Annotated with @XmlRegistry for JAXB runtime discovery.

# Algorithm

Factory methods instantiate new objects:
1. **createPrinterConfiguration** - Returns new PrinterConfiguration instance.
2. **createStateReportState** - Returns new StateReport.State instance.
3. **createXmppConfigTcpPorts** - Returns new XmppConfig.TcpPorts instance.
4. **createXmppConfigTcpPortsTcpPort** - Returns new XmppConfig.TcpPorts.TcpPort instance.
5. **createXmppConfigJabberIDs** - Returns new XmppConfig.JabberIDs instance.
6. **createStateReportStateError** - Returns new StateReport.State.Error instance.
7. **createSessionSecret** - Returns new SessionSecret instance.
8. **createXmppConfig** - Returns new XmppConfig instance.
9. **createPrinterEmailAddress** - Returns new PrinterEmailAddress instance.
10. **createStateReport** - Returns new StateReport instance.
11. **createPrinterIdentification** - Returns new PrinterIdentification instance.
12. **createCloudConfiguration** - Returns new CloudConfiguration instance.
13. **createPrinterClaimInfo** - Returns new PrinterClaimInfo instance.
14. **createInstructionType** - Returns JAXBElement<String> wrapping the instruction type value with namespace-qualified name.

# Business rules

• All factory methods return new instances; no caching or pooling.
• InstructionType element uses namespace http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11 and applies CollapsedStringAdapter for whitespace normalization.
