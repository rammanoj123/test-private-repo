---
type: Component
title: Printer Configuration
description: Holds printer ID, key, XMPP configuration, and version for printer registration responses.
tags: [component, config, printer, xmpp, xml-schema]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterConfiguration.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterConfiguration.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/PrinterConfiguration.java, title: PrinterConfiguration.java }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterConfiguration`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerID | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| printerKey | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| xmppConfig | XmppConfig | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerKey;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerID;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String printerKey;     @XmlElement(namespace = "http:     protected XmppConfig xmppConfig;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterID | String |  |  |
| setPrinterID | void | String value |  |
| getPrinterKey | String |  |  |
| setPrinterKey | void | String value |  |
| getXmppConfig | XmppConfig |  |  |
| setXmppConfig | void | XmppConfig value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |

# Business context

JAXB-generated data transfer object representing printer registration response. Contains printer ID, authentication key, XMPP configuration for cloud messaging, and schema version. Returned after successful printer registration to provide credentials and connection details.

# Algorithm

All methods are standard JavaBean getters and setters:
1. **getPrinterID/setPrinterID** - Get/set printer ID (32-character token).
2. **getPrinterKey/setPrinterKey** - Get/set printer key (max 45 characters).
3. **getXmppConfig/setXmppConfig** - Get/set XMPP configuration object.
4. **getVersion/setVersion** - Get/set schema version attribute (required).

# Business rules

• printerID must be exactly 32 characters (token).
• printerKey must be max 45 characters (token).
• xmppConfig is required.
• version attribute is required.
• All fields use CollapsedStringAdapter for whitespace normalization.
• XML namespace is http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11.
