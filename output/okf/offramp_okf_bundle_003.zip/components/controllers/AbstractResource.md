---
type: Component
title: Abstract Resource
description: Provides base HTTP method allowance logic for Restlet resources.
tags: [component, controller, base-class, restlet, http]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\AbstractResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: AbstractResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/AbstractResource.java, title: AbstractResource.java }
---

`com.hp.cloudprint.api.offramp.resources.AbstractResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |

# Business context

Abstract base class for Restlet resources providing configurable HTTP method allowance. Subclasses inherit method permission logic driven by Spring-injected method list. Simplifies resource configuration by externalizing allowed methods to Spring configuration.

# Algorithm

1. **setMethods(methods)** - Spring injection setter to configure allowed HTTP methods list.
2. **allowGet** - Returns true if methods list contains "GET".
3. **allowPost** - Returns true if methods list contains "POST".
4. **allowDelete** - Returns true if methods list contains "DELETE".
5. **allowPut** - Returns true if methods list contains "PUT".
6. **allowOptions** - Returns true if methods list contains "OPTIONS".
7. **allowHead** - Returns true if methods list contains "HEAD".

# Business rules

• HTTP method allowance is determined by presence of method name in the methods list.
• Methods list is injected via Spring configuration.
• Subclasses extend this class to inherit method permission logic.
