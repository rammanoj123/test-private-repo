---
type: Component
title: Device Upload Resource
description: Handles POST and PUT requests to upload scanned document pages to the scan service.
tags: [component, controller, resource, scan, upload]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\DeviceUploadResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: DeviceUploadResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/DeviceUploadResource.java, title: DeviceUploadResource.java }
---

`com.hp.cloudprint.api.offramp.resources.DeviceUploadResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| scanService | ScanService | @javax.annotation.Resource |
| tmpFile | File | @javax.annotation.Resource |
| LOG | Logger | @javax.annotation.Resource |
| jobId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| documentId | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| pageNo | String | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST") |
| entityStream | InputStream |  |
| offRampAPIConfig | OffRampAPIConfig | @Override, @Auditable(name = "/jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#PUT") |
| CHUNK_SIZE | int |  |
| MAX_POSSIBLE_MEMORY | long |  |
| totalSize | long |  |
| inStream | InputStream |  |
| byteOutStream | ByteArrayOutputStream |  |
| chunk | byte[] |  |
| readBytes | int |  |
| doContinue | boolean |  |
| outStream | OutputStream |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setScanService | void | ScanService scanService |  |
| DeviceUploadResource |  |  |  |
| allowPost | boolean |  |  |
| allowPut | boolean |  |  |
| getShardCodeFromJobId | String | String jobId |  |
| acceptRepresentation | void | Representation entity |  |
| storeRepresentation | void | Representation entity |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| convertToInputStream | InputStream | InputStream entityStream, String documentId |  |


# Depends on

• `ScanService` (push document page data)
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) (BUFFER_SIZE, MAX_POSSIBLE_MEMORY)
• `ShardUtil` (extract shard code from job ID)

# Business context

RESTful resource handling scanned document page uploads from devices. Accepts POST/PUT requests with page image data, buffers in memory up to configured threshold, spills to temp file for large uploads, and pushes to scan service. Manages shard context and cleans up temp files after processing.

# Algorithm

1. **acceptRepresentation** (audited as /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#POST):
   1. Extract jobId, documentId, pageNo from request attributes.
   2. Set shard context via EprintShardHolder.setShard(getShardCodeFromJobId(jobId)).
   3. Validate jobId and documentId are not null/empty; return 400 if invalid.
   4. Convert entity stream to InputStream via convertToInputStream(entity.getStream(), documentId).
   5. Call scanService.pushDocumentPageData(pageNo, documentId, jobId, entityStream).
   6. Return 200 on success.
   7. On ConnectionTimeoutException, return 408; on DeviceConnectionException, return 500; on NotFoundException, return 400; on NotPossibleException, return 400; on MustRetryException, throw CpFaultException; on IOException, return 400.
   8. In finally block, wait for stream to drain (check available() > 0 with 1s sleep), close stream, delete tmpFile if exists.
2. **storeRepresentation** (audited as /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE}#PUT):
   1. Delegate to acceptRepresentation(entity).
3. **convertToInputStream(entityStream, documentId)**:
   1. Read BUFFER_SIZE config for chunk size; MAX_POSSIBLE_MEMORY config for memory threshold.
   2. Read entity stream in chunks into ByteArrayOutputStream, tracking totalSize.
   3. If totalSize exceeds MAX_POSSIBLE_MEMORY, create temp file, write buffered data, continue reading into file, return FileInputStream.
   4. If totalSize within limit, return ByteArrayInputStream from buffered data.
   5. On SocketTimeoutException, throw ConnectionTimeoutException; on IOException, throw DeviceConnectionException.
   6. Close ByteArrayOutputStream in finally block.
4. **getShardCodeFromJobId(jobId)** - Extract shard code from job ID string via ShardUtil.

# Business rules

• If jobId or documentId is null/empty, return 400.
• If upload size exceeds MAX_POSSIBLE_MEMORY, buffer to temp file; otherwise use in-memory ByteArrayOutputStream.
• On connection timeout, return 408; on device connection error, return 500; on job/document not found, return 400.
• Temp file is deleted only after stream is fully consumed (available() == 0).
• Shard context is set from jobId before processing.
