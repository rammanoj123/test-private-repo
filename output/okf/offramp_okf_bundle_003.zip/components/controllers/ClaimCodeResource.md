---
type: Component
title: Claim Code Resource
description: Handles GET requests to retrieve printer claim code information for registration.
tags: [component, controller, resource, claim-code, printer]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\offramp\resources\ClaimCodeResource.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: ClaimCodeResource.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/resources/ClaimCodeResource.java, title: ClaimCodeResource.java }
---

`com.hp.cloudprint.api.offramp.resources.ClaimCodeResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | PrinterManager | @javax.annotation.Resource |
| LOGGER | Logger | @javax.annotation.Resource |
| daoUtil | DaoUtil | @javax.annotation.Resource |
| printer | Printer | @javax.annotation.Resource |
| printerID | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| strClaimCodeXML | String | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| rep | Representation | @Override, @Auditable(name = "/Printers/{PrinterID}/ClaimCode#GET") |
| printerClaimInfo | PrinterClaimInfo |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | PrinterManager printerManager |  |
| ClaimCodeResource |  |  |  |
| setDaoUtil | void | DaoUtil daoUtil |  |
| allowGet | boolean |  |  |
| handleGet | void |  |  |
| getOfframpAPIConfigInstance | OffRampAPIConfig |  |  |
| doWork | void |  |  |
| execute | void |  |  |


# Depends on

• `PrinterManager` (fetch printer, create admin operation)
• `DaoUtil` (transaction management)
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) (EPCUrl, SpecVersion)
• [Utility](/components/misc/Utility.md) (marshal, getPrinterClaimInfo)

# Business context

RESTful resource providing printer claim code information for registration. Retrieves printer details and generates claim info including EPC URL and spec version. Creates admin operation timestamp in transactional context with retry logic. Returns XML response for printer claiming workflow.

# Algorithm

1. **handleGet** (audited as /Printers/{PrinterID}/ClaimCode#GET):
   1. Extract printerID from request attributes.
   2. Fetch active printer via printerManager.getActivePrinterByPrinterID(printerID); return 404 on DeviceNotFoundExcpeption, 500 on other exceptions.
   3. Validate printer is not null; return 404 if null.
   4. Call doWork() to create admin operation timestamp in transaction; return 500 on exception.
   5. Build PrinterClaimInfo via Utility.getPrinterClaimInfo(printer, EPCUrl, SpecVersion).
   6. Marshal PrinterClaimInfo to XML.
   7. Return 200 with XML entity.
2. **doWork** (annotated @EPrintRetriable with 3 retries):
   1. Execute daoUtil.executeInTransaction(this) via RetryHandler.executeWithRetry() with 3 retries.
   2. Wraps CpExternalContingencyException and MustRetryException in RuntimeException for lambda.
3. **execute** (DaoCallBack implementation):
   1. Call printerManager.createAdminOperation(printer) to insert claim code timestamp.

# Business rules

• If printerID is invalid or printer not found, return 404.
• Admin operation timestamp is created in transaction with 3 retry attempts on transient failures.
• Claim info includes EPCUrl and SpecVersion from configuration.
