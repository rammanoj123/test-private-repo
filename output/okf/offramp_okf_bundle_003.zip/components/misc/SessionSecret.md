---
type: Component
title: Session Secret
description: Holds session secret token value with version attribute for XML serialization.
tags: [component, unknown, data, session, security, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\SessionSecret.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: SessionSecret.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/SessionSecret.java, title: SessionSecret.java }
---

`com.hp.cloudprint.api.offramp.schemas.SessionSecret`


# Schema

**value** (String): Base64-encoded session secret token. Maps to XML element text content.

**version** (String, required): Version identifier for the session secret schema. Namespace-qualified attribute, whitespace-collapsed.

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |

# Business context

JAXB-generated data transfer object representing a session secret token for printer authentication. Carries a base64-encoded secret value and a required version attribute for XML serialization/deserialization. Used in printer registration and session management workflows.

# Algorithm

**getValue**
1. Return the `value` field (base64-encoded session secret)

**setValue**
1. Set the `value` field to the provided base64-encoded string

**getVersion**
1. Return the `version` attribute

**setVersion**
1. Set the `version` attribute to the provided token string

# Business rules

• The `version` attribute is required in XML serialization (marked with `@XmlAttribute(required = true)`).
• The `version` attribute is namespace-qualified to `http://www.hp.com/schemas/imaging/con/cloud/print/printerregistration/2009/11/11`.
• The `version` value is collapsed (whitespace normalized) via `CollapsedStringAdapter`.
• The `value` field holds the session secret as a base64Binary string.
