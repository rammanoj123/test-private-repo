---
type: Component
title: Region Name
description: Represents region name enumeration for localization and validation.
tags: [component, unknown, data, enum, localization]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\RegionName.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: RegionName.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/dictionaries/RegionName.java, title: RegionName.java }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.RegionName`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| RegionName |  | String v |  |
| fromValue | RegionName | String v |  |

# Algorithm

1. **Constructor RegionName(v)** - Initializes enum constant with string value.
2. **value()** - Returns the string value of the enum constant.
3. **fromValue(v)** - Iterates through all enum values; returns the enum constant whose value equals v; throws IllegalArgumentException if no match found.

# Business context

JAXB-generated enumeration representing geographic regions for printer localization and configuration. Defines 16 region values including Africa, Asia Pacific, Europe, North America, Latin America, Middle East, and others. Used in printer identification to specify regional settings and compliance.

# Business rules

• Valid region values: africa, asiaPacific, caribbean, europe, indiaChina, japanCISMEA, latinAmerica, middleEast, NALAAP (North America/Latin America/Asia Pacific), nordic, northAfrica, northAmericaUSACanada, northWestAfrica, notSupported, southernAfrica, universal.
• fromValue() throws IllegalArgumentException if input string does not match any enum value.
• Enum values are case-sensitive and must match exactly.
