---
type: Component
title: Version
description: Holds firmware version information including revision string and date.
tags: [component, unknown, data, version, firmware, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\dictionaries\Version.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: version-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/dictionaries/Version.java }
---

`com.hp.cloudprint.api.offramp.schemas.dictionaries.Version`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| revision | String | @XmlElement(name = "Revision",  namespace = "http: |
| date | XMLGregorianCalendar | @XmlElement(name = "Revision",  namespace = "http:     protected String revision;     @XmlElement(name = "Date" , namespace = "http: |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRevision | String |  |  |
| setRevision | void | String value |  |
| getDate | XMLGregorianCalendar |  |  |
| setDate | void | XMLGregorianCalendar value |  |

# Business context

Version is a JAXB-generated schema class representing firmware version information with revision string and date components. It corresponds to the Firmware_Datecode element in pre-XDM XML formats. The class enables XML serialization/deserialization of firmware version data for printer identification and configuration tracking. Generated from XSD schema on 2010.07.26.

# Algorithm

**getRevision()**: Returns the firmware revision string. May be null if not set in the XML.

**setRevision(String value)**: Sets the firmware revision string.

**getDate()**: Returns the firmware date as XMLGregorianCalendar. May be null if not set in the XML.

**setDate(XMLGregorianCalendar value)**: Sets the firmware date.

All methods are simple JAXB bean accessors with no business logic. XML marshalling/unmarshalling is handled automatically by JAXB framework based on annotations.

# Business rules

- Both revision and date fields are optional (minOccurs=0 in schema)
- Revision is represented as a String
- Date uses XMLGregorianCalendar for XML date/time compatibility
- XML namespace: `http://www.hp.com/schemas/imaging/con/dictionaries/1.0/`
- Element names in XML: "Revision" and "Date" with proper namespace qualification
- Field order in XML: revision first, then date (enforced by propOrder in @XmlType)

# Depends on

- `javax.xml.bind.annotation.*` - JAXB annotations for XML binding
- `javax.xml.datatype.XMLGregorianCalendar` - XML-compatible date/time representation

# Participates in

- Firmware version tracking in [PrinterIdentification](/components/misc/PrinterIdentification.md)
- XML serialization/deserialization of printer configuration data
- Printer registration and identification workflows
- Legacy pre-XDM XML format support
