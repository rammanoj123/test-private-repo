---
type: Component
title: Registration Authentication Entry Point
description: Handles registration authentication failures by logging printer details and returning HTTP 401 responses.
tags: [component, unknown, security, authentication, registration, entry-point]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\security\log\RegistrationAuthenticationEntryPoint.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: RegistrationAuthenticationEntryPoint.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/security/log/RegistrationAuthenticationEntryPoint.java, title: RegistrationAuthenticationEntryPoint.java }
---

`com.hp.cloudprint.api.offramp.security.log.RegistrationAuthenticationEntryPoint`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| authentication | Authentication |  |
| authHeader | String |  |
| username | String |  |
| arrParams | String[] |  |
| modelNumber | String |  |
| domain | String |  |
| id | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| commence | void | HttpServletRequest  request, HttpServletResponse  response, AuthenticationException authException |  |

# Algorithm

1. **commence(request, response, authException)**:
   1. If authException is AuthenticationServiceException, set response status to 503 SERVICE_UNAVAILABLE, write exception message to response, and return.
   2. Otherwise, extract message from authException.
   3. Add WWW-Authenticate header with Basic realm set to realmName.
   4. Set response status to 401 UNAUTHORIZED and write message to response.
   5. Attempt to get Authentication from SecurityContextHolder.getContext().getAuthentication().
   6. If authentication is null and Authorization header exists with "Basic " prefix, note but do not extract username.
   7. If authentication is not null, extract username from authentication.getPrincipal().
   8. Split username by "+" delimiter into arrParams.
   9. If arrParams is null or length != 3, log "UNAUTHORIZED: FailureReason=Incorrect Authorization Data Format" with username and return.
   10. Otherwise, extract modelNumber = arrParams[0], domain = arrParams[1], id = arrParams[2].
   11. Log "UNAUTHORIZED: FailureReason=<message>; ModelNumber=<modelNumber>; Domain=<domain>; ID=<id>".
   12. If authentication is null, log "UNAUTHORIZED: FailureReason=<message>" without printer details.

# Business context

Spring Security authentication entry point for registration endpoints. Handles authentication failures by logging detailed printer identification (model number, domain, ID extracted from username) and returning appropriate HTTP responses. Differentiates between service unavailability (503) and authentication failures (401).

# Business rules

• If AuthenticationServiceException, return 503 Service Unavailable.
• Otherwise, return 401 Unauthorized with WWW-Authenticate Basic realm header.
• Username format expected: <modelNumber>+<domain>+<id> (3 parts separated by '+').
• If username format is incorrect, log failure with username.
• If username format is correct, log failure with parsed modelNumber, domain, and ID.
• If authentication is unavailable, log failure without printer details.
