---
type: Component
title: Tunnel Connection Timers
description: Holds tunnel connection timing configuration for first connection and retry delays.
tags: [component, unknown, data, tunnel, configuration, timers]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\tunnelConnectionTimers.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: tunnel-timers-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/tunnelConnectionTimers.java }
---

`com.hp.cloudprint.api.offramp.schemas.tunnelConnectionTimers`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| delayBeforeFirstConnection | Integer |  |
| delayAfterConnectionFailure | Integer |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDelayBeforeFirstConnection | Integer |  |  |
| setDelayBeforeFirstConnection | void | Integer delayBeforeFirstConnection |  |
| getDelayAfterConnectionFailure | Integer |  |  |
| setDelayAfterConnectionFailure | void | Integer delayAfterConnectionFailure |  |

# Business context

tunnelConnectionTimers is a deprecated JAXB schema class that holds timing configuration for tunnel connection establishment and retry logic. It specifies delays before the first connection attempt and after connection failures. The class is marked @Deprecated, indicating it should not be used in new code and may be removed in future versions. It supports XML serialization for tunnel connection timing parameters.

# Algorithm

**getDelayBeforeFirstConnection()**: Returns the delay in milliseconds (or seconds, units not specified in code) before attempting the first tunnel connection. Returns null if not set.

**setDelayBeforeFirstConnection(Integer delayBeforeFirstConnection)**: Sets the delay before first connection attempt.

**getDelayAfterConnectionFailure()**: Returns the delay before retrying after a connection failure. Returns null if not set.

**setDelayAfterConnectionFailure(Integer delayAfterConnectionFailure)**: Sets the delay after connection failure.

All methods are simple JAXB bean accessors. XML elements are named "delayBeforeFirstConnection" and "delayAfterConnectionFailure" with root element "tunnelConnectionTimers".

# Business rules

- Class is deprecated and should not be used in new implementations
- Both delay fields are Integer (nullable), allowing absence of timing configuration
- Delay units are not explicitly documented in the code
- XML root element: "tunnelConnectionTimers"
- XML element names match Java field names
- No validation constraints on delay values (can be any Integer including negative)

# Depends on

- `javax.xml.bind.annotation.*` - JAXB annotations for XML binding

# Participates in

- Legacy tunnel connection configuration (deprecated)
- XML serialization/deserialization of tunnel timing parameters
- Historical printer-to-cloud connection establishment workflows
