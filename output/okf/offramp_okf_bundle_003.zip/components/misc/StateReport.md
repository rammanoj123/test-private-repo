---
type: Component
title: State Report
description: Holds printer state report information including state, errors, and application details.
tags: [component, unknown, data, state, printer, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\StateReport.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: StateReport.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/StateReport.java, title: StateReport.java }
---

`com.hp.cloudprint.api.offramp.schemas.StateReport`


# Schema

**state** (List<State>): Collection of application-specific state entries. Unbounded.

**version** (String, required): Schema version token.

**State.state** (String, optional): Connection state enumeration (connected | disconnected | retrying | error).

**State.error** (Error, optional): Extensible error details container.

**State.reason** (String, optional): Human-readable reason for the current state.

**State.application** (String, optional): Application identifier (xmpp | printerRegistration).

**Error.any** (Object): Extensible error payload, allows any XML element.

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getState | List |  |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getState | String |  |  |
| setState | void | String value |  |
| getError | Error |  |  |
| setError | void | Error value |  |
| getReason | String |  |  |
| setReason | void | String value |  |
| getApplication | String |  |  |
| setApplication | void | String value |  |

# Business context

JAXB-generated data transfer object representing printer state reports for cloud connectivity. Captures connection state, errors, and reasons for multiple applications (XMPP messaging, printer registration). Enables printers to report their connectivity status to the cloud service.

# Algorithm

**getState**
1. If `state` list is null, initialize it as an empty ArrayList
2. Return the live list reference (modifications affect the object directly)

**getVersion / setVersion**
1. Get or set the required `version` attribute (token string)

**State.getState / setState**
1. Get or set the state enumeration value (connected, disconnected, retrying, error)

**State.getError / setError**
1. Get or set the `Error` object containing extensible error details

**State.getReason / setReason**
1. Get or set the optional reason string explaining the state

**State.getApplication / setApplication**
1. Get or set the application identifier (xmpp, printerRegistration)

**Error.getAny / setAny**
1. Get or set the extensible error payload (any XML element allowed)

# Business rules

• The `version` attribute is required at the root level.
• Each `State` entry can represent a different application (xmpp or printerRegistration).
• State values are restricted to: connected, disconnected, retrying, error.
• Application values are restricted to: xmpp, printerRegistration.
• The `error` element supports extensible content via `@XmlAnyElement(lax = true)`.
• Multiple state entries are allowed in a single report (unbounded list).
• All elements are namespace-qualified to `http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11`.
