---
type: Component
title: Utility
description: Provides utility methods for XML schema loading and printer claim info generation.
tags: [component, unknown, utility, xml, schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\Utility.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15 00:00:00+00:00 }
sources:
  - { id: utility-java, resource: source, title: offramp/src/main/java/com/hp/cloudprint/api/offramp/Utility.java }
---

`com.hp.cloudprint.api.offramp.Utility`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| schemaV2 | Schema |  |
| obj | Object |  |
| schemaName | String |  |
| schemaName | String |  |
| printerClaimInfo | PrinterClaimInfo |  |
| printerCrypticEmailAddress | String |  |
| index | int |  |
| printerName | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getSchemaV2 | Schema |  |  |
| getPrinterClaimInfo | PrinterClaimInfo | Printer printer, String ePCURL, String specVersion |  |

# Business context

The Utility class provides centralized helper methods for XML schema validation and printer claim information generation. It supports both base and V2 API specifications through lazy-loaded, thread-safe singleton Schema instances. The class bridges between the Printer entity model and the PrinterClaimInfo XML schema representation required for printer registration workflows.

# Algorithm

**getSchema()**: Implements double-checked locking pattern to lazily initialize the base API schema. Retrieves schema name from `OffRampAPIConfig.XSD_OFFRAMP_API_SPEC` configuration and delegates to `com.hp.cloudprint.util.Utility.getSchema()` for actual schema loading. Thread-safe through synchronized block on shared object lock.

**getSchemaV2()**: Identical lazy initialization pattern for V2 API schema. Retrieves schema name from `OffRampAPIConfig.XSD_OFFRAMP_API_V2_SPEC` configuration. Maintains separate schema instance for V2 compatibility.

**getPrinterClaimInfo(Printer printer, String ePCURL, String specVersion)**: Constructs PrinterClaimInfo from Printer entity. Extracts claim code by parsing the cryptic email address (substring before '@'). Sets claim code, active email address, ePrint Center URL, and API version. Returns fully populated PrinterClaimInfo ready for XML serialization.

# Business rules

- Schema instances are lazily initialized on first access and cached for application lifetime
- Thread safety enforced through double-checked locking with synchronized blocks
- Claim code is derived from the printer's cryptic email address (portion before '@' symbol)
- Both base and V2 schemas are supported through separate configuration keys
- Schema names are externalized to OffRampAPIConfig for environment-specific configuration
- PrinterClaimInfo requires: claim code, active email address, ePrint Center URL, and API version

# Depends on

- [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) - retrieves XSD schema file names for base and V2 API specs
- `com.hp.cloudprint.util.Utility` - performs actual schema loading from configured file names
- `com.hp.cloudprint.entities.Printer` - source entity for printer claim information
- [PrinterClaimInfo](/components/misc/PrinterClaimInfo.md) - target schema object for claim data

# Participates in

- Printer registration workflows requiring XML validation against API schemas
- Claim code generation during printer setup and registration
- API version negotiation (base vs V2 specification handling)
- XML marshalling/unmarshalling with JAXB schema validation
