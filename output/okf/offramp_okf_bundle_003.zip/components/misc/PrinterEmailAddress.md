---
type: Component
title: Printer Email Address
description: Holds printer email address with version attribute for XML serialization.
tags: [component, unknown, data, email, printer, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterEmailAddress.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterEmailAddress.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/PrinterEmailAddress.java, title: PrinterEmailAddress.java }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterEmailAddress`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| version | String | @XmlAttribute(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getValue | String |  |  |
| setValue | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |

# Algorithm

All methods are standard JavaBean getters and setters:
1. **getValue/setValue** - Get/set email address value (anyURI, stored in @XmlValue).
2. **getVersion/setVersion** - Get/set schema version attribute (required token).

# Business context

JAXB-generated data transfer object representing printer email address with schema version. Uses simple content extension pattern where the element value is the email address and version is an attribute. Used in printer email address API responses.

# Business rules

• value field holds the email address (anyURI).
• version attribute is required (token).
• Version attribute uses CollapsedStringAdapter for whitespace normalization.
• XML namespace is http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11.
