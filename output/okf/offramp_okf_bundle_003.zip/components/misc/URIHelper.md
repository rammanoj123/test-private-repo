---
type: Component
title: URI Helper
description: Provides utility methods to construct URI paths for offramp API resources.
tags: [component, unknown, utility, uri, helper]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\URIHelper.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: URIHelper.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/URIHelper.java, title: URIHelper.java }
---

`com.hp.cloudprint.api.offramp.URIHelper`


# Schema

**Constants**:
- `OFF_RAMP_LEFT_OVER_URL`: `/` - base path prefix
- `PRINTER_ID`: `"PrinterID"` - parameter name constant
- `EMAIL_ADDRESS`: `"EmailAddress"` - parameter name constant
- `OWNERSHIP_ID`: `"OwnershipID"` - parameter name constant
- `OwernershipsUri`: `/ownerships` - ownership base path
- `JOBID`: `"JOBID"` - job ID parameter name
- `DOCUMENTID`: `"DOCUMENTID"` - document ID parameter name
- `PAGE`: `"PAGE"` - page parameter name
- `SESSION_TOKEN`: `"sessiontoken"` - session token parameter name
- `HOST_NAME`: `"sessionserver"` - host name parameter name

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintersURI | String |  |  |
| getPrinterURI | String | String printerId |  |
| getEmailAddressURI | String | String opaqueURI |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getInstructionURI | String | String parameter |  |
| getXMPPConfigURI | String | String parameter |  |
| getPrinterCloudConfigURI | String | String parameter |  |
| getPrinterStateReportURI | String | String parameter |  |
| getOutputURI | String | String jobID, String documentID |  |

# Business context

Centralizes URI construction logic for offramp API resources. Provides consistent path templates for printer resources, email addresses, ownerships, instructions, configurations, and output. Ensures uniform URL structure across the offramp REST API.

# Algorithm

**getParameterURI**
1. Return `"{" + parameterName + "}"`

**getPrintersURI**
1. Return `OFF_RAMP_LEFT_OVER_URL + "Printers"` (evaluates to `/Printers`)

**getPrinterURI**
1. Call `getPrintersURI()`
2. Append `"/" + printerId + "/"`
3. Return the concatenated string (e.g., `/Printers/{printerId}/`)

**getEmailAddressURI**
1. Call `getPrinterURI(opaqueURI)`
2. Append `"EmailAddress"`
3. Return the concatenated string (e.g., `/Printers/{opaqueURI}/EmailAddress`)

**getOwnerShipsURI**
1. Return `OwernershipsUri` constant (`/ownerships`)

**getOwnerShipURI**
1. Return `OwernershipsUri + "/" + ownerShipId + "/"` (e.g., `/ownerships/{ownerShipId}/`)

**getInstructionURI**
1. Call `getPrintersURI()`
2. Append `"/" + parameter + "/PrintJobs/Instructions"`
3. Return the concatenated string (e.g., `/Printers/{parameter}/PrintJobs/Instructions`)

**getXMPPConfigURI**
1. Call `getPrintersURI()`
2. Append `"/" + parameter + "/XMPPConfiguration"`
3. Return the concatenated string (e.g., `/Printers/{parameter}/XMPPConfiguration`)

**getPrinterCloudConfigURI**
1. Call `getPrintersURI()`
2. Append `"/" + parameter + "/CloudConfiguration"`
3. Return the concatenated string (e.g., `/Printers/{parameter}/CloudConfiguration`)

**getPrinterStateReportURI**
1. Call `getPrintersURI()`
2. Append `"/" + parameter + "/StateReport"`
3. Return the concatenated string (e.g., `/Printers/{parameter}/StateReport`)

**getOutputURI**
1. Call `getPrintersURI()`
2. Append `"/" + "PrintJobs/Output/" + getParameterURI(jobID) + "/" + getParameterURI(documentID)`
3. Return the concatenated string (e.g., `/Printers/PrintJobs/Output/{jobID}/{documentID}`)

# Business rules

• All printer resource URIs are prefixed with `/Printers`.
• Printer-specific URIs include a trailing slash after the printer ID.
• Parameter placeholders are wrapped in curly braces (e.g., `{PrinterID}`).
• Ownership URIs use a separate path hierarchy (`/ownerships`) independent of printers.
• The base path constant `OFF_RAMP_LEFT_OVER_URL` is set to `/` for all offramp resources.
• Email address URIs use `EmailAddress` (no trailing slash).
• Configuration and state report URIs follow the pattern `/Printers/{id}/{ResourceType}`.
