---
type: Component
title: Printer Claim Info
description: Holds printer claim information including email address, claim code, and ePrint Center URL.
tags: [component, unknown, data, claim, printer, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterClaimInfo.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterClaimInfo.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/PrinterClaimInfo.java, title: PrinterClaimInfo.java }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterClaimInfo`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAddress | String | @XmlElement(required = true) |
| claimCode | String | @XmlElement(name = "ClaimCode", required = true) |
| epcUrl | String | @XmlElement(name = "ePCUrl", required = true) |
| version | String | @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEmailAddress | String |  |  |
| setEmailAddress | void | String value |  |
| getClaimCode | String |  |  |
| setClaimCode | void | String value |  |
| getEPCUrl | String |  |  |
| setEPCUrl | void | String value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |

# Algorithm

All methods are standard JavaBean getters and setters:
1. **getEmailAddress/setEmailAddress** - Get/set printer email address (anyURI, required).
2. **getClaimCode/setClaimCode** - Get/set claim code string (required).
3. **getEPCUrl/setEPCUrl** - Get/set ePrint Center URL (anyURI, required).
4. **getVersion/setVersion** - Get/set schema version attribute (required).

# Business context

JAXB-generated data transfer object representing printer claim information for registration workflow. Contains email address, claim code for user claiming, and ePrint Center URL for web-based claiming. Returned in claim code API responses to enable printer ownership claiming.

# Business rules

• emailAddress, claimCode, and epcUrl are required fields.
• version attribute is required.
• emailAddress and epcUrl are anyURI types.
• claimCode is a string.
• All string fields use CollapsedStringAdapter for whitespace normalization on version attribute.
