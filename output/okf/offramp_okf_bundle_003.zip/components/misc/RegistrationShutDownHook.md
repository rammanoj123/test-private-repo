---
type: Component
title: Registration Shutdown Hook
description: Registers shutdown hook to gracefully wait for in-flight instruction jobs to complete before termination.
tags: [component, unknown, shutdown, lifecycle, graceful, registration]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\gracefullshutdown\RegistrationShutDownHook.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: RegistrationShutDownHook.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/gracefullshutdown/RegistrationShutDownHook.java, title: RegistrationShutDownHook.java }
---

`com.hp.cloudprint.api.offramp.gracefullshutdown.RegistrationShutDownHook`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| instructionJobThreadMetricsCollector | InstructionJobThreadMetricsCollector |  |
| shutDownInitiated | Long |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setInstructionJobThreadMetricsCollector | void | InstructionJobThreadMetricsCollector instructionJobThreadMetricsCollector |  |
| registerShoutDownHookHandler | void |  |  |
| isRegNode | boolean |  |  |
| execute | void |  |  |
| isWaitOver | boolean |  |  |

# Business context

Manages graceful shutdown of the offramp service by waiting for in-flight printer registration instruction jobs to complete before allowing termination. Only active on registration nodes (non-pull nodes). Ensures data integrity by preventing abrupt termination during active registration processing.

# Algorithm

**registerShoutDownHookHandler**
1. Check if current node is a registration node via `isRegNode()` (returns true if not a pull node)
2. If registration node, register this hook with `ServiceLifeCycleInstanceHolder` for execution before stopping
3. Log registration or skip message accordingly

**execute** (shutdown handler)
1. Record shutdown initiation timestamp in `shutDownInitiated`
2. Enter infinite loop:
   a. Check if wait timeout exceeded via `isWaitOver()` (compares elapsed time against configured `ShutDownHookDelay`)
   b. If timeout exceeded, log uncompleted registration count and break
   c. If pending count from `instructionJobThreadMetricsCollector` is zero, log completion time and break
   d. Log current pending registration count
   e. Sleep for 5 seconds
   f. Repeat
3. Log shutdown hook completion

**isWaitOver**
1. Calculate elapsed seconds since `shutDownInitiated`
2. Compare against `OffRampAPIConfig.getInstance().getShutDownHookDelay()`
3. Return true if elapsed time exceeds configured delay

**isRegNode**
1. Return negation of `OffRampAPIConfig.getInstance().isPullNode()`

# Business rules

• If the node is a pull node, shutdown hook registration is skipped.
• If elapsed time exceeds the configured shutdown delay, the hook terminates regardless of pending jobs.
• If all pending registrations complete before timeout, the hook terminates immediately.
• The hook polls pending job count every 5 seconds during shutdown.
• Only registration nodes (non-pull nodes) participate in graceful shutdown waiting.

# Depends on

• [InstructionJobThreadMetricsCollector](code:InstructionJobThreadMetricsCollector) - injected via setter, provides pending job count
• [OffRampAPIConfig](/components/config/OffRampAPIConfig.md) - provides pull node flag and shutdown delay configuration
• `ServiceLifeCycleInstanceHolder` - framework hook registration
• `Logger` (SLF4J) - logging
