---
type: Component
title: Stratus Client Implementation
description: Publishes printer ownership deletion events to Stratus eventing service with retry logic.
tags: [component, unknown, integration, stratus, eventing, client]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\StratusClientImpl.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: StratusClientImpl.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/StratusClientImpl.java, title: StratusClientImpl.java }
---

`com.hp.cloudprint.api.offramp.StratusClientImpl`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| log | Logger |  |
| notificationServiceClientHelper | NotificationServiceClientHelper | @Resource |
| AUTHORIZATION | String | @Resource |
| BEARER | String | @Resource |
| httpHeaders | HashMap |  |
| stratusEventPayload | StratusEventPayload |  |
| maxRetries | int |  |
| retryDelay | long |  |
| i | int |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setNotificationServiceClientHelper | void | NotificationServiceClientHelper notificationServiceClientHelper |  |
| getPrinterConfigInstance | PrinterConfig |  |  |
| publishDeleteOwnershipToStratus | void | String ownershipId, String  printerId |  |
| sleep | void | long timeSpan, String id |  |


# Depends on

• [NotificationServiceClientHelper](code:NotificationServiceClientHelper) - injected via `@Resource`, posts notifications to Stratus
• `PrinterConfig` - singleton providing retry configuration (max retries, retry delay)
• `StratusEventPayload` - payload object carrying printer and ownership IDs
• `NotificationType.DEREGISTRATION` - enumeration value for deregistration events
• `Logger` (SLF4J) - logging

# Business context

Publishes printer ownership deletion events to the Stratus eventing service during deregistration workflows. Implements retry logic with configurable attempts and delays to ensure reliable event delivery. Critical for maintaining consistency between printer ownership state and downstream event consumers.

# Algorithm

**publishDeleteOwnershipToStratus**
1. Create `StratusEventPayload` with `printerId` and `ownershipId`
2. Retrieve max retries from `PrinterConfig.getInstance().getDeRegMessagingNotificationMaxRetries()`
3. Retrieve retry delay from `PrinterConfig.getInstance().getDeRegMessagingNotificationRetryDelay()`
4. Initialize retry counter `i` to 1
5. Loop while `i <= maxRetries`:
   a. Try to post notification via `notificationServiceClientHelper.postStratusNotification(NotificationType.DEREGISTRATION, "OFFRAMP", printerId, stratusEventPayload)`
   b. If successful, break from loop
   c. If `NotificationRetriableException` caught:
      - If `i == maxRetries`, re-throw the exception
      - Otherwise, log warning with retry message and printer ID
   d. If `NotificationNotRetriableException` caught, re-throw immediately
   e. Sleep for `retryDelay` milliseconds via `sleep(retryDelay, printerId)`
   f. Increment `i`
6. Exit when successful or max retries exhausted

**sleep**
1. If debug logging enabled, log sleep request with printer ID and time span
2. Call `Thread.sleep(timeSpan)`
3. If `InterruptedException` caught, log warning about thread interruption

**getPrinterConfigInstance**
1. Return singleton `PrinterConfig.getInstance()`

# Business rules

• If a retriable exception occurs and max retries is reached, the exception is propagated to the caller.
• Non-retriable exceptions are immediately propagated without retry attempts.
• Retry delay is applied after each failed attempt, including the final one before re-throwing.
• The notification type is always DEREGISTRATION for ownership deletion events.
• The source system identifier is hardcoded as "OFFRAMP".
