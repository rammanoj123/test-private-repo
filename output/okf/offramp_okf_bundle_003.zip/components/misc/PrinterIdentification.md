---
type: Component
title: Printer Identification
description: Holds printer identification details including model, serial number, firmware, localization, and cloud configuration.
tags: [component, unknown, data, printer, identification, xml-schema]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\offramp\schemas\PrinterIdentification.java
generated: { by: gpt-4o-2024-05-13, at: 2025-01-15T00:00:00Z }
sources:
  - { id: PrinterIdentification.java, resource: offramp/src/main/java/com/hp/cloudprint/api/offramp/schemas/PrinterIdentification.java, title: PrinterIdentification.java }
---

`com.hp.cloudprint.api.offramp.schemas.PrinterIdentification`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| modelName | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| modelNumber | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelName;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| serialNumber | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelName;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| registrationDomain | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String modelNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String serialNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| ledmDiscoveryTreeUrl | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String serialNumber;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI") |
| associatedPrinterId | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| countryAndRegionName | CountryAndRegionName | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token")     protected String registrationDomain;     @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http: |
| deviceLanguage | String | @XmlElement(namespace = "http:     @XmlSchemaType(name = "anyURI")     protected String ledmDiscoveryTreeUrl;     @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| hardwareAddress | String | @XmlElement(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String associatedPrinterId;     @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http: |
| firmwareVersion | Version | @XmlElement(name = "CountryAndRegionName", namespace = "http:     protected CountryAndRegionName countryAndRegionName;     @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http: |
| printInfoPage | Boolean | @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http: |
| immutableID | String | @XmlElement(name = "DeviceLanguage", namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     protected String deviceLanguage;     @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http: |
| printerUUID | String | @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http: |
| registrationID | String | @XmlElement(name = "HardwareAddress", namespace = "http:     protected String hardwareAddress;     @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http: |
| cloudConfiguration | CloudConfiguration | @XmlElement(name = "FirmwareVersion", namespace = "http:     protected Version firmwareVersion;     @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http:     protected String registrationID;     @XmlElement(namespace = "http: |
| version | String | @XmlElement(namespace = "http:     protected Boolean printInfoPage = true;     @XmlElement(namespace = "http:     protected String immutableID;     @XmlElement(namespace = "http:     protected String printerUUID;     @XmlElement(namespace = "http:     protected String registrationID;     @XmlElement(namespace = "http:     protected CloudConfiguration cloudConfiguration;     @XmlAttribute(namespace = "http:     @XmlJavaTypeAdapter(CollapsedStringAdapter.class)     @XmlSchemaType(name = "token") |
| printerFwVersion | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getModelName | String |  |  |
| setModelName | void | String value |  |
| getModelNumber | String |  |  |
| setModelNumber | void | String value |  |
| getSerialNumber | String |  |  |
| setSerialNumber | void | String value |  |
| getRegistrationDomain | String |  |  |
| setRegistrationDomain | void | String value |  |
| getLedmDiscoveryTreeUrl | String |  |  |
| setLedmDiscoveryTreeUrl | void | String value |  |
| getAssociatedPrinterId | String |  |  |
| setAssociatedPrinterId | void | String value |  |
| getCountryAndRegionName | CountryAndRegionName |  |  |
| setCountryAndRegionName | void | CountryAndRegionName value |  |
| getDeviceLanguage | String |  |  |
| setDeviceLanguage | void | String value |  |
| getHardwareAddress | String |  |  |
| setHardwareAddress | void | String value |  |
| getFirmwareVersion | Version |  |  |
| setFirmwareVersion | void | Version value |  |
| isPrintInfoPage | Boolean |  |  |
| setPrintInfoPage | void | Boolean value |  |
| getImmutableID | String |  |  |
| setImmutableID | void | String value |  |
| getPrinterUUID | String |  |  |
| setPrinterUUID | void | String value |  |
| getRegistrationID | String |  |  |
| setRegistrationID | void | String value |  |
| getCloudConfiguration | CloudConfiguration |  |  |
| setCloudConfiguration | void | CloudConfiguration value |  |
| getVersion | String |  |  |
| setVersion | void | String value |  |
| getFirmwareRevision | String |  |  |

# Algorithm

All methods are standard JavaBean getters and setters except:
1. **getFirmwareRevision** - Extracts firmware revision string from firmwareVersion object; returns empty string if firmwareVersion is null, otherwise returns firmwareVersion.getRevision().

Other methods:
- Standard getters/setters for modelName, modelNumber, serialNumber, registrationDomain, ledmDiscoveryTreeUrl, associatedPrinterId, countryAndRegionName, deviceLanguage, hardwareAddress, firmwareVersion, printInfoPage, immutableID, printerUUID, registrationID, cloudConfiguration, version.

# Business context

JAXB-generated data transfer object representing comprehensive printer identification and configuration for registration. Contains hardware details (model, serial, MAC address), firmware version, localization settings (country, region, language), registration domain, LEDM URL, and cloud configuration. Used in printer registration requests to identify and configure printers.

# Business rules

• modelName, modelNumber, registrationDomain, ledmDiscoveryTreeUrl, and version are required.
• serialNumber, associatedPrinterId, countryAndRegionName, deviceLanguage, hardwareAddress, firmwareVersion, printInfoPage, immutableID, printerUUID, registrationID, and cloudConfiguration are optional.
• printInfoPage defaults to true.
• associatedPrinterId enum values: 'newIdentity' or 'reuseExistingIdentity'.
• All token fields use CollapsedStringAdapter for whitespace normalization.
• XML namespace is http://www.hp.com/schemas/imaging/con/cloud/offramp/printerregistration/2009/11/11.
