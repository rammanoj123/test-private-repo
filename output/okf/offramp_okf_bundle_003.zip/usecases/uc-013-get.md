---
type: Use Case
title: Get Printer Claim Code
description: Retrieve the claim code for a printer to enable user registration and ownership.
tags: [usecase, printer, claimcode, registration, api]
status: draft
usecase_id: UC-013
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

| Field | Value |
| --- | --- |
| Id | UC-013 |
| Trigger | GET /Printers/{PrinterID}/ClaimCode |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
