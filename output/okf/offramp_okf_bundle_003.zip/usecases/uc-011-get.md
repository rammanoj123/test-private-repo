---
type: Use Case
title: Get Print Job Output
description: Retrieve cached print job output data by cache identifier for rendering or delivery.
tags: [usecase, printjob, output, cache, api]
status: draft
usecase_id: UC-011
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

| Field | Value |
| --- | --- |
| Id | UC-011 |
| Trigger | GET /Printers/PrintJobs/Output/{CACHEID} |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
