---
type: Use Case
title: Get Scan Job Document Page
description: Retrieve a specific page of a scanned document within a scan job for upload processing.
tags: [usecase, scan, document, upload, api]
status: draft
usecase_id: UC-001
generated: { by: gpt-4o-2024-11-20, at: 2025-01-13T10:30:00Z }
---

| Field | Value |
| --- | --- |
| Id | UC-001 |
| Trigger | GET /jobs/scanjobs/{JOBID}/documents/{DOCUMENTID}/upload/{PAGE} |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
