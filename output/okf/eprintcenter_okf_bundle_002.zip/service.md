---
type: Service
title: eprintcenter
description: Spring service hp/eprintcenter; entry point for the OKF bundle.
tags: [service, root]
status: draft
artifact_id: eprintcenter
group_id: com.hp.cloudprint
okf_bundle_id: hp/eprintcenter
version: 25.1.17
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

eprintcenter — a war service.

This is the root concept of the bundle — the *you-are-here* node. It links out to the architecture, API surface, components, domain model, and the ecosystem this service participates in.

# Coordinates

| Field | Value |
| --- | --- |
| Group | com.hp.cloudprint |
| Artifact | eprintcenter |
| Version | 25.1.17 |
| Packaging | war |
| Bundle id | hp/eprintcenter |

# Map

* [Architecture & layering](/architecture/layering.md)
* [Build & test (attested)](/architecture/build-and-test.md)
* API surface — see api/
* Components — see `components/`
* Domain model — see `domain/`
* Use cases — see `usecases/`
* Configuration — see `config/`
* [Ecosystem & dependencies](/ecosystem/ecosystem.md)
* [Playbook: JIRA ticket → code](/playbooks/jira-to-code.md)

# Layer inventory

| Layer | Types |
| --- | --- |
| unknown | EventAttribute, LoggingInitializer, StratusEventInfo, ClaimStatus, CustomHttpStatus, EmailAliasRetention, EventAttribute, StratusEventInfo, Tenant, Token, URIHelper, Utility, BlackListHandler, BlackListsHandler, WhitelistHandler, JAXBObjectCreationHelper, OutEmailHelper, SortingAndPaginationHelper, OptinClientSchedulesMap, OwnerAccessProcessor, CalypsoClientImpl, StratusClientImpl, StratusHttpClient, HttpsTest, EPrintCenterResourceTest, JaxbUnmarshallTest, OwnerAccessProcessorTest, AppPlayerEventResourceTest, CDCASubscriptionResourceTest, DeviceOwnershipResourceTest, OptinInkLevelResourceTest, OptinScheduleResourceTest, OptinSuppliesInfoResourceTest, OwnershipResourceTest, OwnershipStatusResourceTest, PrinterOwnerResourceTest, PrintJobsResourceTest, SolutionOptinResourceTest, WhiteListEntryResourceTest, WhiteListResourceTest, PrinterStateReasonsEnumTest, CalypsoClientImplTest, CacheImpl, CacheImpl, CacheImpl, SecurityManagerImpl, SecurityDirectoryImpl, MBeanExporter, MetricsHolder, EmailAddressGeneratorImpl, CPGRequestProcessor, CPGSecurityProcessor, CPGLogProcessor, CPGResourceHandler, CPGResourceHandler, PUMAClientWrapper, PDSClientWrapper, CpHttpClient, PLSClientImpl, EOSClientImpl, PamClientImpl, ULSClientImpl, UserEmailAddressHelper, Client, HttpClientUtil, PumaClientTokenGenerator, SpringRouter, HashMap, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, SpringFinder, ProviderManager, BasicLookupStrategy_withFixes, NullAclCache, ChannelDecisionManagerImpl, SecureChannelProcessor, URLProcessorUtilityImpl, String |
| controller | AbstractResource, EprintCenterHealthController, AppPlayerEventResource, AvailabilityResource, CancelPrintResource, CDCASubscriptionResource, DeviceOwnershipResource, DeviceOwnershipStratusResource, EmailAddressResource, OptinInkLevelResource, OptInScheduleResource, OptinSuppliesInfoResource, OwnerShipResource, OwnerShipsResource, OwnershipStatusResource, PrinterDefaultsProcessingElementsResource, PrinterOwnerResource, PrinterResource, PrinterStatusResource, PrinterSupportedProcessingElementsResource, PrintJobsResource, SolutionOptInResource, SuggestionsResource, VersionResource, WhiteListEntryResource, WhiteListResource, EprintCenterHealthControllerTest, EmailAddressResourceTest, OwnerShipsResourceTest, PrinterResourceTest, PrinterStatusResourceTest, PrinterSupportedProcessingElementsResourceTest |
| entity | EntityConverter |
| config | EPrintCenterAPIConfig, CloudConfigurationResource, ConsumableSubscriptionConfigResource, OptInConfigResource, McsOptinConfig, CoreOAuthSignatureMethodFactory_DraftHammer, LoggingConfig, CloudConfigurationResourceTest, ConsumableSubscriptionConfigResourceTest, OptInConfigResourceTest, PAPIConfigAppConfigImpl, AppConfig, EprintUserDirectoryContextFactory, HttpClientConfig, WpPropertyPlaceholderConfigurer, EPrintDirectoryConfig |
| exception | InvalidUUIDException, ExceptionTranslationFilter, ClientConflictException, ClientErrorException, ExceptionTranslationFilterTest |
| service | ProductListingServiceHelper, OwnershipStatusService, OwnershipUserService, OwnershipStatusServiceImpl, OwnershipUserServiceImpl, WpConfigurationServiceProvider, ConsumerDetailServiceProvider, EPrintUserDetailsService, ProtectedResourceAccessTokenService, CalypsoClient, StratusClient, JobService, PrintServiceImpl, ScanServiceImpl, JdbcMutableAclService_withFixes, WpConfigurationServiceImpl |
| security | BasicAuthenticationFilter, ProtectedResourceProcessingFilter_DraftHammer, ShardPersistenceFilter, X509NullAuthenticationFilter, BasicAuthenticationFilterTest, FilterChainProxy, AuthHeaderAnalyzingFilter, AuthorizationFilter, AuthorizationFilter, AuthorizationFilter, X509AuthenticationFilter, OAuthProcessingFilterEntryPoint, SecurityContextPersistenceFilter, PUMAValidateFilter |
| repository | JEFDAOImpl, JobDAOImpl, SecurityDAOImpl |
