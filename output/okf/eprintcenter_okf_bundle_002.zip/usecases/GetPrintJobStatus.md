---
type: UseCase
description: Retrieve the status of a specific print job.
---


