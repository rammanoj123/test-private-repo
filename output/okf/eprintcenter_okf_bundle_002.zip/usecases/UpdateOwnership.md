---
type: UseCase
description: Update ownership details including nickname.
---


