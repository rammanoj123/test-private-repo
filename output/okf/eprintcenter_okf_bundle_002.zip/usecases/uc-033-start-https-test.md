---
type: Use Case
title: UC-033 — Start Https Test
description: Carries out Start Https Test triggered by main(String[] args) in HttpsTest entering at HttpsTest.main.
tags: [usecase]
status: draft
usecase_id: UC-033
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-033 |
| Trigger | main(String[] args) in HttpsTest |
| Actor | JVM / OS Process |
| Entry point | HttpsTest.main |

# Steps

| # | Call |
| --- | --- |
| 1 | HttpsTest |
