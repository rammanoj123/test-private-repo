---
type: UseCase
description: Retrieve detailed information about a specific printer including PLS metadata.
---


