---
type: UseCase
description: Retrieve printer opt-in configuration for the specified type.
---


