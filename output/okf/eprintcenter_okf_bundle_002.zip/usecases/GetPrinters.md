---
type: UseCase
description: Retrieve a list of printers with optional filtering and enhanced details.
---


