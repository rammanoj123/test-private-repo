---
type: UseCase
description: Retrieve printer default processing elements (print settings).
---


