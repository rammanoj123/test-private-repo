---
type: UseCase
description: Cancel a print job with retry logic for transient failures.
---


