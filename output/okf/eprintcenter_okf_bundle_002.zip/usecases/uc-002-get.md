---
type: Use Case
title: UC-002 — Get
description: Carries out Get triggered by GET /jobs/printjobs/{JobID}/cancel/ entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-002
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-002 |
| Trigger | GET /jobs/printjobs/{JobID}/cancel/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
