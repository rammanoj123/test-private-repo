---
type: Use Case
title: UC-032 — Get
description: Carries out Get triggered by GET /v2/devices/printers/{optinType}/schedules entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-032
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-032 |
| Trigger | GET /v2/devices/printers/{optinType}/schedules |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
