---
type: Use Case
title: UC-014 — Get
description: GET /devices/printers (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-014
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Field | Value |
| --- | --- |
| Id | UC-014 |
| Trigger | GET /devices/printers |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
