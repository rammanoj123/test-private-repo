---
type: UseCase
description: Delete a specific blacklist entry from a printer.
---


