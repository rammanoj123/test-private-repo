---
type: UseCase
description: Claim printer ownership by printer ID, claim code, or email address with Stratus eventing.
---


