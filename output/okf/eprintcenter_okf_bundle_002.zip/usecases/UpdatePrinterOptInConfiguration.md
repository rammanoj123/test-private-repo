---
type: UseCase
description: Update printer opt-in configuration for the specified type.
---


