---
type: Use Case
title: UC-023 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/optin/ entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-023
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-023 |
| Trigger | GET /devices/printers/{PrinterID}/optin/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
