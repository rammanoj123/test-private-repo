---
type: UseCase
description: Retrieve comprehensive printer status with ownership verification.
---


