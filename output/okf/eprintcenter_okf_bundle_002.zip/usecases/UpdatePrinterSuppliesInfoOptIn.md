---
type: UseCase
description: Update supplies information opt-in settings for a printer.
---


