---
type: UseCase
description: Update printer email address with Calypso validation and replication.
---


