---
type: Use Case
title: UC-031 — Get
description: Carries out Get triggered by GET /v2/devices/printers/{PrinterID}/optin/{optinType} entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-031
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-031 |
| Trigger | GET /v2/devices/printers/{PrinterID}/optin/{optinType} |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
