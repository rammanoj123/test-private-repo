---
type: UseCase
description: Retrieve all blacklist entries for a printer.
---


