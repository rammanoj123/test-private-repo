---
type: UseCase
description: Delete a printer ownership with optional email alias retention.
---


