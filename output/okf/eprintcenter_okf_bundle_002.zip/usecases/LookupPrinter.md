---
type: UseCase
description: Look up printers by claim code or email address.
---


