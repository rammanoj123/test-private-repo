---
type: UseCase
description: Retrieve owner information for a specific ownership.
---


