---
type: UseCase
description: Register CDCA subscription opt-in for a printer with schedule selection.
---


