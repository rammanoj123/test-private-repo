---
type: UseCase
description: Update printer consumable subscription configuration for ink/toner service advertising.
---


