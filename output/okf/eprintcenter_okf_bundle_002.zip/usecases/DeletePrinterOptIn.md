---
type: UseCase
description: Delete a printer's opt-in configuration for the specified type.
---


