---
type: Use Case
title: UC-021 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/appplayer/event/ entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-021
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-021 |
| Trigger | GET /devices/printers/{PrinterID}/appplayer/event/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
