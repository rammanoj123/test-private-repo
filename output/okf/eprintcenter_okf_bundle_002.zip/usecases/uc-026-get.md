---
type: Use Case
title: UC-026 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/optin/cDCA entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-026
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-026 |
| Trigger | GET /devices/printers/{PrinterID}/optin/cDCA |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
