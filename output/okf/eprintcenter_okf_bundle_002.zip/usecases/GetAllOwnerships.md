---
type: UseCase
description: Retrieve all ownerships for the authenticated user with optional favorites.
---


