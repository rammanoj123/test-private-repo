---
type: UseCase
description: Add a new whitelist entry to a printer.
---


