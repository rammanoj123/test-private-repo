---
type: UseCase
description: Delete a specific whitelist entry from a printer.
---


