---
type: UseCase
description: Update ink level metrics collection opt-in settings.
---


