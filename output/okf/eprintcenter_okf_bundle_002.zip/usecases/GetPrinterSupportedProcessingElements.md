---
type: UseCase
description: Retrieve printer supported processing elements including capabilities and media options.
---


