---
type: UseCase
description: Retrieve detailed information about a specific print job.
---


