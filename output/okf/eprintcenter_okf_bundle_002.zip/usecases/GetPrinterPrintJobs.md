---
type: UseCase
description: Retrieve paginated print job history for a printer.
---


