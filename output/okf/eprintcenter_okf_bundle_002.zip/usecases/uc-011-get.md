---
type: Use Case
title: UC-011 — Get
description: GET /ownerships/{OwnershipID}/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-011
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Field | Value |
| --- | --- |
| Id | UC-011 |
| Trigger | GET /ownerships/{OwnershipID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
