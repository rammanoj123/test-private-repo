---
type: Use Case
title: UC-011 — Get
description: Carries out Get triggered by GET /ownerships/{OwnershipID}/ entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-011
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-011 |
| Trigger | GET /ownerships/{OwnershipID}/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
