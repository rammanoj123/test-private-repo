---
type: UseCase
description: Retrieve all whitelist entries for a printer.
---


