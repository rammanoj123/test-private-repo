---
type: UseCase
description: Retrieve a specific blacklist entry for a printer.
---


