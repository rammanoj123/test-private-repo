---
type: UseCase
description: Retrieve the printer's email address configuration.
---


