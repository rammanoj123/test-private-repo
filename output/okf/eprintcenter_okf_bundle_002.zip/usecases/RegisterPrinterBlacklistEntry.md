---
type: UseCase
description: Add a new blacklist entry to a printer.
---


