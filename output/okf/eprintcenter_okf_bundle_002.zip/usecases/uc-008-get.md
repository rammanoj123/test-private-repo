---
type: Use Case
title: UC-008 — Get
description: Carries out Get triggered by GET /ownerships entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-008
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-008 |
| Trigger | GET /ownerships |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
