---
type: Use Case
title: UC-015 — Get
description: Carries out Get triggered by GET /devices/printers/{PrinterID}/status/ entering at SpringFinder.represent.
tags: [usecase]
status: draft
usecase_id: UC-015
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Field | Value |
| --- | --- |
| Id | UC-015 |
| Trigger | GET /devices/printers/{PrinterID}/status/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
