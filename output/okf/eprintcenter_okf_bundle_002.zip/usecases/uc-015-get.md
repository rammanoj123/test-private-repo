---
type: Use Case
title: UC-015 — Get
description: GET /devices/printers/{PrinterID}/status/ (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-015
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Field | Value |
| --- | --- |
| Id | UC-015 |
| Trigger | GET /devices/printers/{PrinterID}/status/ |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
