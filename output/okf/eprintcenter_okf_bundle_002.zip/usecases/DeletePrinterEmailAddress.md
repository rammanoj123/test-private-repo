---
type: UseCase
description: Delete the printer's email address configuration.
---


