---
type: Use Case
title: UC-007 — Get
description: GET /ownerships/status (pending enrichment).
tags: [usecase]
status: draft
usecase_id: UC-007
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Field | Value |
| --- | --- |
| Id | UC-007 |
| Trigger | GET /ownerships/status |
| Actor | API Client |
| Entry point | SpringFinder.represent |

# Steps

| # | Call |
| --- | --- |
| 1 | SpringFinder |
