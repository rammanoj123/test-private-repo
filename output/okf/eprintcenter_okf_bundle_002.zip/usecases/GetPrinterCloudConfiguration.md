---
type: UseCase
description: Retrieve printer cloud configuration including email, mobile apps, SIPs, and protection mode.
---


