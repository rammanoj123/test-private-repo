---
type: UseCase
description: Update printer details including nickname and favorite status.
---


