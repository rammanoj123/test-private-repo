---
type: Config
description: Defines application configuration properties for database connections, external services, and feature flags.
---


