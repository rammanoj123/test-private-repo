---
type: Config
description: Defines Maven project dependencies, plugins, and build configuration for the ePrint Center API.
---


