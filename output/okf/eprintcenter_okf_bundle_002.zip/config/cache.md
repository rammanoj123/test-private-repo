---
type: Configuration
title: Cache
description: Cache configuration (pending enrichment).
tags: [config, cache]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Key | Value |
| --- | --- |
| type | None |
| redis_host | None |
