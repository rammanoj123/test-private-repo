---
type: Configuration
title: Cache
description: Configures cache through type, redis_host.
tags: [config, cache]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Key | Value |
| --- | --- |
| type | None |
| redis_host | None |
