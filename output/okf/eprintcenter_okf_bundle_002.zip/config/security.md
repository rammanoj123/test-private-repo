---
type: Configuration
title: Security
description: Configures security through jwt_present, oauth2_providers, ldap_url.
tags: [config, security]
status: draft
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Key | Value |
| --- | --- |
| jwt_present | False |
| oauth2_providers | [] |
| ldap_url | None |
