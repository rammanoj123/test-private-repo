---
type: Internal Library
title: wpp-base-schema
description: Internal library wpp-base-schema.
tags: [dependency, internal, library]
status: draft
artifact_id: wpp-base-schema
depends_on_bundle: hp/wpp-base-schema
group_id: com.hp.iws.wpp
scope: compile
version: ${wpp-version}
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `com.hp.iws.wpp:wpp-base-schema:${wpp-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wpp-base-schema`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
