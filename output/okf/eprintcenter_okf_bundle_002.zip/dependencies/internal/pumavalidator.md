---
type: Internal Library
title: pumavalidator
description: Custom/org library `com.hp.cloudprint:pumavalidator:25.3.4.2` (pending enrichment).
tags: [dependency, internal, library]
status: draft
artifact_id: pumavalidator
depends_on_bundle: hp/pumavalidator
group_id: com.hp.cloudprint
scope: compile
version: 25.3.4.2
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

Maven coordinate: `com.hp.cloudprint:pumavalidator:25.3.4.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/pumavalidator`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
