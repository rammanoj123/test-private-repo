---
type: Internal Library
title: wpp-json-logging-adaptor
description: Internal library wpp-json-logging-adaptor.
tags: [dependency, internal, library]
status: draft
artifact_id: wpp-json-logging-adaptor
depends_on_bundle: hp/wpp-json-logging-adaptor
group_id: com.hp.wpp
scope: compile
version: 1.0.13
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `com.hp.wpp:wpp-json-logging-adaptor:1.0.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/wpp-json-logging-adaptor`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
