---
type: Internal Library
title: printerlist-schema
description: Internal library printerlist-schema.
tags: [dependency, internal, library]
status: draft
artifact_id: printerlist-schema
depends_on_bundle: hp/printerlist-schema
group_id: com.hp.ipg.iws.wp
scope: compile
version: ${ukas-wp-version}
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `com.hp.ipg.iws.wp:printerlist-schema:${ukas-wp-version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

This is a custom library owned inside the organization. Its own OKF bundle is expected at bundle id `hp/printerlist-schema`. Once that bundle is published, set this concept's `okf_ref` to its canonical location so consumers can traverse into it. See [the ecosystem registry](/ecosystem/ecosystem.md).
