---
type: Dependency
title: cglib:cglib-nodep
description: Third-party library cglib:cglib-nodep at 3.3.0 on the compile classpath.
resource: https://central.sonatype.com/artifact/cglib/cglib-nodep
tags: [dependency, external]
status: draft
artifact_id: cglib-nodep
group_id: cglib
scope: compile
version: 3.3.0
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `cglib:cglib-nodep:3.3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
