---
type: Dependency
title: org.springframework:spring-aspects
description: Third-party library org.springframework:spring-aspects at ${spring.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework/spring-aspects
tags: [dependency, external]
status: draft
artifact_id: spring-aspects
group_id: org.springframework
scope: compile
version: ${spring.version}
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.springframework:spring-aspects:${spring.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
