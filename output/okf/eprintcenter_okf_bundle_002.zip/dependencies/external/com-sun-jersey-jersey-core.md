---
type: Dependency
title: com.sun.jersey:jersey-core
description: Third-party library com.sun.jersey:jersey-core at 1.10 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.sun.jersey/jersey-core
tags: [dependency, external]
status: draft
artifact_id: jersey-core
group_id: com.sun.jersey
scope: compile
version: "1.10"
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `com.sun.jersey:jersey-core:1.10`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
