---
type: Dependency
title: org.springframework.security.oauth:spring-security-oauth
description: Third-party library org.springframework.security.oauth:spring-security-oauth at ${spring-security-oauth.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework.security.oauth/spring-security-oauth
tags: [dependency, external]
status: draft
artifact_id: spring-security-oauth
group_id: org.springframework.security.oauth
scope: compile
version: ${spring-security-oauth.version}
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.springframework.security.oauth:spring-security-oauth:${spring-security-oauth.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
