---
type: Dependency
title: org.codehaus.jackson:jackson-mapper-asl
description: Third-party library org.codehaus.jackson:jackson-mapper-asl at 1.9.13 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.codehaus.jackson/jackson-mapper-asl
tags: [dependency, external]
status: draft
artifact_id: jackson-mapper-asl
group_id: org.codehaus.jackson
scope: compile
version: 1.9.13
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.codehaus.jackson:jackson-mapper-asl:1.9.13`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
