---
type: Dependency
title: org.apache.commons:commons-lang3
description: Third-party library org.apache.commons:commons-lang3 at 3.14.0 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.apache.commons/commons-lang3
tags: [dependency, external]
status: draft
artifact_id: commons-lang3
group_id: org.apache.commons
scope: compile
version: 3.14.0
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.apache.commons:commons-lang3:3.14.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
