---
type: Dependency
title: com.fasterxml.jackson.core:jackson-core
description: Third-party library com.fasterxml.jackson.core:jackson-core at 2.15.2 on the compile classpath.
resource: https://central.sonatype.com/artifact/com.fasterxml.jackson.core/jackson-core
tags: [dependency, external]
status: draft
artifact_id: jackson-core
group_id: com.fasterxml.jackson.core
scope: compile
version: 2.15.2
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `com.fasterxml.jackson.core:jackson-core:2.15.2`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
