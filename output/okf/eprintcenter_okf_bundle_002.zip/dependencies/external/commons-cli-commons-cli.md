---
type: Dependency
title: commons-cli:commons-cli
description: Third-party library commons-cli:commons-cli at 1.6.0 on the compile classpath.
resource: https://central.sonatype.com/artifact/commons-cli/commons-cli
tags: [dependency, external]
status: draft
artifact_id: commons-cli
group_id: commons-cli
scope: compile
version: 1.6.0
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `commons-cli:commons-cli:1.6.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
