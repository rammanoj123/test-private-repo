---
type: Dependency
title: com.mchange:c3p0
description: Third-party dependency `com.mchange:c3p0:0.9.5.5` (pending enrichment).
resource: https://central.sonatype.com/artifact/com.mchange/c3p0
tags: [dependency, external]
status: draft
artifact_id: c3p0
group_id: com.mchange
scope: compile
version: 0.9.5.5
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

Maven coordinate: `com.mchange:c3p0:0.9.5.5`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
