---
type: Dependency
title: mysql:mysql-connector-java
description: Third-party dependency `mysql:mysql-connector-java:8.0.11` (pending enrichment).
resource: https://central.sonatype.com/artifact/mysql/mysql-connector-java
tags: [dependency, external]
status: draft
artifact_id: mysql-connector-java
group_id: mysql
scope: compile
version: 8.0.11
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

Maven coordinate: `mysql:mysql-connector-java:8.0.11`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
