---
type: Dependency
title: org.springframework:spring-jdbc
description: Third-party library org.springframework:spring-jdbc at ${spring.version} on the compile classpath.
resource: https://central.sonatype.com/artifact/org.springframework/spring-jdbc
tags: [dependency, external]
status: draft
artifact_id: spring-jdbc
group_id: org.springframework
scope: compile
version: ${spring.version}
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.springframework:spring-jdbc:${spring.version}`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
