---
type: Dependency
title: org.mockito:mockito-core
description: Third-party library org.mockito:mockito-core at 5.8.0 on the test classpath.
resource: https://central.sonatype.com/artifact/org.mockito/mockito-core
tags: [dependency, external]
status: draft
artifact_id: mockito-core
group_id: org.mockito
scope: test
version: 5.8.0
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.mockito:mockito-core:5.8.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
