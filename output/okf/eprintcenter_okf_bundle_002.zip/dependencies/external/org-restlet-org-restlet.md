---
type: Dependency
title: org.restlet:org.restlet
description: Third-party library org.restlet:org.restlet at 1.1.6 on the compile classpath.
resource: https://central.sonatype.com/artifact/org.restlet/org.restlet
tags: [dependency, external]
status: draft
artifact_id: org.restlet
group_id: org.restlet
scope: compile
version: 1.1.6
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `org.restlet:org.restlet:1.1.6`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
