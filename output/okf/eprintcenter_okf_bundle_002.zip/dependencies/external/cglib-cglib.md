---
type: Dependency
title: cglib:cglib
description: Third-party library cglib:cglib at 3.3.0 on the provided classpath.
resource: https://central.sonatype.com/artifact/cglib/cglib
tags: [dependency, external]
status: draft
artifact_id: cglib
group_id: cglib
scope: provided
version: 3.3.0
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

Maven coordinate: `cglib:cglib:3.3.0`.

# Used by

_Enrichment agent: list the components in this bundle that import this dependency, linking each._

# Ecosystem link

Third-party library. If the organization maintains an OKF bundle describing how it is used across services, set `okf_ref` to it.
