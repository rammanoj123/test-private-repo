---
type: Component
description: Implements OAuth signature method factory for draft Hammer specification.
---


