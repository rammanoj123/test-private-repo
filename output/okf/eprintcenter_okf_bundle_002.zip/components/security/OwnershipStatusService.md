---
type: Component
description: Retrieves printer ownership status for claim validation.
---


