---
type: Component
title: Protected Resource Processing Filter Draft Hammer
description: Custom OAuth protected resource processing filter that validates OAuth parameters, extracts consumer details, and logs originator ID for authenticated requests.
tags: [component, security]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceProcessingFilter_DraftHammer.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ProtectedResourceProcessingFilter_DraftHammer.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/ProtectedResourceProcessingFilter_DraftHammer.java, title: ProtectedResourceProcessingFilter_DraftHammer.java }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceProcessingFilter_DraftHammer`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| signatureMethod | String | @Override |
| signature | String | @Override |
| token | String |  |
| clientId | String | @Override |
| authentication | ConsumerAuthentication | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| validateOAuthParams | void | ConsumerDetails consumerDetails, Map<String, String> oauthParams |  |
| onValidSignature | void | HttpServletRequest request, HttpServletResponse response, FilterChain chain |  |
| fail | void | HttpServletRequest request, HttpServletResponse response, AuthenticationException failure |  |

# Business context

ProtectedResourceProcessingFilter_DraftHammer extends Spring Security OAuth's ProtectedResourceProcessingFilter to validate OAuth parameters and extract consumer identity for access logging. It ensures required OAuth parameters are present and logs the originator ID (hashed consumer key) for audit trails.

# Algorithm

**validateOAuthParams(consumerDetails, oauthParams)**
1. Get oauth_signature_method from params
2. If missing, throw InvalidOAuthParametersException
3. Get oauth_signature from params
4. If missing, throw InvalidOAuthParametersException
5. Get oauth_token from params
6. If missing, throw InvalidOAuthParametersException

**onValidSignature(request, response, chain)**
1. Get ConsumerAuthentication from SecurityContextHolder
2. If authentication exists:
   - Compute hash of consumer key as clientId using Utility.getHash
   - Log originator ID
   - Set clientId as request attribute with key LOG_ORIGINATOR_ID for access logging
3. Call super.onValidSignature() to continue processing
4. Catch and log any exceptions during ID extraction (don't fail the request)

**fail(request, response, failure)**
1. Delegate to authentication entry point to commence authentication
2. Entry point handles OAuth authentication failure response

# Business rules

- oauth_signature_method, oauth_signature, and oauth_token are required parameters
- Missing required OAuth parameters throw InvalidOAuthParametersException
- Originator ID is computed as hash of consumer key for privacy
- Originator ID is stored in request attribute for access logging
- Exceptions during ID extraction are logged but don't fail the request
- Authentication failures are delegated to configured authentication entry point

# Depends on

- Spring Security OAuth `ProtectedResourceProcessingFilter` (extends)
- `ConsumerAuthentication` for OAuth consumer details
- [Utility](/components/misc/Utility.md) for hash computation
- `SecurityContextHolder` for authentication context
