---
type: Component
description: Provides OAuth consumer details for Spring Security authentication.
---


