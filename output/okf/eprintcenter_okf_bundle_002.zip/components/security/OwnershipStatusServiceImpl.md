---
type: Component
description: Implements ownership status retrieval checking if printer is claimed, claimed by another user, or unclaimed.
---


