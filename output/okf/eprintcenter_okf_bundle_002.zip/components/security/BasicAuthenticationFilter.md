---
type: Component
title: Basic Authentication Filter
description: Servlet filter that validates HTTP Basic Authentication credentials by decoding the Authorization header and verifying client ID and secret against the security directory.
tags: [component, security]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\BasicAuthenticationFilter.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: BasicAuthenticationFilter.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/BasicAuthenticationFilter.java, title: BasicAuthenticationFilter.java }
---

`com.hp.cloudprint.api.eprintcenter.security.BasicAuthenticationFilter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| authorizationHeader | String |  |
| headerValueType | String |  |
| securityDirectory | SecurityDirectory |  |
| wpConfigurationService | WpConfigurationService |  |
| request | HttpServletRequest | @Override |
| response | HttpServletResponse | @Override |
| headerValue | String | @Override |
| base64Token | byte[] |  |
| decodedBasicToken | String |  |
| token | Token |  |
| characterEncoding | String |  |
| isTokenValid | boolean |  |
| clientAuthDetails | ClientAuthDetails |  |
| isWellFormedToken | boolean |  |
| clientAuthDetails | ClientAuthDetails |  |
| clientID | String |  |
| clientSecret | String |  |
| decodedTokens | String[] |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| BasicAuthenticationFilter |  |  |  |
| doFilter | void | ServletRequest req, ServletResponse res, FilterChain chain |  |
| getCharacterEncoding | String | HttpServletRequest request |  |
| isBasicValidationAllowed | boolean |  |  |
| validateToken | boolean | Token token |  |
| getToken | Token | String decodedBasicToken |  |
| isWellFormedToken | boolean | Token token |  |
| getClientAuthDetails | ClientAuthDetails | Token token |  |
| setUnAuthResponse | void | HttpServletResponse response |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getClientID | String |  |  |
| setClientID | void | String clientID |  |
| getClientSecret | String |  |  |
| setClientSecret | void | String clientSecret |  |


# Depends on

- `SecurityDirectory` for client authentication details lookup
- `WpConfigurationService` for isBasicValidationAllowed configuration

# Business context

BasicAuthenticationFilter validates HTTP Basic Authentication credentials for API clients by decoding the Authorization header and verifying client ID and secret against the security directory. It supports configuration-based validation bypass for testing scenarios.

# Algorithm

**doFilter(request, response, chain)**
1. Cast request and response to HTTP types
2. Get Authorization header value
3. If header is not blank and starts with 'Basic':
   - Extract base64 token after 'Basic' prefix
   - Get character encoding from request (default UTF-8)
   - Decode base64 token to get 'clientID:clientSecret' string
   - Parse token into Token object
   - Check if token is well-formed (both clientID and clientSecret present)
   - If not well-formed, return HTTP 401 Unauthorized
   - Validate token against security directory
   - If validation fails and isBasicValidationAllowed is true, return HTTP 401
4. Continue filter chain

**validateToken(token)**
1. Check if clientID and clientSecret are both not blank
2. Get ClientAuthDetails from security directory by clientID
3. If details found and client secret matches (case-insensitive), return true
4. Otherwise return false

**getToken(decodedBasicToken)**
1. Create new Token object from decoded basic token string
2. Token constructor parses 'clientID:clientSecret' format
3. Return Token

**isWellFormedToken(token)**
1. Check if clientID or clientSecret is blank
2. Return false if either is blank, true otherwise

**getCharacterEncoding(request)**
1. Get character encoding from request
2. If blank, default to 'UTF-8'
3. Return encoding

**setUnAuthResponse(response)**
1. Add WWW-Authenticate header with headerValueType
2. Add WWW-Authenticate header with 'Basic realm=http://eprint.hp.com'
3. Set response status to 401 Unauthorized

# Business rules

- Authorization header must use 'Basic' scheme
- Token must be base64 encoded
- Token format: 'clientID:clientSecret' separated by colon
- Client secret comparison is case-insensitive
- Character encoding defaults to UTF-8 if not specified in request
- Validation can be bypassed if isBasicValidationAllowed config is false
- Returns HTTP 401 with WWW-Authenticate headers on authentication failure
- Returns null from getClientAuthDetails on any exception (logged but not propagated)
