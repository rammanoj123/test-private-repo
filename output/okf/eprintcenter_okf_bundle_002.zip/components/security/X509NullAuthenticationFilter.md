---
type: Component
title: X509NullAuthenticationFilter
description: Validates X.509 client certificates from servlet request for certificate-based authentication.
tags: [component, security]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\X509NullAuthenticationFilter.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.security.X509NullAuthenticationFilter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| req | HttpServletRequest | @Override |
| res | HttpServletResponse | @Override |
| certs | X509Certificate[] | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |
