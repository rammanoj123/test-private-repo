---
type: Component
title: X509 Null Authentication Filter
description: Servlet filter that validates the presence of X.509 client certificates in HTTPS requests, returning HTTP 401 if certificate is not available.
tags: [component, security]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\X509NullAuthenticationFilter.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: X509NullAuthenticationFilter.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/X509NullAuthenticationFilter.java, title: X509NullAuthenticationFilter.java }
---

`com.hp.cloudprint.api.eprintcenter.security.X509NullAuthenticationFilter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| req | HttpServletRequest | @Override |
| res | HttpServletResponse | @Override |
| certs | X509Certificate[] | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |

# Business context

X509NullAuthenticationFilter validates the presence of X.509 client certificates in HTTPS requests, ensuring mutual TLS authentication is properly configured. It acts as a security gate, rejecting requests without valid client certificates.

# Algorithm

**doFilter(request, response, chain)**
1. Cast request and response to HTTP types
2. Get X509Certificate array from request attribute 'javax.servlet.request.X509Certificate'
3. If certs is null:
   - Set response status to HTTP 401 Unauthorized
   - Set status message to 'EPC_CLIENT_CERT_NOT_AVAILABLE'
   - Return (do not continue chain)
4. Else continue filter chain

# Business rules

- X.509 certificate must be present in request attributes
- Certificate is retrieved from standard servlet attribute 'javax.servlet.request.X509Certificate'
- Returns HTTP 401 SC_UNAUTHORIZED if certificate not available
- Error message: EPC_CLIENT_CERT_NOT_AVAILABLE
- Filter chain only continues if certificate is present

# Depends on

This filter has no injected dependencies. It validates the presence of X.509 certificates in the servlet request.
