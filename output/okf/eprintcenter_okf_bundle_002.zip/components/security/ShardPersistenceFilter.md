---
type: Component
title: Shard Persistence Filter
description: Servlet filter that extracts and persists shard code information from requests for database sharding, supporting both printer-based and ownership-based shard resolution.
tags: [component, security]
status: stable
component_type: Security
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ShardPersistenceFilter.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ShardPersistenceFilter.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/ShardPersistenceFilter.java, title: ShardPersistenceFilter.java }
---

`com.hp.cloudprint.api.eprintcenter.security.ShardPersistenceFilter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| urlProcessorUtility | URLProcessorUtility | @Resource |
| printerManager | PrinterManager | @Resource |
| request | HttpServletRequest | @Resource |
| response | HttpServletResponse | @Resource |
| requestURL | String | @Resource |
| shardCode | String | @Resource |
| printerID | String |  |
| ownerID | String |  |
| shardCode | String |  |
| lisOfShardsForTheGivenUser | List |  |
| ownerList | List |  |
| printer | Printer |  |
| uri | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain |  |
| getShardCode | String | HttpServletRequest request, HttpServletResponse response, String requestURL |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| getActivePrinter | Printer | String printerID |  |
| buildRequestUrl | String | String servletPath, String requestURI, String contextPath, String pathInfo, String queryString |  |
| setUrlProcessorUtility | void | URLProcessorUtility urlProcessorUtility |  |
| setPrinterManager | void | PrinterManager printerManager |  |
| init | void | FilterConfig filterConfig |  |
| destroy | void |  |  |


# Depends on

- `URLProcessorUtility` for extracting printer ID and owner ID from URLs
- `PrinterManager` for retrieving printer entities
- `EprintUserDirectory` for printer owner shard map access
- `EprintShardHolder` for shard context management

# Business context

ShardPersistenceFilter extracts and persists shard code information from requests to support database sharding. It resolves shards based on printer ID for printer-related requests or owner ID for ownership requests, storing the shard code in request attributes for access logging and downstream processing.

# Algorithm

**doFilter(servletRequest, servletResponse, filterChain)**
1. Cast request and response to HTTP types
2. Wrap request in BufferedRequestWrapper if not already wrapped
3. Build request URL from servlet path, request URI, context path, path info, and query string
4. Get shard code via getShardCode()
5. If shard code is not null/empty, set it as request attribute with key LogEntry.SHARD_CODE for access logging
6. Continue filter chain

**getShardCode(request, response, requestURL)**
1. If requestURL starts with '/devices/printers/':
   - Extract printerID using urlProcessorUtility.getPrinterId()
   - If printerID found, call getActivePrinter() which sets shard in EprintShardHolder
   - Get shard code from EprintShardHolder.getShard()
2. Else if requestURL starts with '/ownerships' and method is GET:
   - Extract ownerID using urlProcessorUtility.getOwnerId()
   - If ownerID found, get shards from printer owner shard map via getEprintUserDirectory().getShardsFromPrinterOwnerShardMap()
   - Return first shard from list
3. Return shard code or empty string on exception

**getActivePrinter(printerID)**
1. Call printerManager.getActivePrinterByPrinterID with printerID
2. This call also sets shard in EprintShardHolder as side effect
3. Return printer entity

**buildRequestUrl(servletPath, requestURI, contextPath, pathInfo, queryString)**
1. Use servletPath as uri if not null, else extract from requestURI by removing contextPath
2. Append pathInfo if not null
3. Append query string with '?' prefix if not null
4. Return constructed URL

# Business rules

- Request is wrapped in BufferedRequestWrapper for buffering
- Shard code is persisted in request attribute with key LogEntry.SHARD_CODE
- Printer-based requests use EprintShardHolder for shard resolution (set as side effect of getActivePrinter)
- Ownership GET requests use printer owner shard map for resolution
- Only GET method supported for ownership shard resolution
- Exceptions during shard extraction return empty string (best-effort)
- Servlet path takes precedence over request URI for URL construction
- Path info and query string are optional in URL construction
