---
type: Component
description: Base exception class for ePrint Center API errors.
---


