---
type: Component
title: ClientErrorException
description: Exception thrown when an HTTP client encounters a 4xx client error response (excluding 409 CONFLICT), indicating invalid requests, authentication failures, or resource not found errors.
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\http\clients\ClientErrorException.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.http.clients.ClientErrorException`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ClientErrorException |  | Throwable throwable |  |

# Algorithm

**Constructor**: Accepts a Throwable cause parameter → Passes cause to parent exception constructor → Preserves original exception stack trace and message.

# Business context

ClientErrorException is thrown by HTTP client components when they receive 4xx client error status codes (excluding 409 CONFLICT which has its own exception) from remote services. This includes errors such as 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, and other client-side errors. The exception wraps the underlying cause to preserve the full error context for debugging and error handling.

# Business rules

1. **HTTP status mapping**: Represents HTTP 4xx client error responses from remote services (excluding 409 CONFLICT).
2. **Cause preservation**: Always wraps the underlying Throwable cause to preserve stack trace and error context.
3. **Use cases**: Invalid request parameters (400), authentication failures (401), authorization failures (403), resource not found (404), unsupported media type (415), and other client errors.
4. **Error handling**: Calling code should catch this exception to handle client error scenarios appropriately (e.g., validate input, re-authenticate, check permissions, handle missing resources).
5. **Distinction from ClientConflictException**: 409 CONFLICT errors are handled separately by ClientConflictException for more specific conflict handling.

# Depends on

Throwable (parent exception class).
