---
type: Component
description: Signals invalid request data submitted to the API.
---


