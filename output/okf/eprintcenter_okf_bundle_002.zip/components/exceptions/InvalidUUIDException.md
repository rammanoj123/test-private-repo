---
type: Component
title: Invalid UUID Exception
description: Custom exception thrown when an invalid UUID is encountered for a device or resource.
tags: [component, exception]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: InvalidUUIDException.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/InvalidUUIDException.java, title: InvalidUUIDException.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |

# Algorithm

**InvalidUUIDException()**
1. Call this(null, null, null, null) to delegate to full constructor

**InvalidUUIDException(String uuidParm)**
1. Call super with CPGStatusCode.DEVICE_NOT_FOUND, UserMessage.INVALID_REQUEST_WITH_MSG, and uuidParm
2. Store uuidParm in uuid field

**InvalidUUIDException(String uuidParm, CPGStatusCode statusCode, Status httpStatus, UserMessage message)**
1. Call super with statusCode, message, uuidParm array, and null cause
2. Store uuidParm in uuid field

**getUUID()**
1. Return uuid field

# Business context

Custom exception thrown when an invalid UUID is encountered for a device or resource. Extends EntityNotFoundException with UUID-specific context and defaults to DEVICE_NOT_FOUND status.

# Business rules

- If Default status code is DEVICE_NOT_FOUND.
- If Default message is INVALID_REQUEST_WITH_MSG.
- If Stores the invalid UUID value for diagnostic purposes.

# Depends on
