---
type: Component
title: InvalidUUIDException
description: Exception `InvalidUUIDException`. (Description pending enrichment.)
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |
