---
type: Component
title: InvalidUUIDException
description: Custom exception thrown when an invalid UUID is encountered for a device or resource.
tags: [component, exception]
status: draft
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\InvalidUUIDException.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.InvalidUUIDException`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| uuid | String | @Serial |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| InvalidUUIDException |  |  |  |
| getUUID | String |  |  |
