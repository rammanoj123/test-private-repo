---
type: Component
title: Exception Translation Filter
description: Intercepts authentication exceptions and translates missing client certificate scenarios to HTTP 401 responses.
tags: [component, exception]
status: stable
component_type: Exception
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ExceptionTranslationFilter.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T12:00:00Z }
sources:
  - { id: ExceptionTranslationFilter.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/ExceptionTranslationFilter.java, title: ExceptionTranslationFilter.java }
---

`com.hp.cloudprint.api.eprintcenter.security.ExceptionTranslationFilter`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| res | HttpServletResponse | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| doFilter | void | ServletRequest request, ServletResponse response, FilterChain chain |  |

# Algorithm

**doFilter**
1. Cast ServletResponse to HttpServletResponse
2. Invoke chain.doFilter(request, response) to continue filter chain
3. Catch UsernameNotFoundException
4. Set HTTP response status to 401 UNAUTHORIZED with message EPC_CLIENT_CERT_NOT_AVAILABLE
5. Allow other exceptions to propagate

# Business context

Security filter that intercepts authentication exceptions during request processing and translates them to appropriate HTTP responses. Specifically handles missing client certificate scenarios.

# Business rules

- If UsernameNotFoundException is caught, return HTTP 401 UNAUTHORIZED with message 'EPC_CLIENT_CERT_NOT_AVAILABLE'.
- If All other exceptions propagate unchanged.

# Depends on
