---
type: Component
description: Indicates operation should be retried due to transient failure.
---


