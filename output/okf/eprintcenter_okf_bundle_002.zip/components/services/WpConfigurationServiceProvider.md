---
type: Component
title: Wp Configuration Service Provider
description: Singleton provider for WpConfigurationService that loads configuration from Spring context.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\WpConfigurationServiceProvider.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: WpConfigurationServiceProvider.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/healthcheck/WpConfigurationServiceProvider.java, title: WpConfigurationServiceProvider.java }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |

# Algorithm

**getInstance()**
1. Return the wpConfigurationServiceProvider static instance
2. Singleton pattern ensures only one instance exists

**getWpConfigurationService()**
1. Get wpConfigurationService bean from applicationContext
2. Return WpConfigurationService

**Constructor (private)**
1. Initialize Spring application context with wpConfigService configuration file
2. Load ClassPathXmlApplicationContext with 'applicationContext-wpConfigService.xml'

# Business context

WpConfigurationServiceProvider is a singleton that provides access to WpConfigurationService by loading it from Spring application context. It initializes the Spring context with wpConfigService configuration on construction and provides thread-safe singleton access.

# Business rules

- Only one instance exists (singleton pattern)
- Application context is initialized in constructor with 'applicationContext-wpConfigService.xml'
- WpConfigurationService bean is retrieved from Spring context on demand
- Thread-safe singleton access via static instance

# Depends on

- Spring `ClassPathXmlApplicationContext` for configuration loading
- `WpConfigurationService` bean from Spring context
