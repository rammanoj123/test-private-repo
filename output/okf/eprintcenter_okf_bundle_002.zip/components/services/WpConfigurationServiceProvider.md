---
type: Component
title: WpConfigurationServiceProvider
description: Singleton provider for WpConfigurationService that loads configuration from Spring context.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\WpConfigurationServiceProvider.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.WpConfigurationServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| wpConfigurationServiceProvider | WpConfigurationServiceProvider |  |
| applicationContext | ClassPathXmlApplicationContext |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| WpConfigurationServiceProvider |  |  |  |
| getInstance | WpConfigurationServiceProvider |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
