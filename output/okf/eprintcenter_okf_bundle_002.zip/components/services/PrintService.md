---
type: Component
description: Manages print job operations and history retrieval.
---


