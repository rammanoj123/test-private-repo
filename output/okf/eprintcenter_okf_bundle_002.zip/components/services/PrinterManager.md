---
type: Component
description: Manages printer CRUD operations, whitelist/blacklist entries, and device capabilities.
---


