---
type: Component
title: Calypso Client
description: Interface for Calypso email address management client that provides operations to add, update, delete, and check expiry status of email addresses.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CalypsoClient.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/http/clients/CalypsoClient.java, title: CalypsoClient.java }
---

`com.hp.cloudprint.http.clients.CalypsoClient`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |

# Business context

CalypsoClient defines the contract for managing email addresses in the Calypso system, which handles email address lifecycle including creation, expiry management, and deletion. This is used for printer email address management and retention policies.

# Algorithm

**addEmailAddress(emailAddress)**
- Interface method - implementation adds email address to Calypso system

**patchEmailAddress(emailAddress, expiryInMills)**
- Interface method - implementation updates email address with expiry time in milliseconds

**deleteEmailAddress(emailAddress)**
- Interface method - implementation deletes email address from Calypso system

**isMarkedForExpiry(emailAddress)**
- Interface method - implementation checks if email address is marked for expiry and returns boolean result

# Business rules

- All operations throw CpInternalContingencyException on failure
- Expiry time is specified in milliseconds
- Email addresses can be marked for expiry and checked for expiry status
- Supports full lifecycle: add, update (patch with expiry), delete, and status check

# Depends on

This is an interface. Implementations will depend on HTTP client infrastructure and Calypso service endpoints.
