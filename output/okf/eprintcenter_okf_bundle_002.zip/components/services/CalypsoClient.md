---
type: Component
title: CalypsoClient
description: Interface for Calypso email address management client that provides operations to add, update, delete, and check expiry status of email addresses.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClient.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.http.clients.CalypsoClient`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
