---
type: Component
title: E Print User Details Service
description: Spring Security UserDetailsService implementation that loads ePrint user details from the security manager for authentication purposes.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\EPrintUserDetailsService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EPrintUserDetailsService.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/EPrintUserDetailsService.java, title: EPrintUserDetailsService.java }
---

`com.hp.cloudprint.api.eprintcenter.security.EPrintUserDetailsService`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| messages | MessageSourceAccessor |  |
| securityManager | SecurityManager |  |
| eprintUser | EPrintUser | @Override |
| grantedAuthoritiesList | List | @Override |
| user | User |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadUserByUsername | UserDetails | String userName |  |

# Algorithm

**loadUserByUsername(userName)**
1. Get EPrintUser from securityManager by userName
2. If user is null, throw UsernameNotFoundException
3. Create GrantedAuthority list with user type as authority
4. Create Spring Security User object with:
   - userName
   - Empty password (authentication handled elsewhere)
   - All account flags set to true (enabled, accountNonExpired, credentialsNonExpired, accountNonLocked)
   - Granted authorities list
5. Return User object

# Business context

EPrintUserDetailsService integrates ePrint user management with Spring Security authentication framework. It loads user details from the security manager and converts them to Spring Security UserDetails format, using user type as the granted authority.

# Business rules

- Username must exist in security manager, otherwise UsernameNotFoundException is thrown
- User type is used as granted authority for authorization
- Password is always empty string (authentication handled by other mechanisms)
- All account flags are always true (no account expiry or locking)
- User type determines authorization level in the system

# Depends on

- `SecurityManager` for retrieving ePrint user details
- Spring Security `UserDetailsService` (implements)
- Spring Security `UserDetails` for return type
