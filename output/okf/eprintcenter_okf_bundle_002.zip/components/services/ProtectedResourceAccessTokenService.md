---
type: Component
title: Protected Resource Access Token Service
description: Manages OAuth access token lifecycle including creation, validation, and expiration for protected resources.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceAccessTokenService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ProtectedResourceAccessTokenService.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/ProtectedResourceAccessTokenService.java, title: ProtectedResourceAccessTokenService.java }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| securityManager | SecurityManager |  |
| tokenToVerify | AccessTokenEntity | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | AccessTokenEntity | String token |  |
| removeToken | void | String token | @Transactional |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication |  |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token |  |
| isExpired | boolean | AccessTokenEntity tokenToVerify |  |


# Cross-cutting

* Transactional: `removeToken`

# Algorithm

**readToken(token)**
1. Call securityManager.getAccessToken with the token string
2. Return the access token entity

**removeToken(token)**
1. Call securityManager.deleteAccessToken with the token string
2. Method is transactional

**getToken(token)**
1. Call readToken to fetch token from database
2. If token is null, throw InvalidOAuthTokenException
3. Call isExpired to check if token has expired
4. If expired:
   - Call removeToken to delete expired token
   - Throw ExpiredOAuthTokenException
5. Return the valid token

**isExpired(tokenToVerify)**
1. Get current time in GMT timezone
2. Compare token's expiry time with current time
3. Return true if expiry time is less than current time, false otherwise

**authorizeRequestToken, createAccessToken, createUnauthorizedRequestToken**
- Not implemented - throw NotImplementedException

# Business context

ProtectedResourceAccessTokenService manages OAuth access token validation and expiration for protected resources. It validates tokens from the database, checks expiration against GMT timezone, and automatically removes expired tokens. This is part of the OAuth protected resource flow.

# Business rules

- Token expiry time is checked against GMT timezone
- Expired tokens are automatically removed from database
- Throws InvalidOAuthTokenException if token not found
- Throws ExpiredOAuthTokenException if token has expired
- removeToken is transactional to ensure consistency
- authorizeRequestToken, createAccessToken, and createUnauthorizedRequestToken are not implemented (throw NotImplementedException)

# Depends on

- `SecurityManager` for token database access
- Spring Security OAuth `OAuthProviderTokenServices` (implements)
