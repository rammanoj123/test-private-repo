---
type: Component
title: Protected Resource Access Token Service
description: Manages OAuth access token lifecycle including creation, validation, and expiration for protected resources.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ProtectedResourceAccessTokenService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T12:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ProtectedResourceAccessTokenService`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| tokenSecretLengthBytes | int |  |
| securityManager | SecurityManager |  |
| tokenToVerify | AccessTokenEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| getTokenSecretLengthBytes | int |  |  |
| setTokenSecretLengthBytes | void | int tokenSecretLengthBytes |  |
| readToken | AccessTokenEntity | String token |  |
| removeToken | void | String token | @Transactional |
| authorizeRequestToken | void | String requestToken, String verifier, Authentication authentication |  |
| createAccessToken | OAuthAccessProviderToken | String requestToken |  |
| createUnauthorizedRequestToken | OAuthProviderToken | String consumerKey, String callbackUrl |  |
| getToken | OAuthProviderToken | String token |  |
| isExpired | boolean | AccessTokenEntity tokenToVerify |  |

# Cross-cutting

* Transactional: `removeToken`
