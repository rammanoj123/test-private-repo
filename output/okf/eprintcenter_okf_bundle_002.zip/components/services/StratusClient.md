---
type: Component
title: Stratus Client
description: Defines interface for publishing ownership events to Stratus for both standard and PUC tokens.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: StratusClient.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/http/clients/StratusClient.java, title: StratusClient.java }
---

`com.hp.cloudprint.http.clients.StratusClient`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| publishAddOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  token |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownership |  |

# Algorithm

**publishAddOwnershipToStratus(ownership, token)**
- Interface method - implementation publishes add ownership event to Stratus with entity ownership and token

**publishDeleteOwnershipToStratus(ownership, token)**
- Interface method - implementation publishes delete ownership event to Stratus with entity ownership and token

**publishAddOwnershipToStratusForPucToken(ownership)**
- Interface method - implementation publishes add ownership event to Stratus with schema ownership for PUC token

# Business context

StratusClient defines the contract for publishing ownership events to the Stratus event streaming service. It supports both entity and schema ownership representations and handles token-based and PUC token-based publishing for event distribution.

# Business rules

- Supports both add and delete ownership events
- Handles two ownership representations: entity (com.hp.cloudprint.entities.Ownership) and schema (com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership)
- Token-based methods use standard OAuth tokens
- PUC token method uses schema ownership representation
- All operations throw exceptions on failure

# Depends on

This is an interface. Implementations will depend on HTTP client infrastructure and Stratus service endpoints.
