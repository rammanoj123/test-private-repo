---
type: Component
title: ConsumerDetailServiceProvider
description: Service `ConsumerDetailServiceProvider`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ConsumerDetailServiceProvider.java
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

`com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| securityManager | SecurityManager |  |
| consumerDetails | ConsumerDetailsEntity | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadConsumerByConsumerKey | ConsumerDetails | String consumerKey |  |
