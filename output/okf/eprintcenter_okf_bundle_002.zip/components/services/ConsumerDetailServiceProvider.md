---
type: Component
title: Consumer Detail Service Provider
description: Service `ConsumerDetailServiceProvider`. (Description pending enrichment.)
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\ConsumerDetailServiceProvider.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ConsumerDetailServiceProvider.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/ConsumerDetailServiceProvider.java, title: ConsumerDetailServiceProvider.java }
---

`com.hp.cloudprint.api.eprintcenter.security.ConsumerDetailServiceProvider`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| securityManager | SecurityManager |  |
| consumerDetails | ConsumerDetailsEntity | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setSecurityManager | void | SecurityManager securityManager |  |
| getSecurityManager | SecurityManager |  |  |
| loadConsumerByConsumerKey | ConsumerDetails | String consumerKey |  |

# Algorithm

**loadConsumerByConsumerKey**
1. Get consumer details from DB using securityManager.getConsumerDetails with consumerKey
2. If consumerDetails is null, throw InvalidOAuthParametersException with message 'Consumer not found: ' + consumerKey
3. Return consumerDetails

# Business context

Service provider for loading OAuth consumer details from the database. Implements Spring Security OAuth ConsumerDetailsService interface to retrieve consumer credentials for OAuth authentication.

# Business rules

- If Consumer must exist in database.
- If Throws InvalidOAuthParametersException if consumer not found.

# Depends on

- [SecurityManager](/components/security/SecurityManager.md)
