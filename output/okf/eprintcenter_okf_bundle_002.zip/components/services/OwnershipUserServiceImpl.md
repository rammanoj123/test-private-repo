---
type: Component
title: OwnershipUserServiceImpl
description: Implementation of OwnershipUserService that manages printer ownership operations including adding, deleting, and retrieving ownerships with shard map optimization.
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipUserServiceImpl.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| printerManager | IPrinterManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| eprintUserDirectory | EprintUserDirectory | @Override |
| eprintUserDirectory | EprintUserDirectory | @Override |
| eprintUserDirectory | EprintUserDirectory | @Override |
| ownership | Ownership | @Override |
| rowsUpdated | int | @Override |
| retainAliasForUser | boolean | @Override |
| hasFEA | boolean | @Override |
| activeEmailAddress | String | @Override |
| ownershipDetails | Ownership | @Override |
| ownerUserIDList | List |  |
| ownerships | List |  |
| shardCodeList | List |  |
| startTime | long |  |
| ownerUserIDList | List |  |
| ownerships | List |  |
| startTime | long |  |
| ownerUserIDList | List |  |
| ownerships | List |  |
| eprintUserDirectory | EprintUserDirectory |  |
| shardMap | List |  |
| startTime | long |  |
| ownershipDetails | Ownership | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnerShipsUsingShardcodeMap | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso, List<String> shardCodeList |  |
| getOwnerShipsUsingAllShard | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| getShardsFromPrinterOwnerShardMap | List | List<String> ownerUserId |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |

# Depends on

* `IPrinterManager`
* [CalypsoClient](/components/services/CalypsoClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
