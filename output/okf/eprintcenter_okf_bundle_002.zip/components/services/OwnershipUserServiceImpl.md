---
type: Component
title: Ownership User Service Impl
description: Implementation of OwnershipUserService that manages printer ownership operations including adding, deleting, and retrieving ownerships with shard map optimization.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipUserServiceImpl.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnershipUserServiceImpl.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/serviceimpl/OwnershipUserServiceImpl.java, title: OwnershipUserServiceImpl.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipUserServiceImpl`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| printerManager | IPrinterManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| eprintUserDirectory | EprintUserDirectory | @Override |
| eprintUserDirectory | EprintUserDirectory | @Override |
| eprintUserDirectory | EprintUserDirectory | @Override |
| ownership | Ownership | @Override |
| rowsUpdated | int | @Override |
| retainAliasForUser | boolean | @Override |
| hasFEA | boolean | @Override |
| activeEmailAddress | String | @Override |
| ownershipDetails | Ownership | @Override |
| ownerUserIDList | List |  |
| ownerships | List |  |
| shardCodeList | List |  |
| startTime | long |  |
| ownerUserIDList | List |  |
| ownerships | List |  |
| startTime | long |  |
| ownerUserIDList | List |  |
| ownerships | List |  |
| eprintUserDirectory | EprintUserDirectory |  |
| shardMap | List |  |
| startTime | long |  |
| ownershipDetails | Ownership | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEprintUserDirectory | EprintUserDirectory |  |  |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnerShipsUsingShardcodeMap | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso, List<String> shardCodeList |  |
| getOwnerShipsUsingAllShard | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| getShardsFromPrinterOwnerShardMap | List | List<String> ownerUserId |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |


# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md) for ownership data access
- [CalypsoClient](/components/services/CalypsoClient.md) for email address retention
- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md) for FEA TTL configuration
- `EprintUserDirectory` for shard map management
- `EprintShardHolder` for current shard context

# Algorithm

**addOwnership(devOwnership, instructionPageExpiryDurationInSecs, allEmailIds)**
1. Call printerManager.addOwnerForPrinter with ownership, expiry duration, and email IDs
2. Catch PrinterAlreadyOwnedException and rethrow
3. Get EprintUserDirectory instance
4. Call addPrinterOwnerShardMapEntry with ownerUserId, printerId, and current shard from EprintShardHolder
5. Catch EntityExistsException and log info (shard map entry already exists)
6. Catch EprintUserDirectoryException, log info, and rethrow

**addOwnershipByPrinterId(devOwnership)**
1. Call printerManager.addOwnerForPrinterByPrinterId with ownership
2. Catch PrinterAlreadyOwnedException and rethrow
3. Get EprintUserDirectory instance
4. Call addPrinterOwnerShardMapEntry with ownerUserId, printerId, and current shard from EprintShardHolder
5. Catch EntityExistsException and log info (shard map entry already exists)
6. Catch EprintUserDirectoryException, log info, and rethrow

**deleteOwnership(ownerShipId, emailAliasRetention)**
1. Initialize variables for ownership, rowsUpdated, retainAliasForUser, hasFEA, activeEmailAddress
2. If emailAliasRetention equals USER value, set retainAliasForUser true
3. Get ownership details for ownerShipId from printerManager
4. Get active email address from printer
5. If active email address differs from cryptic email address, set hasFEA true
6. Log retention flags and cloudId
7. Call printerManager.markAndReturnOwnershipForDeletion with ownerShipId and (retainAliasForUser AND hasFEA)
8. Get EprintUserDirectory instance
9. Delete shard map entry for ownerUserId and printerId
10. If retainAliasForUser AND hasFEA, call calypsoClient.patchEmailAddress with activeEmailAddress and FEA TTL from config
11. Catch OwnershipNotFoundException and rethrow
12. Catch EprintUserDirectoryException and log severe
13. Return rowsUpdated

**getOwnershipsForUser(ownerUserIdentities, userId, getFavoritesAlso)**
1. Get all user IDs as list from ownerUserIdentities
2. If shard map is enabled:
   - If ownerUserIDList is null, create list with userId
   - Get shard codes from PrinterOwnerShardMap via getShardsFromPrinterOwnerShardMap
   - If shard codes empty and fallback required:
     - Get ownerships using all shards via getOwnerShipsUsingAllShard
     - Log if ownerships found but shard map empty (stale data)
   - Else get ownerships using shard code map via getOwnerShipsUsingShardcodeMap
3. Else get ownerships using all shards via getOwnerShipsUsingAllShard
4. If ownerships is null, create empty list
5. Return ownerships

**getOwnershipsForUserToDelete(ownerShipId)**
1. Call printerManager.getOwnershipForId with ownerShipId
2. Return ownership details
3. Catch OwnershipNotFoundException and rethrow

# Business context

OwnershipUserServiceImpl manages printer ownership operations with shard map optimization for performance. It coordinates between printer manager, user directory, and Calypso client to handle ownership lifecycle including creation, deletion with email alias retention, and retrieval with shard-based optimization.

# Business rules

- Printer can only have one owner (PrinterAlreadyOwnedException thrown otherwise)
- Shard map entries are created when ownership is added
- Shard map entry failure is logged but doesn't fail the operation unless it's a directory exception
- Email alias is retained only if user requests AND printer has friendly email alias (FEA)
- Calypso is patched with FEA TTL when email is retained
- Shard map optimization is configurable via isOwnershipsEnabledForGetShardFromMap
- Fallback to all shards if shard map is empty and fallback is enabled
- Empty shard map with existing ownerships indicates stale data (logged as warning)
- Ownership marked for delete is treated as not found
