---
type: Component
description: Manages printer cloud configuration including opt-in settings, email addresses, and whitelist/blacklist entries.
---


