---
type: Component
title: Product Listing Service Helper
description: Helper class for retrieving printer information from Product Listing Service (PLS).
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\ProductListingServiceHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ProductListingServiceHelper.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/helper/ProductListingServiceHelper.java, title: ProductListingServiceHelper.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.ProductListingServiceHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| plsClient | PLSClient | @Resource |
| printerInfoResponse | PrinterInfoList | @Resource |
| printerIdWithInfo | Map | @Resource |
| printerInfoResponse | PrinterInfoList |  |
| completePrinterInfoList | PrinterInfoList |  |
| printerInfoAsList | List |  |
| printerInfoBasedOnModelAndFirmwareVersion | PrinterInfo |  |
| printerInfoAsList | List |  |
| appPlayerEntries | List |  |
| matchingPlayerEntry | AppPlayerEntry |  |
| appPlayerEntries | List |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPlsClient | void | PLSClient plsClient |  |
| getPrinterInfoFromPLS | Map | String userId, List<String> modelNumbers |  |
| getPrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber |  |
| getCompletePrinterInfoFromPLS | PrinterInfo | String userId, String modelNumber, String firmwareVersion |  |
| getPrinterInfoAsList | List | String modelNumber, PrinterInfoList completePrinterInfoList |  |
| filterPrinterInfoBasedOnFirmwareVersion | PrinterInfo | List<PrinterInfo> printerInfoAsList, String firmwareVersion |  |
| reCreatePrinterInfo | PrinterInfo | AppPlayerEntry matchingPlayerEntry, List<PrinterInfo> printerInfoAsList |  |
| convertToAppPlayerEntries | List | List<PrinterInfo> printerInfoAsList |  |


# Depends on

- `PLSClient` for Product Listing Service access
- `AppPlayerEntryFinder` for firmware version filtering

# Algorithm

**getPrinterInfoFromPLS(userId, modelNumbers)**
1. Call plsClient.getPrinterInfo with userId and modelNumbers list
2. If response is null, throw ProductListingServiceClientException
3. Create map printerIdWithInfo
4. Iterate through printerInfos in response
5. Put each printerInfo in map with id as key
6. Return map

**getPrinterInfoFromPLS(userId, modelNumber)**
1. Call plsClient.getPrinterInfo with userId and single modelNumber
2. If response is null, throw ProductListingServiceClientException
3. Log response size
4. Iterate through printerInfos in response
5. Log each iteration with expected and actual model number
6. If printerInfo.id contains modelNumber (trimmed), return printerInfo
7. Return null if no match found

**getCompletePrinterInfoFromPLS(userId, modelNumber, firmwareVersion)**
1. Call plsClient.getCompletePrinterInfo with userId and modelNumber
2. If response is null, throw ProductListingServiceClientException
3. Log response size
4. Call getPrinterInfoAsList to filter by modelNumber
5. If firmwareVersion is not null:
   - Try to filter by firmware version using filterPrinterInfoBasedOnFirmwareVersion
   - Catch any throwable during filtering and log
6. If filtered result is null and list has entries, return first entry
7. Return filtered result

# Business context

ProductListingServiceHelper retrieves printer information from the Product Listing Service (PLS) for single or multiple model numbers. It supports firmware version filtering using AppPlayerEntryFinder and provides fallback logic when filtering fails.

# Business rules

- Model number matching is done with contains check after trimming
- If firmware version filtering fails, fall back to first entry in list
- Null response from PLS throws ProductListingServiceClientException
- Complete printer info supports firmware version filtering
- Firmware version filtering is best-effort (exceptions are caught and logged)
