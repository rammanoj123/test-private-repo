---
type: Component
description: Implements print job management including cancellation, status retrieval, and history queries with sorting and pagination.
---


