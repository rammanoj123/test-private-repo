---
type: Component
title: Ownership User Service
description: Service interface for managing printer ownership operations for users.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipUserService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnershipUserService.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/service/OwnershipUserService.java, title: OwnershipUserService.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |

# Algorithm

**addOwnership(devOwnership, instructionPageExpiryDurationInSecs, allEmailIds)**
- Interface method - implementation adds ownership for a printer with instruction page expiry duration and email IDs

**addOwnershipByPrinterId(devOwnership)**
- Interface method - implementation adds ownership for a printer by printer ID

**deleteOwnership(ownerShipId, emailAliasRetention)**
- Interface method - implementation removes ownership for the given ownership ID with email alias retention policy
- Returns number of rows updated

**getOwnershipsForUser(ownerUserIdentities, userId, getFavoritesAlso)**
- Interface method - implementation fetches the ownerships for the given user with optional favorites
- Returns list of Ownership objects

**getOwnershipsForUserToDelete(ownerShipId)**
- Interface method - implementation retrieves ownership details for deletion by ownership ID
- Returns Ownership object

# Business context

OwnershipUserService defines the contract for managing printer ownership operations including adding, deleting, and retrieving ownerships. It acts as the interface between ownership resources and the printer manager, supporting email alias retention policies and shard map optimization.

# Business rules

- All operations throw CpInternalContingencyException on failure
- addOwnership supports instruction page expiry and multiple email IDs
- deleteOwnership respects email alias retention policy (USER or DEVICE)
- getOwnershipsForUser supports optional favorites retrieval
- getOwnershipsForUserToDelete is specifically for deletion workflows

# Depends on

This is an interface. Implementations will depend on printer manager, user directory, and Calypso client.
