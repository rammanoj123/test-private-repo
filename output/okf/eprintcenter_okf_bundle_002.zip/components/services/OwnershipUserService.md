---
type: Component
title: OwnershipUserService
description: Service `OwnershipUserService`. (Description pending enrichment.)
tags: [component, service]
status: draft
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipUserService.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipUserService`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| addOwnership | void | Ownership devOwnership, long instructionPageExpiryDurationInSecs, List<String> allEmailIds |  |
| addOwnershipByPrinterId | void | Ownership devOwnership |  |
| deleteOwnership | int | String ownerShipId, String emailAliasRetention |  |
| getOwnershipsForUser | List | UserIdentities ownerUserIdentities, String userId, boolean getFavoritesAlso |  |
| getOwnershipsForUserToDelete | Ownership | String ownerShipId |  |
