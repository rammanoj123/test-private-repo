---
type: Component
title: Ownership Status Service Impl
description: Implementation of OwnershipStatusService that determines printer ownership status for users.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\serviceimpl\OwnershipStatusServiceImpl.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnershipStatusServiceImpl.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/serviceimpl/OwnershipStatusServiceImpl.java, title: OwnershipStatusServiceImpl.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.serviceimpl.OwnershipStatusServiceImpl`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| version | String |  |
| self | String |  |
| printerManager | IPrinterManager | @Resource |
| deviceData | DeviceData | @Override |
| printerEntity | Printer | @Override |
| ownershipEntity | Ownership |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| links | List |  |
| ownershipLink | Link |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |
| getOwnershipStatusResponse | OwnershipStatusResponse | Ownership ownershipEntity, ClaimStatus claimStatus, String rootUrl |  |


# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md) for printer and ownership data access

# Algorithm

**getOwnershipsForPrinter(modelNumber, serialNumber, uuid, userId, rootUrl)**
1. Call printerManager.getPrinterBySerialAndModelNumber to get deviceData
2. If deviceData is null, throw DeviceNotFoundExcpeption
3. Get active printer by deviceId from printerManager
4. If printerEntity or printerAdditionalInfo is null, throw InvalidUUIDException
5. If printer UUID is null, log error and throw InvalidUUIDException
6. If printer UUID doesn't match request UUID, log error and throw InvalidUUIDException
7. Try to get ownership entry for user and printer combination from printerManager
8. If ownership found and not marked for delete:
   - Return response with 'claimed' status
9. If ownership not found, try to get printer owner from printerManager
10. If owner found and not marked for delete:
    - Return response with 'claimed_by_other' status
11. If no owner found:
    - Return response with 'not_claimed' status

**getOwnershipStatusResponse(ownershipEntity, claimStatus, rootUrl)**
1. Create new OwnershipStatusResponse
2. Set version to '1.0'
3. Set claimStatus
4. Create links list
5. Create ownership link with 'self' relation and rootUrl
6. Add link to links list
7. Set links in response
8. Return response

# Business context

OwnershipStatusServiceImpl determines printer ownership status by validating printer UUID and checking ownership records. It returns one of three statuses: claimed (user owns it), claimed_by_other (someone else owns it), or not_claimed (no owner).

# Business rules

- UUID must match exactly between request and printer record
- Ownership marked for delete is treated as not found
- Three possible statuses: claimed, claimed_by_other, not_claimed
- Version is always '1.0'
- Self link relation is always 'self'
- DeviceNotFoundExcpeption thrown if printer not found by serial and model
- InvalidUUIDException thrown if UUID is null or doesn't match
