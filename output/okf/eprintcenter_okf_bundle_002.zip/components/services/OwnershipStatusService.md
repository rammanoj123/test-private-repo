---
type: Component
title: Ownership Status Service
description: Service interface for retrieving ownership status of printers.
tags: [component, service]
status: stable
component_type: Service
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\service\OwnershipStatusService.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnershipStatusService.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/service/OwnershipStatusService.java, title: OwnershipStatusService.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.service.OwnershipStatusService`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOwnershipsForPrinter | OwnershipStatusResponse | String modelNumber, String serialNumber, String uuid, String userId, String rootUrl |  |

# Algorithm

**getOwnershipsForPrinter(modelNumber, serialNumber, uuid, userId, rootUrl)**
- Interface method - implementation retrieves ownership status for a printer identified by model number, serial number, and UUID
- Returns OwnershipStatusResponse with claim status and links

# Business context

OwnershipStatusService defines the contract for determining printer ownership status. It identifies printers by model number, serial number, and UUID, then determines if the printer is claimed by the requesting user, claimed by another user, or not claimed at all.

# Business rules

- Throws DeviceNotFoundExcpeption if printer not found
- Throws InvalidUUIDException if UUID validation fails
- Throws JsonProcessingException for JSON serialization errors
- Returns one of three statuses: claimed, claimed_by_other, or not_claimed

# Depends on

This is an interface. Implementations will depend on printer manager and ownership data access.
