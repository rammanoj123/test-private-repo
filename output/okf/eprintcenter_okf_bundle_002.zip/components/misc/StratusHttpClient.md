---
type: Component
title: Stratus Http Client
description: Unknown `StratusHttpClient`. (Description pending enrichment.)
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusHttpClient.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: StratusHttpClient.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/http/clients/StratusHttpClient.java, title: StratusHttpClient.java }
---

`com.hp.cloudprint.http.clients.StratusHttpClient`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| httpClient | CloseableHttpClient |  |
| appConfig | HttpClientConfig |  |
| socketTimeout | int | @PostConstruct |
| config | RequestConfig | @PostConstruct |
| httpClientBuilder | HttpClientBuilder | @PostConstruct |
| hostnameVerifier | HostnameVerifier |  |
| sslConnectionSocketFactory | SSLConnectionSocketFactory |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInMilliseconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| getRequest | HttpGet |  |
| RETRY_THRESHOLD | int |  |
| getRequest | HttpGet |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| postRequest | HttpPost |  |
| RETRY_THRESHOLD | int |  |
| postRequest | HttpPost |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| putRequest | HttpPut |  |
| RETRY_THRESHOLD | int |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| putRequest | HttpPut |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| patchRequest | HttpPatch |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| entryTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| response | HttpResponse |  |
| closeableHttpResponse | CloseableHttpResponse |  |
| deleteRequest | HttpDelete |  |
| RETRY_THRESHOLD | int |  |
| exitTimeInMilliseconds | long |  |
| diffTimeInSeconds | long |  |
| entryTimeInMilliseconds | long |  |
| putRequest | HttpPut |  |
| patchRequest | HttpPatch |  |
| deleteRequest | HttpDelete |  |
| putRequest | HttpPut |  |
| responseCode | int |  |
| respBody | byte[] |  |
| httpResponseUtil | HttpResponseUtil |  |
| responseStream | InputStream |  |
| responseCode | int |  |
| respBody | byte[] |  |
| responseStream | InputStream |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| StratusHttpClient |  |  |  |
| getAppConfig | HttpClientConfig |  |  |
| setAppConfig | void | HttpClientConfig appConfig |  |
| init | void |  |  |
| getHttpClient | CloseableHttpClient |  |  |
| doGet | HttpResponse | String url, Map<String, String> headers |  |
| addLoggerForHttpCalls | void | long entryTimeInMilliseconds, long exitTimeInMilliseconds, HttpResponse response, long diffTimeInSec, String url, String methodType |  |
| createGetRequest | HttpGet | String url, Map<String, String> headers |  |
| doPost | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| createPostRequest | HttpPost | String url, Map<String, String> headers, HttpEntity entity |  |
| doPut | HttpResponse | String url, Map<String, String> headers, byte[] content |  |
| doPatch | HttpResponse | String url, Map<String, String> headers, HttpEntity entity |  |
| doDelete | HttpResponse | String url, Map<String, String> headers |  |
| createPutRequest | HttpPut | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createPatchRequest | HttpPatch | String url, Map<String, String> headers, HttpEntity httpEntity |  |
| createDeleteRequest | HttpDelete | String url, Map<String, String> headers |  |
| createResponse | HttpResponseUtil | HttpResponse resp |  |
| setHeaders | void | Map<String, String> headers, HttpUriRequest request |  |

# Algorithm

**init**
1. Get socket timeout from appConfig
2. Create RequestConfig with connection timeout and socket timeout
3. Create HttpClientBuilder
4. Set max connections and max connections per route
5. Set default socket config with socket timeout
6. If hostname verification disabled, use NoopHostnameVerifier
7. If SSL protocol specified, create SSLConnectionSocketFactory and set on builder
8. Else set SSL hostname verifier
9. Build httpClient

**doGet**
1. Log GET request
2. Record entry time
3. Create GET request with URL and headers
4. Get retry threshold from config
5. Loop up to retry threshold
6. Execute GET request
7. Record exit time and calculate diff
8. Log HTTP call details
9. Break on success
10. Catch IOException: log error, increment retry; if max retries, log and throw CpInternalContingencyException
11. Catch RuntimeException: log error, abort request, throw
12. Finally release connection
13. Return response

**doPost**
1. Log POST request
2. Record entry time
3. Create POST request with URL, headers, and entity
4. Get retry threshold from config
5. Loop up to retry threshold
6. Execute POST request
7. Record exit time and calculate diff
8. Log HTTP call details
9. Break on success
10. Catch IOException: log error, increment retry; if max retries, log and throw CpInternalContingencyException
11. Catch RuntimeException: log error, abort request, throw
12. Finally release connection
13. Return response

**doPut/doPatch/doDelete**
(Similar retry logic as doPost with respective HTTP methods)

**createResponse**
1. Check response and entity are not null
2. Get status code from response
3. Get input stream from entity
4. Read stream to byte array
5. Log response body
6. Create HttpResponseUtil with status code and body
7. Catch IOException: set status to 500, log error
8. Finally close input stream
9. Return HttpResponseUtil

# Business context

HTTP client for making REST calls with SSL support, retry logic, and configurable timeouts. Supports GET, POST, PUT, PATCH, DELETE methods with automatic retry on IOException up to configured threshold. Logs processing time and response details.

# Business rules

- If Retry threshold is configurable.
- If Socket timeout and connection timeout are configurable.
- If Hostname verification can be disabled.
- If SSL protocol can be specified.
- If IOException triggers retry up to threshold.
- If RuntimeException aborts request immediately.
- If Connection is released in finally block.

# Depends on

- [HttpClientConfig](/components/config/HttpClientConfig.md)
