---
type: Component
title: JAXB Object Creation Helper
description: Helper class for creating JAXB objects from entities, mapping PLS printer info to printer descriptions, and managing print history.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\JAXBObjectCreationHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: JAXBObjectCreationHelper.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/helper/JAXBObjectCreationHelper.java, title: JAXBObjectCreationHelper.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.JAXBObjectCreationHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| storageEndPoint | String | @Resource |
| printHistory | PrintHistory | @Resource |
| printHistoryDocument | Document |  |
| isCurrentUserTheDocumentOwner | boolean |  |
| isDocumentPending | boolean |  |
| isDocumentRejectedOrAborted | boolean |  |
| wasTnCAccepted | boolean |  |
| isHavingAccessToDocument | boolean |  |
| sunsetPeriodInDays | int |  |
| cal | Calendar |  |
| isPossibleToDeleteDocument | boolean |  |
| newLink | Link |  |
| ownerAdditionalEmailAddressEntries | List |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| formatter | DateFormat |  |
| gregorianCalendar | GregorianCalendar |  |
| printerIdMappedWithPrinterInfo | Map |  |
| infoAboutPrinterFromPLS | PrinterInfo |  |
| imagesForResponse | Images |  |
| imagesFromPLS | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images |  |
| imageForResponse | com.hp.cloudprint.api.eprintcenter.schemas.Image |  |
| printerIdMappedWithPrinterInfo | Map |  |
| infoAboutPrinterFromPLS | PrinterInfo |  |
| imagesForResponse | Images |  |
| imagesFromPLS | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images |  |
| imageForResponse | com.hp.cloudprint.api.eprintcenter.schemas.Image |  |
| SD_APP_DEVICE_CLASS | String |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerVersion | PrinterVersion |  |
| modelKey | String |  |
| revisionFoundFromAppconfig | String |  |
| firmwareVersion | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerCloudConfigResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| state | DocumentState |  |
| stateReason | String |  |
| comments | DocumentComments |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getUserPrintHistory | PrintHistory | List<com.hp.cloudprint.entities.Document>  documentsBasedOnCriteria, UserHistorySearchCriteria historySearchCriteria, long total, UserIdentities userIdentities, boolean userEmailVerified |  |
| createDocumentForResponse | Document | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities, boolean userEmailVerified |  |
| isDocumentRejectedOrAbortedBecauseOfInputContent | boolean | Document printHistoryDocument |  |
| wasTermsAndConditionsAcceptedWhenJobWasProcessed | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| getStorageEndPoint | String |  |  |
| formNewLinkElement | Link | String name, String href |  |
| isDocumentInPendingState | boolean | com.hp.cloudprint.entities.Document docEntity |  |
| isCurrentUserTheDocumentOwner | boolean | com.hp.cloudprint.entities.Document docEntity, UserHistorySearchCriteria historySearchCriteria, UserIdentities userIdentities |  |
| verifyOriginator | boolean | List<String> allEmailIds, String originatingUserId |  |
| getXMLEncodedDate | XMLGregorianCalendar | Date date |  |
| mapPLSPrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo printerInfo |  |
| mapPLSCompletePrinterInfoToPrinterDescriptionForResponse | void | PrinterDescription printerDesc, PrinterInfo completePrinterInfo |  |
| overrideInkCapability | void | PrinterDescription printerDesc |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | String supportedAppPlayerVersions |  |
| getImageListSize | Object | hp.cloud.eprint.papi.services.pls._2._0.PrinterInfo.Images imagesFromPLS |  |
| generatePrinterCloudConfigurationJAXBObject | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | PrinterCloudConfiguration printerCloudConfiguration |  |
| configureInkSubscription | void | PrinterDescription printerDesc, byte consumableSubscription |  |
| setDocumentStateAndStateReason | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| setDocumentStateAndStateReasonForError | void | com.hp.cloudprint.entities.Document docEntity, Document doc |  |
| populateOptinSubscriptionDetails | OptinConfig | DataCollectionGroupType dataCollectionGroupType, OptinConfig optinConfig |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |


# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Algorithm

**getUserPrintHistory**
1. Create new PrintHistory object
2. Iterate through documentsBasedOnCriteria
3. For each document, call createDocumentForResponse
4. Add created document to printHistory
5. Set total count
6. Return printHistory

**createDocumentForResponse**
1. Create new Document object
2. Set documentId from entity
3. Call setDocumentStateAndStateReason
4. Check if current user is document owner
5. Check if document is in pending state
6. Check if document is rejected or aborted
7. Check if T&C was accepted
8. Determine if user has access: is owner AND not pending AND not rejected/aborted AND T&C accepted AND email verified
9. Set document properties (name, fileType, sender, size, pages, printerId)
10. Set print date and expiration date (creation date + sunset period)
11. If user has access and urlMapper exists, add INPUT, PREVIEW, DOWNLOAD links and set havingAccessToDocument true
12. Otherwise set havingAccessToDocument false
13. If document not pending, add DELETE link and set possibleToDeleteDocument true
14. Return document

**setDocumentStateAndStateReason**
1. Get document state from entity
2. Map state: ACCEPTED→OPENED, DEVICE_NOTIFIED_FOR_PRINT→SENDING_FILE_TO_PRINTER, OUTPUT_CREATED→RENDERED, COMPLETED→COMPLETED, DEVICE_BUSY/OFFLINE/ERROR/DISCONNECTED→PENDING, CANCELLED→CANCELED, ERROR→call setDocumentStateAndStateReasonForError, UNKNOWN→UNKNOWN, Default→PROCESSING

**configureInkSubscription**
1. Check if printerDesc is not null
2. Switch on consumableSubscription value: 0→INK_USAGE_COLLECTION_DEFAULT, 1→INK_USAGE_COLLECTION_V2, -1→no override

**populateOptinSubscriptionDetails**
1. If dataCollectionGroupType is null, set both inkSubscription and inkSubscriptionV2 to false
2. Else if INK_USAGE_COLLECTION, set inkSubscription true and inkSubscriptionV2 false
3. Else if INK_USAGE_COLLECTION_V2, set inkSubscription false and inkSubscriptionV2 true
4. Return optinConfig

# Business context

Helper class for creating JAXB objects from entities, mapping PLS printer info to printer descriptions, and managing print history. Determines document access permissions based on ownership, state, T&C acceptance, and email verification. Manages instant ink capabilities and overrides.

# Business rules

- If User has access to document if: is owner AND not pending AND not rejected/aborted AND T&C accepted AND email verified.
- If Expiration date is creation date plus sunset period in days.
- If DELETE link only available for non-pending documents.
- If Ink subscription: 0=disable, 1=enable V2, -1=no override.
- If Only one ink subscription version can be active at a time.
