---
type: Component
title: EmailAliasRetention
description: Defines email alias retention policy enumeration for ownership deletion operations with USER and DEVICE level options.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EmailAliasRetention.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.EmailAliasRetention`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAliasRetention | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EmailAliasRetention |  | String retentionChoice |  |
| getEnum | EmailAliasRetention | String value |  |
