---
type: Component
title: Email Alias Retention
description: Enumeration defining email alias retention policies for user or device.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EmailAliasRetention.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EmailAliasRetention.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/EmailAliasRetention.java, title: EmailAliasRetention.java }
---

`com.hp.cloudprint.api.eprintcenter.EmailAliasRetention`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| emailAliasRetention | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EmailAliasRetention |  | String retentionChoice |  |
| getEnum | EmailAliasRetention | String value |  |

# Algorithm

**value**
1. Return emailAliasRetention field

**getEnum**
1. Iterate through all enum values
2. Compare each value (case-insensitive) with input
3. Return matching enum
4. If no match found, return DEVICE as default

# Business context

Enumeration defining email alias retention policies for user or device. Determines whether an email alias is retained for the user or the device when ownership changes. DEVICE is the default retention policy.

# Business rules

- If Two retention choices: USER or DEVICE.
- If DEVICE is the default retention policy when value is not recognized.
- If Case-insensitive matching for string-to-enum conversion.
