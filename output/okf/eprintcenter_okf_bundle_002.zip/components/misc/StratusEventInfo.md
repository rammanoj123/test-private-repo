---
type: Component
title: Stratus Event Info
description: A data transfer object encapsulating event information for Stratus event publishing.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\StratusEventInfo.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: StratusEventInfo.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/StratusEventInfo.java, title: StratusEventInfo.java }
---

`com.hp.cloudprint.StratusEventInfo`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| event | String |  |
| fqResourceName | String |  |
| resourceId | String |  |
| tenantResourceId | String |  |
| scopes | List |  |
| eventAttributeValueMap | Map |  |
| customData | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEvent | String |  |  |
| setEvent | void | String event |  |
| getFqResourceName | String |  |  |
| setFqResourceName | void | String fqResourceName |  |
| getResourceId | String |  |  |
| setResourceId | void | String resourceId |  |
| getTenantResourceId | String |  |  |
| setTenantResourceId | void | String tenantResourceId |  |
| getScopes | List |  |  |
| getEventAttributeValueMap | Map |  |  |
| setEventAttributeValueMap | void | Map<String, EventAttribute> eventAttributeValueMap |  |
| setScopes | void | List<String> scopes |  |
| getCustomData | String |  |  |
| setCustomData | void | String customData |  |

# Business context

Data transfer object encapsulating event information for Stratus event publishing. Stores event name, resource identifiers, scopes, custom data, and event attribute value mappings.

# Business rules

- If Holds event metadata for Stratus publishing.
- If Provides getter/setter access to all event properties.
