---
type: Component
title: StratusEventInfo
description: Represents Stratus event information including resource details, scopes, and attribute maps for event publishing.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\StratusEventInfo.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.StratusEventInfo`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| event | String |  |
| fqResourceName | String |  |
| resourceId | String |  |
| tenantResourceId | String |  |
| scopes | List |  |
| eventAttributeValueMap | Map |  |
| customData | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEvent | String |  |  |
| setEvent | void | String event |  |
| getFqResourceName | String |  |  |
| setFqResourceName | void | String fqResourceName |  |
| getResourceId | String |  |  |
| setResourceId | void | String resourceId |  |
| getTenantResourceId | String |  |  |
| setTenantResourceId | void | String tenantResourceId |  |
| getScopes | List |  |  |
| getEventAttributeValueMap | Map |  |  |
| setEventAttributeValueMap | void | Map<String, EventAttribute> eventAttributeValueMap |  |
| setScopes | void | List<String> scopes |  |
| getCustomData | String |  |  |
| setCustomData | void | String customData |  |
