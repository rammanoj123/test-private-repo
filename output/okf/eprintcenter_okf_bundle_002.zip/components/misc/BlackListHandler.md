---
type: Component
title: BlackListHandler
description: Unknown `BlackListHandler`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | IPrinterManager |  |
| blackListID | String printerID, | @Override |
| blackListID | String printerID, | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleDelete | void | CPGMessage message |  |
| handleGet | void | CPGMessage message |  |
