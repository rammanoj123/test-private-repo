---
type: Component
title: Black List Handler
description: REST handler for managing individual blacklist entries with GET and DELETE operations.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListHandler.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: BlackListHandler.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/handlers/device/BlackListHandler.java, title: BlackListHandler.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListHandler`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerManager | IPrinterManager |  |
| blackListID | String printerID, | @Override |
| blackListID | String printerID, | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleDelete | void | CPGMessage message |  |
| handleGet | void | CPGMessage message |  |

# Algorithm

**handleDelete**
1. Extract printerID from request parameters
2. Extract blackListID from request parameters
3. Call printerManager.removeBlackListEntry with printerID and blackListID
4. Set response status to SUCCESS_NO_CONTENT

**handleGet**
1. Extract printerID from request parameters
2. Extract blackListID from request parameters
3. Call printerManager.getBlackListEntry with printerID and blackListID
4. Convert result using EntityConverter.createBlackListEntry
5. Set converted entry in response entity

# Business context

REST handler for managing individual blacklist entries. Provides GET and DELETE operations for specific blacklist entries identified by blackListID within a printer's blacklist.

# Business rules

- If PrinterID and blackListID are required parameters.
- If DELETE returns 204 NO_CONTENT on success.
- If GET returns the blacklist entry converted to schema format.

# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md)
- [EntityConverter](/components/converters/EntityConverter.md)
