---
type: Component
title: Sorting And Pagination Helper
description: Helper class for sorting and paginating print history document lists.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: SortingAndPaginationHelper.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/helper/SortingAndPaginationHelper.java, title: SortingAndPaginationHelper.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| comparator | UserHistoryComparator |  |
| paginatedDocList | List |  |
| paginationStart | int |  |
| normalizedCount | int |  |
| paginationEnd | int |  |
| maxCountPerPage | int |  |
| normalizedCount | int |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |

# Algorithm

**sortPrintHistoryBasedOnSortCriteria**
1. Create UserHistoryComparator with sortCriteria and sortOrder
2. Call Collections.sort with documents and comparator

**paginateResultsBasedOnStartAndCountParams**
1. Create empty paginatedDocList
2. Log pagination request with list size, start, and count
3. Call getNormalizedStart to get paginationStart
4. Call getNormalizedCount to get normalizedCount
5. Call getPaginationEndIndexBasedOnStartAndCount to get paginationEnd
6. Log normalized pagination parameters
7. Iterate from paginationStart to paginationEnd
8. Add each document to paginatedDocList
9. Log result size
10. Return paginatedDocList

# Business context

Helper class for sorting and paginating print history document lists. Normalizes pagination parameters according to configuration limits and sorts documents using UserHistoryComparator.

# Business rules

- If Pagination parameters are normalized according to configuration limits.
- If Sorting uses UserHistoryComparator with specified criteria and order.
