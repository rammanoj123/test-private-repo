---
type: Component
title: SortingAndPaginationHelper
description: Provides sorting and pagination utilities for user print history document lists with configurable criteria and page size.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| comparator | UserHistoryComparator |  |
| paginatedDocList | List |  |
| paginationStart | int |  |
| normalizedCount | int |  |
| paginationEnd | int |  |
| maxCountPerPage | int |  |
| normalizedCount | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |
