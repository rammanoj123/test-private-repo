---
type: Component
title: SortingAndPaginationHelper
description: Helper class for sorting and paginating print history document lists.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\SortingAndPaginationHelper.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.SortingAndPaginationHelper`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| comparator | UserHistoryComparator |  |
| paginatedDocList | List |  |
| paginationStart | int |  |
| normalizedCount | int |  |
| paginationEnd | int |  |
| maxCountPerPage | int |  |
| normalizedCount | int |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| sortPrintHistoryBasedOnSortCriteria | void | List<Document> documents, UserHistorySortCriteria sortCriteria, UserHistorySortOrder sortOrder |  |
| paginateResultsBasedOnStartAndCountParams | List | List<com.hp.cloudprint.entities.Document> documents, int start, int count |  |
| getPaginationEndIndexBasedOnStartAndCount | int | int documentsSize, int paginationStart, int normalizedCount |  |
| getNormalizedCount | int | int count |  |
| getNormalizedStart | int | int start |  |
