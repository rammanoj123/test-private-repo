---
type: Component
title: Owner Access Processor
description: Pre-processor that validates printer owner access by checking if the authenticated user matches the printer owner or their additional identities.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\processors\OwnerAccessProcessor.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnerAccessProcessor.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/processors/OwnerAccessProcessor.java, title: OwnerAccessProcessor.java }
---

`com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager |  |
| securityDirectory | SecurityDirectory |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| logger | EPrintLogger |  |
| printerId | String | @Override |
| printerOwner | Ownership | @Override |
| accessToken | AccessTokenEntity | @Override |
| pumaToken | TokenDO | @Override |
| userID | String |  |
| issuer | String |  |
| allUserIdentities | UserIdentities |  |
| userIdentitiesAsList | List |  |
| userID | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| preProcess | void | CPGMessage message, Request request |  |
| isAccessAllowed | boolean | String ownerUserId, List<String> allUserIdentities |  |
| getUIDFromTokens | String | AccessTokenEntity accessToken, TokenDO pumaToken |  |

# Algorithm

**preProcess**
1. Extract printerId from request attributes
2. Try to get printer owner using printerManager
3. Catch OwnershipNotFoundException and throw AccessDeniedException with DEVICE_UNCLAIMED
4. Get accessToken and pumaToken from request attributes
5. Get userID from tokens using getUIDFromTokens
6. Get issuer from request attributes
7. Log issuer and userID
8. If issuer is AUTHZ, get all user identities with email sync enabled
9. Else get all user identities without email sync
10. Create userIdentitiesAsList
11. If allUserIdentities is null, add userID to list
12. Else check for PAM failure code: if 404, throw AccessDeniedException; else throw InternalServerError
13. Check for ULS failure code: if 404, throw AccessDeniedException; else throw InternalServerError
14. Add all user IDs from allUserIdentities to list
15. Call isAccessAllowed with ownerUserId and userIdentitiesAsList
16. If not allowed, throw AccessDeniedException with SENDER_IS_NOT_OWNER

**isAccessAllowed**
1. Log owner userId and number of user identities
2. Iterate through allUserIdentities
3. For each userId, log comparison
4. If ownerUserId equals userId, log match and return true
5. Return false if no match found

**getUIDFromTokens**
1. Initialize userID as null
2. If accessToken is not null, log and get user from accessToken
3. Else if pumaToken is not null, log and get uid from pumaToken
4. Return userID

# Business context

Pre-processor that validates printer owner access by checking if the authenticated user matches the printer owner or their additional identities. Resolves user identities from OAuth or PUMA tokens and handles PAM/ULS failures appropriately.

# Business rules

- If Printer must be claimed to allow access.
- If User must match printer owner or one of owner's identities.
- If PAM/ULS 404 errors result in access denied.
- If Other PAM/ULS errors result in internal server error.
- If OAuth access token takes precedence over PUMA token.

# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md)
- [UserEmailAddressHelper](/components/helpers/UserEmailAddressHelper.md)
