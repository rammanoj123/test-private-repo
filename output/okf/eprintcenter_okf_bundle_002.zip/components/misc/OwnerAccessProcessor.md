---
type: Component
title: OwnerAccessProcessor
description: Pre-processor that validates printer owner access by checking if the authenticated user matches the printer owner or their additional identities.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\processors\OwnerAccessProcessor.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.processors.OwnerAccessProcessor`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager |  |
| securityDirectory | SecurityDirectory |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| logger | EPrintLogger |  |
| printerId | String | @Override |
| printerOwner | Ownership | @Override |
| accessToken | AccessTokenEntity | @Override |
| pumaToken | TokenDO | @Override |
| userID | String |  |
| issuer | String |  |
| allUserIdentities | UserIdentities |  |
| userIdentitiesAsList | List |  |
| userID | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getSecurityDirectory | SecurityDirectory |  |  |
| setSecurityDirectory | void | SecurityDirectory securityDirectory |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| preProcess | void | CPGMessage message, Request request |  |
| isAccessAllowed | boolean | String ownerUserId, List<String> allUserIdentities |  |
| getUIDFromTokens | String | AccessTokenEntity accessToken, TokenDO pumaToken |  |
