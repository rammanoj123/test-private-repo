---
type: Component
description: Retrieves printer information from Product Listing Service (PLS) for enhanced metadata.
---


