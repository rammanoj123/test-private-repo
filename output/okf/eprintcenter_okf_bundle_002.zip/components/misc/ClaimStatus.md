---
type: Component
title: Claim Status
description: Enumeration representing the claim status of a device or resource.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ClaimStatus.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/ClaimStatus.java, title: ClaimStatus.java }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`

# Business context

Enumeration representing the claim status of a device or resource. Defines three possible states: claimed (owned by current user), claimed_by_other (owned by different user), and not_claimed (no owner).

# Business rules

- If Three possible claim states: claimed, claimed_by_other, not_claimed.
- If Used to communicate device ownership status in API responses.
