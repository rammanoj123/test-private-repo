---
type: Component
title: ClaimStatus
description: Enumeration representing the claim status of a device or resource.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\ClaimStatus.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.ClaimStatus`
