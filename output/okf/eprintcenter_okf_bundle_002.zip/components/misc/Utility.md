---
type: Component
title: Utility
description: Utility class providing XML schema validation, API version retrieval, date conversion, and token processing.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Utility.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: Utility.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/Utility.java, title: Utility.java }
---

`com.hp.cloudprint.api.eprintcenter.Utility`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| schema | Schema |  |
| version | String |  |
| obj | Object |  |
| sf | SchemaFactory |  |
| schemaName | String |  |
| schemaName | String |  |
| schemaFile | File |  |
| dbf | DocumentBuilderFactory |  |
| db | DocumentBuilder |  |
| doc | Document |  |
| xmlGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| tokenDO | TokenDO |  |
| tokenDO | TokenDO |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getSchema | Schema |  |  |
| getApiVersion | String |  |  |
| addCacheHeaderToResponse | Response | Response resp |  |
| createXMLGregorianCalendar | XMLGregorianCalendar | Date creationTime |  |
| extractUIDFromPUC | String | Map<String, Object> parameters |  |
| isServicePuc | boolean | Request request |  |

# Business context

Utility provides shared infrastructure services for XML schema validation, API version management, date conversions, and token processing. It uses lazy initialization with double-checked locking for schema and version caching to optimize performance.

# Algorithm

**getSchema()**
1. Check if schema is null
2. If null, synchronize on obj
3. Double-check if schema is still null
4. Create SchemaFactory for W3C XML Schema
5. Get schema name from EPrintCenterAPIConfig
6. Load schema from classpath resource
7. Cache and return schema

**getApiVersion()**
1. Check if version is null
2. If null, synchronize on obj
3. Double-check if version is still null
4. Get schema name from EPrintCenterAPIConfig
5. Create File from classpath resource
6. Parse XML document using DocumentBuilder
7. Normalize document
8. Extract 'version' attribute from root element
9. Cache and return version

**createXMLGregorianCalendar(creationTime)**
1. Return null if creationTime is null
2. Create GregorianCalendar and set time
3. Extract year, month, day, hour, minute, second from calendar
4. Calculate timezone offset from ZONE_OFFSET and DST_OFFSET
5. Create XMLGregorianCalendar using DatatypeFactory with extracted values
6. Return XMLGregorianCalendar

**extractUIDFromPUC(parameters)**
1. Check if parameters is null, throw exception if so
2. Try to get TokenDO from PUC_DO parameter
3. If TokenDO is null, throw exception
4. Return tokenDO.getUid()
5. On exception, fall back to uid from parameters map

**addCacheHeaderToResponse(response)**
1. Get headers Form from response attributes
2. If headers is null, create new Form and add to attributes
3. Add 'Cache-Control: no-cache' header
4. Add 'Pragma: no-cache' header
5. Add 'Expires: 0' header
6. Put headers back in response attributes
7. Return response

**isServicePuc(request)**
1. Get TokenDO from request attributes
2. Check if uid is null, empty, or 'null' string
3. Return true if service PUC (no user context), false otherwise

# Business rules

- Schema and version are loaded once and cached using double-checked locking for thread safety
- Month conversion adjusts by +1 to convert from Julian (0-based) to Gregorian (1-based) calendar
- Service PUC is identified by null, empty, or 'null' string uid
- extractUIDFromPUC falls back to uid parameter if TokenDO extraction fails
- All responses get no-cache headers to prevent caching of sensitive data

# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md) for configuration values
- TokenDO for token processing
