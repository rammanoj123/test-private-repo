---
type: Component
title: Token
description: Data transfer object representing an authentication/authorization token with tenant, policy, and identity information.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Token.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: Token.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/Token.java, title: Token.java }
---

`com.hp.cloudprint.api.eprintcenter.Token`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| fq_tenant_id | String |  |
| nbf | String |  |
| group_policy | String |  |
| policy_id | String |  |
| scope | String |  |
| iss | String |  |
| tenants | List |  |
| exp | String |  |
| iat | String |  |
| jti | String |  |
| client_id | String |  |
| idp_id | String |  |
| tenant_id | String |  |
| stratus_id | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |
| getStratus_id | String |  |  |
| setStratus_id | void | String stratus_id |  |
| getIdp_id | String |  |  |
| setIdp_id | void | String idp_id |  |
| getFq_tenant_id | String |  |  |
| setFq_tenant_id | void | String fq_tenant_id |  |
| getNbf | String |  |  |
| setNbf | void | String nbf |  |
| getGroup_policy | String |  |  |
| setGroup_policy | void | String group_policy |  |
| getPolicy_id | String |  |  |
| setPolicy_id | void | String policy_id |  |
| getScope | String |  |  |
| setScope | void | String scope |  |
| getIss | String |  |  |
| setIss | void | String iss |  |
| getExp | String |  |  |
| setExp | void | String exp |  |
| getIat | String |  |  |
| setIat | void | String iat |  |
| getJti | String |  |  |
| setJti | void | String jti |  |
| getClient_id | String |  |  |
| setClient_id | void | String client_id |  |
| getTenants | List |  |  |
| setTenants | void | List<Tenant> tenants |  |

# Business context

Data transfer object representing an authentication/authorization token with tenant, policy, and identity information. Stores token claims (tenant, IDP, Stratus IDs), token metadata (expiration, issued at, JWT ID), and policy and scope information.

# Business rules

- If Provides getter/setter access to all token fields.
- If Stores token claims: fq_tenant_id, tenant_id, idp_id, stratus_id.
- If Stores token metadata: exp, iat, jti, nbf.
- If Stores policy information: policy_id, group_policy, scope.
- If Stores issuer and client_id.
