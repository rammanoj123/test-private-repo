---
type: Component
title: Token
description: Represents JWT token structure with claims including tenant, scope, issuer, expiration, and client identification fields.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Token.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.Token`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| fq_tenant_id | String |  |
| nbf | String |  |
| group_policy | String |  |
| policy_id | String |  |
| scope | String |  |
| iss | String |  |
| tenants | List |  |
| exp | String |  |
| iat | String |  |
| jti | String |  |
| client_id | String |  |
| idp_id | String |  |
| tenant_id | String |  |
| stratus_id | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |
| getStratus_id | String |  |  |
| setStratus_id | void | String stratus_id |  |
| getIdp_id | String |  |  |
| setIdp_id | void | String idp_id |  |
| getFq_tenant_id | String |  |  |
| setFq_tenant_id | void | String fq_tenant_id |  |
| getNbf | String |  |  |
| setNbf | void | String nbf |  |
| getGroup_policy | String |  |  |
| setGroup_policy | void | String group_policy |  |
| getPolicy_id | String |  |  |
| setPolicy_id | void | String policy_id |  |
| getScope | String |  |  |
| setScope | void | String scope |  |
| getIss | String |  |  |
| setIss | void | String iss |  |
| getExp | String |  |  |
| setExp | void | String exp |  |
| getIat | String |  |  |
| setIat | void | String iat |  |
| getJti | String |  |  |
| setJti | void | String jti |  |
| getClient_id | String |  |  |
| setClient_id | void | String client_id |  |
| getTenants | List |  |  |
| setTenants | void | List<Tenant> tenants |  |
