---
type: Component
title: URI Helper
description: Utility class providing URI construction methods for CloudPrint API endpoints.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\URIHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: URIHelper.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/URIHelper.java, title: URIHelper.java }
---

`com.hp.cloudprint.api.eprintcenter.URIHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| OPTIN_TYPE | String |  |
| SCHEDULE | String |  |
| UriSeperator | String |  |
| PRINTER_ID | String |  |
| OWNERSHIP_ID | String |  |
| JOBID | String |  |
| DOCUMENTID | String |  |
| PAGE_QUERYSTRING | String |  |
| RESULTS_PER_PAGE | String |  |
| WHITELIST_ID | String |  |
| EmailId | String |  |
| OWNER_ID | String |  |
| GET_FAVORITES | String |  |
| GET_MORE_PRINTER_DETAILS | String |  |
| ParameterLeftDelimiter | String |  |
| ParameterRightDelimiter | String |  |
| OwnershipsUri | String |  |
| PrintJobStatusUri | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getParameterURI | String | String parameterName |  |
| getPrintJobURI | String | String jobId |  |
| getCancelURI | String | String jobId |  |
| getPrintJobsURI | String |  |  |
| getPrintJobStatusURI | String | String jobId |  |
| getEmailAddressURIOnRamp | String | String printerId |  |
| getOwnerShipsURI | String |  |  |
| getOwnerShipURI | String | String ownerShipId |  |
| getPrintersURIOnRamp | String |  |  |
| getPrinterURIOnRamp | String | String printerId |  |
| getCloudConfigURI | String | String printerId |  |
| getWhiteListURI | String | String printerId |  |
| getWhiteListEntryURI | String | String printerId, String WhiteListID |  |
| getPrinterPrintJobsURI | String | String printerId |  |
| getPrinterSupportedProcesssingElementsURI | String | String printerId |  |
| getPrinterStatusURI | String | String printerId |  |
| getPrinterDefaultProcessingElementsURI | String | String printerId |  |
| getBlackListURI | String | String printerId, String blackListID |  |
| getOwnerAdditionalEmailAddressLink | String | String ownerAdditionalEmailAddressID |  |

# Business context

URIHelper provides centralized URI construction for all CloudPrint API endpoints including printers, ownerships, print jobs, whitelists, blacklists, and email addresses. It ensures consistent URI formatting across the API by defining path constants and template parameters.

# Algorithm

**getParameterURI(parameterName)**
1. Wrap parameter name in curly braces: `{parameterName}`
2. Return formatted template parameter

**getPrintJobURI(jobId)**
1. Get base print jobs URI
2. Append jobId and separator
3. Return constructed URI

**getCancelURI(jobId)**
1. Get print job URI for jobId
2. Append 'cancel/' path segment
3. Return cancel URI

**getOwnerShipURI(ownerShipId)**
1. Get base ownerships URI
2. Append separator, ownerShipId, and separator
3. Return ownership URI

**getPrinterURIOnRamp(printerId)**
1. Get base printers URI ('/devices/printers/')
2. Append printerId and separator
3. Return printer URI

**getWhiteListURI(printerId)**
1. Get printer URI for printerId
2. Append 'whitelist/' path segment
3. Return whitelist URI

**getWhiteListEntryURI(printerId, whiteListID)**
1. Get whitelist URI for printerId
2. Append whiteListID and separator
3. Return whitelist entry URI

**getBlackListURI(printerId, blackListID)**
1. Get printer URI for printerId
2. Append 'blacklist', separator, and blackListID
3. Return blacklist entry URI

# Business rules

- All URIs use forward slash as separator
- Template parameters are wrapped in curly braces for URI templates
- Base URIs are defined as constants: '/ownerships', '/devices/printers/', '/jobs/printjobs/'
- Printer-related URIs are prefixed with '/devices/printers/{printerId}/'
- Print job URIs are prefixed with '/jobs/printjobs/{jobId}/'
- Ownership URIs are prefixed with '/ownerships/{ownershipId}/'

# Depends on

This is a utility class with no injected dependencies. It provides static methods for URI construction.
