---
type: Component
title: Out Email Helper
description: Helper class for sending outbound email notifications for additional email address validation.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\helper\OutEmailHelper.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OutEmailHelper.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/helper/OutEmailHelper.java, title: OutEmailHelper.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.helper.OutEmailHelper`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| EMAIL_LIST_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| EMAIL_LIST_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_NAME_ADDITIONAL_EMAIL_VALIDATION | String |  |
| TEMPLATE_FOLDER_ADDITIONAL_EMAIL_VALIDATION | String |  |
| logger | EPrintLogger |  |
| FROM_EMAIL_ID | String |  |
| eosClient | EOSClient | @hpeprint.com |
| templateData | Map | @hpeprint.com |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getEosClient | EOSClient |  |  |
| setEosClient | void | EOSClient eosClient |  |
| sendAdditionalEmailAddressValidationMail | void | String userId, String emailId, String url, String firstName |  |

# Algorithm

**sendAdditionalEmailAddressValidationMail**
1. Log request with userId, emailId, and url
2. Create templateData map
3. Put AddedEmailAddress, AuthenticationString in map
4. If firstName is not empty, put FIRST_NAME in map
5. Call eosClient.sendResponsysTemplateMail with userId, FROM_EMAIL_ID, emailId, template folder, template name, email list folder, email list name, and templateData
6. Log success message

# Business context

Helper class for sending outbound email notifications for additional email address validation via EOS client. Constructs template data for validation emails using Responsys templates.

# Business rules

- If FROM_EMAIL_ID is always 'donotreply@hpeprint.com'.
- If First name is optional in template data.
- If Uses specific Responsys template and list for validation emails.

# Depends on

- [EOSClient](/components/clients/EOSClient.md)
