---
type: Component
title: Calypso Client Impl
description: Manages email address lifecycle operations with Calypso service using OAuth2 authentication and retry logic.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\CalypsoClientImpl.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T12:00:00Z }
sources:
  - { id: CalypsoClientImpl.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/http/clients/CalypsoClientImpl.java, title: CalypsoClientImpl.java }
---

`com.hp.cloudprint.http.clients.CalypsoClientImpl`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| logger | Logger |  |
| EMAILADDRESS_URL | String |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| httpclient | HttpClientUtil | @Resource |
| pumaClientWrapper | PUMAClientWrapper | @Resource |
| emailAddressUrl | String | @Override |
| emailAddressUrl | String | @Override |
| jsonbody | String | @Override |
| entity | HttpEntity | @Override |
| emailAddressUrl | String | @Override |
| emailAddressUrl | String | @Override |
| httpResponseUtil | HttpResponseUtil | @Override |
| isMarkedForExpiry | Boolean | @Override |
| respBody | String | @Override |
| retryCount | int |  |
| response | HttpResponse |  |
| httpResponseUtil | HttpResponseUtil |  |
| status | int |  |
| markedForDelete | Boolean |  |
| mapper | ObjectMapper |  |
| node | JsonNode |  |
| cloudNode | JsonNode |  |
| body | String |  |
| headersMap | Map |  |
| authToken | String |  |
| authTokenPuma | String |  |
| index | int |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| addEmailAddress | void | String emailAddress |  |
| patchEmailAddress | void | String emailAddress, long expiryInMills |  |
| deleteEmailAddress | void | String emailAddress |  |
| isMarkedForExpiry | boolean | String emailAddress |  |
| executeHttpCall | HttpResponseUtil | String emailAddressUrl, HTTPMethods method, HttpEntity entity |  |
| getMarkedForExpiry | Boolean | String responseBody |  |
| prepareErrorMessage | String | HTTPMethods method, String url, String status |  |
| prepareJsonBody | String | long expiryInMills |  |
| prepareHeaders | Map |  |  |
| trimDomainFromEmailAddress | String | String emailAdddress |  |
| getHttpclient | HttpClientUtil |  |  |
| setHttpclient | void | HttpClientUtil httpclient |  |


# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
- [HttpClientUtil](/components/http/HttpClientUtil.md)
- [PUMAClientWrapper](/components/auth/PUMAClientWrapper.md)

# Algorithm

**addEmailAddress**
1. Build email address URL: calypsoUrl + EMAILADDRESS_URL + trimmed email address
2. Execute HTTP PUT call with no entity

**patchEmailAddress**
1. Build email address URL: calypsoUrl + EMAILADDRESS_URL + trimmed email address
2. Prepare JSON body with expiryTimeInMillisec field
3. Create StringEntity with JSON content type
4. Execute HTTP PATCH call with entity

**deleteEmailAddress**
1. Build email address URL: calypsoUrl + EMAILADDRESS_URL + trimmed email address
2. Execute HTTP DELETE call with no entity
3. Log debug message

**isMarkedForExpiry**
1. Build email address URL: calypsoUrl + EMAILADDRESS_URL + trimmed email address
2. Execute HTTP GET call with no entity
3. Extract string response from HttpResponseUtil
4. Parse response body to get marked_for_expiry field
5. If field not found, throw CpInternalContingencyException
6. Return boolean value

**executeHttpCall**
1. Get retry count from config
2. Loop up to retry count times
3. Log retry attempt
4. Switch on HTTP method (GET, PUT, PATCH, DELETE) and execute corresponding httpclient call with prepared headers
5. Create HttpResponseUtil from response
6. Extract HTTP status code
7. Log API call result
8. If status 409, throw ClientConflictException (email already exists)
9. If status 400, throw ClientErrorException
10. If status 5xx, increment retry counter; if max retries reached, throw ClientErrorException; else continue loop
11. If status >= 300, throw CpInternalContingencyException
12. If response is null, throw CpInternalContingencyException
13. Break loop on success
14. Return HttpResponseUtil

**getMarkedForExpiry**
1. Create ObjectMapper
2. Parse response body as JsonNode
3. Get marked_for_expiry field from JSON
4. Return boolean value or null if not found

**prepareHeaders**
1. Create headers map
2. Get OAuth2 access token from pumaClientWrapper
3. Add Authorization header with Bearer token
4. Return headers map
5. Catch PUMAClientException and throw RuntimeException

**trimDomainFromEmailAddress**
1. Find index of '@' character
2. Return substring from 0 to index (local part only)

# Business context

HTTP client implementation for Calypso email address service. Manages email address lifecycle (add, patch, delete, check expiry) with retry logic for 5xx errors. Uses OAuth2 Bearer token authentication via PUMA.

# Business rules

- If Email addresses are trimmed to local part (before @) for Calypso API calls.
- If Status 409 indicates email already exists (ClientConflictException).
- If Status 400 indicates bad request (ClientErrorException).
- If Status 5xx triggers retry up to configured retry count.
- If All other 3xx+ statuses throw CpInternalContingencyException.
- If OAuth2 token retrieval failure throws RuntimeException.
