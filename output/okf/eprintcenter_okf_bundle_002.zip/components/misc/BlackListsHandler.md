---
type: Component
title: Black Lists Handler
description: REST handler for managing printer blacklists with GET and POST operations for collections.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\BlackListsHandler.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: BlackListsHandler.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/handlers/device/BlackListsHandler.java, title: BlackListsHandler.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.BlackListsHandler`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| userEmailAddressHelper | UserEmailAddressHelper |  |
| printerID | String | @Override |
| printerID | String | @Override |
| blackList | BlackList | @Override |
| printerOwner | Ownership | @Override |
| primaryEmailAddress | String | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |

# Algorithm

**handleGet**
1. Initialize EPrintMDC with logger and message
2. Extract printerID from request parameters and put in MDC
3. Log debug message
4. Call printerManager.getBlackListEntries with printerID
5. Convert result using EntityConverter.createBlacklist
6. Set converted blacklist in response entity
7. Finally, purge and clear MDC

**handlePost**
1. Initialize EPrintMDC with logger and message
2. Extract printerID from request parameters
3. Extract BlackList from request object
4. Try to get printer owner using printerManager.getPrinterOwner
5. Catch OwnershipNotFoundException and log it (continue processing)
6. If printerOwner is not null, get primary email address using userEmailAddressHelper
7. Catch UserIdRetrievalException, log it, build error message, set SERVER_ERROR_INTERNAL status, and return
8. Call printerManager.addEntryToBlackList with printerID, primaryEmailAddress, and converted blacklist
9. Convert result using EntityConverter.createBlacklist
10. Set converted blacklist in response entity
11. Set response status to SUCCESS_CREATED
12. Finally, purge and clear MDC

# Business context

REST handler for managing printer blacklists with GET and POST operations for collections. Retrieves printer owner and primary email address for blacklist operations. Ownership not found is logged but does not fail the operation.

# Business rules

- If Primary email address is retrieved from printer owner if available.
- If Ownership not found is logged but does not fail the operation.
- If UserIdRetrievalException returns SERVER_ERROR_INTERNAL.
- If POST returns SUCCESS_CREATED on success.

# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md)
- [UserEmailAddressHelper](/components/helpers/UserEmailAddressHelper.md)
- [EntityConverter](/components/converters/EntityConverter.md)
