---
type: Component
title: Stratus Client Impl
description: Publishes ownership claim and unclaim events to Stratus with OAuth2 authentication and multi-issuer support.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\http\clients\StratusClientImpl.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T12:00:00Z }
sources:
  - { id: StratusClientImpl.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/http/clients/StratusClientImpl.java, title: StratusClientImpl.java }
---

`com.hp.cloudprint.http.clients.StratusClientImpl`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| pumaClientWrapper | PUMAClientWrapper | @Resource |
| stratusHttpClient | StratusHttpClient | @Resource |
| AUTHORIZATION | String |  |
| BEARER | String |  |
| FQ_RESOURCE_NAME | String |  |
| EVENT_ADDED | String |  |
| SCOPE | String |  |
| DEVICE_ID | String |  |
| USER_ID | String |  |
| ACCOUNT_ID | String |  |
| STRATUS_ID | String |  |
| OWNERSHIP_ID | String |  |
| EVENT_DELETED | String |  |
| OCTOKEN_EXPECTED_ISSUER_URL | String |  |
| httpHeaders | HashMap |  |
| stratusURL | String | @Override |
| token | String | @Override |
| claimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| statusCode | int |  |
| token | String |  |
| event | StratusEventInfo |  |
| authzToken | Token |  |
| scope | List |  |
| eventAttMap | Map |  |
| expected_issuer | String |  |
| issuer | String |  |
| accountId | String |  |
| split_accountId | String[] |  |
| tenant_id | Optional |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |
| eventAttributeValueMap | Map |  |
| eventAttribute | EventAttribute |  |
| tokens | String[] |  |
| split_string | String[] |  |
| base64EncodedHeader | String |  |
| base64EncodedBody | String |  |
| base64EncodedSignature | String |  |
| base64Url | Base64 |  |
| header | String |  |
| body | String |  |
| mapper | ObjectMapper |  |
| tp | Token |  |
| stratusURL | String |  |
| token | String |  |
| unClaimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| event | StratusEventInfo |  |
| authzToken | Token |  |
| eventAttMap | Map |  |
| scope | List |  |
| expected_issuer | String |  |
| issuer | String |  |
| accountId | String |  |
| split_accountId | String[] |  |
| tenant_id | Optional |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |
| stratusURL | String |  |
| token | String |  |
| unClaimPayload | String |  |
| httpEntity | HttpEntity |  |
| response | HttpResponse |  |
| event | StratusEventInfo |  |
| eventAttMap | Map |  |
| Obj | ObjectMapper |  |
| jsonStr | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPumaClientWrapper | PUMAClientWrapper |  |  |
| setPumaClientWrapper | void | PUMAClientWrapper pumaClientWrapper |  |
| getStratusHttpClient | StratusHttpClient |  |  |
| setStratusHttpClient | void | StratusHttpClient stratusHttpClient |  |
| publishAddOwnershipToStratus | void | Ownership ownership, String tokenid |  |
| getAuthAccessToken | String | String userID |  |
| getPayloadForClaim | String | Ownership ownership, String tokenid |  |
| getEventAttributeValueMap | Map | Map<String, String> eventMap |  |
| getTenantIdFromToken | Token | String token |  |
| publishDeleteOwnershipToStratus | void | Ownership ownership, String  tokenid |  |
| getPayloadForUnClaim | String | Ownership ownership, String tokenid |  |
| publishAddOwnershipToStratusForPucToken | void | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |
| getPayloadForDeviceClaimByPuc | String | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownershipJson |  |


# Depends on

- [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
- [PUMAClientWrapper](/components/auth/PUMAClientWrapper.md)
- [StratusHttpClient](/components/misc/StratusHttpClient.md)

# Algorithm

**publishAddOwnershipToStratus**
1. Get Stratus URL from config and log
2. Get auth access token for owner user ID
3. Catch PAPIClientException and log error
4. Put Authorization header with Bearer token
5. Get claim payload using getPayloadForClaim
6. Create StringEntity with payload
7. Execute POST to Stratus URL with headers and entity
8. Check status code: if 204, log success; else log warning
9. Catch CpInternalContingencyException and log error

**getPayloadForClaim**
1. Log setting payload for claim
2. Create StratusEventInfo object
3. Get tenant ID from token using getTenantIdFromToken
4. Set resourceId (UUID), fqResourceName, event (ADDED), scopes
5. Get expected issuer from config
6. Get issuer from token
7. If issuer matches expected (AUTHZ): extract account ID from fq_tenant_id, set event attributes, set tenantResourceId
8. Else (OC): get tenant_id from tenants list, set event attributes, set tenantResourceId
9. Log claim request with printer ID and client ID
10. Set event attribute value map
11. Marshal to JSON string using ObjectMapper
12. Return JSON string

**getTenantIdFromToken**
1. Check token is not null and not empty
2. Split token by space
3. Validate format: 2 tokens, first is 'bearer'
4. Split second token by '.'
5. Base64 decode header and body
6. Configure ObjectMapper to fail on unknown properties
7. Deserialize body to Token class
8. Return Token object
9. Catch exceptions and return null

# Business context

HTTP client implementation for Stratus event publishing service. Publishes ownership claim/unclaim events to Stratus with OAuth2 Bearer token authentication. Supports both AUTHZ and OC token issuers with different tenant ID extraction logic.

# Business rules

- If Status 204 indicates successful event publishing.
- If AUTHZ issuer: extract account ID from fq_tenant_id.
- If OC issuer: extract tenant_id from tenants list, use idp_id as userId.
- If Token must be in 'Bearer <jwt>' format.
- If JWT is Base64 decoded and deserialized to Token class.
- If Event types: ADDED for claim, DELETED for unclaim.
