---
type: Component
title: Whitelist Handler
description: REST handler for managing printer whitelists with GET and POST operations.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\WhitelistHandler.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: WhitelistHandler.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/dm/handlers/device/WhitelistHandler.java, title: WhitelistHandler.java }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerID | String | @Override |
| userId | String | @Override |
| printerID | String | @Override |
| whiteList | WhiteList | @Override |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |

# Business context

WhitelistHandler manages printer whitelist operations, controlling which email addresses are allowed to send print jobs to a printer. It handles retrieval and addition of whitelist entries with proper MDC logging context.

# Algorithm

**handleGet(message)**
1. Extract userId from PUC token in request parameters using Utility.extractUIDFromPUC
2. Initialize EPrintMDC with logger and message
3. Put userId and printerId in MDC for logging context
4. Extract printerID from request parameters
5. Log debug message
6. Get active printer by printerID from printerManager
7. Get whitelist by internal printer ID from printerManager
8. Convert result using EntityConverter.createWhiteList
9. Set converted whitelist in response entity
10. Finally, purge and clear MDC

**handlePost(message)**
1. Initialize EPrintMDC with logger and message
2. Extract printerID from request parameters
3. Extract WhiteList from request object
4. Log debug message with printerID and whitelist entry count
5. Put printerID in MDC for logging context
6. Convert whitelist using EntityConverter.createWhiteList (schema to entity)
7. Call printerManager.addEntryToWhiteList with printerID and converted whitelist
8. Convert result using EntityConverter.createWhiteList (entity to schema)
9. Set converted whitelist in response entity
10. Set response status to SUCCESS_CREATED (201)
11. Finally, purge and clear MDC

# Business rules

- User ID is extracted from PUC token for authentication context
- MDC is initialized for all operations to ensure proper logging correlation
- GET returns all whitelist entries for a printer
- POST adds new entries and returns the complete updated whitelist
- POST returns HTTP 201 Created on success
- MDC is always purged and cleared in finally block to prevent context leakage

# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md) for whitelist data access
- [EntityConverter](/components/misc/EntityConverter.md) for schema/entity conversion
- [Utility](/components/misc/Utility.md) for extracting user ID from PUC token
