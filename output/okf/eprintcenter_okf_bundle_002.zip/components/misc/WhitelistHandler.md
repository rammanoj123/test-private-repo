---
type: Component
title: WhitelistHandler
description: REST handler for managing printer whitelists with GET and POST operations.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\dm\handlers\device\WhitelistHandler.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.dm.handlers.device.WhitelistHandler`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerID | String | @Override |
| userId | String | @Override |
| printerID | String | @Override |
| whiteList | WhiteList | @Override |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| handleGet | void | CPGMessage message |  |
| handlePost | void | CPGMessage message |  |
