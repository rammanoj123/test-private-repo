---
type: Component
title: LoggingInitializer
description: A servlet context listener that initializes JSON logging mode for the application.
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\LoggingInitializer.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.LoggingInitializer`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| contextInitialized | void | ServletContextEvent sce |  |
| contextDestroyed | void | ServletContextEvent sce |  |
