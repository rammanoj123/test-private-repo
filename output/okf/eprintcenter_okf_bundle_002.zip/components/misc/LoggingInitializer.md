---
type: Component
title: Logging Initializer
description: A servlet context listener that initializes JSON logging mode for the application.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\LoggingInitializer.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: LoggingInitializer.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/LoggingInitializer.java, title: LoggingInitializer.java }
---

`com.hp.cloudprint.LoggingInitializer`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| contextInitialized | void | ServletContextEvent sce |  |
| contextDestroyed | void | ServletContextEvent sce |  |

# Algorithm

**contextInitialized**
1. Call LogOutputModeController.setMode with JSON mode

**contextDestroyed**
1. No-op cleanup method

# Business context

Servlet context listener that initializes JSON logging mode for the application on startup. Configures logging output mode to JSON when the servlet context is initialized.

# Business rules

- If Logging mode is set to JSON on application startup.
- If Context destruction performs no cleanup.
