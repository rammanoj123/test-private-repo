---
type: Component
title: LoggingInitializer
description: Initializes logging configuration on servlet context startup and cleanup on shutdown.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\LoggingInitializer.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.LoggingInitializer`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| contextInitialized | void | ServletContextEvent sce |  |
| contextDestroyed | void | ServletContextEvent sce |  |
