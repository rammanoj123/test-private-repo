---
type: Component
title: Event Attribute
description: A simple data transfer object holding event attribute information with data type and string value.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\EventAttribute.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EventAttribute.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/EventAttribute.java, title: EventAttribute.java }
---

`com.hp.cloudprint.EventAttribute`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |

# Business context

Simple data transfer object holding event attribute information with data type and string value. Used to pass event metadata in structured format.

# Business rules

- If Stores event attribute data type.
- If Stores event attribute string value.
- If Provides getter/setter access to attributes.
