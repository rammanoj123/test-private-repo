---
type: Component
title: Event Attribute-eprintcenter
description: Unknown `EventAttribute`. (Description pending enrichment.)
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EventAttribute.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.EventAttribute`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| dataType | String |  |
| stringValue | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getDataType | String |  |  |
| setDataType | void | String dataType |  |
| getStringValue | String |  |  |
| setStringValue | void | String stringValue |  |

# Business context

Simple data transfer object holding event attribute information with data type and string value. Used to pass event metadata in structured format within the eprintcenter package.

# Business rules

- If Stores event attribute data type.
- If Stores event attribute string value.
- If Provides getter/setter access to attributes.
