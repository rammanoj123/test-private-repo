---
type: Component
title: Tenant
description: Data transfer object representing tenant information with roles and identifiers.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\Tenant.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: Tenant.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/Tenant.java, title: Tenant.java }
---

`com.hp.cloudprint.api.eprintcenter.Tenant`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| roles | List |  |
| tenant_fqid | String |  |
| tenant_id | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getRoles | List |  |  |
| setRoles | void | List<String> roles |  |
| getTenant_fqid | String |  |  |
| setTenant_fqid | void | String tenant_fqid |  |
| getTenant_id | String |  |  |
| setTenant_id | void | String tenant_id |  |

# Business context

Data transfer object representing tenant information with roles and identifiers. Stores tenant roles list, fully-qualified ID, and tenant ID.

# Business rules

- If Provides getter/setter access to tenant properties.
- If Stores tenant roles list.
- If Stores tenant fully-qualified ID and tenant ID.
