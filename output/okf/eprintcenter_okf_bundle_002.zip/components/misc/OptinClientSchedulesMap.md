---
type: Component
title: OptinClientSchedulesMap
description: Maps opt-in types to client-specific schedule configurations for CDCA and ACR opt-in flows.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |
| cDCAScheduleMapCDCA | Map |  |
| cDCAScheduleMapACR | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |
