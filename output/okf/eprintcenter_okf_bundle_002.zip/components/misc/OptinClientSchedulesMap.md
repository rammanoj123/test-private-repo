---
type: Component
title: Optin Client Schedules Map
description: Configuration class that stores allowed optin types and their associated schedule mappings for different clients.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OptinClientSchedulesMap.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/enums/OptinClientSchedulesMap.java, title: OptinClientSchedulesMap.java }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |
| cDCAScheduleMapCDCA | Map |  |
| cDCAScheduleMapACR | Map |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |

# Algorithm

**init**
1. Create new EnumMap for OptInEnum
2. Create CDCA schedule map with DEFAULT and S1-S6 schedules
3. Put CDCA schedule map in clientSchedules
4. Create ACR schedule map with DEFAULT and S1-S6 schedules
5. Put ACR schedule map in clientSchedules

**getClientSchedules**
1. Return clientSchedules EnumMap

# Business context

Configuration class that stores allowed optin types (CDCA, ACR) and their associated schedule mappings for different clients. Each optin type has a schedule map with DEFAULT and S1-S6 schedules.

# Business rules

- If Each schedule type has 7 entries: DEFAULT and S1-S6.
- If All schedules are in UTC time zones.
- If Schedules are 4-hour windows except DEFAULT which is 23 hours.
- If DEFAULT schedule is always present for each optin type.
