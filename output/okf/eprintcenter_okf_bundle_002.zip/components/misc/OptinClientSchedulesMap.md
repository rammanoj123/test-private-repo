---
type: Component
title: OptinClientSchedulesMap
description: Unknown `OptinClientSchedulesMap`. (Description pending enrichment.)
tags: [component, unknown]
status: draft
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\enums\OptinClientSchedulesMap.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.enums.OptinClientSchedulesMap`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| clientSchedules | EnumMap |  |
| cDCAScheduleMapCDCA | Map |  |
| cDCAScheduleMapACR | Map |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
| getClientSchedules | EnumMap |  |  |
