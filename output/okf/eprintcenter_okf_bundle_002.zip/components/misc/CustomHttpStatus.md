---
type: Component
title: Custom Http Status
description: Defines custom HTTP status codes beyond standard HTTP specifications.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CustomHttpStatus.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/CustomHttpStatus.java, title: CustomHttpStatus.java }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |

# Business context

Defines custom HTTP status codes beyond standard HTTP specifications. Provides custom status code 520 for invalid registration scenarios.

# Business rules

- If INVALID_REGISTRATION uses custom HTTP status code 520.
- If Used for non-standard error conditions specific to ePrint Center.
