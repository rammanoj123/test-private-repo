---
type: Component
title: CustomHttpStatus
description: Defines custom HTTP status code 421 for invalid printer registration scenarios.
tags: [component, unknown]
status: stable
component_type: Unknown
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\CustomHttpStatus.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.CustomHttpStatus`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| INVALID_REGISTRATION | Status |  |
