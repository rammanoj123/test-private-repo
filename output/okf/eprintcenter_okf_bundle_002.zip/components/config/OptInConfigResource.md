---
type: Component
title: Opt In Config Resource
description: REST resource for managing printer opt-in configuration for data collection, supporting both CRM and MCS systems with ink subscription options.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptInConfigResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OptInConfigResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/OptInConfigResource.java, title: OptInConfigResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptInConfigResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| IS_MCS_ENABLED | String |  |
| IS_CRM_ENABLED | String |  |
| INVALID_REQUEST_DATA | String |  |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| dataCollectionGroupType | DataCollectionGroupType | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#GET") |
| optinConfig | OptinConfig |  |
| optInXML | String |  |
| rep | Representation |  |
| startTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| optInConfig | OptinConfig | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| getActivePrinterByPrinterIDStartTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/#PUT") |
| dataCollectionGroupType | DataCollectionGroupType |  |
| numberOfSelectedOptions | int |  |
| updateOptInConfigStartTime | long |  |
| updatePrinterCloudConfigForMCSStartTime | long |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OptInConfigResource |  |  |  |
| handleGet | void |  |  |
| handlePut | void |  |  |
| isCRMEnabled | boolean |  |  |
| isMCSEnabled | boolean |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* [WpConfigurationService](/components/services/WpConfigurationService.md)

# Algorithm

**handleGet** - Retrieve opt-in configuration:
1. Generate unique log ID and extract printer ID from request
2. Retrieve opt-in data collection group type for printer
3. Create OptinConfig object
4. Populate optin subscription details from data collection group type
5. Marshal OptinConfig to XML
6. Set response entity with XML and return 200 OK

**handlePut** - Update opt-in configuration:
1. Record start time and generate unique log ID
2. Extract printer ID from request attributes
3. Get request entity representation
4. Retrieve active printer by printer ID with timing
5. Validate printer is not null, return 404 if null
6. Unmarshal and validate XML request to OptinConfig
7. Determine data collection group type from inkSubscription or inkSubscriptionV2 flags
8. Count number of selected options
9. If more than one option selected, return 400 with 'Invalid Request Data'
10. If CRM enabled, update opt-in config with timing
11. If MCS enabled, update printer cloud config for MCS with timing
12. Log total time taken
13. Return 200 OK

**isCRMEnabled** - Check if CRM enabled:
1. Query wpConfigurationService for IS_CRM_ENABLED boolean value
2. Return result

**isMCSEnabled** - Check if MCS enabled:
1. Query wpConfigurationService for IS_MCS_ENABLED boolean value
2. Return result

# Business context

Manages printer opt-in configuration for data collection supporting both CRM (Customer Relationship Management) and MCS (Managed Cloud Services) systems. Handles ink subscription options (v1 and v2) and enforces single subscription type selection. CRM and MCS updates are independent and conditionally executed based on configuration.

# Business rules

If only one subscription type can be selected at a time (inkSubscription or inkSubscriptionV2). If CRM and MCS can be independently enabled via configuration. If data collection group type must be valid (INK_USAGE_COLLECTION or INK_USAGE_COLLECTION_V2). If printer not found, return 404 NOT_FOUND. If cloud configuration not found, return 404 NOT_FOUND. If unmarshalling fails, return 400 BAD_REQUEST with 'Invalid Request Data'. If multiple subscription types selected, return 400 BAD_REQUEST.
