---
type: Component
title: Logging Config
description: Spring configuration component that initializes logging output mode to JSON format on application startup.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\config\LoggingConfig.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: LoggingConfig.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/config/LoggingConfig.java, title: LoggingConfig.java }
---

`com.hp.cloudprint.config.LoggingConfig`


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |

# Business context

Spring configuration component that initializes the application logging output mode to JSON format on startup. Ensures consistent structured logging across the ePrint Center application.

# Algorithm

**init** - Initialize logging configuration:
1. Call LogOutputModeController.setMode with LogOutputMode.JSON
2. This sets the global logging output mode to JSON format

# Business rules

If default logging mode is JSON. If initialization happens automatically via @PostConstruct annotation on application startup.

# Depends on

* `LogOutputModeController`
* `LogOutputMode`
