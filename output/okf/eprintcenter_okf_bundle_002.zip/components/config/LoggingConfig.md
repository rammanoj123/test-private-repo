---
type: Component
title: LoggingConfig
description: Initializes application logging mode to JSON format at startup
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\config\LoggingConfig.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.config.LoggingConfig`

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| init | void |  |  |
