---
type: Component
title: Consumable Subscription Config Resource
description: REST resource for managing consumable subscription configuration, allowing printers to advertise subscription services via notification system.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\ConsumableSubscriptionConfigResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: ConsumableSubscriptionConfigResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/ConsumableSubscriptionConfigResource.java, title: ConsumableSubscriptionConfigResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.ConsumableSubscriptionConfigResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| IS_MCS_ENABLED | String |  |
| IS_CRM_ENABLED | String |  |
| INVALID_REQUEST_DATA | String |  |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| notificationServiceClientHelper | NotificationServiceClientHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#GET") |
| startTime | long | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| consumableSubscriptionConfig | ConsumableSubscriptionConfig | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/consumablesubscription/#PUT") |
| printer | Printer |  |
| getActivePrinterByPrinterIDStartTime | long |  |
| consumableSubscriptionPayload | ConsumableSubscriptionPayload |  |
| link | Link |  |
| linkInXML | String |  |
| index | int |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| ConsumableSubscriptionConfigResource |  |  |  |
| handleGet | void |  |  |
| handlePut | void |  |  |
| getPrinterConfigInstance | PrinterConfig |  |  |
| sleep | void | long timeSpan, String id |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| trimDomainFromEmailAddress | String | String emailAdddress |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)
* [NotificationServiceClientHelper](/components/helpers/NotificationServiceClientHelper.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)

# Business context

Manages consumable subscription configuration for printers, allowing them to advertise ink subscription services via the notification system. Validates printer existence, encodes sensitive printer information (serial number), and posts subscription notifications to external notification service. Supports both CRM and MCS systems independently.

# Algorithm

**handleGet** - Retrieve subscription configuration (not implemented):
1. Generate unique log ID and set in MDC
2. Set response status to 501 NOT_IMPLEMENTED
3. Clear MDC

**handlePut** - Configure consumable subscription:
1. Record start time and generate unique log ID
2. Extract printer ID from request attributes
3. Get request entity representation
4. Retrieve active printer by printer ID with timing
5. Validate printer is not null, return 404 if null
6. Unmarshal and validate XML request to ConsumableSubscriptionConfig
7. Create ConsumableSubscriptionPayload with encrypted serial number (base64 encoded), model, email (domain trimmed), country, shard, and advertise flag
8. Post notification to notification service with CONSUMABLE_SUBSCRIPTION type
9. Create Link object with subscription URI
10. Marshal link to XML
11. Set response entity with XML
12. Log total time taken
13. Return 202 ACCEPTED

**trimDomainFromEmailAddress** - Extract local part from email:
1. Find index of '@' character in email address
2. If index is -1 (not found), return null
3. Return substring from start to '@' index

**sleep** - Sleep during retry attempts:
1. Log debug message with device ID and retry timespan
2. Sleep for specified timespan
3. Catch InterruptedException and log warning

# Business rules

If printer not found, return 404 NOT_FOUND. If unmarshalling fails, return 400 BAD_REQUEST with 'Invalid Request Data'. If notification posting fails, return 500 INTERNAL_ERROR. If serial number must be base64 encoded before sending to notification service. If email domain must be trimmed from printer cryptic email address. If successful subscription returns 202 ACCEPTED. If GET operation is not implemented (returns 501).
