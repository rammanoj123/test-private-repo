---
type: Component
title: Cloud Configuration Resource
description: REST resource for managing printer cloud configuration settings including email, mobile apps, SIP server, Google services, and protection mode.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CloudConfigurationResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CloudConfigurationResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/CloudConfigurationResource.java, title: CloudConfigurationResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.CloudConfigurationResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| securityDirectory | SecurityDirectory | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| printerCloudConfigurationOld | PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printerCloudConfig | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#PUT") |
| printer | Printer |  |
| uid | String |  |
| ownersAdditionalEmailAddresses | List |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| data | String |  |
| printerCloudConfigResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| objFactory | ObjectFactory |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerCloudConfig | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration | @Override, @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printerCloudConfiguration | PrinterCloudConfiguration | @Auditable(name = "/devices/printers/{PrinterID}/cloudconfiguration/#GET") |
| printer | com.hp.cloudprint.entities.Printer |  |
| cloudConfigLink | Link |  |
| data | String |  |
| objFactory | ObjectFactory |  |
| responseHeaders | Form |  |
| uid | String |  |
| tokenDO | TokenDO |  |
| whitelist | List |  |
| userId | String |  |
| userIdentities | UserIdentities |  |
| userId | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| handlePut | void |  |  |
| handleGet | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| extractUIDFromPUC | String |  |  |
| createWhitelist | List | List<OwnerAdditionalEmailAddress> ownerAdditionalEmailAddresses |  |
| updateUserEmailInWhitelistOrBlacklistOfPrinter | void | Printer printer |  |
| getUserIdFromHeader | String |  |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* [SecurityDirectory](/components/services/SecurityDirectory.md)
* [UserEmailAddressHelper](/components/helpers/UserEmailAddressHelper.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Business context

Manages printer cloud configuration settings including email printing, mobile printing, SIP server, Google services, and protection mode. When protection mode is enabled, automatically whitelists owner email addresses to ensure owners can always print. Updates whitelist/blacklist for the requesting user when protection mode changes.

# Algorithm

**handlePut** - Update cloud configuration:
1. Generate unique log ID and extract printer ID from request
2. Unmarshal and optionally validate XML request to PrinterCloudConfiguration schema
3. Retrieve active printer by printer ID
4. Retrieve existing printer cloud configuration
5. Update configuration with new settings (email, mobile, SIP, Google, protection mode)
6. If protection mode is being enabled (old=false, new=true), extract UID from PUC token
7. If UID exists, retrieve owner additional email addresses and add to whitelist
8. Retrieve updated printer cloud configuration
9. If protection mode is enabled, update user email in whitelist/blacklist for requesting user
10. Generate JAXB response object and marshal to XML
11. Set response entity with XML and return 200 OK

**handleGet** - Retrieve cloud configuration:
1. Generate unique log ID and extract printer ID
2. Retrieve active printer by printer ID
3. Retrieve printer cloud configuration
4. Create Link object with cloud config URI
5. Populate PrinterCloudConfiguration schema with configuration values (email, mobile, SIP, Google, protection mode)
6. Marshal response to XML
7. Add Cache-Control: no-store header to response
8. Return 200 OK with XML entity

**extractUIDFromPUC** - Extract user ID from token:
1. Retrieve TokenDO from request attributes using PUC_DO key
2. If TokenDO is not null, extract UID from token
3. Return UID (may be null)

**createWhitelist** - Create whitelist from owner emails:
1. Create empty ArrayList of WhiteList
2. Iterate over owner additional email addresses
3. For each address, create WhiteList entry with ALLOW privilege, PRINT feature, email address, and ALLOW_OUTBOUND_EMAIL_STATUS operation type
4. Return whitelist

**updateUserEmailInWhitelistOrBlacklistOfPrinter** - Update whitelist/blacklist for user:
1. Extract user ID from request header
2. If user ID is null, return early
3. Retrieve all user identities (primary and additional) based on user ID
4. If user identities is null, return early
5. Call printerManager to add whitelist and remove blacklist entries for user emails
6. Catch and log any exceptions (non-fatal)

# Business rules

If protection mode is being enabled, owner email addresses must be automatically added to whitelist. If protection mode is enabled, requesting user's email addresses must be added to whitelist and removed from blacklist. If XSD validation is enabled via configuration, XML requests are validated against schema. If Cache-Control: no-store header must be included in GET responses. If printer not found, return 404 NOT_FOUND. If cloud configuration not found, return 400 BAD_REQUEST. If unmarshalling fails, return 400 BAD_REQUEST.
