---
type: Component
title: Mcs Optin Config
description: Holds printer identification and opt-in group configuration for Managed Cloud Services data collection.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\schemas\mcs\McsOptinConfig.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T12:00:00Z }
sources:
  - { id: McsOptinConfig.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/schemas/mcs/McsOptinConfig.java, title: McsOptinConfig.java }
---

`com.hp.cloudprint.api.eprintcenter.schemas.mcs.McsOptinConfig`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| optinGroup | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| modelNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |
| serialNumber | String | @XmlElement(required = true), @XmlJavaTypeAdapter(CollapsedStringAdapter.class) |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinGroup | String |  |  |
| setOptinGroup | void | String value |  |
| getModelNumber | String |  |  |
| setModelNumber | void | String value |  |
| getSerialNumber | String |  |  |
| setSerialNumber | void | String value |  |

# Algorithm

**getOptinGroup** - Get optin group:
1. Return optinGroup field value

**setOptinGroup** - Set optin group:
1. Set optinGroup field to provided value

**getModelNumber** - Get model number:
1. Return modelNumber field value

**setModelNumber** - Set model number:
1. Set modelNumber field to provided value

**getSerialNumber** - Get serial number:
1. Return serialNumber field value

**setSerialNumber** - Set serial number:
1. Set serialNumber field to provided value

# Business context

JAXB-annotated XML schema class representing MCS (Managed Cloud Services) opt-in configuration for printers. Holds printer identification (model number, serial number) and opt-in group type for data collection configuration.

# Business rules

If all three fields (optinGroup, modelNumber, serialNumber) are required in XML representation. If whitespace in field values is collapsed via CollapsedStringAdapter.

# Depends on

* `XmlRootElement`
* `XmlElement`
* `CollapsedStringAdapter`
