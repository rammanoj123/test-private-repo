---
type: Component
title: Core O Auth Signature Method Factory Draft Hammer
description: Config `CoreOAuthSignatureMethodFactory_DraftHammer`. (Description pending enrichment.)
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\CoreOAuthSignatureMethodFactory_DraftHammer.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CoreOAuthSignatureMethodFactory_DraftHammer.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/security/CoreOAuthSignatureMethodFactory_DraftHammer.java, title: CoreOAuthSignatureMethodFactory_DraftHammer.java }
---

`com.hp.cloudprint.api.eprintcenter.security.CoreOAuthSignatureMethodFactory_DraftHammer`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| key | String |  |
| secretKeySpec | SecretKeySpec |  |
| mac | Mac |  |
| rawHmac | byte[] |  |
| generatedSignature | String |  |
| isValid | boolean | @Override |
| consumerSecret | String |  |
| finalTokenSecret | String |  |
| plainTextSignatureMethod | PlainTextSignatureMethod |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| generateHmacSha1Signature | String | String baseString, String consumerSecret, String tokenSecret |  |
| validateHmacSha1Signature | boolean | String baseString, String consumerSecret, String tokenSecret, String providedSignature |  |
| getSignatureMethod | OAuthSignatureMethod | String methodName, SignatureSecret signatureSecret, final String tokenSecret |  |

# Business context

Implements OAuth signature method factory supporting both HMAC-SHA1 and PLAINTEXT signature methods for OAuth authentication. Provides signature generation and verification for OAuth requests according to draft hammer specification.

# Algorithm

**generateHmacSha1Signature** - Generate HMAC-SHA1 signature:
1. Construct key as consumerSecret + '&' + (tokenSecret or empty string)
2. Create SecretKeySpec with key bytes and 'HmacSHA1' algorithm
3. Get Mac instance for 'HmacSHA1'
4. Initialize Mac with SecretKeySpec
5. Compute HMAC by calling mac.doFinal with baseString bytes
6. Encode raw HMAC bytes to Base64 string
7. Return Base64-encoded signature

**validateHmacSha1Signature** - Validate HMAC-SHA1 signature:
1. Generate signature using generateHmacSha1Signature with baseString, consumerSecret, and tokenSecret
2. Compare generated signature with provided signature
3. Return true if equal, false otherwise

**getSignatureMethod** - Get signature method by name:
1. If methodName is 'HMAC-SHA1':
   - Return anonymous OAuthSignatureMethod implementation
   - getName() returns 'HMAC-SHA1'
   - sign() calls generateHmacSha1Signature with baseString, consumer secret, and token secret
   - verify() calls validateHmacSha1Signature and throws RuntimeException if validation fails
2. Else if methodName is 'PLAINTEXT':
   - Get consumer secret from signatureSecret (default to empty string if null)
   - Default token secret to empty string if null
   - Return PlainTextSignatureMethod with consumerSecret + '&' + tokenSecret
3. Else throw UnsupportedSignatureMethodException

# Business rules

If HMAC-SHA1 signature key is constructed as consumerSecret + '&' + tokenSecret. If token secret is null, use empty string in key construction. If PLAINTEXT signature is constructed as consumerSecret + '&' + tokenSecret. If signature verification failure throws RuntimeException. If unsupported signature methods throw UnsupportedSignatureMethodException.

# Depends on

* `OAuthSignatureMethodFactory`
* `OAuthSignatureMethod`
* `SharedConsumerSecret`
* `PlainTextSignatureMethod`
