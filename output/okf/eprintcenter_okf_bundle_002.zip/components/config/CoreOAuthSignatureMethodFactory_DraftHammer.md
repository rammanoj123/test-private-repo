---
type: Component
title: CoreOAuthSignatureMethodFactory_DraftHammer
description: Provides OAuth signature method factory for generating and validating HMAC-SHA1 signatures
tags: [component, config]
status: draft
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\security\CoreOAuthSignatureMethodFactory_DraftHammer.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.security.CoreOAuthSignatureMethodFactory_DraftHammer`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| key | String |  |
| secretKeySpec | SecretKeySpec |  |
| mac | Mac |  |
| rawHmac | byte[] |  |
| generatedSignature | String |  |
| isValid | boolean | @Override |
| consumerSecret | String |  |
| finalTokenSecret | String |  |
| plainTextSignatureMethod | PlainTextSignatureMethod |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| generateHmacSha1Signature | String | String baseString, String consumerSecret, String tokenSecret |  |
| validateHmacSha1Signature | boolean | String baseString, String consumerSecret, String tokenSecret, String providedSignature |  |
| getSignatureMethod | OAuthSignatureMethod | String methodName, SignatureSecret signatureSecret, final String tokenSecret |  |
