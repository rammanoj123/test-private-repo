---
type: Component
title: E Print Center API Config
description: Singleton configuration manager for ePrint Center API that provides access to configuration values from either WpConfigurationService or XML file.
tags: [component, config]
status: stable
component_type: Config
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EPrintCenterAPIConfig.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EPrintCenterAPIConfig.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/EPrintCenterAPIConfig.java, title: EPrintCenterAPIConfig.java }
---

`com.hp.cloudprint.api.eprintcenter.EPrintCenterAPIConfig`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | Logger |  |
| objectInstance | EPrintCenterAPIConfig |  |
| wpConfigurationService | WpConfigurationService | @Resource |
| SERVICE_NAME | String | @Resource |
| maxCount | String |  |
| clientsList | List |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| EPrintCenterAPIConfig |  |  |  |
| getInstance | EPrintCenterAPIConfig |  |  |
| init | void |  |  |
| getWpConfigurationService | WpConfigurationService |  |  |
| setWpConfigurationService | void | WpConfigurationService wpConfigurationService |  |
| getBooleanValue | boolean | String key |  |
| getStringValue | String | String key |  |
| getIntValue | int | String key |  |
| getMaxCountForUserPrintHistory | int |  |  |
| getDocumentSunsetNumberOfDays | int |  |  |
| enableMigrationDateCheck | boolean |  |  |
| getSipsDeviceClassForSDApp | String |  |  |
| getRetryAfterInSecs | String |  |  |
| getKeys | Iterator | String prefix |  |
| getFirmwareVersionsForInkSubOverride | String | String dynamicKeyWithModelNumer |  |
| isOwnershipsEnabledForGetShardFromMap | boolean |  |  |
| isfallbackRequired | boolean |  |  |
| shouldLogPerformanceMetrics | boolean |  |  |
| isPlsOverRideEnabledForInstantInk | boolean |  |  |
| getInstantInkOverrideValue | int |  |  |
| isCalypsoEmailAddressReplicationEnabled | boolean |  |  |
| isCalypsoEmailAddressValidationEnabled | boolean |  |  |
| getCalypsoUrl | String |  |  |
| getCalypsoRetryCount | int |  |  |
| getCalypsoAuthToken | String |  |  |
| getFeaTTL | Long |  |  |
| getDomain | String |  |  |
| getStratusPublishUrl | String |  |  |


# Depends on

* [WpConfigurationService](/components/services/WpConfigurationService.md)
* `XMLConfiguration`

# Business context

Singleton configuration manager providing centralized access to ePrint Center API configuration values. Supports dual configuration sources: WpConfigurationService (primary) and XML file (fallback). Exposes domain-specific configuration getters for print history, document sunset, migration, Calypso integration, and Stratus event publishing.

# Algorithm

**getInstance** - Get singleton instance:
1. Check if objectInstance is null
2. If null, synchronize on class
3. Double-check if objectInstance is still null
4. Create new instance and call init()
5. Return objectInstance

**init** - Initialize configuration:
1. Check if wpConfigurationService is null
2. If null, load XMLConfiguration from EPrintCenterAPIConfig.xml resource
3. Handle ConfigurationException by throwing CpFaultException

**getBooleanValue** - Get boolean configuration value:
1. Check if wpConfigurationService is not null
2. If available, call wpConfigurationService.getBoolean with SERVICE_NAME and key
3. Otherwise, call super.getBooleanValue

**getStringValue** - Get string configuration value:
1. Check if wpConfigurationService is not null
2. If available, call wpConfigurationService.getString with SERVICE_NAME and key
3. Otherwise, call super.getStringValue

**getIntValue** - Get integer configuration value:
1. Check if wpConfigurationService is not null
2. If available, call wpConfigurationService.getInt with SERVICE_NAME and key
3. Otherwise, call super.getIntValue

**getMaxCountForUserPrintHistory** - Get max print history count:
1. Call getIntValue with 'MAX_COUNT_FOR_USER_PRINT_HISTORY' and default -1

**getDocumentSunsetNumberOfDays** - Get document sunset period:
1. Call getIntValue with 'FILE_SUNSET_PERIOD' and default 30

**enableMigrationDateCheck** - Check if migration date check enabled:
1. If wpConfigurationService is not null, call getBoolean with 'enableMigrationDateCheck' and default false
2. Otherwise return false

**isCalypsoEmailAddressReplicationEnabled** - Check if Calypso replication enabled:
1. If wpConfigurationService is not null, call getBoolean with 'calypso.emailaddress.replication' and default false
2. Otherwise return false

**getCalypsoUrl** - Get Calypso service URL:
1. If wpConfigurationService is not null, call getString with 'calypso.url' and default null
2. Otherwise return null

**getStratusPublishUrl** - Get Stratus event publishing URL:
1. If wpConfigurationService is not null, call getString with 'stratus.url' and default null
2. Otherwise return null

# Business rules

If only one instance can exist (singleton pattern). If XML configuration is fallback when WpConfigurationService is unavailable. If WpConfigurationService takes precedence over XML configuration. If default max count for user print history is -1. If default document sunset period is 30 days. If migration date check is disabled by default. If Calypso email address replication is disabled by default.
