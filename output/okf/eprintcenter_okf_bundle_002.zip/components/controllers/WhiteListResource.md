---
type: Component
title: WhiteListResource
description: REST resource for managing printer whitelist entries including adding users and retrieving whitelist with access control permissions.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\WhiteListResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.WhiteListResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| printerID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whitelistentry | JAXBElement | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whitelistEntity | com.hp.cloudprint.entities.WhiteList | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whiteListEntrySchema | WhiteListEntryType |  |
| printer | com.hp.cloudprint.entities.Printer |  |
| WhitelistID | String |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| whiteListSchema | WhiteList | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| whiteListEntity | List | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| itr | Iterator |  |
| e | List |  |
| element | com.hp.cloudprint.entities.WhiteList |  |
| entry | WhiteListEntryType |  |
| WhitelistEntryLink | Object |  |
| data | String |  |
| responseHeaders | Form |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePost | void |  |  |
| handleGet | void |  |  |

# Depends on

* `IPrinterManager`
