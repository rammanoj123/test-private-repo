---
type: Component
title: White List Resource
description: REST resource for managing printer whitelist entries including adding users and retrieving whitelist with access control permissions.
tags: [component, controller, web]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\WhiteListResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: WhiteListResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/WhiteListResource.java, title: WhiteListResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.WhiteListResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| printerID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whitelistentry | JAXBElement | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whitelistEntity | com.hp.cloudprint.entities.WhiteList | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#POST") |
| whiteListEntrySchema | WhiteListEntryType |  |
| printer | com.hp.cloudprint.entities.Printer |  |
| WhitelistID | String |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| whiteListSchema | WhiteList | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| whiteListEntity | List | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/#GET") |
| itr | Iterator |  |
| e | List |  |
| element | com.hp.cloudprint.entities.WhiteList |  |
| entry | WhiteListEntryType |  |
| WhitelistEntryLink | Object |  |
| data | String |  |
| responseHeaders | Form |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePost | void |  |  |
| handleGet | void |  |  |


# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md)

# Algorithm

**handlePost**
1. Generate log UID and set MDC context
2. Extract printer ID from request attributes
3. Unmarshal WhiteListEntryType XML from request entity
4. Create WhiteList entity and populate fields from schema
5. Map allowOutBoundMailStatus: true → ALLOW_OUTBOUND_EMAIL_STATUS, false → DENY_OUTBOUND_EMAIL_STATUS
6. Set feature, privilege, username from schema
7. Validate printer exists and is active via printerManager.getActivePrinterByPrinterID
8. Set printer reference in whitelist entity
9. Add whitelist entry via printerManager.addWhiteList
10. Set response status to SUCCESS_CREATED with location reference to new entry
11. Clear MDC in finally block

**handleGet**
1. Generate log UID and set MDC context
2. Extract printer ID from request attributes
3. Validate printer exists and is active via printerManager.getActivePrinterByPrinterID
4. Retrieve all whitelist entries for printer via printerManager.getWhiteListByInternalPrinterID
5. Iterate through whitelist entities and convert to WhiteListEntryType schema objects
6. Map entity fields to schema: id, feature, privilege, username
7. Map allowOperationType: ALLOW_OUTBOUND_EMAIL_STATUS → true, DENY_OUTBOUND_EMAIL_STATUS → false
8. Add link URI for each entry using URIHelper.getWhiteListEntryURI
9. Marshal WhiteList to XML string
10. Set response entity with custom media type and SUCCESS_OK status
11. Add Cache-Control: no-store header
12. Clear MDC in finally block

# Business context

Manages printer whitelist entries for access control, allowing administrators to specify who can send print jobs and whether outbound email status notifications are permitted. Enforces uniqueness and maximum user limits.

# Business rules

- If Printer must exist and be active before whitelist operations.
- If Duplicate whitelist entries return CONFLICT status.
- If Maximum user count exceeded returns custom status 451.
- If AllowOutBoundMailStatus true maps to ALLOW_OUTBOUND_EMAIL_STATUS, false to DENY_OUTBOUND_EMAIL_STATUS.
- If Each entry includes link to individual whitelist entry URI.
- If GET response must include Cache-Control: no-store header.
