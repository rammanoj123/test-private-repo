---
type: Component
title: OwnershipStatusResource
description: REST resource for retrieving printer ownership status based on model number, serial number, UUID, and user ID for Instant Ink service.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnershipStatusResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ownershipStatusService | OwnershipStatusService | @Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/status#POST") |
| rootUrl | String |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| response | Representation |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnershipStatusResource |  |  |  |
| setOwnershipStatusService | void | OwnershipStatusService ownershipStatusService |  |
| acceptRepresentation | void | Representation entity |  |
| unMarshalAndValidateInputForOwnershipStatus | OwnershipStatusRequest | Representation entity |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| returnResponse | void | OwnershipStatusResponse res |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |

# Depends on

* [OwnershipStatusService](/components/services/OwnershipStatusService.md)
