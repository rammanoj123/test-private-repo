---
type: Component
title: OwnershipStatusResource
description: REST resource for retrieving printer ownership status based on model number, serial number, UUID, and user ID for Instant Ink service integration.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnershipStatusResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnershipStatusResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ownershipStatusService | OwnershipStatusService | @Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/status#POST") |
| rootUrl | String |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| ownershipStatusResponse | OwnershipStatusResponse |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownershipStatusRequest | OwnershipStatusRequest |  |
| response | Representation |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnershipStatusResource |  |  |  |
| setOwnershipStatusService | void | OwnershipStatusService ownershipStatusService |  |
| acceptRepresentation | void | Representation entity |  |
| unMarshalAndValidateInputForOwnershipStatus | OwnershipStatusRequest | Representation entity |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| returnResponse | void | OwnershipStatusResponse res |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |


# Depends on

OwnershipStatusService (query ownership status), EPrintLogger (logging), EPrintMDC (MDC management), ObjectMapper (JSON serialization/deserialization), Request (HTTP request access), Response (HTTP response manipulation), Representation (entity access), StringRepresentation (JSON response wrapping), MediaType (content type specification), Status (HTTP status codes), OwnershipStatusRequest (request payload model), OwnershipStatusResponse (response payload model), Errors (error response model), Error (individual error model).

# Business context

OwnershipStatusResource provides a specialized endpoint for the Instant Ink service to query printer ownership status. It accepts POST requests with printer identification details (model number, serial number, UUID) and user ID, then returns ownership status information. This resource is designed for service-to-service integration and uses JSON for request/response payloads instead of the XML format used by other ePrint Center resources.

# Algorithm

**POST (acceptRepresentation)**: Generates unique log ID and sets in MDC → Extracts root URL from request → Unmarshals and validates JSON input to OwnershipStatusRequest object (calls unMarshalAndValidateInputForOwnershipStatus) → If validation fails, returns error response → Calls ownershipStatusService with request payload → If service returns null, calls returnErrorResponse with appropriate error code and description → Otherwise, calls returnResponse with OwnershipStatusResponse → Clears MDC in finally block.

**unMarshalAndValidateInputForOwnershipStatus**: Reads entity text from Representation → Creates ObjectMapper → Deserializes JSON to OwnershipStatusRequest object → Returns request object → On IOException, calls returnErrorResponse with INVALID_SCHEMA error and 400 BAD_REQUEST status.

**returnResponse**: Creates ObjectMapper → Serializes OwnershipStatusResponse to JSON string → Wraps in StringRepresentation with APPLICATION_JSON media type → Sets entity on response with 200 SUCCESS_OK status → On IOException, calls getErrorResponse and sets entity with 500 INTERNAL_SERVER_ERROR.

**returnErrorResponse**: Calls getErrorResponse with error code, description, and status → Wraps JSON in StringRepresentation → Sets entity on response with specified status.

**getErrorResponse**: Creates Errors object → Creates Error object with error code and description → Adds error to errors list → Creates ObjectMapper → Serializes Errors to JSON string → Returns JSON string → On JsonProcessingException, logs error and returns null.

# Business rules

1. **Service integration**: Designed specifically for Instant Ink service integration, not general user access.
2. **JSON format**: Uses JSON for request/response payloads instead of XML used by other ePrint Center resources.
3. **POST-only endpoint**: Only supports POST method at `/ownerships/status#POST`.
4. **Mandatory fields**: Model number, serial number, UUID, and user ID are required in the request payload.
5. **Error handling**: Returns structured error responses with error code and description in JSON format.
6. **Status codes**: Returns 200 for successful queries, 400 for invalid input, 500 for internal errors.
7. **Auditable**: Endpoint is tracked as `/ownerships/status#POST` for auditing purposes.
