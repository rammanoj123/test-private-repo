---
type: Component
title: VersionResource
description: Handles GET requests to return API version information as XML representation.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\VersionResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.VersionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| logUID | String | @Override, @Auditable(name = "/version/#GET") |
| rep | Representation | @Override, @Auditable(name = "/version/#GET") |
| version | Version | @Override, @Auditable(name = "/version/#GET") |
| strVersion | String | @Override, @Auditable(name = "/version/#GET") |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |
