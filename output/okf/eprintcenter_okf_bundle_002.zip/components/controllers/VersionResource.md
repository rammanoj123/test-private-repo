---
type: Component
title: Version Resource
description: REST resource that returns the current API version of the ePrintCenter service.
tags: [component, controller, web]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\VersionResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: VersionResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/VersionResource.java, title: VersionResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.VersionResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| logUID | String | @Override, @Auditable(name = "/version/#GET") |
| rep | Representation | @Override, @Auditable(name = "/version/#GET") |
| version | Version | @Override, @Auditable(name = "/version/#GET") |
| strVersion | String | @Override, @Auditable(name = "/version/#GET") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |

# Business context

Returns the current API version of the ePrintCenter service. Provides version information for API consumers to verify compatibility.

# Algorithm

**handleGet**
1. Generate unique log ID and initialize MDC context
2. Create Version schema object
3. Retrieve API version from Utility.getApiVersion()
4. Set apiVersion on Version object
5. Marshal Version object to XML string
6. Create StringRepresentation with XML media type
7. Set response entity and HTTP 200 status
8. Clear MDC context in finally block

# Business rules

- If Always returns current API version.
- If version retrieval or marshalling fails, return HTTP 500.

# Depends on

- [Utility](/components/misc/Utility.md)
