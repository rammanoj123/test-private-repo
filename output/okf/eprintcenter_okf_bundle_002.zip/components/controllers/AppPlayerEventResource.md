---
type: Component
title: AppPlayerEventResource
description: REST resource that handles app player events from printers, specifically managing screen cache deletion when app list updates occur.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AppPlayerEventResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| entityStr | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/appplayer/event/#POST") |
| xmlObject | Object |  |
| appPlayerEvent | AppPlayerEvent |  |
| printerID | String |  |
| printer | Printer |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| acceptRepresentation | void | Representation entity |  |

# Depends on

* `PrinterManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
