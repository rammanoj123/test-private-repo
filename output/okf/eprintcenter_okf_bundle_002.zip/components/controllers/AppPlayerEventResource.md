---
type: Component
title: AppPlayerEventResource
description: Handles app player events from printers to manage screen cache based on app list updates
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AppPlayerEventResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| entityStr | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/appplayer/event/#POST") |
| xmlObject | Object |  |
| appPlayerEvent | AppPlayerEvent |  |
| printerID | String |  |
| printer | Printer |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| acceptRepresentation | void | Representation entity |  |

# Depends on

* `PrinterManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
