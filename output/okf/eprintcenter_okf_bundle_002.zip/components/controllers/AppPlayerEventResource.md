---
type: Component
title: App Player Event Resource
description: REST resource that handles app player events from printers, specifically managing screen cache deletion when app list updates occur.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AppPlayerEventResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: AppPlayerEventResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/AppPlayerEventResource.java, title: AppPlayerEventResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.AppPlayerEventResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| printerManager | PrinterManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| entityStr | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/appplayer/event/#POST") |
| xmlObject | Object |  |
| appPlayerEvent | AppPlayerEvent |  |
| printerID | String |  |
| printer | Printer |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| acceptRepresentation | void | Representation entity |  |


# Depends on

* [PrinterManager](/components/services/PrinterManager.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* [Utility](/components/helpers/Utility.md)

# Algorithm

**acceptRepresentation** - Handle app player events:
1. If logging at FINER level, log received representation (catch IOException and continue)
2. If XSD validation enabled, unmarshal and validate input
3. Else unmarshal input without validation
4. Extract printerID from request attributes
5. Try to get active printer by printerID
6. If printer is null, return 404 CLIENT_ERROR_NOT_FOUND
7. If appListUpdate flag is true, delete screen cache for printer
8. Else return 200 SUCCESS_OK
9. Catch DeviceDisconnectedException and return 200 SUCCESS_OK with offline message
10. Catch JAXBException, IOException and return 400 CLIENT_ERROR_BAD_REQUEST
11. Catch generic Exception and return 500 SERVER_ERROR_INTERNAL

# Business context

Handles app player events from printers, specifically managing screen cache deletion when app list updates occur. Supports graceful handling of device offline scenarios by treating them as successful operations.

# Business rules

If screen cache is only deleted when appListUpdate flag is true. If device offline is treated as success (200 OK). If XSD validation is optional based on configuration. If printer not found returns 404 NOT_FOUND. If unmarshalling fails returns 400 BAD_REQUEST. If generic exceptions return 500 INTERNAL_ERROR.
