---
type: Component
title: AvailabilityResource
description: Checks availability of desired email address aliases for printers
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-20T00:00:00Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| desiredEmailAddressAlias | String |  |
| isAliasAvailable | boolean |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
