---
type: Component
title: Availability Resource
description: REST resource that checks if a desired email address alias is available for a printer.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: AvailabilityResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/AvailabilityResource.java, title: AvailabilityResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| desiredEmailAddressAlias | String |  |
| isAliasAvailable | boolean |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |


# Depends on

* [EmailAddressManager](/components/services/EmailAddressManager.md)
* [Utility](/components/helpers/Utility.md)

# Algorithm

**handlePost** - Check email alias availability:
1. Get printerId from request attributes
2. Get representation from request entity
3. If printerId is null, return 400 CLIENT_ERROR_BAD_REQUEST and log warning
4. Create new PrinterEmailAddress
5. Try to unmarshal and validate request XML to PrinterEmailAddress
6. Extract desiredEmailAddressAlias from printerEmailAddress
7. Try to check if alias is available using emailAddressManager
8. If alias is available, return 200 SUCCESS_OK and log info
9. Else return 409 CLIENT_ERROR_CONFLICT and log warning
10. Catch JAXBException and return 400 CLIENT_ERROR_BAD_REQUEST
11. Catch IOException and return 500 SERVER_ERROR_INTERNAL
12. Catch SAXException and return 400 CLIENT_ERROR_BAD_REQUEST
13. Catch CpExternalContingencyException and return 400 CLIENT_ERROR_BAD_REQUEST

# Business context

Checks if a desired email address alias is available for a printer. Validates printer ID, parses and validates PrinterEmailAddress XML, and checks alias availability via EmailAddressManager. Returns appropriate status codes based on availability.

# Business rules

If printer ID is required. If email alias must pass basic acceptance testing. If available alias returns 200 OK. If unavailable alias returns 409 CONFLICT. If printer ID missing returns 400 BAD_REQUEST. If unmarshalling fails returns 400 BAD_REQUEST. If IOException returns 500 INTERNAL_ERROR.
