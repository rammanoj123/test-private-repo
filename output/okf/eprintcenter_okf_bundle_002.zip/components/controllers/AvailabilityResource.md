---
type: Component
title: AvailabilityResource
description: REST resource that checks if a desired email address alias is available for a printer.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\AvailabilityResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.AvailabilityResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| emailAddressManager | EmailAddressManager | @Resource |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/availability#POST") |
| desiredEmailAddressAlias | String |  |
| isAliasAvailable | boolean |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AvailabilityResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
