---
type: Component
title: PrinterSupportedProcessingElementsResource
description: Retrieves printer supported processing elements including margins, input bins, media sizes, media types, print qualities, colors, and copy limits.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterSupportedProcessingElementsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ERROR_MESSAGE_INTERNAL_ERROR | String |  |
| ERROR_MESSAGE_INVALID_PRINTER | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| suppProcessingElms | PrinterSupportedProcessingElements |  |
| representation | com.hp.cloudprint.api.eprintcenter.schemas.PrinterSupportedProcessingElements |  |
| marginsSupp | MarginsSupported |  |
| inputBinsRep | List |  |
| inputBinRep | InputBin |  |
| mediaSizeNamesSupported | MediaSizeNamesSupported |  |
| mediaSizesRep | List |  |
| mediaTypesSupported | MediaTypesSupported |  |
| mediaTypesRep | List |  |
| printQualitiesSuppRep | List |  |
| printQualitiesSupported | Set |  |
| colorsRep | List |  |
| copiesSupported | BigInteger |  |
| data | String |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| handleGet | void |  |  |

# Depends on

* `IPrinterManager`
* `DeviceCapabilitiesManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
