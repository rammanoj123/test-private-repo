---
type: Component
title: PrinterSupportedProcessingElementsResource
description: REST resource that retrieves and returns the supported processing elements (capabilities) for a printer including input bins, media sizes, media types, print qualities, colors, margins, and copies.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterSupportedProcessingElementsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterSupportedProcessingElementsResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ERROR_MESSAGE_INTERNAL_ERROR | String |  |
| ERROR_MESSAGE_INVALID_PRINTER | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/supportedprocessingelements/#GET") |
| suppProcessingElms | PrinterSupportedProcessingElements |  |
| representation | com.hp.cloudprint.api.eprintcenter.schemas.PrinterSupportedProcessingElements |  |
| marginsSupp | MarginsSupported |  |
| inputBinsRep | List |  |
| inputBinRep | InputBin |  |
| mediaSizeNamesSupported | MediaSizeNamesSupported |  |
| mediaSizesRep | List |  |
| mediaTypesSupported | MediaTypesSupported |  |
| mediaTypesRep | List |  |
| printQualitiesSuppRep | List |  |
| printQualitiesSupported | Set |  |
| colorsRep | List |  |
| copiesSupported | BigInteger |  |
| data | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| handleGet | void |  |  |


# Depends on

IPrinterManager (get active printer by printer ID), DeviceCapabilitiesManager (get printer supported processing elements), EPrintCenterAPIConfig (configuration values: DEFAULT_MAX_COPIES_SUPPORTED_BY_PRINTER), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML marshalling), Request (HTTP request access), Response (HTTP response manipulation), StringRepresentation (XML response wrapping), MediaType (content type specification), Status (HTTP status codes), PrinterSupportedProcessingElements (entity), com.hp.cloudprint.api.eprintcenter.schemas.PrinterSupportedProcessingElements (JAXB schema object), MarginsSupported (JAXB schema object), InputBin (JAXB schema object), MediaSizeNamesSupported (JAXB schema object), MediaTypesSupported (JAXB schema object), BigInteger (copies range), Printer (printer entity), URIHelper (URI constants).

# Algorithm

**GET (handleGet)**: Generates unique log ID and sets in MDC → Extracts printer ID from URL path parameter → Retrieves active printer by printer ID via printerManager → Validates printer is not null (returns 400 if null) → Gets PrinterSupportedProcessingElements from deviceCapabilitiesManager using internal printer ID → Validates supported processing elements is not null (returns 500 if null) → Creates schema representation object → Sets margins: MARGIN_LESS if fullBleedSupported, else NONE → Iterates through input bins: for each bin, maps input bin type, name (with PHOTO_IPP→PHOTO_TRAY conversion), plex → Sets default and list of supported media size names → Sets default and list of supported media types → Iterates through print qualities and adds to representation → Sets colors: adds COLOR if supported, always adds GREY_CMY and GREY_K → Sets copies supported from printer or config default (DEFAULT_MAX_COPIES_SUPPORTED_BY_PRINTER) → Marshals representation to XML string → Sets response entity with XML and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), general exceptions (500), JAXBException (500).

# Business context

PrinterSupportedProcessingElementsResource provides comprehensive printer capability information to clients, enabling them to understand what print settings and options are supported by a specific printer. This includes input bin configurations, supported media sizes and types, print quality options, color capabilities, margin support, and copy limits. The resource performs special mapping for certain input bin types (PHOTO_IPP to PHOTO_TRAY) to maintain API compatibility and always includes baseline color support (GREY_CMY and GREY_K) regardless of printer capabilities.

# Business rules

1. **Input bin mapping**: PHOTO_IPP input bin enum is converted to PHOTO_TRAY for API response to maintain compatibility.
2. **Margin support**: Full bleed support maps to MARGIN_LESS, otherwise NONE.
3. **Color support**: GREY_CMY and GREY_K are always supported colors; COLOR support is conditional based on printer capability.
4. **Copies default**: Copies supported defaults to config value DEFAULT_MAX_COPIES_SUPPORTED_BY_PRINTER if printer value unavailable.
5. **Printer validation**: Printer must exist and be active before capability retrieval; returns 400 if printer is null after fetch, 404 if DeviceNotFoundExcpeption.
6. **Capability validation**: Supported processing elements must not be null; returns 500 if null.
7. **Auditable endpoint**: Tracked as `/devices/printers/{PrinterID}/supportedprocessingelements/#GET` for auditing purposes.
8. **Response format**: Returns XML-formatted PrinterSupportedProcessingElements schema object.
9. **Response status**: Returns 200 OK on success, 400 for null printer, 404 for printer not found, 500 for null capabilities or marshalling errors.
10. **MDC cleanup**: Always clears MDC context in finally block.
11. **Media configuration**: Each input bin includes default and list of supported media sizes and types.
12. **Print quality**: All supported print qualities from printer are included in response.
13. **Plex support**: Plex mode is included for each input bin configuration.
