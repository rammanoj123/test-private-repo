---
type: Component
title: SolutionOptInResource
description: REST resource that manages solution opt-in configurations for printers including opt-in type and schedule settings via v2 API endpoints, enforcing single opt-in type per printer constraint and supporting CDCA v1 to v2 migration.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SolutionOptInResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.SolutionOptInResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| DEFAULT_SCHEDULE | String |  |
| IS_CDCA_SCHEDULE_MIGRATION_ENABLED | String |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| optinClientSchedulesMap | OptinClientSchedulesMap | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#PUT") |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#DELETE") |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| printer | Printer | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| printerID | String | @Override, @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| optInType | String | @Auditable(name = "/v2/devices/printers/{PrinterID}/optin/{optinType}#GET") |
| schedule | String |  |
| schedules | OptinSchedules |  |
| clientSchedulesMap | EnumMap |  |
| supportedOptinTypes | Set |  |
| optinTypeSupported | boolean |  |
| supportedClientSchedules | Map |  |
| response | Response |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| rep | Representation |  |
| form | Form |  |
| schedule | String |  |
| optInType | String |  |
| printerID | String |  |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| optinSchedules | OptinSchedules |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| schedule | Schedule |  |
| supportedOptinTypes | Set |  |
| schedules | List |  |
| previousOptinType | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | com.hp.cloudprint.api.eprintcenter.schemas.json.Error |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinClientSchedulesMap | OptinClientSchedulesMap |  |  |
| setOptinClientSchedulesMap | void | OptinClientSchedulesMap optinClientSchedulesMap |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| SolutionOptInResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| validateOptInTypeAndSchedule | void | String optInType, String schedule |  |
| setSuccessResponseStatus | void | RequestType requestType, OptinSchedules schedules |  |
| getSchedule | String |  |  |
| getOptInType | String |  |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| putPrinterCloudConfiguration | void | Printer printer, String optinType, String schedule |  |
| deletePrinterCloudConfiguration | void | Printer printer, String optinType |  |
| getPrinterCloudConfiguration | OptinSchedules | Printer printer, String optinType |  |
| isUpdateRequired | boolean | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| putPrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String schedule, String printerId |  |
| deletePrinterCloudConfigurationOptin | void | PrinterCloudConfiguration printerCloudConfiguration, String optinType, String printerId |  |
| getErrorResponse | Representation | String errorCode, String errorDescription, Status status |  |


# Depends on

IPrinterManager (get active printer by printer ID), PrinterCloudConfigurationManager (get printer cloud config, update printer cloud configuration, get optin data collection group type), EPrintCenterAPIConfig (configuration values: IS_CDCA_SCHEDULE_MIGRATION_ENABLED), OptinClientSchedulesMap (get client schedules map with supported opt-in types and schedules), EPrintLogger (logging), EPrintMDC (MDC management), ObjectMapper (JSON serialization with NON_NULL inclusion), Request (HTTP request access), Response (HTTP response manipulation), Form (query parameter access), Reference (query form access), StringRepresentation (JSON response wrapping), MediaType (content type specification), Status (HTTP status codes), Timestamp (timestamp creation), System (current time millis), OptinSchedules (JSON response model), Schedule (JSON model), Errors (JSON error model), Error (JSON error model), Printer (printer entity), PrinterCloudConfiguration (cloud configuration entity), URIHelper (URI constants: PRINTER_ID, OPTIN_TYPE, SCHEDULE), RequestType (enum: PUT, DELETE, GET).

# Algorithm

**PUT (handlePut)**: Generates unique log ID and sets in MDC → Calls handleMethod(RequestType.PUT) → Clears MDC in finally block.

**DELETE (handleDelete)**: Generates unique log ID and sets in MDC → Calls handleMethod(RequestType.DELETE) → Clears MDC in finally block.

**GET (handleGet)**: Generates unique log ID and sets in MDC → Calls handleMethod(RequestType.GET) → Clears MDC in finally block.

**handleMethod**: Resets response status to null → Extracts and validates printer ID from URL (calls getPrinterID) → Extracts and validates opt-in type from URL (calls getOptInType, converts to uppercase) → Retrieves and validates printer entity (calls getPrinter) → For PUT: extracts schedule from query (calls getSchedule, defaults to 'DEFAULT', converts to uppercase) → Validates opt-in type and schedule (calls validateOptInTypeAndSchedule) → Calls putPrinterCloudConfiguration → For DELETE: calls deletePrinterCloudConfiguration → For GET: calls getPrinterCloudConfiguration to retrieve schedules → Sets success response status based on request type (calls setSuccessResponseStatus) → Catches PrinterCloudConfigurationNotFoundException and returns HTTP 404 with error JSON → Catches generic Exception and returns HTTP 500 with error JSON.

**validateOptInTypeAndSchedule**: Gets client schedules map from optinClientSchedulesMap → If map is null, returns HTTP 500 'Schedules not found at server' → Iterates through supported opt-in types to find match with optInType → If opt-in type not found, returns HTTP 400 'Invalid optin type' → If schedule provided and not in supported schedules for that type, returns HTTP 400 'Invalid schedule'.

**putPrinterCloudConfiguration**: Gets PrinterCloudConfiguration by internal printer ID → If null, returns HTTP 500 'PrinterCloudConfiguration Not Found' → Checks if update is required (calls isUpdateRequired) → If update required: calls putPrinterCloudConfigurationOptin to set fields → Calls printerCloudConfigurationManager.updatePrinterCloudConfiguration → If no update required, logs and skips update.

**deletePrinterCloudConfiguration**: Gets PrinterCloudConfiguration by internal printer ID → If null, returns HTTP 500 'PrinterCloudConfiguration Not Found' → Calls deletePrinterCloudConfigurationOptin to clear opt-in fields → Calls printerCloudConfigurationManager.updatePrinterCloudConfiguration.

**getPrinterCloudConfiguration**: Gets PrinterCloudConfiguration by internal printer ID → If null, returns HTTP 500 'PrinterCloudConfiguration Not Found' → If optinType is blank or doesn't match stored optinType, returns HTTP 404 'Optin not set' → Creates Schedule object with ID from stored schedule → Looks up schedule value from optinClientSchedulesMap → Adds schedule to OptinSchedules list and returns.

**isUpdateRequired**: Gets previous opt-in type from configuration → If previous type is blank or matches new type: if schedule matches existing schedule, returns false (no update needed) → If previous type exists and doesn't match new type: returns HTTP 409 CONFLICT 'Cannot change opt-in type' and false → If CDCA migration enabled and CDCAOptin flag is true: if new type is CDCA, clears CDCAOptin flag; if new type is not CDCA, returns HTTP 409 CONFLICT and false → Returns true (update required).

**putPrinterCloudConfigurationOptin**: Sets optinType on configuration → Sets schedule on configuration → Sets isOptinConfigSynced to 0 → Sets lastOptinUpdateTime to current timestamp.

**deletePrinterCloudConfigurationOptin**: Checks if stored opt-in type matches requested opt-in type → If match: sets optinType to null, schedule to null, isOptinConfigSynced to 0, lastOptinUpdateTime to current timestamp → If no match: returns HTTP 404 'Optin not set'.

**setSuccessResponseStatus**: If response status is null (no error occurred): For PUT, sets HTTP 201 CREATED → For DELETE, sets HTTP 204 NO_CONTENT → For GET, serializes schedules to JSON using ObjectMapper with NON_NULL inclusion, sets as entity with HTTP 200 OK.

**getSchedule**: Gets 'schedule' query parameter from request → If null, defaults to 'DEFAULT' → Converts to uppercase and returns.

**getOptInType**: Extracts optInType from URL path attributes → If blank, returns HTTP 400 'OptinType missing' → Converts to uppercase and returns.

**getPrinterID**: Extracts printerID from URL path attributes → If null, returns HTTP 400 'printerID missing' → Returns printerID.

**getPrinter**: Calls printerManager.getActivePrinterByPrinterID(printerID) → If printer is null, returns HTTP 404 'Printer not found' → Returns printer entity → Catches DeviceNotFoundExcpeption and returns HTTP 404 → Catches generic Exception and returns HTTP 500.

**getErrorResponse**: Creates Errors and Error objects → Sets serviceName='ePrintCenter', version='1.0' → Sets error code, HTTP code, and description → Adds error to errors list → Serializes to JSON string → If JsonProcessingException, returns plain error description → Returns StringRepresentation with JSON media type.

# Business context

SolutionOptInResource manages v2 opt-in configurations for printers in the ePrint Center system, supporting data collection opt-in types (such as CDCA) with schedule-based settings. It enforces a critical business constraint that only one opt-in type can be active per printer at a time, requiring deletion before changing types. The resource supports migration from legacy CDCA v1 opt-in to v2 schedule-based opt-in when enabled via configuration. All configuration changes mark the printer as not synced and update the timestamp to trigger synchronization with the device.

# Business rules

1. **Single opt-in type constraint**: Only one opt-in type can be active per printer at a time; attempting to change opt-in type without deleting first returns HTTP 409 CONFLICT 'Cannot change opt-in type'.
2. **Schedule default**: Schedule defaults to 'DEFAULT' if not provided in PUT request.
3. **Case normalization**: Opt-in type and schedule are converted to uppercase for storage and comparison.
4. **Sync flag**: IsOptinConfigSynced is set to 0 and LastOptinUpdateTime is updated on any configuration change (PUT or DELETE).
5. **CDCA migration**: When IS_CDCA_SCHEDULE_MIGRATION_ENABLED is true and CDCAOptin flag is true, v1 CDCA opt-in can only be migrated to v2 CDCA (not other types); attempting to migrate to non-CDCA type returns HTTP 409 CONFLICT; CDCAOptin flag is cleared when migrating to v2 CDCA.
6. **Opt-in type validation**: Opt-in type must be in supported types list from optinClientSchedulesMap; invalid type returns HTTP 400 'Invalid optin type'.
7. **Schedule validation**: Schedule must be in supported schedules for the opt-in type; invalid schedule returns HTTP 400 'Invalid schedule'; blank/null schedule is allowed (defaults to DEFAULT).
8. **Configuration existence**: PrinterCloudConfiguration must exist for all operations; missing configuration returns HTTP 500 'PrinterCloudConfiguration Not Found'.
9. **Delete validation**: Can only delete opt-in if type matches stored type; mismatched type returns HTTP 404 'Optin not set'.
10. **GET validation**: Stored opt-in type must match requested opt-in type; mismatch or blank stored type returns HTTP 404 'Optin not set'.
11. **No-op optimization**: If PUT request has same opt-in type and schedule as stored values, update is skipped (no database write).
12. **Auditable endpoints**: PUT tracked as `/v2/devices/printers/{PrinterID}/optin/{optinType}#PUT`, DELETE tracked as `/v2/devices/printers/{PrinterID}/optin/{optinType}#DELETE`, GET tracked as `/v2/devices/printers/{PrinterID}/optin/{optinType}#GET`.
13. **Response format**: All responses use JSON format.
14. **Response status**: PUT returns 201 CREATED, DELETE returns 204 NO_CONTENT, GET returns 200 OK with JSON schedule data on success.
15. **Error responses**: All errors return JSON with serviceName='ePrintCenter', version='1.0', error code, HTTP code, and description.
16. **MDC cleanup**: Always clears MDC context in finally block.
