---
type: Component
title: Cancel Print Resource
description: REST resource that provides an interface to cancel print jobs by job ID.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CancelPrintResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CancelPrintResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/CancelPrintResource.java, title: CancelPrintResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.CancelPrintResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |
| jobId | String | @Override, @Auditable(name = "/jobs/printjobs/{JobID}/cancel/#PUT") |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| doWork | void | String jobId |  |


# Depends on

* [PrintService](/components/services/PrintService.md)
* [EprintShardHolder](/components/helpers/EprintShardHolder.md)
* [URIHelper](/components/helpers/URIHelper.md)

# Algorithm

**handlePut** - Cancel print job:
1. Generate unique log ID and set in MDC
2. Extract job ID from request attributes
3. Set shard context from job ID
4. Log job cancel request
5. Call doWork to cancel job with retry logic
6. Catch NotFoundException and return 404 with error message
7. Catch SuccessOkPartiallyCanceledException and return 400 for already completed/canceled jobs
8. Catch MustRetryException and log warning
9. On success, set 202 ACCEPTED status and location header to job status URI
10. Clear MDC in finally block

**doWork** - Cancel job with retry:
1. Call printService.cancelJob with job ID
2. Retry up to 3 times on MustRetryException (via @EPrintRetriable annotation)

# Business context

Provides interface to cancel print jobs by job ID. Extracts job ID from request URI, sets shard context for database routing, and delegates cancellation to PrintService with automatic retry logic for transient failures.

# Business rules

If job ID must be present in request URI. If shard must be set before calling PrintService. If job not found returns 404. If already completed or canceled job returns 400. If successful cancellation returns 202 ACCEPTED with location header. If retry up to 3 times on transient failures.
