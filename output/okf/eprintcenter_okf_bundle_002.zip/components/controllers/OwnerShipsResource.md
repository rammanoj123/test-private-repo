---
type: Component
title: OwnerShipsResource
description: REST resource for managing collections of printer ownerships, supporting POST to create ownership claims, PUT to update ownership nicknames, and GET to retrieve all ownerships for a user with comprehensive printer details including PLS data, device capabilities, and cloud configuration.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnerShipsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnerShipsResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| ISSUER | String |  |
| AUTHZ | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @javax.annotation.Resource |
| productListingServiceHelper | ProductListingServiceHelper | @javax.annotation.Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| FIRMWARE_NOT_FOUND | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships#POST") |
| ownerShip | OwnerShip | @Override, @Auditable(name = "/ownerships#POST") |
| isFavorite | boolean | @Override, @Auditable(name = "/ownerships#POST") |
| printer | Printer |  |
| devOwnership | Ownership |  |
| expiryInSecs | long |  |
| allEmailIdsForUser | List |  |
| userIdentities | UserIdentities |  |
| stratusEventing | boolean |  |
| awful | HttpServletRequest |  |
| token | String |  |
| logUID | String | @Override, @Auditable(name = "/ownerships#PUT") |
| ownerShipXMLInput | OwnerShip | @Override, @Auditable(name = "/ownerships#PUT") |
| isFavorite | boolean | @Override, @Auditable(name = "/ownerships#PUT") |
| printer | Printer |  |
| ownershipEntity | Ownership |  |
| startTime | long | @Override, @Auditable(name = "/ownerships#GET") |
| shouldLogPerfMetrics | boolean | @Override, @Auditable(name = "/ownerships#GET") |
| logUID | String | @Override, @Auditable(name = "/ownerships#GET") |
| form | Form | @Override, @Auditable(name = "/ownerships#GET") |
| issuer | String | @Override, @Auditable(name = "/ownerships#GET") |
| userId | String |  |
| getMorePrinterDetails | String |  |
| getFavoritesAlso | boolean |  |
| getFavorites | String |  |
| ownershipsEntity | List |  |
| ownerUserIdentities | UserIdentities |  |
| pamCallStartTime | long |  |
| getOwnershipsStartTime | long |  |
| ownerShipsSchema | OwnerShips |  |
| ownerShips | List |  |
| printerDescription | PrinterDescription |  |
| ownerShipSchema | OwnerShip |  |
| owner | Owner |  |
| ownershipLink | Link |  |
| getPrinterDescStartTime | long |  |
| rep | Representation |  |
| ownerShipsString | String |  |
| claimDate | XMLGregorianCalendar |  |
| dateFromOwnership | Date |  |
| printerDescription | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| printerGeoLocationType | PrinterGeoLocationType |  |
| printerLocationType | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| modelNumber | String |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| printVersionSchema | PrinterVersion |  |
| gregorianCalendar | GregorianCalendar |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printer | Printer |  |
| xmlObject | Object |  |
| applicationTrace | StringBuffer |  |
| trace | StackTraceElement[] |  |
| ownerShip | OwnerShip |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnerShipsResource |  |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| acceptRepresentation | void | Representation entity |  |
| storeRepresentation | void | Representation entity |  |
| handleGet | void |  |  |
| getOwnershipClaimDate | XMLGregorianCalendar | Ownership ownership |  |
| getPrinterDescription | PrinterDescription | Printer printer, String getMorePrinterDetails |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| getInstantInkSubscriptionCongigValue | int |  |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDescription, String modelNumber |  |
| verifyPrinterStatus | Printer | String strEmailladdress, boolean isFavorite |  |
| unMarshalAndValidateOwnershipsInput | OwnerShip | Representation entity |  |
| setShardCode | void | String printerId |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| getDeviceCapabilitiesManager | DeviceCapabilitiesManager |  |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| getUserEmailAddressHelper | UserEmailAddressHelper |  |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |
| getOwnershipUserService | OwnershipUserService |  |  |


# Depends on

IPrinterManager (printer CRUD operations, ownership management, connection state retrieval, shard management), OwnershipUserService (add ownership, get ownerships for user), ProductListingServiceHelper (retrieve printer info from PLS), JAXBObjectCreationHelper (JAXB object creation, PLS mapping, optin subscription details, ink subscription configuration, supported player versions), PrinterCloudConfigurationManager (get printer cloud config, optin data collection group type), DeviceCapabilitiesManager (get printer app player elements, check SIPS support), UserEmailAddressHelper (get all user identities, get all primary and additional user identities), StratusClient (publish add ownership events to Stratus), EPrintCenterAPIConfig (configuration values: instruction page expiry, Stratus eventing enabled, instant ink override, performance metrics logging, XSD validation, APS enabled), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML marshalling/unmarshalling, schema validation, string validation, date conversion, UID extraction from PUC token), ShardUtil (shard code extraction, ID string conversion), URIHelper (ownership URI generation, print job URI generation), Request (HTTP request access), Response (HTTP response manipulation), Form (query parameter access), Representation (entity access), DatatypeFactory (XMLGregorianCalendar creation), GregorianCalendar (date handling), Calendar (timestamp generation), UUID (ownership ID generation), ExceptionUtils (root cause extraction).

# Business context

OwnerShipsResource manages the lifecycle of printer ownership relationships in the ePrint Center system. It handles three primary operations: creating new ownership claims when users register printers, updating ownership metadata (nicknames), and retrieving comprehensive ownership information for a user's printer fleet. The resource enriches printer data with information from multiple sources including Product Listing Service (PLS), device capabilities, app player configurations, and cloud settings. It supports optional detailed printer information retrieval and integrates with Stratus for event publishing when enabled. The favorite device functionality is temporarily disabled.

# Algorithm

**POST (acceptRepresentation)**: Generates unique log ID → Unmarshals and validates ownership XML input → Checks if relationship type is FAVORITE_DEVICE (rejects with 404 if true, as favorites are disabled) → Verifies printer status by email address (for favorites) or claim code (for ownership) → Creates Ownership object with generated UUID (with shard prefix), printer reference, user ID, and timestamp → Sets expiry duration from configuration → Sets nickname if provided → For favorites, retrieves all email IDs for user from PAM → Adds ownership via ownershipUserService → Returns 201 CREATED with location header → If Stratus eventing enabled, extracts authorization token and publishes event to Stratus → Handles exceptions: PrinterAlreadyOwnedException (423 LOCKED), TimeOutException (409 CONFLICT), InvalidRegistrationException (custom status), OwnershipNotFoundException (423 LOCKED), PrinterAlreadyFavoriteException (423 LOCKED), UnAuthorizedToFavoriteException (403 FORBIDDEN).

**PUT (storeRepresentation)**: Generates unique log ID → Unmarshals and validates ownership XML input → Checks if relationship type is FAVORITE_DEVICE (rejects with 404 if true) → Verifies printer status by email address → Retrieves ownership entity for printer-user combination → Updates nickname (sets to empty string if not provided) → Updates ownership via printerManager → Returns 200 OK → Handles OwnershipNotFoundException (404).

**GET (handleGet)**: Records start time → Generates unique log ID → Extracts query parameters (issuer, userId, getMorePrinterDetails, getFavorites) → Validates userId is not null/empty (400 if invalid) → Checks getFavorites flag (rejects with 404 if true, as favorites are disabled) → Retrieves all user identities from PAM based on issuer type (AUTHZ vs HPID) → Retrieves ownerships for user via ownershipUserService → For each ownership: creates OwnerShip schema with owner, relationship type, nickname, link, claim date → Gets printer description with optional details (calls getPrinterDescription) → Logs performance metrics if enabled → Marshals ownerships to XML → Returns 200 OK with XML entity.

**getPrinterDescription**: Creates PrinterDescription object → Sets printer email, geo location, printer ID, info, location address → If getMorePrinterDetails is true, sets country code or region name → Sets make/model, model number, more info, name, serial number, reserved fields, nickname, immutable ID → Converts printer version to XMLGregorianCalendar if exists → Sets UI language → Sets shard code and retrieves printer connection state (defaults to OFFLINE on error) → If getMorePrinterDetails is true and APS enabled, gets app player capabilities (calls getAppPlayerCapabilities) → Adds printer details from PLS (calls addPrinterDetailsFromPLS) → Adds printer cloud configuration (calls addPrinterCloudConfiguration) → Returns PrinterDescription.

**getAppPlayerCapabilities**: Creates AppPlayerCapabilities object → Returns empty if printer model elements is null → Creates UIConfiguration with input type and display capabilities (calls getDisplayCapabilities) → Creates PlayerInterfaceVersions with supported player and cloud UI versions (calls getSupportedPlayerVersions, getSupportedCloudUIVersions) → Sets isSipsSupported flag → Returns AppPlayerCapabilities.

**addPrinterCloudConfiguration**: Retrieves printer cloud configuration from PrinterCloudConfigurationManager → Generates JAXB object from entity → Sets on printer description → If instant ink override configured, configures ink subscription → Adds opt-in config details (calls addOptinConfigDetails).

**verifyPrinterStatus**: If favorite, gets printer by email address (including cryptic and friendly) → Otherwise, gets printer by claim code → Returns 400 if printer not found or null → Returns printer entity.

# Business rules

1. **Ownership constraints**: Only one owner can be added per printer; attempting to add a second owner returns 423 LOCKED.
2. **Favorite device disabled**: Favorite device functionality is temporarily disabled; any request with FAVORITE_DEVICE relationship type returns 404 NOT_FOUND.
3. **Printer identification**: Printers can be identified by claim code for ownership operations or email address for favorite operations.
4. **User identity retrieval**: User identities must be retrieved from PAM before ownership operations; issuer type (AUTHZ vs HPID) determines PAM call behavior.
5. **Stratus eventing**: Event publishing to Stratus is conditionally enabled via configuration flag `stratusEventingEnabled`.
6. **Instruction page expiry**: Configurable via EPrintCenterAPIConfig.getIntValue().
7. **Optional detailed information**: Query parameter `getMorePrinterDetails` triggers additional printer information retrieval including country code/region name, app player capabilities (if APS enabled), PLS data, and cloud configuration.
8. **PLS integration**: Product Listing Service integration only attempted if user ID is present in token; EPC 1.0 requests without token are ignored for PLS.
9. **Connection state**: Defaults to OFFLINE on error when retrieving printer connection state.
10. **App player capabilities**: Only included if getMorePrinterDetails is true and APS (App Player Service) is enabled.
11. **Instant ink override**: Instant ink subscription can be conditionally overridden based on configuration.
12. **Performance metrics**: Performance metrics logging is conditionally enabled and tracks PAM call timing, ownerships retrieval timing, printer description timing, and total API call timing.
13. **XSD validation**: XML schema validation is optional based on configuration flag.
14. **Mandatory fields**: Owner username and printer email address are mandatory in ownership input payloads.
15. **Nickname updates**: Nickname can be updated to empty string via PUT operation.
