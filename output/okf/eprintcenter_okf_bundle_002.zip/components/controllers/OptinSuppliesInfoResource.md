---
type: Component
title: Optin Supplies Info Resource
description: REST resource for managing supplies information opt-in settings for printers, supporting printer identification by email, claim code, or printer ID.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptinSuppliesInfoResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OptinSuppliesInfoResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/OptinSuppliesInfoResource.java, title: OptinSuppliesInfoResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| OPTIN_PARAMETER | String |  |
| printer | Printer |  |
| parameter | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| errorXml | String | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| error | Error | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| printer | Printer |  |
| printer | Printer |  |
| printer | Printer |  |
| claimCodeWithDomain | String |  |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| response | Response |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| OptinSuppliesInfoResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| getErrorXML | String | ErrorCode errorCode |  |
| getParameter | String |  |  |
| getPrinter | Printer |  |  |
| getPrinterFromEmail | Printer | String printerEmail |  |
| getPrinterFromClaimCode | Printer | String claimCode |  |
| getPrinterFromPrinterId | Printer | String printerID |  |
| handleRequestMethod | void | Printer printer, RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| putPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| deletePrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| getPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| putPrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Algorithm

**handlePut** - Enable supplies info opt-in:
1. Retrieve printer object
2. If printer is not null, delegate to handleRequestMethod with RequestType.PUT

**handleDelete** - Disable supplies info opt-in:
1. Retrieve printer object
2. If printer is not null, delegate to handleRequestMethod with RequestType.DELETE

**handleGet** - Retrieve supplies info opt-in status:
1. Retrieve printer object
2. If printer is not null, delegate to handleRequestMethod with RequestType.GET

**getPrinter** - Obtain printer from parameter:
1. Get parameter from request
2. If parameter is null, return null
3. Check if parameter contains '@' character
4. If contains '@', treat as email and call getPrinterFromEmail
5. Otherwise, treat as claim code and call getPrinterFromClaimCode
6. If printer is null from claim code, treat as printer ID and call getPrinterFromPrinterId
7. Return printer object (may be null)

**getPrinterFromEmail** - Get printer by email:
1. Call printerManager.getActivePrinterByEmailAddress
2. If printer is null, return 404
3. Catch DeviceNotFoundExcpeption and return 404
4. Catch general exceptions and return 500
5. Return printer object (may be null)

**getPrinterFromClaimCode** - Get printer by claim code:
1. If claim code is not null, append domain from configuration
2. Call printerManager.getActivePrinterByClaimCode
3. If printer is null, return 404
4. Catch DeviceNotFoundExcpeption and return 404
5. Catch general exceptions and return 500
6. Return printer object (may be null)

**getPrinterFromPrinterId** - Get printer by ID:
1. Call printerManager.getActivePrinterByPrinterID
2. If printer is null, return 404
3. Catch DeviceNotFoundExcpeption and return 404
4. Catch general exceptions and return 500
5. Return printer object (may be null)

**handleRequestMethod** - Core request processing:
1. Reset response status and entity to null
2. Route to appropriate method based on request type (PUT/DELETE/GET)
3. Catch PrinterCloudConfigurationNotFoundException and return 404
4. Catch general exceptions and return 500
5. Set success response status based on request type

**putPrinterCloudConfigurationSuppliesInfoOptin** - Update opt-in flag:
1. Set suppliesStatusOptin to true
2. Set lastOptinUpdateTime to current timestamp

**deletePrinterCloudConfigurationSuppliesInfoOptin** - Clear opt-in flag:
1. Set suppliesStatusOptin to false
2. Set lastOptinUpdateTime to current timestamp

# Business context

Manages supplies information opt-in settings for printers with flexible printer identification. Supports printer identification by email address, claim code (with domain appended), or printer ID. When opt-in is updated, triggers timestamp update.

# Business rules

If parameter containing '@' is treated as email address. If parameter without '@' is first tried as claim code, then as printer ID. If claim code must be appended with domain before lookup. If opt-in changes must trigger timestamp update. If printer not found returns 404. If cloud configuration not found returns 404. If supplies info opt-in not enabled returns 404 on GET. If PUT returns 201 CREATED. If DELETE returns 204 NO_CONTENT. If GET returns 204 NO_CONTENT.
