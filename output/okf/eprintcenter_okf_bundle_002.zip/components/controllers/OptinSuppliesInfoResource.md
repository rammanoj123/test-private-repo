---
type: Component
title: OptinSuppliesInfoResource
description: Manages supplies information opt-in configuration supporting email, claim code, or printer ID identification with PUT/DELETE/GET operations.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptinSuppliesInfoResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptinSuppliesInfoResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| OPTIN_PARAMETER | String |  |
| printer | Printer |  |
| parameter | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| errorXml | String | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| error | Error | @Override, @Auditable(name = "/devices/printers/{optinParameter}/optin/suppliesinfo/#GET") |
| printer | Printer |  |
| printer | Printer |  |
| printer | Printer |  |
| claimCodeWithDomain | String |  |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| response | Response |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| OptinSuppliesInfoResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| getErrorXML | String | ErrorCode errorCode |  |
| getParameter | String |  |  |
| getPrinter | Printer |  |  |
| getPrinterFromEmail | Printer | String printerEmail |  |
| getPrinterFromClaimCode | Printer | String claimCode |  |
| getPrinterFromPrinterId | Printer | String printerID |  |
| handleRequestMethod | void | Printer printer, RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| putPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| deletePrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| getPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| putPrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationSuppliesInfoOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
