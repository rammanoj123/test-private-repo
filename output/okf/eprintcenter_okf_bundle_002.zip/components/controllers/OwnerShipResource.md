---
type: Component
title: Owner Ship Resource
description: REST resource for managing individual ownership records, supporting GET to retrieve ownership details with printer information and DELETE to remove ownership.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OwnerShipResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OwnerShipResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/OwnerShipResource.java, title: OwnerShipResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.OwnerShipResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @Resource |
| productListingServiceHelper | ProductListingServiceHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @Resource |
| stratusClient | StratusClient | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| userHeader | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| form | Form | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownerShipId | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownershipEntity | Ownership | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| getMorePrinterDetails | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#GET") |
| ownerShipSchema | OwnerShip |  |
| printerDescription | PrinterDescription |  |
| owner | Owner |  |
| printer | Printer |  |
| ownerShipString | String |  |
| rep | Representation |  |
| claimDate | XMLGregorianCalendar |  |
| dateFromOwnership | Date |  |
| logUID | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| ownerShipId | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| queryParams | Form | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| emailAliasRetention | String | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| aliasRetentionEnum | EmailAliasRetention | @Override, @Auditable(name = "/ownerships/{OwnershipID}/#DELETE") |
| ownership | Ownership |  |
| stratusEventingEnabled | boolean |  |
| awful | HttpServletRequest |  |
| token | String |  |
| printerDescription | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| printerGeoLocationType | PrinterGeoLocationType |  |
| printerLocationType | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| modelNumber | String |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| printVersionSchema | PrinterVersion |  |
| gregorianCalendar | GregorianCalendar |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| OwnerShipResource |  |  |  |
| represent | Representation | Variant variant |  |
| getOwnerShipClaimDate | XMLGregorianCalendar | Ownership ownershipEntity |  |
| removeRepresentations | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |
| getOwnershipUserService | OwnershipUserService |  |  |
| setShardCode | void | String printerId |  |
| getDeviceCapabilitiesManager | DeviceCapabilitiesManager |  |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| getPrinterDescription | PrinterDescription | Printer printer, String  getMorePrinterDetails |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDescription, String modelNumber |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| getInstantInkSubscriptionCongigValue | int |  |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* [DeviceCapabilitiesManager](/components/services/DeviceCapabilitiesManager.md)
* [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)
* [StratusClient](/components/services/StratusClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)

# Algorithm

**represent** - Retrieve ownership details (GET):
1. Generate unique log ID and set in MDC
2. Get query parameters from request
3. Extract ownership ID from request attributes
4. Get 'getMorePrinterDetails' query parameter
5. Retrieve ownership entity by ownership ID
6. Create OwnerShip schema object
7. Set owner username from ownership entity
8. Set relationship type (FAVORITE_DEVICE or OWN_DEVICE) based on isFavorite flag
9. Set nickname from ownership entity
10. Set claim date from ownership createdAt timestamp
11. Get printer from ownership entity
12. If printer is null, return 404
13. Get printer description with optional details
14. Set printer on ownership schema
15. Marshal ownership schema to XML
16. Set response entity with XML and 200 OK status
17. Clear MDC in finally block

**removeRepresentations** - Delete ownership (DELETE):
1. Generate unique log ID and set in MDC
2. Extract ownership ID from request attributes
3. Get query parameters and extract 'emailAliasRetention' value
4. Convert emailAliasRetention to enum
5. Check if Stratus eventing is enabled via configuration
6. If Stratus enabled, retrieve ownership entity for deletion
7. Delete ownership with retention policy
8. If Stratus eventing enabled, extract authorization token from HTTP headers
9. Publish delete ownership event to Stratus
10. Clear MDC in finally block

**getPrinterDescription** - Build printer description:
1. Create PrinterDescription object
2. Set printer email address, ID, info, make and model, model number, name, serial number
3. Set reserved fields, nickname, immutable ID
4. If printer version exists, convert createdAt to XMLGregorianCalendar and set version
5. Set UI language
6. Set shard code and retrieve printer connection state (ONLINE or OFFLINE)
7. If 'getMorePrinterDetails' is true and APS enabled, get app player capabilities
8. Add printer details from PLS (Product Listing Service)
9. Add printer cloud configuration
10. Return PrinterDescription

**getAppPlayerCapabilities** - Build app player capabilities:
1. Create AppPlayerCapabilities object
2. If printer model elements is null, return empty capabilities
3. Create UIConfiguration with input type and display capabilities
4. Set UI configuration on app player capabilities
5. Create PlayerInterfaceVersions with supported player and cloud UI versions
6. Set player interface versions on app player capabilities
7. Set isSipsSupported flag
8. Return AppPlayerCapabilities

**addPrinterDetailsFromPLS** - Add PLS details:
1. Extract user ID from PUC token in request attributes
2. If user ID is not null, get complete printer info from PLS
3. Map PLS printer info to printer description for response
4. If user ID is null, skip PLS integration (EPC 1.0 request)

**addPrinterCloudConfiguration** - Add cloud config:
1. Retrieve printer cloud configuration by internal printer ID
2. Generate JAXB object from cloud configuration entity
3. If JAXB object is not null, set on printer description
4. If instant ink override is configured, configure ink subscription
5. Add opt-in config details to printer description

# Business context

Manages individual ownership records supporting GET to retrieve ownership details with comprehensive printer information and DELETE to remove ownership. Enriches printer descriptions with details from PLS, device capabilities, and cloud configuration. Publishes ownership deletion events to Stratus when enabled. Supports email alias retention policy during ownership deletion.

# Business rules

If ownership must exist before retrieval or deletion. If printer details can be optionally enriched with additional information from PLS and device capabilities. If Stratus eventing is conditionally enabled via configuration. If email alias retention policy is specified during ownership deletion. If relationship type is FAVORITE_DEVICE if favorite flag is true, otherwise OWN_DEVICE. If connection state defaults to OFFLINE on error. If app player capabilities are only included if 'getMorePrinterDetails' is true and APS is enabled. If PLS integration is only attempted if user ID is present in token.
