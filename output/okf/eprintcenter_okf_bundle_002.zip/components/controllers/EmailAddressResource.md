---
type: Component
title: Email Address Resource
description: REST resource for managing printer email addresses including friendly aliases and cryptic addresses with Calypso validation and replication.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\EmailAddressResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EmailAddressResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/EmailAddressResource.java, title: EmailAddressResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.EmailAddressResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| emailAddressManager | EmailAddressManager | @Resource |
| calypsoClient | CalypsoClient | @Autowired |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| strPrinterEmailAddress | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| xmlObject | Object | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#PUT") |
| printer | Printer |  |
| markedForExpiry | boolean |  |
| isEmailAddressLockedForDeviceOwner | boolean |  |
| sendbackObjects | Map[] |  |
| emailAddress | String |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printerEmailAddress | PrinterEmailAddress | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| strPrinterEmailAddressXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/#POST") |
| logUID | String | @Override |
| printerID | String | @Override |
| printerEmailAddress | PrinterEmailAddress | @Override |
| strPrinterEmailAddressXML | String | @Override |
| rep | Representation | @Override |
| printer | Printer | @Override |
| emailAddress | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| deleteEmailAddressFromCalypso | void | String printerEmailAddress |  |
| handlePost | void |  |  |
| handleGet | void |  |  |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getEmailAddressManager | EmailAddressManager |  |  |
| setEmailAddressManager | void | EmailAddressManager emailAddressManager |  |
| getCalypsoClient | CalypsoClient |  |  |
| setCalypsoClient | void | CalypsoClient calypsoClient |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [EmailAddressManager](/components/services/EmailAddressManager.md)
* [CalypsoClient](/components/services/CalypsoClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* [Utility](/components/helpers/Utility.md)

# Algorithm

**handlePut** - Update printer email address:
1. Extract printer ID from request attributes
2. Validate printer exists and is active via printerManager
3. Unmarshal and validate PrinterEmailAddress XML from request body
4. Check that new email is not the cryptic email address
5. If Calypso validation enabled: add email to Calypso, handle conflicts by checking expiry/lock status
6. If email marked for expiry and locked for this device owner: delete and re-add to Calypso
7. Persist email address alias via emailAddressManager
8. If Calypso replication enabled: add new email and patch existing email with lockout time
9. Return 200 SUCCESS_OK
10. On persistence failure, delete email from Calypso to maintain consistency

**handlePost** - Reset to cryptic email:
1. Extract printer ID from request attributes
2. Validate printer exists and is active
3. Update printer cryptic email address via printerManager
4. Create PrinterEmailAddress object with cryptic address
5. Marshal to XML string
6. Return XML representation with 200 SUCCESS_OK

**handleGet** - Retrieve active email:
1. Extract printer ID from request attributes
2. Retrieve printer via printerManager
3. Get active email address (friendly or cryptic)
4. Create PrinterEmailAddress object with active address
5. Marshal to XML string
6. Return XML representation with 200 SUCCESS_OK

**deleteEmailAddressFromCalypso** - Delete from Calypso:
1. Check if Calypso validation is enabled
2. If enabled: call CalypsoClient.deleteEmailAddress
3. Log any CpInternalContingencyException as warning

# Business context

Manages printer email addresses including friendly aliases and cryptic addresses with Calypso validation and replication. Validates email addresses against Calypso service, manages email address expiry and lock status for device owners. Maintains consistency between local database and Calypso service.

# Business rules

If cannot set cryptic email as friendly email (returns 409 CONFLICT). If email must be unique unless marked for expiry and locked to same owner. If Calypso validation failure returns 409 CONFLICT or 400 BAD_REQUEST. If on persistence failure, delete email from Calypso to maintain consistency. If printer not found returns 404. If returns friendly email if set, otherwise cryptic email. If always returns cryptic email address after reset.
