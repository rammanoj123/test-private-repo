---
type: Component
title: White List Entry Resource
description: REST resource that manages whitelist entries for printers, allowing control over who can send print jobs and whether outbound email status notifications are allowed.
tags: [component, controller, web]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\WhiteListEntryResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: WhiteListEntryResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/WhiteListEntryResource.java, title: WhiteListEntryResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.WhiteListEntryResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| userEmailAddressHelper | UserEmailAddressHelper | @javax.annotation.Resource |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| printerID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whiteListID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whitelistentry | JAXBElement | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| whitelistEntity | com.hp.cloudprint.entities.WhiteList | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#PUT") |
| printer | com.hp.cloudprint.entities.Printer |  |
| requestWhiteListentity | com.hp.cloudprint.entities.WhiteList |  |
| e | WhiteListEntryType |  |
| responseWhiteListentity | com.hp.cloudprint.entities.WhiteList |  |
| whiteListEntryType | WhiteListEntryType |  |
| objectfactory | com.hp.cloudprint.api.eprintcenter.schemas.ObjectFactory |  |
| element | JAXBElement |  |
| data | String |  |
| sw | StringWriter |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| whiteListID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#GET") |
| whiteListEntity | com.hp.cloudprint.entities.WhiteList |  |
| objectfactory | ObjectFactory |  |
| whiteListEntryType | WhiteListEntryType |  |
| element | JAXBElement |  |
| data | String |  |
| sw | StringWriter |  |
| responseHeaders | Form |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| whiteListID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printer | com.hp.cloudprint.entities.Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/whitelist/{WhiteListID}/#DELETE") |
| printerOwner | Ownership |  |
| primaryEmailAddress | String |  |
| existingWhiteListEntity | WhiteList |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handlePut | void |  |  |
| handleGet | void |  |  |
| handleDelete | void |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setUserEmailAddressHelper | void | UserEmailAddressHelper userEmailAddressHelper |  |


# Depends on

- [IPrinterManager](/components/services/IPrinterManager.md)
- [UserEmailAddressHelper](/components/helpers/UserEmailAddressHelper.md)

# Business context

Manages whitelist entries for printers, controlling who can send print jobs and whether outbound email status notifications are allowed. Supports CRUD operations on individual whitelist entries identified by WhiteListID.

# Algorithm

**handlePut**
1. Generate log UID and set in MDC
2. Extract printerID and whiteListID from URL path parameters
3. Unmarshal XML request payload to WhiteListEntryType
4. Retrieve printer entity via printerManager.getActivePrinterByPrinterID; validate not null
5. Retrieve existing whitelist entry by whiteListID and internal printer ID; validate exists
6. Update whitelist entity fields: feature, privilege, username, allowOperationType (derived from allowOutBoundMailStatus)
7. Set whiteListID and printer on entity
8. Call printerManager.updateWhiteList to persist changes
9. Retrieve updated whitelist entry from database
10. Convert entity to WhiteListEntryType schema
11. Marshal to XML string
12. Set response entity with custom media type (application/com.hp.eprint.common.WhiteListEntry+xml) and HTTP 200
13. Clear MDC in finally block

**handleGet**
1. Generate log UID and set in MDC
2. Extract printerID and whiteListID from URL path parameters
3. Retrieve printer entity via printerManager.getActivePrinterByPrinterID; validate not null
4. Retrieve whitelist entry by whiteListID and internal printer ID; validate exists
5. Convert entity to WhiteListEntryType schema with all fields
6. Marshal to XML string
7. Set response entity with custom media type and HTTP 200
8. Add Cache-Control: no-store header to response
9. Clear MDC in finally block

**handleDelete**
1. Generate log UID and set in MDC
2. Extract printerID and whiteListID from URL path parameters
3. Retrieve printer entity via printerManager.getActivePrinterByPrinterID; validate not null
4. Try to retrieve printer owner (catch OwnershipNotFoundException silently)
5. If owner exists, get primary email address via userEmailAddressHelper
6. Retrieve existing whitelist entry by whiteListID and internal printer ID; validate exists
7. Call printerManager.deleteWhiteListEntry with printerID, whiteListID, and primaryEmailAddress
8. Set HTTP 200 status on success
9. Clear MDC in finally block

# Business rules

- If AllowOperationType is ALLOW_OUTBOUND_EMAIL_STATUS when allowOutBoundMailStatus=true, else DENY_OUTBOUND_EMAIL_STATUS.
- If Printer must exist and be active for all operations.
- If Whitelist entry must exist before update or delete.
- If Printer owner lookup is optional for delete (OwnershipNotFoundException is caught and ignored).
- If Returns HTTP 400 for invalid XML or missing whitelist entry.
- If Returns HTTP 404 for printer not found.
- If Returns HTTP 500 for update/retrieval/marshalling failures.
- If GET response must not be cached (Cache-Control: no-store).
