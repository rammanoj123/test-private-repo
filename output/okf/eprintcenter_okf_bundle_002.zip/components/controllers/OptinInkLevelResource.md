---
type: Component
title: Optin Ink Level Resource
description: REST resource for managing ink level metrics collection opt-in settings for printers.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptinInkLevelResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OptinInkLevelResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/OptinInkLevelResource.java, title: OptinInkLevelResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptinInkLevelResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#DELETE") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/inklevel/#GET") |
| printer | Printer |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| response | Response |  |
| printerID | String |  |
| printer | Printer |  |
| errorXml | String |  |
| error | Error |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| OptinInkLevelResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| getErrorXML | String | ErrorCode errorCode |  |
| putPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| deletePrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| getPrinterCloudConfiguration | void | PrinterCloudConfiguration printerCloudConfiguration, Printer printer |  |
| putPrinterCloudConfigurationInkLevelOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationInkLevelOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)

# Algorithm

**handlePut** - Enable ink level opt-in:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.PUT
3. Clear MDC in finally block

**handleDelete** - Disable ink level opt-in:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.DELETE
3. Clear MDC in finally block

**handleGet** - Retrieve ink level opt-in status:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.GET
3. Clear MDC in finally block

**handleMethod** - Core request processing:
1. Reset response status to null
2. Extract and validate printer ID from request
3. Retrieve and validate printer object
4. Route to appropriate method based on request type (PUT/DELETE/GET)
5. Catch PrinterCloudConfigurationNotFoundException and return 404 with error XML
6. Catch general exceptions and return 500
7. Set success response status based on request type

**putPrinterCloudConfiguration** - Enable ink level opt-in:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, enable ink level opt-in flag
3. Update configuration in database
4. If configuration is null, return 500

**deletePrinterCloudConfiguration** - Disable ink level opt-in:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, disable ink level opt-in flag
3. Update configuration in database
4. If configuration is null, return 500

**getPrinterCloudConfiguration** - Retrieve opt-in status:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, check if ink level opt-in is false
3. If opt-in is false, return 404
4. If configuration is null, return 500

**putPrinterCloudConfigurationInkLevelOptin** - Update opt-in flag:
1. Set loiMetricsCollectionOptin to true
2. Set isOptinConfigSynced to 0 (needs sync)
3. Set lastOptinUpdateTime to current timestamp

**deletePrinterCloudConfigurationInkLevelOptin** - Clear opt-in flag:
1. Set loiMetricsCollectionOptin to false
2. Set isOptinConfigSynced to 0 (needs sync)
3. Set lastOptinUpdateTime to current timestamp

# Business context

Manages ink level metrics collection opt-in settings for printers. Handles enabling, disabling, and retrieving opt-in status. When opt-in is updated, triggers sync flag reset and timestamp update to ensure configuration is synchronized with devices.

# Business rules

If printer ID must be present in request. If printer must exist and be active. If configuration must exist before opt-in changes. If opt-in changes must trigger sync flag reset and timestamp update. If printer not found returns 404. If cloud configuration not found returns 404. If ink level opt-in not enabled returns 404 on GET. If PUT returns 201 CREATED. If DELETE returns 204 NO_CONTENT. If GET returns 204 NO_CONTENT.
