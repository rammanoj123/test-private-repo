---
type: Component
title: Opt In Schedule Resource
description: REST resource for retrieving available opt-in schedules for different opt-in types, providing schedule options for client applications.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\OptInScheduleResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: OptInScheduleResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/OptInScheduleResource.java, title: OptInScheduleResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.OptInScheduleResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| optinClientSchedulesMap | OptinClientSchedulesMap |  |
| logUID | String | @Override, @Auditable(name = "/v2/devices/printers/{optinType}/schedules#GET") |
| optinSchedules | OptinSchedules | @Override, @Auditable(name = "/v2/devices/printers/{optinType}/schedules#GET") |
| optinType | String |  |
| schedulesMap | EnumMap |  |
| supportedOptinTypes | Set |  |
| optinTypeSupported | boolean |  |
| response | Response |  |
| mapper | ObjectMapper |  |
| statusResponse | String |  |
| rep | Representation |  |
| optinSchedules | OptinSchedules |  |
| schedules | List |  |
| schedule | Schedule |  |
| optInType | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | com.hp.cloudprint.api.eprintcenter.schemas.json.Error |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getOptinClientSchedulesMap | OptinClientSchedulesMap |  |  |
| setOptinClientSchedulesMap | void | OptinClientSchedulesMap optinClientSchedulesMap |  |
| OptInScheduleResource |  |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| getOptinSchedules | OptinSchedules | Map<String, String> clientScheduleMap |  |
| getOptInType | String |  |  |
| getErrorResponse | Representation | String errorCode, String errorDescription, Status status |  |

# Algorithm

**handleGet** - Retrieve opt-in schedules:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.GET
3. Clear MDC in finally block

**handleMethod** - Core request processing:
1. Reset response status to null
2. Extract opt-in type from request
3. If opt-in type is null, return early
4. Retrieve schedules map from optinClientSchedulesMap
5. If optinClientSchedulesMap or schedulesMap is null, log error, set error response, return 500
6. Get supported opt-in types from schedules map keys
7. Iterate through supported types to find matching opt-in type (case-insensitive)
8. If match found, set optinTypeSupported flag and get schedules for that type
9. If opt-in type not supported, log error, set error response, return 400
10. If response status is null, serialize optinSchedules to JSON with non-null inclusion
11. Set response entity with JSON and 200 OK status
12. Catch general exceptions, log error, set error response, return 500

**getOptinSchedules** - Convert schedule map to object:
1. Create new OptinSchedules object
2. Create empty list of Schedule objects
3. Iterate over clientScheduleMap entries
4. For each entry, create Schedule object with id and value
5. Add schedule to list
6. Set schedules list on OptinSchedules object
7. Return OptinSchedules

**getOptInType** - Extract opt-in type:
1. Extract opt-in type from request attributes using URIHelper.OPTIN_TYPE key
2. If null, log bad request and set 400 status
3. Return opt-in type (may be null)

# Business context

Retrieves available opt-in schedules for different opt-in types (CDCA, ACR), providing schedule options for client applications. Validates opt-in type against supported types and returns schedules as JSON with id and value pairs.

# Business rules

If opt-in type must be one of the supported types. If invalid opt-in type returns 400 BAD_REQUEST. If missing schedules configuration returns 500 INTERNAL_ERROR. If response excludes null fields in JSON. If schedules are returned as JSON with id and value pairs.

# Depends on

* [OptinClientSchedulesMap](/components/config/OptinClientSchedulesMap.md)
