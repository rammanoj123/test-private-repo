---
type: Component
title: Device Ownership Resource
description: REST resource for managing device ownership claims, allowing users to claim ownership of printers.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\DeviceOwnershipResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: DeviceOwnershipResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/DeviceOwnershipResource.java, title: DeviceOwnershipResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/ownerships#POST") |
| printer | Printer | @Auditable(name = "/devices/printers/ownerships#POST") |
| ownerShip | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |
| devOwnership | Ownership |  |
| response | Representation |  |
| devOwnership | Ownership |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownership | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceOwnershipResource |  |  |  |
| acceptRepresentation | void | Representation entity |  |
| getResponse | void | Ownership devOwnership |  |
| getOwnership | Ownership | Printer printer, com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownerShip |  |
| fetchPrinterDetails | Printer | String printerId |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| unMarshalAndValidateOwnershipsInput | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership | Representation entity |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* [ShardUtil](/components/helpers/ShardUtil.md)

# Algorithm

**acceptRepresentation** - Claim printer ownership:
1. Generate unique log ID and set in MDC
2. Validate entity is not null, return 400 if null
3. Validate request is from service PUC (not user PUC), return 403 if user PUC
4. Unmarshal and validate ownership input from JSON
5. Fetch printer details by printer ID
6. Create Ownership object with generated UUID, printer, user ID, timestamp, and optional nickname
7. Add ownership via ownershipUserService
8. Create response with 201 CREATED status and location header
9. Catch PrinterAlreadyOwnedException and return 423 LOCKED
10. Catch IOException and return 500
11. Catch InvalidMediaTypeException and return 415
12. Catch IllegalInputArgExternalContigencyException and return 400
13. Catch DeviceNotFoundExcpeption and return 404
14. Catch general exceptions and return 500
15. Clear MDC in finally block

**getOwnership** - Create ownership entity:
1. Create new Ownership object
2. Generate ownership ID as UUID with shard prefix
3. Set printer reference
4. Set owner user ID from input
5. Set created timestamp to current time
6. If nickname is provided, set nickname
7. Return ownership object

**fetchPrinterDetails** - Get printer:
1. Call printerManager.getActivePrinterByPrinterID with printer ID
2. Return printer object

**unMarshalAndValidateOwnershipsInput** - Validate input:
1. Extract text from entity representation
2. Validate media type is APPLICATION_JSON and payload is not empty
3. Create ObjectMapper and deserialize JSON to Ownership object
4. Validate ownership object is not null
5. Validate printer ID and user ID are not blank
6. Return ownership object

# Business context

Manages device ownership claims allowing users to claim ownership of printers. Validates service PUC authentication, creates ownership records with generated UUIDs, and prevents duplicate ownership claims. Only one owner can be added per printer.

# Business rules

If only service PUC tokens are allowed for ownership claims. If user PUC tokens are rejected with 403 FORBIDDEN. If printer can only have one owner. If ownership ID is generated as UUID with shard prefix. If successful claim returns 201 CREATED with location header. If printer already owned returns 423 LOCKED. If printer not found returns 404. If invalid media type returns 415. If invalid input returns 400.
