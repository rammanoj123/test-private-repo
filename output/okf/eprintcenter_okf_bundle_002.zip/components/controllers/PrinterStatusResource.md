---
type: Component
title: PrinterStatusResource
description: REST resource that retrieves and returns the current status of a printer including connection state, printer state, queued job count, and state reasons, with support for non-blocking queries and owner verification.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterStatusResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterStatusResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| NON_BLOCKING | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| startTime | long | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| logUID | String | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| nonBlockingFlag | boolean | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| queryParams | Form | @SuppressWarnings("unchecked"), @Override, @Auditable(name = "/devices/printers/{PrinterID}/status/#GET") |
| printerID | String |  |
| printer | Printer |  |
| tokenDO | TokenDO |  |
| userId | String |  |
| getActivePrinterByPrinterIDStartTime | long |  |
| printerStatusToReturn | PrinterStatus |  |
| printerStatus | com.hp.cloudprint.devices.printer.data.PrinterStatus |  |
| printerConnectionState | ConnectionStateEnum |  |
| getPrinterConnectionStateStartTime | long |  |
| connectionState | ConnectionState |  |
| getPrinterStatusStartTime | long |  |
| responseHeaders | Form |  |
| getQueuedJobsCountStartTime | long |  |
| queuedJobsCount | int |  |
| reasons | PrinterStateReasons |  |
| printerStateReason | PrinterStateReasons.PrinterStateReason |  |
| locId | String |  |
| calendar | GregorianCalendar |  |
| xmlGregorianCalendar | XMLGregorianCalendar |  |
| ownership | Ownership |  |
| rep | Representation |  |
| objectFactory | ObjectFactory |  |
| resp | Response |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| verifyPrinterOwner | boolean | String printerID, String userId |  |
| sendData | void | PrinterStatus printStatus |  |


# Depends on

IPrinterManager (get active printer by printer ID, get printer connection state, get printer status asynchronously with/without wait, get printer owner), PrintService (get queued jobs count), EPrintCenterAPIConfig (configuration values: retry after seconds), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML marshalling, add cache headers to response), Request (HTTP request access), Response (HTTP response manipulation), Form (query parameter access), Reference (query form access), StringRepresentation (XML response wrapping), MediaType (content type specification), Status (HTTP status codes), DatatypeFactory (XMLGregorianCalendar creation), GregorianCalendar (date handling), PrinterStatus (JAXB schema object), ConnectionState (JAXB schema object), PrinterStateReasons (JAXB schema object), ObjectFactory (JAXB object factory), TokenDO (token data object), Printer (printer entity), Ownership (ownership entity), ConnectionStateEnum (connection state enum).

# Algorithm

**GET (handleGet)**: Records start time → Generates unique log ID and sets in MDC → Parses 'nonblocking' query parameter to determine blocking behavior → Extracts printer ID from URL path parameter → Validates printer ID is not null/empty → Extracts user ID from TokenDO → Verifies printer ownership (calls verifyPrinterOwner) → Returns 403 FORBIDDEN if not owner → Retrieves active printer by printer ID via printerManager → Gets printer connection state (ONLINE/OFFLINE) → If nonblocking=true, gets printer status asynchronously without wait (calls printerManager.getPrinterStatusAsynchWithoutWait) → If nonblocking=false, gets printer status asynchronously with wait (calls printerManager.getPrinterStatusAsynch) → If DeviceInfoNotAvailableException and nonblocking=true, returns HTTP 202 ACCEPTED with Retry-After header (value from ePrintCenterAPIConfig.getRetryAfterInSecs()) → If DeviceInfoNotAvailableException and blocking, returns UNKNOWN/OFFLINE status → Handles device exceptions (disconnected, unhealthy, error) by returning OFFLINE/UNKNOWN status → Gets queued jobs count from print service → Converts internal printer status to schema PrinterStatus object → Converts printer state reasons to schema format → Sets printer up time as XMLGregorianCalendar → Marshals to XML (calls sendData) → Returns HTTP 200 → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), DeviceUnknownException (404), general exceptions (500).

**verifyPrinterOwner**: Calls printerManager.getPrinterOwner(printerID) to get ownership entity → Compares userId with ownership.getOwnerUserId() → Returns true if match, false otherwise → Returns false if DeviceNotFoundExcpeption or OwnershipNotFoundException.

**sendData**: Creates ObjectFactory for JAXB → Marshals PrinterStatus to XML string using Utility.marshal → Wraps XML in StringRepresentation with MediaType.TEXT_XML → Adds cache headers to response via Utility.addCacheHeaderToResponse → Sets entity and status SUCCESS_OK on response → If JAXBException occurs, logs error and returns HTTP 500.

# Business context

PrinterStatusResource provides real-time printer status information to clients, including connection state, operational state, queued job count, and state reasons. It enforces ownership verification to ensure only printer owners can retrieve status information. The resource supports both blocking and non-blocking query modes: non-blocking queries return immediately with HTTP 202 if status is not available, while blocking queries wait for status or return UNKNOWN/OFFLINE on timeout. This design enables responsive client applications that can poll for status updates without blocking.

# Business rules

1. **Ownership verification**: Only printer owners (verified via userId from token) can retrieve status; returns 403 FORBIDDEN if not owner.
2. **Non-blocking mode**: When nonblocking=true, returns HTTP 202 ACCEPTED with Retry-After header if device info not immediately available.
3. **Blocking mode**: When nonblocking=false or not specified, waits for device info or returns UNKNOWN/OFFLINE status on timeout.
4. **Retry-After header**: Value comes from ePrintCenterAPIConfig.getRetryAfterInSecs() configuration.
5. **Connection state**: Determined independently from printer operational state; can be ONLINE or OFFLINE.
6. **Device exceptions**: Disconnected, unhealthy, or error conditions result in OFFLINE/UNKNOWN status.
7. **Queued job count**: Always included in response.
8. **Printer up time**: Converted to XMLGregorianCalendar format for XML response.
9. **Cache headers**: Added to response via Utility.addCacheHeaderToResponse.
10. **Auditable endpoint**: Tracked as `/devices/printers/{PrinterID}/status/#GET` for auditing purposes.
11. **Response format**: Returns XML-formatted PrinterStatus schema object.
12. **Response status**: Returns 200 OK on success, 202 ACCEPTED for non-blocking unavailable, 403 FORBIDDEN for non-owner, 404 for printer not found, 500 on internal errors.
13. **MDC cleanup**: Always clears MDC context in finally block.
