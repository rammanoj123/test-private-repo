---
type: Component
title: PrintJobsResource
description: REST resource for retrieving paginated print job history for a specific printer with configurable results per page and page number.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrintJobsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| errorMessage | String |  |
| form | Form |  |
| resultsPerPageStr | String |  |
| restultsPerPage | Integer |  |
| criteria | SearchJobCriteria |  |
| pageNumberStr | String |  |
| pageNumber | Integer |  |
| presults | PagedResult |  |
| jobs | Collection |  |
| dyF | DatatypeFactory |  |
| gregorianCalendar | GregorianCalendar |  |
| printJobs | PrintJobs |  |
| jobReferences | List |  |
| jobReference | JobReference |  |
| jobLnk | Link |  |
| printJobsRepresentation | String |  |
| reasons | JobStateReasonsType |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrintService | PrintService |  |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| setCorrespondingJobStateAndStateReasonInJobReference | void | JobReference jobReference, final Job job |  |


# Depends on

IPrinterManager (get active printer by printer ID), PrintService (get active jobs from current shard), EPrintLogger (logging), EPrintMDC (MDC management), EprintShardHolder (set shard context), ShardUtil (get shard code from ID string), URIHelper (get print job URI), Request (HTTP request access), Response (HTTP response manipulation), Form (query parameter access), Reference (query form access), SearchJobCriteria (job search criteria), PagedResult (paginated results), DatatypeFactory (XMLGregorianCalendar creation), GregorianCalendar (date handling), PrintJobs (JAXB schema object), JobReference (JAXB schema object), Link (JAXB schema object), JobStateReasonsType (JAXB schema object), Utility (XML marshalling), StringRepresentation (XML response wrapping), MediaType (content type specification), Status (HTTP status codes), Job (job entity), Printer (printer entity), StateReasons (state reason enum), JobStateReason (JAXB enum).

# Business context

PrintJobsResource provides access to historical print job data for a specific printer. It supports pagination to handle large job histories efficiently and converts internal job state representations to schema-compliant formats for API consumers. The resource enforces printer existence validation and sets the appropriate shard context before querying job data from the distributed database.

# Algorithm

**GET (handleGet)**: Generates unique log ID and sets in MDC → Extracts printer ID from request attributes → Sets shard context from printer ID (calls EprintShardHolder.setShard with ShardUtil.getShardCodeFromIdString) → Retrieves active printer by printer ID via printerManager → Validates printer is not null (returns 400 if null) → Gets query parameters for resultsPerPage (default 100) and pageNumber (default 1) → Creates SearchJobCriteria with printer ID, ordering (default descending), paging size (resultsPerPage), and start index ((pageNumber - 1) * resultsPerPage) → Retrieves active jobs from current shard using criteria via printService.getActiveJobsFromCurrentShard → Creates DatatypeFactory for date conversion → Creates PrintJobs object → Iterates over job results: for each job, creates JobReference with creation date (converted to XMLGregorianCalendar), user name (originating user ID), state and state reason (calls setCorrespondingJobStateAndStateReasonInJobReference), name, job ID, and link (URIHelper.getPrintJobURI) → Adds JobReference to list → Sets page number, results per page, and calculates number of pages (ceiling of total results / results per page) → Marshals PrintJobs to XML → Sets response entity with XML and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), general exceptions (500).

**setCorrespondingJobStateAndStateReasonInJobReference**: Creates JobStateReasonsType object → Switches on job state: ACCEPTING → sets PENDING state; ACCEPTED → sets OPENED state; PROCESSING → sets PROCESSING state with JOB_TRANSFORMING reason; CANCEL_IN_PROGRESS → sets PROCESSING state with JOB_CANCELED_BY_USER reason; CANCELLED → sets CANCELED state with JOB_CANCELED_BY_USER reason; PARTIALLY_CANCELLED → sets CANCELED state with JOB_CANCELED_BY_USER reason; ERROR → sets ABORTED state, checks state reason for FEATURE_BLOCKED (maps to EMAIL_BLOCKED) or maps state reason to StateReasons enum (defaults to UNKNOWN if not found); COMPLETED → sets COMPLETED state; SUSPENDED → sets PENDING state; COMPLETED_WITH_ERROR → sets COMPLETED_WITH_ERROR state; default → sets PROCESSING state with UNKNOWN reason and logs warning → Sets job state reasons on job reference.

# Business rules

1. **Pagination defaults**: Results per page defaults to 100 if not specified; page number defaults to 1 if not specified.
2. **Ordering**: Jobs are ordered by default ordering descending (most recent first).
3. **Number of pages calculation**: Calculated as ceiling of total results divided by results per page.
4. **Shard context**: Shard must be set based on printer ID before job queries to ensure correct database routing.
5. **Printer validation**: Printer must exist and be active before job retrieval; returns 400 if printer is null, 404 if DeviceNotFoundExcpeption.
6. **Job state mapping**: Internal job states are mapped to schema-compliant states following specific rules: ACCEPTING→PENDING, ACCEPTED→OPENED, PROCESSING→PROCESSING (JOB_TRANSFORMING), CANCEL_IN_PROGRESS→PROCESSING (JOB_CANCELED_BY_USER), CANCELLED/PARTIALLY_CANCELLED→CANCELED (JOB_CANCELED_BY_USER), ERROR→ABORTED (with FEATURE_BLOCKED→EMAIL_BLOCKED or mapped state reason), COMPLETED→COMPLETED, SUSPENDED→PENDING, COMPLETED_WITH_ERROR→COMPLETED_WITH_ERROR, unknown→PROCESSING (UNKNOWN).
7. **State reason handling**: ERROR state checks for FEATURE_BLOCKED to map to EMAIL_BLOCKED; unknown state reasons default to UNKNOWN; unexpected states log warning.
8. **Auditable endpoint**: Tracked as `/devices/printers/{PrinterID}/printjobs/#GET` for auditing purposes.
9. **Date conversion**: Job creation dates are converted to XMLGregorianCalendar format for XML response.
