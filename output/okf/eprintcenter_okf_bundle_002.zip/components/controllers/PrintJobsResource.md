---
type: Component
title: PrintJobsResource
description: Handles GET requests to retrieve paginated print job history for a printer with job state and reason mapping.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrintJobsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrintJobsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printService | PrintService | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/printjobs/#GET") |
| errorMessage | String |  |
| form | Form |  |
| resultsPerPageStr | String |  |
| restultsPerPage | Integer |  |
| criteria | SearchJobCriteria |  |
| pageNumberStr | String |  |
| pageNumber | Integer |  |
| presults | PagedResult |  |
| jobs | Collection |  |
| dyF | DatatypeFactory |  |
| gregorianCalendar | GregorianCalendar |  |
| printJobs | PrintJobs |  |
| jobReferences | List |  |
| jobReference | JobReference |  |
| jobLnk | Link |  |
| printJobsRepresentation | String |  |
| reasons | JobStateReasonsType |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| getPrinterManager | IPrinterManager |  |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrintService | PrintService |  |  |
| setPrintService | void | PrintService printService |  |
| handleGet | void |  |  |
| setCorrespondingJobStateAndStateReasonInJobReference | void | JobReference jobReference, final Job job |  |

# Depends on

* `IPrinterManager`
* `PrintService`
* `Form`
