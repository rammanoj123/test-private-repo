---
type: Component
title: Eprint Center Health Controller
description: Health check controller that monitors internal and external dependencies for ePrint Center including databases, services, and channels.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\healthcheck\EprintCenterHealthController.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: EprintCenterHealthController.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/healthcheck/EprintCenterHealthController.java, title: EprintCenterHealthController.java }
---

`com.hp.cloudprint.api.eprintcenter.healthcheck.EprintCenterHealthController`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | Logger |  |
| LOG | EPrintLogger |  |
| HEALTH_CHECK_NAME_SUFFIX | String |  |
| GEN2_CALYPSO_HEALTH_CHECK | String |  |
| ULS_HEALTH_CHECK | String |  |
| EPC_PLATFORM | String |  |
| DISABLE_PAM_LOOKUP_FOR_USER_IDENTITIES | String |  |
| ULS_ABOUT_URL | String |  |
| ULS_PROXY_ENABLED | String |  |
| ULS_PROXY_HOST | String |  |
| ULS_PROXY_PORT | String |  |
| comboPooledDataSource | ComboPooledDataSource |  |
| jdbcUrl | String |  |
| hostName | String |  |
| uri | URI |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| shardDS | ComboPooledDataSource |  |
| hostName | String |  |
| shardUpCountMinThreshold | int |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| tigaseDS | ComboPooledDataSource |  |
| hostName | String |  |
| xmppRoutingDataSource | XmppRoutingDataSource |  |
| shardDataSourceProvider | ShardDataSourceProvider |  |
| shardDSMap | Map |  |
| xmppDirectory | XMPPDirectory |  |
| shardCodes | Set |  |
| shardCodesItr | Iterator |  |
| shardCode | String |  |
| xmppServerGroup | XmppServerGroup |  |
| channelIP | String |  |
| plsServiceURL | String |  |
| authzserviceurl | String |  |
| pamServiceURL | String |  |
| ulsServiceURL | String |  |
| pumaServiceURL | String |  |
| pdsAboutUrl | String |  |
| pdsServiceURL | String |  |
| outBoundEmailServiceURL | String |  |
| applicationContext | ApplicationContext |  |
| eprintUserDirectoryDataSource | ComboPooledDataSource |  |
| jdbcUrl | String |  |
| hostName | String |  |
| GEN2_CALYPSO_URL | String |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| initialize | void |  |  |
| cpgDBHealthCheck | void |  |  |
| getEprintDirDS | ComboPooledDataSource |  |  |
| getDetails | String | ComboPooledDataSource comboPooledDataSource |  |
| getHostName | String | String url |  |
| shardDBHealthCheck | void |  |  |
| getGroupType | GroupType |  |  |
| getThresholdForShardHealth | int |  |  |
| getShardDetails | String | DataSource shardDS |  |
| getShardDataSourceProvider | ShardDataSourceProvider |  |  |
| tigaseDBHealthCheck | void |  |  |
| getTigaseDBDataSource | DataSource | String shardCode |  |
| getTigaseDbGroupType | GroupType |  |  |
| getThresholdForTigaseDbHealth | int |  |  |
| channelHealthCheck | void |  |  |
| plsHealthCheck | void |  |  |
| idmHealthCheck | void |  |  |
| authzHealthCheck | void |  |  |
| pamHealthCheck | void |  |  |
| ulsHealthCheck | void |  |  |
| pumaHealthCheck | void |  |  |
| pdsHealthCheck | void |  |  |
| outBoundEmailHealthCheck | void |  |  |
| eprintUserDirectoryHealthCheck | void |  |  |
| gen2CalypsoHealthCheck | void |  |  |
| constructAboutContextPathFromServiceContext | String | String serviceContextPath |  |
| getWpConfigurationServiceinstance | WpConfigurationService |  |  |

# Algorithm

**initialize** - Initialize all health checks:
1. Log and call cpgDBHealthCheck
2. Log and call shardDBHealthCheck
3. Log and call tigaseDBHealthCheck
4. Log and call channelHealthCheck
5. Log and call plsHealthCheck
6. Log and call idmHealthCheck
7. Log and call authzHealthCheck
8. Log and call pdsHealthCheck
9. Log and call eprintUserDirectoryHealthCheck
10. Log and call gen2CalypsoHealthCheck

**shardDBHealthCheck** - Check shard databases:
1. Get ShardDataSourceProvider instance
2. Get shard datasource map
3. If map is null or empty, log warning
4. Else iterate through shard codes
5. For each shard, get datasource and extract hostname
6. Add database check for each shard with CRITICAL type and INTERNAL scope
7. Get threshold for shard health from config
8. Set strategy for SHARD_DB group type with threshold

**plsHealthCheck** - Check Product Listing Service:
1. Get PLS service URL from config
2. Construct about context path from root URI
3. Log health check URL
4. If proxy is enabled, add health check with proxy settings
5. Else add health check without proxy

**gen2CalypsoHealthCheck** - Check Gen2 Calypso service:
1. Get Calypso URL from config
2. Log endpoint URL
3. If proxy is required, add health check with proxy host and port
4. Else add health check without proxy

# Business context

Health check controller that monitors internal and external dependencies for ePrint Center. Checks cpgDB and shard databases, Tigase databases for XMPP, external services (PLS, ULS, Authz, PDS, Calypso), and channel connectivity. Configures health check strategies and thresholds for each dependency type.

# Business rules

If minimum threshold for shard health is configurable. If all shard checks are CRITICAL and INTERNAL. If PLS health check is NON_CRITICAL and EXTERNAL. If Calypso health check is CRITICAL and EXTERNAL. If proxy usage is configurable for external services.

# Depends on

* [ShardDataSourceProvider](/components/services/ShardDataSourceProvider.md)
* [WpConfigurationService](/components/services/WpConfigurationService.md)
* [XmppRoutingDataSource](/components/services/XmppRoutingDataSource.md)
* [XMPPDirectory](/components/services/XMPPDirectory.md)
