---
type: Component
title: SuggestionsResource
description: Handles POST requests to generate minimum five email address suggestions for printers based on user hints.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SuggestionsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| MIN_SUGGESTIONS | int |  |
| emailAddressManager | EmailAddressManager | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| hints | EmailAddressGenerationHints |  |
| firstName | String |  |
| lastName | String |  |
| screenName | String |  |
| desiredAlias | String |  |
| userEmailAddress | String |  |
| suggestionsListForAliases | List |  |
| suggestedEmailAddress | EmailAddressSuggestions |  |
| emailAddressList | EmailAddressList |  |
| printerEmailAddress | PrinterEmailAddress |  |
| dataToBeReturned | String |  |
| responseHeaders | Form |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SuggestionsResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
