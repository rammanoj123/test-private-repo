---
type: Component
title: SuggestionsResource
description: REST resource that generates email address suggestions for printers based on user-provided hints such as first name, last name, screen name, desired alias, and account email.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\SuggestionsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.SuggestionsResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| MIN_SUGGESTIONS | int |  |
| emailAddressManager | EmailAddressManager | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| rep | Representation | @Override, @Auditable(name = "/devices/printers/{PrinterID}/emailaddress/suggestions#POST") |
| hints | EmailAddressGenerationHints |  |
| firstName | String |  |
| lastName | String |  |
| screenName | String |  |
| desiredAlias | String |  |
| userEmailAddress | String |  |
| suggestionsListForAliases | List |  |
| suggestedEmailAddress | EmailAddressSuggestions |  |
| emailAddressList | EmailAddressList |  |
| printerEmailAddress | PrinterEmailAddress |  |
| dataToBeReturned | String |  |
| responseHeaders | Form |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| SuggestionsResource |  |  |  |
| handlePost | void |  |  |

# Depends on

* `EmailAddressManager`
