---
type: Component
title: PrinterOwnerResource
description: Handles GET requests to retrieve printer owner information as XML representation.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterOwnerResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerEntity | Ownership | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwner | Owner |  |
| xmlRepresentation | Representation |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrinterManager | IPrinterManager |  |  |
| handleGet | void |  |  |
