---
type: Component
title: PrinterOwnerResource
description: REST resource for retrieving printer owner information by printer ID, returning the owner's username in XML format.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterOwnerResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterOwnerResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| LOG | EPrintLogger |  |
| MDC | EPrintMDC |  |
| printerManager | IPrinterManager |  |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerEntity | Ownership | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwnerXML | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/owner/") |
| printerOwner | Owner |  |
| xmlRepresentation | Representation |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| getPrinterManager | IPrinterManager |  |  |
| handleGet | void |  |  |

# Business context

PrinterOwnerResource provides a simple endpoint to retrieve the owner of a specific printer. It returns the owner's username in an XML-formatted Owner schema object. This resource is used by clients that need to identify the current owner of a printer without retrieving the full ownership details.

# Algorithm

**GET (handleGet)**: Extracts printer ID from request attributes → Retrieves printer owner (Ownership entity) via printerManager.getPrinterOwner(printerId) → Creates Owner schema object → Sets username from ownership entity (ownership.getOwnerUserId()) → Marshals Owner to XML → Wraps in StringRepresentation with TEXT_XML media type → Sets response entity with XML and 200 OK status → Handles DeviceNotFoundExcpeption (404), OwnershipNotFoundException (404), general exceptions (500).

# Business rules

1. **Printer validation**: Printer must exist before owner retrieval; returns 404 if DeviceNotFoundExcpeption.
2. **Ownership validation**: Ownership must exist for the printer; returns 404 if OwnershipNotFoundException.
3. **Auditable endpoint**: Tracked as `/devices/printers/{PrinterID}/owner/` for auditing purposes.
4. **Response format**: Returns XML-formatted Owner schema object with username field.
5. **Response status**: Returns 200 OK on success, 404 if printer or ownership not found, 500 on internal errors.

# Depends on

IPrinterManager (get printer owner), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML marshalling), Request (HTTP request access), Response (HTTP response manipulation), StringRepresentation (XML response wrapping), MediaType (content type specification), Status (HTTP status codes), Owner (JAXB schema object), Ownership (ownership entity), ObjectFactory (JAXB object factory).
