---
type: Component
title: PrinterDefaultsProcessingElementsResource
description: REST resource for managing printer default processing elements including color, media size, plex mode, print quality, and other print settings via GET and PUT operations.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterDefaultsProcessingElementsResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterDefaultsProcessingElementsResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#GET") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#GET") |
| printer | Printer |  |
| printerDefaultsProcessingElements | PrinterDefaultsProcessingElements |  |
| objFactory | ObjectFactory |  |
| strDefaultProcessingEleXML | String |  |
| rep | Representation |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/defaultprocessingelements/#PUT") |
| printer | Printer |  |
| defaultsProcessingElementsSchema | PrinterDefaultsProcessingElements |  |
| objFactory | ObjectFactory |  |
| strDefaultProcessingEleXML | String |  |
| rep | Representation |  |
| lstPrinterDefaultProcessingElements | List |  |
| defaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |
| familyDefaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |
| printerDefaultProcessingElements | PrinterDefaultProcessingElements |  |
| printerDefaultsProcessingElements | PrinterDefaultsProcessingElements |  |
| defaultProcessingEle | com.hp.cloudprint.entities.PrinterDefaultProcessingElements |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| handleGet | void |  |  |
| handlePut | void |  |  |
| updatePrinterDefaultsProcessingElements | void | Printer printer, PrinterDefaultsProcessingElements defaultsProcessingElementsSchema |  |
| getPrinterDefaultsProcessingElements | PrinterDefaultsProcessingElements | Printer printer |  |


# Depends on

IPrinterManager (get active printer by printer ID), DeviceCapabilitiesManager (get printer default processing elements, save/update defaults), EPrintCenterAPIConfig (configuration values), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML marshalling/unmarshalling, schema validation), Request (HTTP request access), Response (HTTP response manipulation), Representation (entity access), StringRepresentation (XML response wrapping), MediaType (content type specification), Status (HTTP status codes), PrinterDefaultsProcessingElements (JAXB schema object), PrinterDefaultProcessingElements (entity), ObjectFactory (JAXB object factory), Printer (printer entity).

# Business context

PrinterDefaultsProcessingElementsResource manages the default print settings for printers in the ePrint Center system. It allows retrieval and modification of printer-specific default processing elements such as color mode, media size, duplex settings, print quality, and other print job attributes. The resource supports both printer-specific defaults and family-level defaults, with printer-specific settings taking precedence. It validates that multiple processing elements have different PrintingType values to prevent conflicts.

# Algorithm

**GET (handleGet)**: Generates unique log ID and sets in MDC → Extracts printer ID from request attributes → Retrieves active printer by printer ID via printerManager → Calls getPrinterDefaultsProcessingElements to retrieve defaults → Marshals PrinterDefaultsProcessingElements to XML → Sets response entity with XML and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), general exceptions (500).

**PUT (handlePut)**: Generates unique log ID and sets in MDC → Extracts printer ID from request attributes → Retrieves active printer by printer ID via printerManager → Unmarshals and validates XML input to PrinterDefaultsProcessingElements schema object → Calls updatePrinterDefaultsProcessingElements to update defaults → Marshals updated PrinterDefaultsProcessingElements to XML → Sets response entity with XML and 201 CREATED status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), JAXBException (400 INVALID_SCHEMA), IOException (400 INVALID_SCHEMA), general exceptions (500).

**getPrinterDefaultsProcessingElements**: Retrieves list of printer default processing elements from deviceCapabilitiesManager → If list is empty, returns null → Iterates through list to find printer-specific default (where internalPrinterId matches) → If printer-specific default not found, finds family default (where internalPrinterId is null) → If default found, creates PrinterDefaultsProcessingElements schema object → Populates with color, media size, plex mode, print quality, and other attributes → Returns PrinterDefaultsProcessingElements.

**updatePrinterDefaultsProcessingElements**: Retrieves list of printer default processing elements from deviceCapabilitiesManager → Finds existing printer-specific default in list → If not found, creates new PrinterDefaultProcessingElements entity → Populates entity from schema object (color, media size, plex mode, print quality, etc.) → Sets printer reference and internal printer ID → Validates that multiple processing elements have different PrintingType values → Saves or updates via deviceCapabilitiesManager → Logs success.

# Business rules

1. **Printer-specific vs family defaults**: Printer-specific defaults (where internalPrinterId matches) take precedence over family defaults (where internalPrinterId is null).
2. **Default fallback**: If no printer-specific default exists, family default is used.
3. **PrintingType validation**: Multiple processing elements must have different PrintingType values to prevent conflicts.
4. **Printer validation**: Printer must exist and be active before operations; returns 404 if DeviceNotFoundExcpeption.
5. **XSD validation**: XML schema validation is performed on PUT requests; invalid schema returns 400 INVALID_SCHEMA.
6. **Auditable endpoints**: GET tracked as `/devices/printers/{PrinterID}/defaultprocessingelements/#GET`, PUT tracked as `/devices/printers/{PrinterID}/defaultprocessingelements/#PUT`.
7. **Response status**: GET returns 200 OK, PUT returns 201 CREATED on success.
8. **Supported attributes**: Color (color mode), MediaSize (paper size), PlexMode (duplex settings), PrintQuality, Copies, Orientation, Sides, Collate, and other print job attributes.
9. **Empty defaults**: If no defaults exist (list is empty), returns null for GET requests.
