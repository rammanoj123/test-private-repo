---
type: Component
title: PrinterResource
description: REST resource for comprehensive printer management including GET to retrieve printer details with PLS integration, PUT to update printer information, POST for printer lookup, and DELETE to remove printers.
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21 15:21:29+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| VERSION | String |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @Resource |
| productListingServiceHelper | ProductListingServiceHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| FIRMWARE_NOT_FOUND | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#PUT") |
| objectFactory | ObjectFactory |  |
| printerRequest | PrinterDescription |  |
| rep | Representation |  |
| internalPrinterID | long |  |
| printerEntity | com.hp.cloudprint.entities.Printer |  |
| printerLoc | PrinterLocationAddress |  |
| countryCodeAndRegionName | String |  |
| printerGeoLoc | PrinterGeoLocation |  |
| strPrinterXML | String |  |
| printerId | String | @Auditable(name = "/devices/printersDel/{PrinterID}/#DELETE") |
| printerEntity | Printer | @Auditable(name = "/devices/printersDel/{PrinterID}/#DELETE") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| tokenDO | TokenDO | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| userId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| printerEntity | com.hp.cloudprint.entities.Printer |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| objFactory | ObjectFactory |  |
| printerDesc | PrinterDescription |  |
| pspElems | Link |  |
| strPrinterXML | String |  |
| rep | Representation |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers#POST") |
| request | PrinterLookupRequest | @Override, @Auditable(name = "/devices/printers#POST") |
| deviceData | DeviceData | @Override, @Auditable(name = "/devices/printers#POST") |
| printerEntity | Printer | @Override, @Auditable(name = "/devices/printers#POST") |
| printerInformation | PrinterInformation |  |
| lookupResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| version | PrinterInformation.PrinterVersion |  |
| mapper | ObjectMapper |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |
| request | String |  |
| mapper | ObjectMapper |  |
| lookupRequest | PrinterLookupRequest |  |
| printerDesc | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| emailAddressURI | Link |  |
| printerLocationAddress | PrinterLocationAddress |  |
| printerLoc | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| printerGeoLoc | PrinterGeoLocationType |  |
| printerLoc | PrinterLocationType |  |
| printerVersion | com.hp.cloudprint.api.eprintcenter.schemas.PrinterVersion |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| internalPrinterId | long |  |
| entityPrinter | com.hp.cloudprint.entities.Printer |  |
| ownership | Ownership |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| storeRepresentation | void | Representation entity |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| acceptRepresentation | void | Representation entity |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| getLookupResponse | String | PrinterInformation printerInformation, DeviceData deviceData, Printer printerEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDesc, String modelNumber |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |
| unMarshalAndValidateInput | PrinterLookupRequest | Representation entity |  |
| getPrinterDescription | PrinterDescription | com.hp.cloudprint.entities.Printer printerEntity, ConnectionStateEnum printerConnectionState |  |
| getPrinterGeoLocationType | PrinterGeoLocationType | com.hp.cloudprint.entities.Printer printerEntity |  |
| getPrinterLocationType | PrinterLocationType | PrinterLocationAddress printerLocationAddress |  |
| getPrinterVersion | com.hp.cloudprint.api.eprintcenter.schemas.PrinterVersion | com.hp.cloudprint.entities.Printer printerEntity |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getInterPrinterId | long | String printerID |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| verifyPrinterOwner | boolean | String printerID, String userId |  |


# Depends on

IPrinterManager (get active printer by printer ID, get printer by serial and model number, update printer, delete printer, get printer owner, get printer connection state), DeviceCapabilitiesManager (get printer app player elements, check SIPS support), ProductListingServiceHelper (get complete printer info from PLS), JAXBObjectCreationHelper (generate printer cloud configuration JAXB object, map PLS info to printer description, configure ink subscription, populate optin subscription details, get supported player versions, get supported cloud UI versions), PrinterCloudConfigurationManager (get printer cloud config, get optin data collection group type), EPrintCenterAPIConfig (configuration values: APS enabled, instant ink override, XSD validation, document sunset days), EPrintLogger (logging), EPrintMDC (MDC management), Utility (XML/JSON marshalling/unmarshalling, schema validation, UID extraction from PUC token, date conversion), Request (HTTP request access), Response (HTTP response manipulation), Representation (entity access), StringRepresentation (XML/JSON response wrapping), MediaType (content type specification), Status (HTTP status codes), ObjectMapper (JSON serialization/deserialization), DatatypeFactory (XMLGregorianCalendar creation), GregorianCalendar (date handling), PrinterDescription (JAXB schema object), PrinterLookupRequest (JSON request model), PrinterInformation (JSON response model), DeviceData (JSON model), Errors (JSON error model), Error (JSON error model), Link (JAXB schema object), URIHelper (URI generation), TokenDO (token data object), Printer (printer entity), Ownership (ownership entity), PrinterCloudConfiguration (cloud configuration entity), PrinterModelDefaultAppPlayerElements (app player elements entity).

# Algorithm

**PUT (storeRepresentation)**: Generates unique log ID and sets in MDC → Extracts printer ID from request attributes → Unmarshals and validates XML input to PrinterDescription schema object → Retrieves active printer by printer ID via printerManager → Updates printer entity fields (email, geo location, location address, make/model, model number, more info, name, serial number, reserved fields, nickname, UI language) → Extracts and sets country code or region name from location → Updates printer via printerManager → Marshals updated printer to XML → Sets response entity with XML and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), JAXBException (400 INVALID_SCHEMA), IOException (400 INVALID_SCHEMA), general exceptions (500).

**DELETE (handleDelete)**: Extracts printer ID from request attributes → Deletes printer via printerManager.deletePrinter → Sets response status to 204 NO_CONTENT → Handles DeviceNotFoundExcpeption (404), general exceptions (500).

**GET (handleGet)**: Generates unique log ID and sets in MDC → Extracts printer ID from request attributes → Extracts user ID from TokenDO → Verifies printer ownership (calls verifyPrinterOwner) → Returns 403 FORBIDDEN if not owner → Retrieves active printer by printer ID via printerManager → Gets printer connection state → Calls getPrinterDescription to build comprehensive printer description → Adds link to supported processing elements → Marshals printer description to XML → Sets response entity with XML and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404), general exceptions (500).

**POST (acceptRepresentation)**: Generates unique log ID and sets in MDC → Unmarshals and validates JSON input to PrinterLookupRequest → Extracts device data (model number, serial number) → Retrieves printer by serial and model number via printerManager → If printer not found, returns error response with DEVICE_NOT_FOUND → Retrieves active printer by device ID → Calls getPrinterDescription to build printer description → Calls getLookupResponse to create JSON response with printer information → Sets response entity with JSON and 200 OK status → Clears MDC in finally block → Handles DeviceNotFoundExcpeption (404 DEVICE_NOT_FOUND), general exceptions (500).

**getPrinterDescription**: Creates PrinterDescription object → Sets printer email, geo location (calls getPrinterGeoLocationType), printer ID, info, location (calls getPrinterLocationType), country code or region name, make/model, model number, more info, name, serial number, reserved fields, nickname, immutable ID → Converts printer version to XMLGregorianCalendar (calls getPrinterVersion) → Sets UI language → Sets connection state → If APS enabled, gets app player capabilities (calls getAppPlayerCapabilities) → Adds printer details from PLS (calls addPrinterDetailsFromPLS) → Adds printer cloud configuration (calls addPrinterCloudConfiguration) → Returns PrinterDescription.

**getAppPlayerCapabilities**: Creates AppPlayerCapabilities object → Returns empty if printer model elements is null → Creates UIConfiguration with input type and display capabilities (calls getDisplayCapabilities) → Creates PlayerInterfaceVersions with supported player and cloud UI versions (calls getSupportedPlayerVersions, getSupportedCloudUIVersions) → Sets isSipsSupported flag (calls isSIPSSupported) → Returns AppPlayerCapabilities.

**addPrinterDetailsFromPLS**: Extracts user ID from PUC token → If user ID not null, gets complete printer info from PLS via productListingServiceHelper → Maps PLS info to printer description via jaxbObjectCreationHelper → If user ID null, logs EPC 1.0 request.

**addPrinterCloudConfiguration**: Retrieves printer cloud configuration from printerCloudConfigurationManager → Generates JAXB object from entity via jaxbObjectCreationHelper → Sets on printer description → If instant ink override configured, configures ink subscription → Adds opt-in config details (calls addOptinConfigDetails).

**verifyPrinterOwner**: Retrieves printer owner via printerManager.getPrinterOwner → Compares user ID with ownership.getOwnerUserId() → Returns true if match, false otherwise → Returns false if DeviceNotFoundExcpeption or OwnershipNotFoundException.

# Business context

PrinterResource is the central REST controller for printer management in the ePrint Center system. It provides comprehensive CRUD operations for printers, enriching printer data with information from multiple sources including Product Listing Service (PLS), device capabilities, app player configurations, and cloud settings. The GET operation enforces ownership verification to ensure only printer owners can retrieve detailed printer information. The POST operation supports printer lookup by serial number and model number, returning printer details in JSON format. The resource integrates with external services for printer information enrichment and supports both XML (GET/PUT/DELETE) and JSON (POST) formats.

# Business rules

1. **Ownership verification**: GET operation requires ownership verification; only printer owners can retrieve detailed printer information (returns 403 FORBIDDEN if not owner).
2. **Printer lookup**: POST operation looks up printers by serial number and model number; returns DEVICE_NOT_FOUND if printer not found.
3. **PLS integration**: Product Listing Service integration only attempted if user ID is present in token; EPC 1.0 requests without token are ignored for PLS.
4. **Connection state**: Printer connection state is retrieved and included in GET responses; defaults to OFFLINE on error.
5. **App player capabilities**: Only included if APS (App Player Service) is enabled via configuration.
6. **Instant ink override**: Instant ink subscription can be conditionally overridden based on configuration.
7. **XSD validation**: XML schema validation is performed on PUT requests; invalid schema returns 400 INVALID_SCHEMA.
8. **Auditable endpoints**: PUT tracked as `/devices/printers/{PrinterID}/#PUT`, DELETE tracked as `/devices/printersDel/{PrinterID}/#DELETE`, GET tracked as `/devices/printers/{PrinterID}/#GET`, POST tracked as `/devices/printers#POST`.
9. **Response formats**: GET/PUT/DELETE use XML format; POST uses JSON format.
10. **Response status**: GET returns 200 OK, PUT returns 200 OK, DELETE returns 204 NO_CONTENT, POST returns 200 OK on success.
11. **Supported processing elements link**: GET response includes link to supported processing elements endpoint.
12. **Country code/region name**: Extracted from printer location address and set on printer description.
13. **Printer version**: Converted to XMLGregorianCalendar format for XML responses.
14. **Cloud configuration**: Always included in GET responses with opt-in config details.
15. **Error handling**: DeviceNotFoundExcpeption returns 404, JAXBException/IOException return 400, general exceptions return 500.
