---
type: Component
title: PrinterResource
description: Manages printer information including retrieval, updates, soft deletion, and lookup by serial/model number with PLS integration.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\PrinterResource.java
generated: { by: okf_generator/1.0, at: 2026-09-20 15:42:49+00:00 }
---

`com.hp.cloudprint.api.eprintcenter.resources.PrinterResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| VERSION | String |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| deviceCapabilitiesManager | DeviceCapabilitiesManager | @Resource |
| productListingServiceHelper | ProductListingServiceHelper | @Resource |
| jaxbObjectCreationHelper | JAXBObjectCreationHelper | @Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @javax.annotation.Resource |
| FIRMWARE_NOT_FOUND | String | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#PUT") |
| printerID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#PUT") |
| objectFactory | ObjectFactory |  |
| printerRequest | PrinterDescription |  |
| rep | Representation |  |
| internalPrinterID | long |  |
| printerEntity | com.hp.cloudprint.entities.Printer |  |
| printerLoc | PrinterLocationAddress |  |
| countryCodeAndRegionName | String |  |
| printerGeoLoc | PrinterGeoLocation |  |
| strPrinterXML | String |  |
| printerId | String | @Auditable(name = "/devices/printersDel/{PrinterID}/#DELETE") |
| printerEntity | Printer | @Auditable(name = "/devices/printersDel/{PrinterID}/#DELETE") |
| printerId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| tokenDO | TokenDO | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| userId | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/#GET") |
| printerEntity | com.hp.cloudprint.entities.Printer |  |
| printerConnectionState | ConnectionStateEnum |  |
| connectionState | ConnectionState |  |
| objFactory | ObjectFactory |  |
| printerDesc | PrinterDescription |  |
| pspElems | Link |  |
| strPrinterXML | String |  |
| rep | Representation |  |
| logUID | String | @Override, @Auditable(name = "/devices/printers#POST") |
| request | PrinterLookupRequest | @Override, @Auditable(name = "/devices/printers#POST") |
| deviceData | DeviceData | @Override, @Auditable(name = "/devices/printers#POST") |
| printerEntity | Printer | @Override, @Auditable(name = "/devices/printers#POST") |
| printerInformation | PrinterInformation |  |
| lookupResponse | String |  |
| response | Representation |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| version | PrinterInformation.PrinterVersion |  |
| mapper | ObjectMapper |  |
| userId | String |  |
| printerInfoFromPLS | PrinterInfo |  |
| printerCloudConfigurationEntity | PrinterCloudConfiguration |  |
| printerCloudConfigurationResponse | com.hp.cloudprint.api.eprintcenter.schemas.PrinterCloudConfiguration |  |
| dataCollectionGroupType | DataCollectionGroupType |  |
| optinConfig | OptinConfig |  |
| request | String |  |
| mapper | ObjectMapper |  |
| lookupRequest | PrinterLookupRequest |  |
| printerDesc | PrinterDescription |  |
| printerEmailAddress | PrinterEmailAddress |  |
| emailAddress | String |  |
| emailAddressURI | Link |  |
| printerLocationAddress | PrinterLocationAddress |  |
| printerLoc | PrinterLocationType |  |
| countryCode | CountryCode |  |
| regionName | RegionName |  |
| strCountryCodeOrRegionName | String |  |
| printerModelDefaultAppPlayerElements | PrinterModelDefaultAppPlayerElements |  |
| printerGeoLoc | PrinterGeoLocationType |  |
| printerLoc | PrinterLocationType |  |
| printerVersion | com.hp.cloudprint.api.eprintcenter.schemas.PrinterVersion |  |
| XMLGCCreationTime | XMLGregorianCalendar |  |
| gregorianCalendar | GregorianCalendar |  |
| appPlayerCapabilities | AppPlayerCapabilities |  |
| uIConfiguration | UIConfiguration |  |
| displayCapabilities | DisplayCapabilities |  |
| playerInterfaceVersions | PlayerInterfaceVersions |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| supportedCloudUIVersions | SupportedCloudUIVersions |  |
| revisionDateVersion | RevisionDateVersion |  |
| supportedAppPlayerVersions | String |  |
| supportedPlayerVersions | SupportedPlayerVersions |  |
| displayCapabilities | DisplayCapabilities |  |
| dimentionInMillimeters | Dimensions |  |
| dimentionInPixels | Dimensions |  |
| internalPrinterId | long |  |
| entityPrinter | com.hp.cloudprint.entities.Printer |  |
| ownership | Ownership |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setProductListingServiceHelper | void | ProductListingServiceHelper productListingServiceHelper |  |
| setJaxbObjectCreationHelper | void | JAXBObjectCreationHelper jaxbObjectCreationHelper |  |
| setDeviceCapabilitiesManager | void | DeviceCapabilitiesManager deviceCapabilitiesManager |  |
| storeRepresentation | void | Representation entity |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| acceptRepresentation | void | Representation entity |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| getLookupResponse | String | PrinterInformation printerInformation, DeviceData deviceData, Printer printerEntity |  |
| addPrinterDetailsFromPLS | void | PrinterDescription printerDesc, String modelNumber |  |
| addPrinterCloudConfiguration | void | PrinterDescription printerDesc, long internalPrinterId |  |
| addOptinConfigDetails | void | PrinterDescription printerDesc, PrinterCloudConfiguration printerCloudConfigurationEntity |  |
| unMarshalAndValidateInput | PrinterLookupRequest | Representation entity |  |
| getPrinterDescription | PrinterDescription | com.hp.cloudprint.entities.Printer printerEntity, ConnectionStateEnum printerConnectionState |  |
| getPrinterGeoLocationType | PrinterGeoLocationType | com.hp.cloudprint.entities.Printer printerEntity |  |
| getPrinterLocationType | PrinterLocationType | PrinterLocationAddress printerLocationAddress |  |
| getPrinterVersion | com.hp.cloudprint.api.eprintcenter.schemas.PrinterVersion | com.hp.cloudprint.entities.Printer printerEntity |  |
| getAppPlayerCapabilities | AppPlayerCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements, Printer printerEntity |  |
| isSIPSSupported | Boolean | Printer printerEntity |  |
| getSupportedCloudUIVersions | SupportedCloudUIVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getSupportedPlayerVersions | SupportedPlayerVersions | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getDisplayCapabilities | DisplayCapabilities | PrinterModelDefaultAppPlayerElements printerModelDefaultAppPlayerElements |  |
| getInterPrinterId | long | String printerID |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| verifyPrinterOwner | boolean | String printerID, String userId |  |

# Depends on

* `IPrinterManager`
* `DeviceCapabilitiesManager`
* [ProductListingServiceHelper](/components/services/ProductListingServiceHelper.md)
* [JAXBObjectCreationHelper](/components/misc/JAXBObjectCreationHelper.md)
* `PrinterCloudConfigurationManager`
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* `String`
