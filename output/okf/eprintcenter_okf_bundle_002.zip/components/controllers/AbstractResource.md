---
type: Component
title: Abstract Resource
description: Base class for Restlet resources that controls HTTP method availability based on configured method list.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\AbstractResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: AbstractResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/AbstractResource.java, title: AbstractResource.java }
---

`com.hp.cloudprint.api.eprintcenter.AbstractResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| methods | List |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| AbstractResource |  |  |  |
| setMethods | void | List<String> methods |  |
| allowGet | boolean |  |  |
| allowPost | boolean |  |  |
| allowDelete | boolean |  |  |
| allowPut | boolean |  |  |
| allowOptions | boolean |  |  |
| allowHead | boolean |  |  |

# Algorithm

**allowGet** - Check if GET allowed:
1. Check if methods list contains 'GET'
2. Return true if present, false otherwise

**allowPost** - Check if POST allowed:
1. Check if methods list contains 'POST'
2. Return true if present, false otherwise

**allowDelete** - Check if DELETE allowed:
1. Check if methods list contains 'DELETE'
2. Return true if present, false otherwise

**allowPut** - Check if PUT allowed:
1. Check if methods list contains 'PUT'
2. Return true if present, false otherwise

**allowOptions** - Check if OPTIONS allowed:
1. Check if methods list contains 'OPTIONS'
2. Return true if present, false otherwise

**allowHead** - Check if HEAD allowed:
1. Check if methods list contains 'HEAD'
2. Return true if present, false otherwise

# Business context

Base class for Restlet resources providing HTTP method-based access control. Extends Restlet Resource class and controls which HTTP methods (GET, POST, PUT, DELETE, OPTIONS, HEAD) are allowed for a resource based on a configured method list.

# Business rules

If methods list must be set before resource is used. If each HTTP method is allowed only if present in the methods list.

# Depends on

* `org.restlet.resource.Resource`
