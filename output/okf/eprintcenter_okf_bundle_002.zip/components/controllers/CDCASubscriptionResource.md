---
type: Component
title: CDCA Subscription Resource
description: REST resource for managing CDCA (Connected Device Configuration and Analytics) subscription opt-in settings for printers.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CDCASubscriptionResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: CDCASubscriptionResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/CDCASubscriptionResource.java, title: CDCASubscriptionResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#DELETE") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#GET") |
| printerID | String |  |
| response | Response |  |
| printerID | String |  |
| printer | Printer |  |
| errorXml | String |  |
| error | Error |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| CDCASubscriptionResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| getErrorXML | String | ErrorCode errorCode |  |
| putPrinterCloudConfiguration | void | Printer printer |  |
| isPrinterOptedinWithSchedule | boolean | PrinterCloudConfiguration printerCloudConfiguration, String printerId |  |
| deletePrinterCloudConfiguration | void | Printer printer |  |
| getPrinterCloudConfiguration | void | Printer printer |  |
| putPrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [PrinterCloudConfigurationManager](/components/services/PrinterCloudConfigurationManager.md)

# Algorithm

**handlePut** - Enable CDCA opt-in:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.PUT
3. Clear MDC in finally block

**handleDelete** - Disable CDCA opt-in:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.DELETE
3. Clear MDC in finally block

**handleGet** - Retrieve CDCA opt-in status:
1. Generate unique log ID and set in MDC
2. Delegate to handleMethod with RequestType.GET
3. Clear MDC in finally block

**handleMethod** - Core request processing:
1. Reset response status to null
2. Extract and validate printer ID from request
3. Retrieve and validate printer object
4. Route to appropriate method based on request type (PUT/DELETE/GET)
5. Catch PrinterCloudConfigurationNotFoundException and return 404
6. Catch general exceptions and return 500
7. Set success response status based on request type

**putPrinterCloudConfiguration** - Enable CDCA opt-in:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, check if printer is already opted in with schedule
3. If not opted in with schedule, update CDCA opt-in flag
4. Update configuration in database
5. If configuration is null, return 500

**isPrinterOptedinWithSchedule** - Check schedule-based opt-in:
1. Check if optinType field is not blank
2. If optinType exists and does not equal CDCA_OPTIN_TYPE, return 409 CONFLICT
3. If optinType exists and equals CDCA, return true (already opted in)
4. If optinType is blank, return false (not opted in with schedule)

**deletePrinterCloudConfiguration** - Disable CDCA opt-in:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, disable CDCA opt-in flag
3. Update configuration in database
4. If configuration is null, return 500

**getPrinterCloudConfiguration** - Retrieve opt-in status:
1. Retrieve PrinterCloudConfiguration by internal printer ID
2. If configuration exists, check if CDCA opt-in is false
3. If opt-in is false, return 404
4. If configuration is null, return 500

**putPrinterCloudConfigurationCDCAOptin** - Update opt-in flag:
1. Set CDCAOptin to true
2. Set isOptinConfigSynced to 0 (needs sync)
3. Set lastOptinUpdateTime to current timestamp

**deletePrinterCloudConfigurationCDCAOptin** - Clear opt-in flag:
1. Set CDCAOptin to false
2. Set isOptinConfigSynced to 0 (needs sync)
3. Set lastOptinUpdateTime to current timestamp

# Business context

Manages CDCA (Connected Device Configuration and Analytics) subscription opt-in settings for printers. Handles enabling, disabling, and retrieving opt-in status. Prevents conflicts with schedule-based opt-in configurations (v2 API). When opt-in is updated, triggers sync flag reset and timestamp update.

# Business rules

If printer ID must be present in request. If printer must exist and be active. If schedule-based opt-in (v2 API) takes precedence over legacy CDCA opt-in flag. If printer can only have one opt-in type at a time. If conflicting opt-in types result in 409 CONFLICT. If opt-in changes must trigger sync flag reset and timestamp update. If printer not found returns 404. If cloud configuration not found returns 404. If CDCA opt-in not enabled returns 404 on GET. If PUT returns 201 CREATED. If DELETE returns 204 NO_CONTENT. If GET returns 204 NO_CONTENT.
