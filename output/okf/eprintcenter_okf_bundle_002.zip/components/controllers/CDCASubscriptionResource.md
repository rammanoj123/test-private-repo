---
type: Component
title: CDCASubscriptionResource
description: Controller `CDCASubscriptionResource`. (Description pending enrichment.)
tags: [component, controller]
status: draft
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\CDCASubscriptionResource.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.resources.CDCASubscriptionResource`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| CDCA_OPTIN_TYPE | String |  |
| printerManager | IPrinterManager | @javax.annotation.Resource |
| printerCloudConfigurationManager | PrinterCloudConfigurationManager | @javax.annotation.Resource |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#PUT") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#DELETE") |
| logUID | String | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#GET") |
| printer | Printer | @Override, @Auditable(name = "/devices/printers/{PrinterID}/optin/CDCA/#GET") |
| printerID | String |  |
| response | Response |  |
| printerID | String |  |
| printer | Printer |  |
| errorXml | String |  |
| error | Error |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |
| printerCloudConfiguration | PrinterCloudConfiguration |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setPrinterCloudConfigurationManager | void | PrinterCloudConfigurationManager printerCloudConfigurationManager |  |
| CDCASubscriptionResource |  |  |  |
| handlePut | void |  |  |
| handleDelete | void |  |  |
| handleGet | void |  |  |
| handleMethod | void | RequestType requestType |  |
| setSuccessResponseStatus | void | RequestType requestType |  |
| getPrinterID | String |  |  |
| getPrinter | Printer | String printerID |  |
| getErrorXML | String | ErrorCode errorCode |  |
| putPrinterCloudConfiguration | void | Printer printer |  |
| isPrinterOptedinWithSchedule | boolean | PrinterCloudConfiguration printerCloudConfiguration, String printerId |  |
| deletePrinterCloudConfiguration | void | Printer printer |  |
| getPrinterCloudConfiguration | void | Printer printer |  |
| putPrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |
| deletePrinterCloudConfigurationCDCAOptin | void | PrinterCloudConfiguration printerCloudConfiguration |  |

# Depends on

* `IPrinterManager`
* `PrinterCloudConfigurationManager`
