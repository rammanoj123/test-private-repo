---
type: Component
title: Device Ownership Stratus Resource
description: REST resource for managing device ownership claims with Stratus eventing integration, publishing ownership events to Stratus service.
tags: [component, controller]
status: stable
component_type: Controller
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\resources\DeviceOwnershipStratusResource.java
generated: { by: claude-3-7-sonnet-20250219, at: 2025-01-10T00:00:00Z }
sources:
  - { id: DeviceOwnershipStratusResource.java, resource: eprintcenter/src/main/java/com/hp/cloudprint/api/eprintcenter/resources/DeviceOwnershipStratusResource.java, title: DeviceOwnershipStratusResource.java }
---

`com.hp.cloudprint.api.eprintcenter.resources.DeviceOwnershipStratusResource`


# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| logger | EPrintLogger |  |
| ePrintMDC | EPrintMDC |  |
| printerManager | IPrinterManager | @Resource |
| ownershipUserService | OwnershipUserService | @Resource |
| stratusClient | StratusClient | @Resource |
| ePrintCenterAPIConfig | EPrintCenterAPIConfig | @Resource |
| stratusEventingEnabled | boolean | @Override, @Auditable(name = "/v1/devices/printers/ownerships#POST") |
| logUID | String | @Override, @Auditable(name = "/v1/devices/printers/ownerships#POST") |
| printer | Printer |  |
| ownerShip | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |
| devOwnership | Ownership |  |
| awful | HttpServletRequest |  |
| token | String |  |
| response | Representation |  |
| devOwnership | Ownership |  |
| errors | Errors |  |
| error | Error |  |
| response | Representation |  |
| inputPayload | String |  |
| mapper | ObjectMapper |  |
| ownership | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership |  |


# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| DeviceOwnershipStratusResource |  |  |  |
| acceptRepresentation | void | Representation entity |  |
| getResponse | void | Ownership devOwnership |  |
| getOwnership | Ownership | Printer printer, com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership ownerShip |  |
| fetchPrinterDetails | Printer | String printerId |  |
| getErrorResponse | String | String errorCode, String errorDescription, Status status |  |
| returnErrorResponse | void | String errorDescription, String errorCode, Status status |  |
| unMarshalAndValidateOwnershipsInput | com.hp.cloudprint.api.eprintcenter.schemas.json.Ownership | Representation entity |  |
| setPrinterManager | void | IPrinterManager printerManager |  |
| setOwnershipUserService | void | OwnershipUserService ownershipUserService |  |


# Depends on

* [IPrinterManager](/components/services/IPrinterManager.md)
* [OwnershipUserService](/components/services/OwnershipUserService.md)
* [StratusClient](/components/services/StratusClient.md)
* [EPrintCenterAPIConfig](/components/config/EPrintCenterAPIConfig.md)
* [ShardUtil](/components/helpers/ShardUtil.md)

# Algorithm

**acceptRepresentation** - Claim ownership with Stratus eventing:
1. Check if Stratus eventing is enabled via configuration
2. If disabled, return 404 with 'Service not enabled'
3. Generate unique log ID and set in MDC
4. Validate entity is not null, return 400 if null
5. Unmarshal and validate ownership input from JSON
6. Fetch printer details by printer ID
7. Create Ownership object with generated UUID, printer, user ID, timestamp, and optional nickname
8. Add ownership via ownershipUserService
9. Create response with 201 CREATED status and location header
10. Check if request is from user PUC (not service PUC)
11. If user PUC, extract authorization token from HTTP headers and publish to Stratus with user token
12. If service PUC, publish to Stratus for PUC token
13. Catch PrinterAlreadyOwnedException and return 423 LOCKED
14. Catch IOException and return 500
15. Catch InvalidMediaTypeException and return 415
16. Catch IllegalInputArgExternalContigencyException and return 400
17. Catch DeviceNotFoundExcpeption and return 404
18. Catch general exceptions and return 500
19. Clear MDC in finally block

**getOwnership** - Create ownership entity:
1. Create new Ownership object
2. Generate ownership ID as UUID with shard prefix
3. Set printer reference
4. Set owner user ID from input
5. Set created timestamp to current time
6. If nickname is provided, set nickname
7. Return ownership object

**fetchPrinterDetails** - Get printer:
1. Call printerManager.getActivePrinterByPrinterID with printer ID
2. Return printer object

**unMarshalAndValidateOwnershipsInput** - Validate input:
1. Extract text from entity representation
2. Validate media type is APPLICATION_JSON and payload is not empty
3. Create ObjectMapper and deserialize JSON to Ownership object
4. Validate ownership object is not null
5. Validate printer ID and user ID are not blank
6. Return ownership object

# Business context

Manages device ownership claims with Stratus eventing integration. Publishes ownership events to Stratus service based on token type (user PUC vs service PUC). Validates Stratus eventing is enabled before processing. Creates ownership records with generated UUIDs and prevents duplicate ownership claims.

# Business rules

If Stratus eventing must be enabled for this endpoint to function. If user PUC tokens trigger Stratus publishing with user token. If service PUC tokens trigger Stratus publishing with PUC token. If printer can only have one owner. If ownership ID is generated as UUID with shard prefix. If successful claim returns 201 CREATED with location header. If printer already owned returns 423 LOCKED. If printer not found returns 404. If Stratus eventing disabled returns 404.
