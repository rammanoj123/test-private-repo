---
type: Domain Entity
title: EntityConverter
description: Utility class for converting between domain entities and API schema objects for printers, blacklists, whitelists, and email addresses.
tags: [domain, entity]
status: draft
source_path: src\main\java\com\hp\cloudprint\api\eprintcenter\EntityConverter.java
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

`com.hp.cloudprint.api.eprintcenter.EntityConverter`

# Schema

| Field | Type | Annotations |
| --- | --- | --- |
| printerOwner | Owner |  |
| blackList | com.hp.cloudprint.api.eprintcenter.schemas.BlackList |  |
| blackList | List |  |
| blackListEntry | BlackListEntryType |  |
| additionalEmailAddress | AdditionalEmailAddress |  |
| additionalEmailAddressEntry | AdditionalEmailAddressEntryType |  |
| whiteList2Return | WhiteList |  |
| whiteListEntry | WhiteListEntryType |  |
| whitelist2Return | List |  |
| whiteListEntry | com.hp.cloudprint.entities.WhiteList |  |
| error | Error |  |

# Methods

| Method | Returns | Params | Notes |
| --- | --- | --- | --- |
| createOwnerFromOwnershipEntity | Owner | Ownership printerOwnerEntity |  |
| createBlacklist | com.hp.cloudprint.api.eprintcenter.schemas.BlackList | List<BlackList> blackListEntries |  |
| createBlacklist | List | com.hp.cloudprint.api.eprintcenter.schemas.BlackList blackListEntries |  |
| createBlackListEntry | BlackList | BlackListEntryType blackListEntry |  |
| createBlackListEntry | JAXBElement | BlackList blackList |  |
| createBlackListEntryType | BlackListEntryType | BlackList blackList |  |
| createAdditionalEmailAddresses | AdditionalEmailAddress | List<OwnerAdditionalEmailAddress> additionalEmailAddresses |  |
| createAdditionalEmailAddress | JAXBElement | OwnerAdditionalEmailAddress additionalEmailAddress |  |
| createAdditionalEmailAddressEntryType | AdditionalEmailAddressEntryType | OwnerAdditionalEmailAddress additionalEmailAddress |  |
| createWhiteList | WhiteList | List<com.hp.cloudprint.entities.WhiteList> whitelist |  |
| createWhiteListEntry | WhiteListEntryType | com.hp.cloudprint.entities.WhiteList whiteList |  |
| createWhiteList | List | WhiteList whiteList |  |
| createWhiteListEntry | com.hp.cloudprint.entities.WhiteList | WhiteListEntryType whiteList |  |
| buildPapiErrorMessage | Error | String message, int httpStatusCode |  |
