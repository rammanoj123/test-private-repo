---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/whitelist/
description: DELETE /devices/printers/{PrinterID}/whitelist/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
