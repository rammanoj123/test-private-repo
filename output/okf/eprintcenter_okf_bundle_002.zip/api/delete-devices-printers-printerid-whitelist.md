---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/whitelist/
description: Serves DELETE /devices/printers/{PrinterID}/whitelist/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/whitelist/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/whitelist/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/whitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
