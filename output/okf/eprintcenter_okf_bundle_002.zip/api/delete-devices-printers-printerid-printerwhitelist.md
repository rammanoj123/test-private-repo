---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/printerwhitelist/
description: Serves DELETE /devices/printers/{PrinterID}/printerwhitelist/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/printerwhitelist/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/printerwhitelist/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/printerwhitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
