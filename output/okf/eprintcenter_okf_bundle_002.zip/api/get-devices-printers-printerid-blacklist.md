---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/blacklist/
description: Serves GET /devices/printers/{PrinterID}/blacklist/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
