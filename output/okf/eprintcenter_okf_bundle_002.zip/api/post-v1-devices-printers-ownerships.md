---
type: API Endpoint
title: POST /v1/devices/printers/ownerships
description: Serves POST /v1/devices/printers/ownerships through SpringFinder.represent.
resource: /v1/devices/printers/ownerships
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /v1/devices/printers/ownerships
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/v1/devices/printers/ownerships` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
