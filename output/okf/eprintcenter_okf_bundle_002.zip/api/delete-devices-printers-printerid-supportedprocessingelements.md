---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/supportedprocessingelements/
description: Serves DELETE /devices/printers/{PrinterID}/supportedprocessingelements/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/supportedprocessingelements/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/supportedprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/supportedprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
