---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/blacklist/
description: PUT /devices/printers/{PrinterID}/blacklist/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{PrinterID}/blacklist/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/blacklist/
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/blacklist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
