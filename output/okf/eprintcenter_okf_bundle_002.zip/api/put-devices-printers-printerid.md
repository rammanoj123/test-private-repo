---
type: API Endpoint
title: PUT /devices/printers/{PrinterID}/
description: Serves PUT /devices/printers/{PrinterID}/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /devices/printers/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/devices/printers/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
