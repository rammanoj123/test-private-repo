---
type: API Endpoint
title: GET /jobs/printjobs/{JobID}/cancel/
description: Serves GET /jobs/printjobs/{JobID}/cancel/ through SpringFinder.represent.
resource: /jobs/printjobs/{JobID}/cancel/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /jobs/printjobs/{JobID}/cancel/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/jobs/printjobs/{JobID}/cancel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
