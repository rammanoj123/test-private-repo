---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/cloudconfiguration/
description: Serves DELETE /devices/printers/{PrinterID}/cloudconfiguration/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/cloudconfiguration/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/cloudconfiguration/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/cloudconfiguration/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
