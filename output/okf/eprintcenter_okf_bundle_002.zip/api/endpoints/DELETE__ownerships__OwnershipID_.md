---
type: API
description: Deletes a printer ownership with optional email alias retention.
---


