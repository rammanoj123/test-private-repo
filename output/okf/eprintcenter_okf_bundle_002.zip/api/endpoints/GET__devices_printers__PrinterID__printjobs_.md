---
type: API
description: Retrieves paginated print job history for a printer.
---


