---
type: API
description: Retrieves a specific blacklist entry for a printer.
---


