---
type: API
description: Updates v2 solution-specific opt-in configuration with schedule selection.
---


