---
type: API
description: Deletes the printer's email address configuration.
---


