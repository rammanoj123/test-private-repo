---
type: API
description: Updates printer cloud configuration including email, mobile apps, SIPs, Google services, and protection mode.
---


