---
type: API
description: Claims printer ownership by printer ID, claim code, or email address.
---


