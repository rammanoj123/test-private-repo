---
type: API
description: Retrieves printer opt-in configuration for the specified type.
---


