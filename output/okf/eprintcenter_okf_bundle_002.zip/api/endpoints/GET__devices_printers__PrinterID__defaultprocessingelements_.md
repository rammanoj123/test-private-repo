---
type: API
description: Retrieves printer default processing elements (print settings).
---


