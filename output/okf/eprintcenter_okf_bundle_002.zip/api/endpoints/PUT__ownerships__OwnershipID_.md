---
type: API
description: Updates ownership details including nickname.
---


