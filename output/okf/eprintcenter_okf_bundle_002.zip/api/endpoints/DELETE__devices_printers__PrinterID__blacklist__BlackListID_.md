---
type: API
description: Deletes a specific blacklist entry from a printer.
---


