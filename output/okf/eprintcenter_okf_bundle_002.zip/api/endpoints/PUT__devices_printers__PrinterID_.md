---
type: API
description: Updates printer details including nickname and favorite status.
---


