---
type: API
description: Retrieves detailed information about a specific print job.
---


