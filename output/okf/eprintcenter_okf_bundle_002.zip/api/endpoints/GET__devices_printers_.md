---
type: API
description: Retrieves a list of printers with optional filtering and enhanced details.
---


