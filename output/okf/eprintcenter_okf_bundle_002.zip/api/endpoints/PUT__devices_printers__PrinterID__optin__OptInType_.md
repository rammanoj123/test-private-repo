---
type: API
description: Updates printer opt-in configuration for the specified type.
---


