---
type: API
description: Updates printer default processing elements (print settings).
---


