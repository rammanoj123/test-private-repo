---
type: API
description: Retrieves all blacklist entries for a printer.
---


