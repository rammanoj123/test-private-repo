---
type: API
description: Retrieves all whitelist entries for a printer.
---


