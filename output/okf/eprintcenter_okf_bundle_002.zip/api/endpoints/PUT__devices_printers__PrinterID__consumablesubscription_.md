---
type: API
description: Updates printer consumable subscription configuration for ink/toner service advertising.
---


