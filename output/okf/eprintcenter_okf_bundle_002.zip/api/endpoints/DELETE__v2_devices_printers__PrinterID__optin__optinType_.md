---
type: API
description: Deletes a v2 solution-specific opt-in configuration for a printer.
---


