---
type: API
description: Retrieves printer supported processing elements including capabilities and media options.
---


