---
type: API
description: Retrieves comprehensive printer status with ownership verification.
---


