---
type: API
description: Updates ink level metrics collection opt-in settings.
---


