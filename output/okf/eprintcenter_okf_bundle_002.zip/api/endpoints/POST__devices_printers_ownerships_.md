---
type: API
description: Claims printer ownership with Stratus eventing integration.
---


