---
type: API
description: Retrieves the status of a specific print job.
---


