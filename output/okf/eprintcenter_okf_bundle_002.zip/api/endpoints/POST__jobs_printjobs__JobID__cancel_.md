---
type: API
description: Cancels a print job with retry logic for transient failures.
---


