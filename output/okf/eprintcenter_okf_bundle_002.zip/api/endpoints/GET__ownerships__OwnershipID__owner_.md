---
type: API
description: Retrieves owner information for a specific ownership.
---


