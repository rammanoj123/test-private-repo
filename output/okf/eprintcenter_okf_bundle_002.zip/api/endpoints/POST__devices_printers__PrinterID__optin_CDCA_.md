---
type: API
description: Creates CDCA subscription opt-in for a printer with schedule selection.
---


