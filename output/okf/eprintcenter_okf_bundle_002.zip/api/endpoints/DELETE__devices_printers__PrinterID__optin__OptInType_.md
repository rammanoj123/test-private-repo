---
type: API
description: Deletes a printer's opt-in configuration for the specified type.
---


