---
type: API
description: Retrieves v2 solution-specific opt-in configuration for a printer.
---


