---
type: API
description: Retrieves printer cloud configuration including email, mobile apps, SIPs, and protection mode settings.
---


