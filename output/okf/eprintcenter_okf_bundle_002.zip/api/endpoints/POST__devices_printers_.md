---
type: API
description: Looks up printers by claim code or email address.
---


