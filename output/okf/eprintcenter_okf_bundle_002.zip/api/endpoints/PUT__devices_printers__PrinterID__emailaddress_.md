---
type: API
description: Updates printer email address with Calypso validation and replication.
---


