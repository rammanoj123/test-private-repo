---
type: API
description: Retrieves all ownerships for the authenticated user with optional favorites.
---


