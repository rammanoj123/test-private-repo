---
type: API
description: Retrieves the printer's email address configuration.
---


