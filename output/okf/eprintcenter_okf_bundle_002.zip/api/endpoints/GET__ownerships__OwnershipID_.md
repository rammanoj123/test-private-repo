---
type: API
description: Retrieves detailed information about a specific ownership.
---


