---
type: API
description: Deletes a specific whitelist entry from a printer.
---


