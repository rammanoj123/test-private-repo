---
type: API
description: Updates supplies information opt-in settings for a printer.
---


