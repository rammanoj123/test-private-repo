---
type: API
description: Adds a new whitelist entry to a printer.
---


