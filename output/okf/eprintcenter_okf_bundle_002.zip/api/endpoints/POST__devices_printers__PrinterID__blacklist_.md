---
type: API
description: Adds a new blacklist entry to a printer.
---


