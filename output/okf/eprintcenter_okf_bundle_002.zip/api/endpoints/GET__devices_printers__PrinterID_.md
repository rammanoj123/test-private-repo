---
type: API
description: Retrieves detailed information about a specific printer including PLS metadata.
---


