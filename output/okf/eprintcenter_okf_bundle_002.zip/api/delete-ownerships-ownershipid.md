---
type: API Endpoint
title: DELETE /ownerships/{OwnershipID}/
description: Serves DELETE /ownerships/{OwnershipID}/ through SpringFinder.represent.
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
