---
type: API Endpoint
title: DELETE /ownerships/{OwnershipID}/
description: DELETE /ownerships/{OwnershipID}/ → SpringFinder.represent (description pending enrichment).
resource: /ownerships/{OwnershipID}/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /ownerships/{OwnershipID}/
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/ownerships/{OwnershipID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
