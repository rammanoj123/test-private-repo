---
type: API Endpoint
title: POST /ownerships/status
description: Serves POST /ownerships/status through SpringFinder.represent.
resource: /ownerships/status
tags: [api, endpoint, post]
status: draft
handler: SpringFinder
handler_method: represent
http_method: POST
http_path: /ownerships/status
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | POST |
| Path | `/ownerships/status` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
