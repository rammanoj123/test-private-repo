---
type: API Endpoint
title: PUT /v2/devices/printers/{optinType}/schedules
description: Serves PUT /v2/devices/printers/{optinType}/schedules through SpringFinder.represent.
resource: /v2/devices/printers/{optinType}/schedules
tags: [api, endpoint, put]
status: draft
handler: SpringFinder
handler_method: represent
http_method: PUT
http_path: /v2/devices/printers/{optinType}/schedules
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | PUT |
| Path | `/v2/devices/printers/{optinType}/schedules` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
