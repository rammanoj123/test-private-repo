---
type: API Endpoint
title: DELETE /devices/printers/{optinParameter}/optin/suppliesinfo/
description: DELETE /devices/printers/{optinParameter}/optin/suppliesinfo/ → SpringFinder.represent (description pending enrichment).
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-20T15:42:49Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
