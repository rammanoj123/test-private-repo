---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/optin/inklevel/
description: Serves GET /devices/printers/{PrinterID}/optin/inklevel/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/optin/inklevel/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/optin/inklevel/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/optin/inklevel/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
