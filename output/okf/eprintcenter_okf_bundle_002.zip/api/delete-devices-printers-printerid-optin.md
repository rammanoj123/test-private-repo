---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/optin/
description: Serves DELETE /devices/printers/{PrinterID}/optin/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/optin/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/optin/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/optin/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
