---
type: API Endpoint
title: GET /devices/printers/{PrinterID}/printerwhitelist/
description: Serves GET /devices/printers/{PrinterID}/printerwhitelist/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/printerwhitelist/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{PrinterID}/printerwhitelist/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{PrinterID}/printerwhitelist/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
