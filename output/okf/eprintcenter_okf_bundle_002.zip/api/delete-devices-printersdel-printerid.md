---
type: API Endpoint
title: DELETE /devices/printersDel/{PrinterID}/
description: Serves DELETE /devices/printersDel/{PrinterID}/ through SpringFinder.represent.
resource: /devices/printersDel/{PrinterID}/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printersDel/{PrinterID}/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printersDel/{PrinterID}/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
