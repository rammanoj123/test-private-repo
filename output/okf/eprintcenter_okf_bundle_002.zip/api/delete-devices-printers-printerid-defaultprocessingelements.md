---
type: API Endpoint
title: DELETE /devices/printers/{PrinterID}/defaultprocessingelements/
description: Serves DELETE /devices/printers/{PrinterID}/defaultprocessingelements/ through SpringFinder.represent.
resource: /devices/printers/{PrinterID}/defaultprocessingelements/
tags: [api, endpoint, delete]
status: draft
handler: SpringFinder
handler_method: represent
http_method: DELETE
http_path: /devices/printers/{PrinterID}/defaultprocessingelements/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | DELETE |
| Path | `/devices/printers/{PrinterID}/defaultprocessingelements/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
