---
type: API Endpoint
title: GET /devices/printers/{optinParameter}/optin/suppliesinfo/
description: Serves GET /devices/printers/{optinParameter}/optin/suppliesinfo/ through SpringFinder.represent.
resource: /devices/printers/{optinParameter}/optin/suppliesinfo/
tags: [api, endpoint, get]
status: draft
handler: SpringFinder
handler_method: represent
http_method: GET
http_path: /devices/printers/{optinParameter}/optin/suppliesinfo/
generated: { by: okf_generator/1.0, at: 2026-09-21T15:21:29Z }
---

| Attribute | Value |
| --- | --- |
| Method | GET |
| Path | `/devices/printers/{optinParameter}/optin/suppliesinfo/` |
| Handler | SpringFinder.represent |
| Returns |  |
| Auth | none detected |

# Parameters

_None._
