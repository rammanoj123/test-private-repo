# UC-004 — Get Job  ·  GET /job/{id}

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/job/{id}`  
> **Actor:** API Client  
> **Entry:** `JobController.getJobById()`  

HTTP endpoint GET /job/{id}. Entry: JobController.getJobById(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-004` |
| Name | **Get Job** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/{id}` |
| Actor | API Client |
| Entry Point | `JobController.getJobById()` |
| Return Type | `Job` |

## 2. Call Chain

`JobController` → `JobService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@PathVariable("id")` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.

1. Call `repo.findById(id)` to retrieve a Job by its ID.
2. If the Job is present, return it.
3. If not present, throw `EntityNotFoundException` with a descriptive message.

## 5. Business Rules

- Throws exception if job is not found.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant API_Client as API Client
    participant JobController as JobController
    participant JobService as JobService
    participant JobRepo as JobRepo

    API_Client->>JobController: GET /job/{id}
    JobController->>JobService: getJobById(id)
    JobService->>JobRepo: findById(id)
    alt Job found
        JobRepo-->>JobService: Job
        JobService-->>JobController: Job
        JobController->>API_Client: 200 OK — Job
    else Job not found
        JobRepo-->>JobService: null
        JobService-->>JobController: throw EntityNotFoundException
        JobController->>API_Client: 404 Not Found
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | repo.findById |
| Events Published | none |
| External Calls | none |
| Exception Types | EntityNotFoundException |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `Job` |

**Response fields** (`Job`):

| Field | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `title` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `company` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `location` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `description` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `salaryRange` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `requiredSkills` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `applications` | `List` | `@OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true)` `@JsonManagedReference` |
| `other` | `Job` | `@Override` |

**HTTP status codes:**

- 200 OK — success
- 404 Not Found — job does not exist

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- The job with the given ID must exist.

**Post-conditions:**

- Job is returned if found, otherwise 404 is sent.

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `GET /job/{id}`. Parse request, call service, return response. |
| ⚙️ `JobService` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |
| 🗄️ `JobRepo` | Repository | Data access for Job entities. |

### Domain Model Fields

**Job** (`entity`) — package `com.jobboard.dvo`

| Field | Type | Annotations | Required? |
|---|---|---|---|
| `id` 🔑 | `Long` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `title` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `company` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `location` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `description` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `salaryRange` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `requiredSkills` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `applications` | `List` | @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference | optional |
| `other` | `Job` | @Override | optional |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobService" class="<your.package>.JobService">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobRepo" class="<your.package>.JobRepo">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-004 — "Get Job"
Trigger : GET /job/{id}
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService → JobRepo

Entry: JobController.getJobById()

Input:
  Parameters : @PathVariable("id") Long id

Implementation steps (IN ORDER — implement each one):
   1. Call repo.findById(id) to retrieve a Job by its ID.
   2. If the Job is present, return it.
   3. If not present, throw EntityNotFoundException with a descriptive message.

Business rules (ENFORCE ALL):
  - Throws exception if job is not found.

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : EntityNotFoundException

Return type: Job
HTTP status: 200 OK — success, 404 Not Found — job does not exist

Side effects: none

Domain types:
  Job (entity):
    id: Long  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    title: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    company: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    location: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    description: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    salaryRange: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    requiredSkills: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    applications: List  @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference
    other: Job  @Override

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Write production-quality code.
```

---
