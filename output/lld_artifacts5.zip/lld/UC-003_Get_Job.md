# UC-003 — List Jobs  ·  GET /job

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/job`  
> **Actor:** API Client  
> **Entry:** `JobController.getAllJobs()`  

Retrieves all Job entities from the database.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-003` |
| Name | **List Jobs** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/job` |
| Actor | API Client |
| Entry Point | `JobController.getAllJobs()` |
| Return Type | `List<Job>` |

## 2. Call Chain

`JobController` → `JobService` → `JobRepo`

## 3. Input Contract

No request body. No parameters required.

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.

1. Call `repo.findAll()` to retrieve all Job entities from the database.
2. Return the list of Job entities.

## 5. Business Rules

(none)

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant API_Client as API Client
    participant JobController as JobController
    participant JobService as JobService
    participant JobRepo as JobRepo

    API_Client->>JobController: GET /job
    JobController->>JobService: getAllJobs()
    JobService->>JobRepo: findAll()
    JobRepo-->>JobService: List<Job>
    JobService-->>JobController: List<Job>
    JobController->>API_Client: 200 OK — List<Job>
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | repo.findAll |
| Events Published | none |
| External Calls | none |
| Exception Types | none |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `List<Job>` |

**HTTP status codes:**

- 200 OK — success

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `GET /job`. Parse request, call service, return response. |
| ⚙️ `JobService` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |
| 🗄️ `JobRepo` | Repository | Data access for Job entities. |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobService" class="<your.package>.JobService">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobRepo" class="<your.package>.JobRepo">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-003 — "List Jobs"
Trigger : GET /job
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService → JobRepo

Entry: JobController.getAllJobs()

Input:
  Parameters : none

Implementation steps (IN ORDER — implement each one):
   1. Call repo.findAll() to retrieve all Job entities from the database.
   2. Return the list of Job entities.

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: List<Job>
HTTP status: 200 OK — success

Side effects: none

Domain types:
  Job (entity)

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Write production-quality code.
```

---
