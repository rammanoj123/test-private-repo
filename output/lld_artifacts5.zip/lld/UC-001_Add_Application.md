# UC-001 — Add Application  ·  POST /application

> **Trigger:** 🌐 **HTTP** — 🟢 POST `/application`  
> **Actor:** API Client  
> **Entry:** `ApplicationController.addApplication()`  

HTTP endpoint POST /application. Entry: ApplicationController.addApplication(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-001` |
| Name | **Add Application** |
| Trigger | 🌐 **HTTP** — 🟢 POST `/application` |
| Actor | API Client |
| Entry Point | `ApplicationController.addApplication()` |
| Return Type | `Application` |

## 2. Call Chain

`ApplicationController` → `ApplicationService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `application` | `Application` | `@RequestBody` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.

1. Validate referenced job exists using `jobRepo.findById`.
2. If job exists, check for duplicate application (`fullName`, `email`, `jobId`) using `repo.findByfullNameAndEmailAndJobId`.
3. If duplicate exists, throw `ApplicationAlreadyExistsException`.
4. If not, save application using `repo.save` and return.
5. If job does not exist, throw `EntityNotFoundException`.

## 5. Business Rules

- A user cannot apply to the same job more than once (unique by fullName, email, and job ID).
- Cannot add application if the referenced job does not exist.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant API_Client as API Client
    participant ApplicationController as ApplicationController
    participant ApplicationService as ApplicationService
    participant JobRepo as JobRepo
    participant ApplicationRepo as ApplicationRepo

    API_Client->>ApplicationController: POST /application
    ApplicationController->>ApplicationService: addApplication(application)
    ApplicationService->>JobRepo: findById(jobId)
    alt Job exists
        ApplicationService->>ApplicationRepo: findByfullNameAndEmailAndJobId(fullName, email, jobId)
        alt Duplicate exists
            ApplicationService-->>ApplicationController: throw ApplicationAlreadyExistsException
        else Not duplicate
            ApplicationService->>ApplicationRepo: save(application)
            ApplicationRepo-->>ApplicationService: Application
            ApplicationService-->>ApplicationController: Application
        end
    else Job not found
        ApplicationService-->>ApplicationController: throw EntityNotFoundException
    end
    ApplicationController->>API_Client: 201 Created / 409 Conflict / 404 Not Found
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | jobRepo.findById, repo.findByfullNameAndEmailAndJobId, repo.save |
| Events Published | none |
| External Calls | none |
| Exception Types | ApplicationAlreadyExistsException, EntityNotFoundException |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `Application` |

**Response fields** (`Application`):

| Field | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `fullName` | `String` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `email` | `String` | `@Id` `@GeneratedValue(strategy = GenerationType.IDENTITY)` |
| `job` | `Job` | `@ManyToOne` `@JoinColumn(name="job_id",nullable=false)` `@JsonBackReference` |

**HTTP status codes:**

- 201 Created — success
- 409 Conflict — duplicate application
- 404 Not Found — job does not exist

## 9. Side Effects

| Effect | Detail |
|---|---|
| Application persisted | On success |

**Pre-conditions:**

- The referenced job must exist.

**Post-conditions:**

- Application is added if no duplicate exists and job is valid.

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `ApplicationController` | Controller | Handle `POST /application`. Parse request, call service, return response. |
| ⚙️ `ApplicationService` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |

### Domain Model Fields

**Application** (`entity`) — package `com.jobboard.dvo`

| Field | Type | Annotations | Required? |
|---|---|---|---|
| `id` 🔑 | `Long` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `fullName` 🔑 | `String` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `email` 🔑 | `String` | @Id @GeneratedValue(strategy = GenerationType.IDENTITY) | optional |
| `job` | `Job` | @ManyToOne @JoinColumn(name="job_id",nullable=false) @JsonBackReference |  *(required)* |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="applicationController" class="<your.package>.ApplicationController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

<bean id="applicationService" class="<your.package>.ApplicationService">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-001 — "Add Application"
Trigger : POST /application
Actor   : API Client

Call chain (implement ALL classes):
  ApplicationController → ApplicationService

Entry: ApplicationController.addApplication()

Input:
  Parameters : @RequestBody Application application

Implementation steps (IN ORDER — implement each one):
   1. Validate referenced job exists using jobRepo.findById.
   2. If job exists, check for duplicate application (fullName, email, jobId) using repo.findByfullNameAndEmailAndJobId.
   3. If duplicate exists, throw ApplicationAlreadyExistsException.
   4. If not, save application using repo.save and return.
   5. If job does not exist, throw EntityNotFoundException.

Business rules (ENFORCE ALL):
  - A user cannot apply to the same job more than once (unique by fullName, email, and job ID).
  - Cannot add application if the referenced job does not exist.

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : ApplicationAlreadyExistsException, EntityNotFoundException

Return type: Application
HTTP status: 201 Created, 409 Conflict, 404 Not Found

Side effects: Application persisted

Domain types:
  Application (entity):
    id: Long  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    fullName: String  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    email: String  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    job: Job  @ManyToOne @JoinColumn(name="job_id",nullable=false) @JsonBackReference

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Write production-quality code.
```

---
