# UC-002 — List Applications  ·  GET /application

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/application`  
> **Actor:** API Client  
> **Entry:** `ApplicationController.getAllApplications()`  

Retrieves all Application entities from the database.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-002` |
| Name | **List Applications** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/application` |
| Actor | API Client |
| Entry Point | `ApplicationController.getAllApplications()` |
| Return Type | `List<Application>` |

## 2. Call Chain

`ApplicationController` → `ApplicationService` → `ApplicationRepo`

## 3. Input Contract

No request body. No parameters required.

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.

1. Call `repo.findAll()` to retrieve all Application entities from the database.
2. Return the list of Application entities.

## 5. Business Rules

(none)

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant API_Client as API Client
    participant ApplicationController as ApplicationController
    participant ApplicationService as ApplicationService
    participant ApplicationRepo as ApplicationRepo

    API_Client->>ApplicationController: GET /application
    ApplicationController->>ApplicationService: getAllApplications()
    ApplicationService->>ApplicationRepo: findAll()
    ApplicationRepo-->>ApplicationService: List<Application>
    ApplicationService-->>ApplicationController: List<Application>
    ApplicationController->>API_Client: 200 OK — List<Application>
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | repo.findAll |
| Events Published | none |
| External Calls | none |
| Exception Types | none |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `List<Application>` |

**HTTP status codes:**

- 200 OK — success

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `ApplicationController` | Controller | Handle `GET /application`. Parse request, call service, return response. |
| ⚙️ `ApplicationService` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |
| 🗄️ `ApplicationRepo` | Repository | Data access for Application entities. |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="applicationController" class="<your.package>.ApplicationController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="applicationService" class="<your.package>.ApplicationService">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="applicationRepo" class="<your.package>.ApplicationRepo">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-002 — "List Applications"
Trigger : GET /application
Actor   : API Client

Call chain (implement ALL classes):
  ApplicationController → ApplicationService → ApplicationRepo

Entry: ApplicationController.getAllApplications()

Input:
  Parameters : none

Implementation steps (IN ORDER — implement each one):
   1. Call repo.findAll() to retrieve all Application entities from the database.
   2. Return the list of Application entities.

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: List<Application>
HTTP status: 200 OK — success

Side effects: none

Domain types:
  Application (entity)

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Write production-quality code.
```

---
