# UC-005 — Get Job By Search  ·  GET /job/search

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/job/search`  
> **Actor:** API Client  
> **Entry:** `JobController.getJobsBySearch()`  

HTTP endpoint GET /job/search. Entry: JobController.getJobsBySearch(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-005` |
| Name | **Get Job By Search** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/search` |
| Actor | API Client |
| Entry Point | `JobController.getJobsBySearch()` |
| Return Type | `List<Job>` |

## 2. Call Chain

`JobController` → `JobService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `search` | `String` | `@RequestParam("search")` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.

1. Call `repo.findByTitle(search)` to retrieve jobs matching the given title.
2. Print the resulting jobs to standard output.
3. If jobs is not null, return the list.
4. If jobs is null, throw `EntityNotFoundException` with a descriptive message.

## 5. Business Rules

- Throws exception if no jobs found for the title.

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber
    participant API_Client as API Client
    participant JobController as JobController
    participant JobService as JobService
    participant JobRepo as JobRepo

    API_Client->>JobController: GET /job/search?search=title
    JobController->>JobService: getJobsBySearch(search)
    JobService->>JobRepo: findByTitle(search)
    JobRepo-->>JobService: List<Job> or null
    JobService->>JobService: System.out.println(jobs)
    alt Jobs found
        JobService-->>JobController: List<Job>
        JobController->>API_Client: 200 OK — List<Job>
    else Not found
        JobService-->>JobController: throw EntityNotFoundException
        JobController->>API_Client: 404 Not Found
    end
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | repo.findByTitle |
| Events Published | none |
| External Calls | System.out.println |
| Exception Types | EntityNotFoundException |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `List<Job>` |

**HTTP status codes:**

- 200 OK — success
- 404 Not Found — no jobs found for the title

## 9. Side Effects

| Effect | Detail |
|---|---|
| Console output | Jobs printed to standard output |

**Pre-conditions:**

- The search parameter must be provided.

**Post-conditions:**

- List of jobs is returned if found, otherwise 404 is sent.

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `GET /job/search`. Parse request, call service, return response. |
| ⚙️ `JobService` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |
| 🗄️ `JobRepo` | Repository | Data access for Job entities. |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobService" class="<your.package>.JobService">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
<bean id="jobRepo" class="<your.package>.JobRepo">
    <!-- inject dependencies via constructor-arg or property -->
</bean>
```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-005 — "Get Job By Search"
Trigger : GET /job/search
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService → JobRepo

Entry: JobController.getJobsBySearch()

Input:
  Parameters : @RequestParam("search") String search

Implementation steps (IN ORDER — implement each one):
   1. Call repo.findByTitle(search) to retrieve jobs matching the given title.
   2. Print the resulting jobs to standard output.
   3. If jobs is not null, return the list.
   4. If jobs is null, throw EntityNotFoundException with a descriptive message.

Business rules (ENFORCE ALL):
  - Throws exception if no jobs found for the title.

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : EntityNotFoundException

Return type: List<Job>
HTTP status: 200 OK — success, 404 Not Found — no jobs found for the title

Side effects: Console output

Domain types:
  Job (entity)

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Write production-quality code.
```

---
